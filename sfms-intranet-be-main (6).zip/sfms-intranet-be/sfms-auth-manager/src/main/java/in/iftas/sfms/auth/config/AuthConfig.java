package in.iftas.sfms.auth.config;/*
 * Copyright (C) 2024 Iftas Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Iftas Inc. ("Confidential Information"). You shall not disclose
 * such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with Iftas Inc.
 *
 * Author: Manoj.Illa
 * Date: July 11, 2024
 */

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.client.WebClient;


@Configuration
public class AuthConfig {
    private static final Logger logger = LoggerFactory.getLogger(AuthConfig.class);


    @Bean
    public WebClient webClient(WebClient.Builder builder) {
        logger.info("Creating WebClient bean");

        logger.debug("WebClient bean created successfully");
        return builder.build();
    }

}
