package in.iftas.sfms.auth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AuthManagerApplication {
    public static void main(String[] args) {
        SpringApplication.run(AuthManagerApplication.class, args);
    }
}