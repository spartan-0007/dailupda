package in.iftas.sfms.auth.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.config.ResourceHandlerRegistry;
import org.springframework.web.reactive.config.WebFluxConfigurer;


@Configuration
public class WebFluxConfig implements WebFluxConfigurer {
    private static final Logger logger = LoggerFactory.getLogger(WebFluxConfig.class);
    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        logger.info("Configuring resource handlers");
        registry.addResourceHandler("/static/**")
                .addResourceLocations("classpath:/static/");
        logger.debug("Resource handler for '/static/**' configured with location 'classpath:/static/'");
    }
}
