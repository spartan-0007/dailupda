package in.iftas.sfms.auth.converter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationConverter;
import org.springframework.stereotype.Component;

@Component
public class CustomJwtAuthenticationConverter extends JwtAuthenticationConverter {
    private static final Logger logger = LoggerFactory.getLogger(CustomJwtAuthenticationConverter.class);

    public CustomJwtAuthenticationConverter(KeycloakRoleConverter keycloakRoleConverter) {
        logger.info("Initializing CustomJwtAuthenticationConverter");

        setJwtGrantedAuthoritiesConverter(keycloakRoleConverter::convert);
        logger.debug("Custom KeycloakRoleConverter set successfully");

    }
}