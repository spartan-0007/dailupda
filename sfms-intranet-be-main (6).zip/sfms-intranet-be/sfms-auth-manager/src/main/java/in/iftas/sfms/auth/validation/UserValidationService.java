package in.iftas.sfms.auth.validation;

import in.iftas.sfms.auth.entity.UserQuotaEntity;
import in.iftas.sfms.auth.exceptions.MaxUserCountExceededException;
import in.iftas.sfms.auth.model.UserCreateRequest;
import in.iftas.sfms.auth.model.UserResponse;
import in.iftas.sfms.auth.repository.UserQuotaRepository;
import in.iftas.sfms.auth.service.AuthService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Lazy;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@Component
public class UserValidationService {
    private static final Logger logger = LoggerFactory.getLogger(UserValidationService.class);

    private final UserQuotaRepository userQuotaRepository;
    private final AuthService authService;

    public UserValidationService(UserQuotaRepository userQuotaRepository,
                                 @Lazy AuthService authService) {
        this.userQuotaRepository = userQuotaRepository;
        this.authService = authService;
    }

    public void validateUserCreation(UserCreateRequest userCreateRequest, String authorization) {
        if (userCreateRequest.getEmail() != null && !userCreateRequest.getEmail().isEmpty()) {
            validateEmailFormat(userCreateRequest.getEmail());
            checkEmailExists(userCreateRequest.getEmail(), authorization);
        }
        if (userCreateRequest.getUsername() != null && !userCreateRequest.getUsername().isEmpty()) {
            checkUsernameExists(userCreateRequest.getUsername(), authorization);
        }
        validateBankQuota(userCreateRequest);
    }

    private void validateEmailFormat(String email) {
        if (!email.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$")) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid email format");
        }
    }

    private void checkEmailExists(String email, String authorization) {
        try {
            List<UserResponse> users = authService.getUsersByEmail(authorization, email);
            if (!users.isEmpty()) {
                throw new ResponseStatusException(HttpStatus.CONFLICT,
                        "User with email " + email + " already exists");
            }
        } catch (Exception e) {
            logger.debug("Exception during email check: {}", e.getMessage(), e);
            String errorMessage = e.getMessage();
            if (errorMessage != null &&
                    (errorMessage.contains("UserNotFoundException") ||
                            errorMessage.contains("User not found") ||
                            errorMessage.contains("404") ||
                            errorMessage.contains("No users found"))) {
                logger.info("Email {} not found, which means it's unique. Proceeding with validation.", email);
                return;
            }
            if (e instanceof ResponseStatusException &&
                    ((ResponseStatusException) e).getStatusCode().equals(HttpStatus.NOT_FOUND)) {
                logger.info("Email {} not found (404 status), which means it's unique. Proceeding with validation.", email);
                return;
            }

            if (errorMessage != null && errorMessage.contains("already exists")) {
                throw new ResponseStatusException(HttpStatus.CONFLICT,
                        "User with email " + email + " already exists");
            }

            logger.error("Unexpected error checking email existence: {}", e.getMessage(), e);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                    "Error while validating email");
        }
    }

    private void checkUsernameExists(String username, String authorization) {
        try {
            List<UserResponse> users = authService.getUsersByUsername(authorization, username);
            if (!users.isEmpty()) {
                throw new ResponseStatusException(HttpStatus.CONFLICT,
                        "Username " + username + " already exists");
            }
        } catch (Exception e) {
            logger.debug("Exception during username check: {}", e.getMessage(), e);
            String errorMessage = e.getMessage();
            if (errorMessage != null &&
                    (errorMessage.contains("UserNotFoundException") ||
                            errorMessage.contains("User not found") ||
                            errorMessage.contains("404") ||
                            errorMessage.contains("No users found"))) {
                logger.info("Username {} not found, which means it's unique. Proceeding with validation.", username);
                return;
            }
            if (e instanceof ResponseStatusException &&
                    ((ResponseStatusException) e).getStatusCode().equals(HttpStatus.NOT_FOUND)) {
                logger.info("Username {} not found (404 status), which means it's unique. Proceeding with validation.", username);
                return;
            }

            if (errorMessage != null && errorMessage.contains("already exists")) {
                throw new ResponseStatusException(HttpStatus.CONFLICT,
                        "Username " + username + " already exists");
            }

            logger.error("Unexpected error checking username existence: {}", e.getMessage(), e);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                    "Error while validating username");
        }
    }

    private void validateBankQuota(UserCreateRequest userCreateRequest) {
        Integer bankId = userCreateRequest.getAttributes().getBankId();
        logger.info("Bank Id is {}", bankId);

        if (bankId != null) {
            logger.info("Checking UserQuota for bankId: {}", bankId);
            UserQuotaEntity userQuota = userQuotaRepository.findByBankId(bankId);

            if (userQuota != null) {
                logger.info("UserQuotaEntity found: {}", userQuota);
                if (userQuota.getUserCount() >= userQuota.getMaxUserCount()) {
                    logger.info("Max user count exceeded for bankId: {}. Current userCount: {}, Max userCount: {}",
                            bankId, userQuota.getUserCount(), userQuota.getMaxUserCount());
                    throw new MaxUserCountExceededException("Max User Creation count Exceeded. Please contact support team.");
                }
            } else {
                logger.info("No UserQuotaEntity found for bankId: {}. Creating a new record.", bankId);
                UserQuotaEntity newQuota = UserQuotaEntity.builder()
                        .bankId(bankId)
                        .userCount(0)
                        .maxUserCount(5)
                        .build();

                userQuotaRepository.save(newQuota);
                logger.info("New UserQuotaEntity created: {}", newQuota);
            }
        } else {
            logger.info("BankId is null, skipping userCount check.");
        }
    }

    public void incrementUserCount(UserCreateRequest userCreateRequest) {
        Integer bankId = userCreateRequest.getAttributes().getBankId();
        if (bankId != null) {
            UserQuotaEntity userQuota = userQuotaRepository.findByBankId(bankId);
            if (userQuota != null) {
                userQuota.setUserCount(userQuota.getUserCount() + 1);
                userQuotaRepository.save(userQuota);
                logger.info("Incremented userCount. New userCount: {}", userQuota.getUserCount());
            }
        }
    }
}