package in.iftas.sfms.auth.filter;


import in.iftas.sfms.auth.exceptions.PasswordResetException;
import in.iftas.sfms.auth.exceptions.PasswordResetRequiredException;
import in.iftas.sfms.auth.exceptions.UserNotFoundException;
import in.iftas.sfms.auth.model.TokenResponse;
import in.iftas.sfms.auth.service.AuthService;
import in.iftas.sfms.auth.service.KeycloakTokenService;
import in.iftas.sfms.auth.utils.SecurityUtils;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.Objects;

import static org.springframework.web.context.request.RequestAttributes.SCOPE_REQUEST;

@Component
public class TokenFilter extends OncePerRequestFilter {
    private static final Logger logger = LoggerFactory.getLogger(TokenFilter.class);

    private final AuthService authService;

    private final SecurityUtils securityUtils;

    private final KeycloakTokenService keycloakTokenService;

    public TokenFilter(AuthService authService, SecurityUtils securityUtils, KeycloakTokenService keycloakTokenService) {
        this.authService = authService;
        this.securityUtils = securityUtils;
        this.keycloakTokenService = keycloakTokenService;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest httpRequest,
                                    HttpServletResponse httpResponse,
                                    FilterChain filterChain) throws ServletException, IOException {

        String requestURI = httpRequest.getRequestURI();
        logger.info("TokenFilter: Processing request for URI: {} ", requestURI);


        if (isBypassEndpoint(requestURI)) {
            logger.debug("Bypassing filter for URI: {}", requestURI);
            filterChain.doFilter(httpRequest, httpResponse);
            return;
        }


        if ("/auth/login".equals(requestURI)) {
            logger.debug("Handling login for URI: {}", requestURI);
            handleLogin(httpRequest, httpResponse, filterChain);
            return;
        }


        String accessToken = null;
        String refreshToken = null;

        Cookie[] cookies = httpRequest.getCookies();

        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if ("access_token".equals(cookie.getName())) {
                    accessToken = cookie.getValue();
                } else if ("refresh_token".equals(cookie.getName())) {
                    refreshToken = cookie.getValue();
                }
            }
        }
        logger.debug("Extracted access token: {}", accessToken != null ? "Present" : "Not present");
        logger.debug("Extracted refresh token: {}", refreshToken != null ? "Present" : "Not present");

        if (accessToken == null) {
            logger.warn("Missing access token. Sending unauthorized response.");

            String authHeader = httpRequest.getHeader("Authorization");
            if (authHeader != null && authHeader.startsWith("Bearer ")) {

                accessToken = authHeader.substring(7);
            }
        }
        logger.info("Access token expired. Checking refresh token.");

        if (refreshToken == null) {
            logger.warn("Access token expired and no valid refresh token. Sending unauthorized response.");
            refreshToken = httpRequest.getHeader("X-refresh-token");
        }

        logger.info("Extracted access token: [REDACTED]");
        logger.info("Extracted refresh token: [REDACTED]");

        if (accessToken == null) {
            sendErrorResponse(httpResponse, HttpServletResponse.SC_UNAUTHORIZED, "Missing access token. Please authenticate.");
            return;
        }

        if (authService.isTokenExpired(accessToken)) {
            if (refreshToken == null || !(authService.isRefreshTokenExpired(refreshToken))) {
                authService.logoutUserUsingToken(accessToken);
                sendErrorResponse(httpResponse, HttpServletResponse.SC_UNAUTHORIZED, "Access token expired and no valid refresh token. Login again.");
                return;
            }
            logger.info("Refreshing access token using refresh token.");
            TokenResponse tokenResponse = authService.refreshAccessToken(refreshToken);
            addTokenCookies(httpResponse, tokenResponse);
        }

        logger.debug("Tokens validated. Proceeding with filter chain.");

        filterChain.doFilter(httpRequest, httpResponse);
    }

    private boolean isBypassEndpoint(String requestURI) {
        return "/auth/forget-password".equals(requestURI) ||
                "/auth/validate-otp".equals(requestURI) ||
                "/auth/resend-otp".equals(requestURI) ||
                "/auth/change-password/change".equals(requestURI) ||
                "/auth/reset-password".equals(requestURI) ||
                "/auth/refresh-token".equals(requestURI);
    }

    private void handleLogin(HttpServletRequest httpRequest, HttpServletResponse httpResponse, FilterChain filterChain) throws IOException, ServletException {
        String username = httpRequest.getParameter("username");
        String password = httpRequest.getParameter("password");
        logger.info("Handling login for user: {}", username);
        try {
            password = securityUtils.decrypt(password);
        } catch (GeneralSecurityException e) {
            logger.error("Security exception during decryption: {}", e.getMessage());
            sendErrorResponse(httpResponse, HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Decryption failed due to security issue.");
            return;
        } catch (Exception e) {
            logger.error("Unexpected error during decryption: {}", e.getMessage(), e);
            sendErrorResponse(httpResponse, HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "An unexpected error occurred.");
        }

        if (username.isEmpty() || password.isEmpty()) {
            logger.warn("Username or password is empty. Sending bad request response.");

            sendErrorResponse(httpResponse, HttpServletResponse.SC_BAD_REQUEST, "Username and password are required.");

            throw new UserNotFoundException("Username and password are required.");
        }

        try {
            TokenResponse tokenResponse = keycloakTokenService.authenticateUser(username, password);
            logger.info("User authenticated successfully. Adding token cookies.");

            addTokenCookies(httpResponse, tokenResponse);

            ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
            Objects.requireNonNull(attributes).setAttribute("tokenResponse", tokenResponse, SCOPE_REQUEST);
            logger.debug("Proceeding with filter chain after successful authentication.");

            filterChain.doFilter(httpRequest, httpResponse);
        } catch (UserNotFoundException e) {
            logger.error("User not found: {}", username);
            sendErrorResponse(httpResponse, HttpServletResponse.SC_UNAUTHORIZED, "User not found.");
        } catch (PasswordResetRequiredException e) {
            logger.error("Password should be reset for : {}", username);
            sendErrorResponse(httpResponse, HttpServletResponse.SC_BAD_REQUEST, e.getMessage());
        } catch (Exception e) {
            logger.error("Internal Server Error");
            sendErrorResponse(httpResponse, HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Internal Server Exception");
        }
    }

    private void sendErrorResponse(HttpServletResponse response, int status, String message) throws IOException {
        response.setStatus(status);
        response.setContentType("application/json");
        response.getWriter().write("{\"error\": \"" + message + "\"}");
    }

    private void addTokenCookies(HttpServletResponse response, TokenResponse tokenResponse) {
        addCookie(response, "access_token", tokenResponse.getAccessToken(), 3600);
        addCookie(response, "refresh_token", tokenResponse.getRefreshToken(), 3600);
    }

    private void addCookie(HttpServletResponse response, String name, String value, int maxAge) {
        Cookie cookie = new Cookie(name, value);
        cookie.setHttpOnly(true);
        cookie.setSecure(false);
        cookie.setPath("/");
        cookie.setMaxAge(maxAge);


        String cookieHeader = String.format("%s=%s; Max-Age=%d; Path=%s; HttpOnly; SameSite=None",
                cookie.getName(), cookie.getValue(), cookie.getMaxAge(), cookie.getPath());
        if (cookie.getSecure()) {
            cookieHeader += "; Secure";
        }

        response.addHeader("Set-Cookie", cookieHeader);
    }

    @Override
    public void destroy() {

    }
}
