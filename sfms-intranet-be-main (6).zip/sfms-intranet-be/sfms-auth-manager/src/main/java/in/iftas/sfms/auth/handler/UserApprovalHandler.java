// In sfms-intranet-core/src/main/java/in/iftas/sfms/core/handler/UserApprovalHandler.java
package in.iftas.sfms.auth.handler;

import com.fasterxml.jackson.databind.ObjectMapper;
import in.iftas.sfms.auth.model.UserCreateRequest;
import in.iftas.sfms.auth.model.UserUpdateRequest;
import in.iftas.sfms.auth.service.KeycloakTokenService;
import in.iftas.sfms.common.handler.ApprovalHandler;
import in.iftas.sfms.auth.service.AuthService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class UserApprovalHandler implements ApprovalHandler {

    private final AuthService authService;
    private final ObjectMapper objectMapper;
    private final KeycloakTokenService keycloakTokenService;

    @Autowired
    public UserApprovalHandler(AuthService authService, ObjectMapper objectMapper, KeycloakTokenService keycloakTokenService) {
        this.authService = authService;
        this.objectMapper = objectMapper;
        this.keycloakTokenService = keycloakTokenService;
    }

    @Override
    public String getEntityType() {
        return "USER";
    }

    @Override
    public void handleApproval(Long approvalId, String actionType, String requestData, Long entityId) {
        log.info("Processing user approval - ID: {}, Action: {}", approvalId, actionType);

        try {
            String adminToken = keycloakTokenService.getAdminToken();

            switch (actionType.toUpperCase()) {
                case "CREATE":
                    UserCreateRequest userCreateRequest = objectMapper.readValue(requestData, UserCreateRequest.class);
                    authService.createUser(adminToken, userCreateRequest);
                    log.info("User created successfully: {}", userCreateRequest.getUsername());
                    break;

                case "UPDATE":
                    UserUpdateRequest userUpdateRequest = objectMapper.readValue(requestData, UserUpdateRequest.class);
                    authService.updateUserByAdmin(userUpdateRequest);
                    log.info("User updated successfully: {}", entityId);
                    break;

                case "DELETE":
                    authService.deleteUser(entityId.toString(), adminToken);
                    log.info("User deleted successfully: {}", entityId);
                    break;

                default:
                    throw new UnsupportedOperationException("Unsupported action type: " + actionType);
            }
        } catch (Exception e) {
            log.error("Error handling user approval: {}", e.getMessage(), e);
            throw new RuntimeException("Failed to process user approval", e);
        }
    }
    @Override
    public void handleRejection(Long approvalId, String rejectionReason, String entityType) {
        log.info("User approval {} rejected with reason: {}", approvalId, rejectionReason);
        // Additional rejection handling logic can be added here if needed
    }
}