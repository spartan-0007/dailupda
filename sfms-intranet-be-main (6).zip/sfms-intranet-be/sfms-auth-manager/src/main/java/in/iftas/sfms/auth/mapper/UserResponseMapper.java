package in.iftas.sfms.auth.mapper;

import in.iftas.sfms.auth.model.Attributes;
import in.iftas.sfms.auth.model.UserResponse;
import in.iftas.sfms.auth.model.UserResponseAccess;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import java.util.List;
import java.util.Map;

@Mapper(componentModel = "spring")
public interface UserResponseMapper {

    UserResponseMapper INSTANCE = Mappers.getMapper(UserResponseMapper.class);

    default UserResponse mapToUserResponse(Map<String, Object> map) {
        if (map == null) {
            return null;
        }

        UserResponse userResponse = new UserResponse();
        userResponse.setId((String) map.get("id"));
        userResponse.setCreatedTimestamp((Long) map.get("createdTimestamp"));
        userResponse.setUsername((String) map.get("username"));
        userResponse.setEnabled((Boolean) map.get("enabled"));
        userResponse.setTotp((Boolean) map.get("totp"));
        userResponse.setEmailVerified((Boolean) map.get("emailVerified"));
        userResponse.setFirstName((String) map.get("firstName"));
        userResponse.setLastName((String) map.get("lastName"));
        userResponse.setEmail((String) map.get("email"));
        userResponse.setRequiredActions((List<String>) map.get("requiredActions"));
        userResponse.setNotBefore((Integer) map.get("notBefore"));

        // Handle nested attributes
        Map<String, Object> attributesMap = (Map<String, Object>) map.get("attributes");
        userResponse.setAttributes(mapAttributes(attributesMap));

        // Handle nested access
        Map<String, Object> accessMap = (Map<String, Object>) map.get("access");
        userResponse.setAccess(mapAccess(accessMap));

        return userResponse;
    }

    default Attributes mapAttributes(Map<String, Object> attributesMap) {
        if (attributesMap != null) {
            Attributes attrs = new Attributes();

            List<String> bankIdList = (List<String>) attributesMap.get("bankId");
            attrs.setBankId(bankIdList != null && !bankIdList.isEmpty() ? Integer.parseInt(bankIdList.get(0)) : null);

            List<String> userTypes = (List<String>) attributesMap.get("userType");
            attrs.setUserType(userTypes != null && !userTypes.isEmpty() ? userTypes.get(0) : null);
            return attrs;
        }
        return null;
    }

    default UserResponseAccess mapAccess(Map<String, Object> accessMap) {
        if (accessMap != null) {
            UserResponseAccess access = new UserResponseAccess();
            access.setManageGroupMembership((Boolean) accessMap.get("manageGroupMembership"));
            access.setView((Boolean) accessMap.get("view"));
            access.setMapRoles((Boolean) accessMap.get("mapRoles"));
            access.setImpersonate((Boolean) accessMap.get("impersonate"));
            access.setManage((Boolean) accessMap.get("manage"));
            return access;
        }
        return null;
    }
}