package in.iftas.sfms.reports.scheduler.repository;

import in.iftas.sfms.reports.scheduler.model.JobSchedule;
import org.springframework.data.jpa.repository.JpaRepository;

public interface JobScheduleRepository extends JpaRepository<JobSchedule, Long> {

    JobSchedule findByJobName(String jobName);
}