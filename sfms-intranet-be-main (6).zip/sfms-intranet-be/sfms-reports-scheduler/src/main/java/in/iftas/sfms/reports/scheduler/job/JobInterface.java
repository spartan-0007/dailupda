package in.iftas.sfms.reports.scheduler.job;

public interface JobInterface {
    void execute();
}