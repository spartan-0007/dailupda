package in.iftas.sfms.notification.service;

import com.fasterxml.jackson.core.JsonProcessingException;

public interface EmailService {
    boolean sendEmail(String emailContent) throws JsonProcessingException;
}
