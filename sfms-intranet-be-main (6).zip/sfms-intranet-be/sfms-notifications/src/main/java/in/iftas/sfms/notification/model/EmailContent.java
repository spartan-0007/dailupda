package in.iftas.sfms.notification.model;

import java.net.URI;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import org.openapitools.jackson.nullable.JsonNullable;
import java.time.OffsetDateTime;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


import java.util.*;
import jakarta.annotation.Generated;

/**
 * EmailContent
 */


public class EmailContent {

  private String toEmail;

  private String otp;

  private String template;

  // Add a no-args constructor
  public EmailContent() {

  }

  /**
   * Constructor with only required parameters
   */
  public EmailContent(String toEmail, String otp, String template) {
    this.toEmail = toEmail;
    this.otp = otp;
    this.template = template;
  }

  public EmailContent toEmail(String toEmail) {
    this.toEmail = toEmail;
    return this;
  }

  /**
   * The email address to send the OTP to
   * @return toEmail
   */
  @NotNull 
  @Schema(name = "toEmail", description = "The email address to send the OTP to", requiredMode = Schema.RequiredMode.REQUIRED)
  @JsonProperty("toEmail")
  public String getToEmail() {
    return toEmail;
  }

  public void setToEmail(String toEmail) {
    this.toEmail = toEmail;
  }

  public EmailContent otp(String otp) {
    this.otp = otp;
    return this;
  }

  /**
   * The OTP to be sent
   * @return otp
   */
  @NotNull 
  @Schema(name = "otp", description = "The OTP to be sent", requiredMode = Schema.RequiredMode.REQUIRED)
  @JsonProperty("otp")
  public String getOtp() {
    return otp;
  }

  public void setOtp(String otp) {
    this.otp = otp;
  }

  public EmailContent template(String template) {
    this.template = template;
    return this;
  }

  /**
   * The template to use for the email
   * @return template
   */
  @NotNull 
  @Schema(name = "template", description = "The template to use for the email", requiredMode = Schema.RequiredMode.REQUIRED)
  @JsonProperty("template")
  public String getTemplate() {
    return template;
  }

  public void setTemplate(String template) {
    this.template = template;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    EmailContent emailContent = (EmailContent) o;
    return Objects.equals(this.toEmail, emailContent.toEmail) &&
        Objects.equals(this.otp, emailContent.otp) &&
        Objects.equals(this.template, emailContent.template);
  }

  @Override
  public int hashCode() {
    return Objects.hash(toEmail, otp, template);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class EmailContent {\n");
    sb.append("    toEmail: ").append(toIndentedString(toEmail)).append("\n");
    sb.append("    otp: ").append(toIndentedString(otp)).append("\n");
    sb.append("    template: ").append(toIndentedString(template)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

