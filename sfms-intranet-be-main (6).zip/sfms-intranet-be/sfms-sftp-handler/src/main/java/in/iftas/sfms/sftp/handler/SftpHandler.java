package in.iftas.sfms.sftp.handler;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SftpHandler {
    public static void main(String[] args) {
        SpringApplication.run(SftpHandler.class, args);
    }
}