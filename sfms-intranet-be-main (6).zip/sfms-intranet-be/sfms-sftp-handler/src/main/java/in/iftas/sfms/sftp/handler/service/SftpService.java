package in.iftas.sfms.sftp.handler.service;

import java.io.InputStream;
import java.io.OutputStream;

public interface SftpService {
    void uploadFile(String remotePath, InputStream inputStream) throws Exception;
    void downloadFile(String remotePath, OutputStream outputStream) throws Exception;
    void deleteFile(String remotePath) throws Exception;
    boolean fileExists(String remotePath) throws Exception;
    void createDirectory(String remotePath) throws Exception;
    void removeDirectory(String remotePath) throws Exception;
}