// In sfms-common/src/main/java/in/iftas/sfms/common/service/ApprovalHandlerRegistry.java
package in.iftas.sfms.common.registry;

import in.iftas.sfms.common.handler.ApprovalHandler;
import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
@Slf4j
public class ApprovalHandlerRegistry {
    
    @Autowired
    private List<ApprovalHandler> handlers;
    
    private final Map<String, ApprovalHandler> handlerMap = new HashMap<>();
    
    @PostConstruct
    public void initializeHandlers() {
        for (ApprovalHandler handler : handlers) {
            String entityType = handler.getEntityType().toUpperCase();
            handlerMap.put(entityType, handler);
            log.info("Registered approval handler for entity type: {}", entityType);
        }
        log.info("Total registered handlers: {}", handlerMap.size());
    }
    
    public ApprovalHandler getHandler(String entityType) {
        ApprovalHandler handler = handlerMap.get(entityType.toUpperCase());
        if (handler == null) {
            log.warn("No handler found for entity type: {}", entityType);
        }
        return handler;
    }
    
    public boolean hasHandler(String entityType) {
        return handlerMap.containsKey(entityType.toUpperCase());
    }
}