package in.iftas.sfms.common.handler;

public interface ApprovalHandler {
    
    /**
     * Returns the entity type this handler is responsible for
     * @return entity type (e.g., "BANK", "USER")
     */
    String getEntityType();
    
    /**
     * Process approval for the entity
     * @param approvalId the approval request ID
     * @param actionType the action type (CREATE, UPDATE, DELETE)
     * @param requestData the JSON data of the entity
     * @param entityId the entity ID (if applicable for UPDATE/DELETE)
     */
    void handleApproval(Long approvalId, String actionType, String requestData, Long entityId);
    
    /**
     * Process rejection for the entity (optional cleanup)
     * @param approvalId the approval request ID
     * @param rejectionReason the reason for rejection
     * @param entityType the type of entity
     */
    void handleRejection(Long approvalId, String rejectionReason, String entityType);
}