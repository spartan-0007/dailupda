package in.iftas.sfms.common.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "i_approval_requests", indexes = {
        @Index(name = "idx_status_entity", columnList = "status, entity_type"),
        @Index(name = "idx_maker", columnList = "created_by"),
        @Index(name = "idx_created_date", columnList = "created_date")
})
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ApprovalRequestEntity extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "entity_type", nullable = false)
    private String entityType;

    @Column(name = "entity_id")
    private String entityId;

    @Column(name = "action_type", nullable = false)
    private String actionType;

    @Column(name = "request_data", nullable = false, columnDefinition = "LONGTEXT")
    private String requestData;

    @Column(name = "request_metadata", columnDefinition = "LONGTEXT")
    private String requestMetadata;

    @Column(name = "status", nullable = false)
    private String status;

    @Column(name = "checker_id")
    private String checkerId;

    @Column(name = "checker_name")
    private String checkerName;

    @Column(name = "maker_name")
    private String makerName;

    @Column(name = "approval_date")
    private LocalDateTime approvalDate;

    @Column(name = "rejection_reason", length = 500)
    private String rejectionReason;

    public enum EntityType {
        BANK, BRANCH, USER, CONTACT
    }

    public enum ActionType {
        CREATE, UPDATE, DELETE
    }

    public enum Status {
        PENDING, APPROVED, REJECTED
    }

    public void setEntityType(EntityType entityType) {
        this.entityType = entityType.name();
    }

    public void setActionType(ActionType actionType) {
        this.actionType = actionType.name();
    }

    public void setStatus(Status status) {
        this.status = status.name();
    }

    public EntityType getEntityTypeEnum() {
        return EntityType.valueOf(entityType);
    }

    public ActionType getActionTypeEnum() {
        return ActionType.valueOf(actionType);
    }

    public Status getStatusEnum() {
        return Status.valueOf(status);
    }
}