package in.iftas.sfms.auth.model;

import java.net.URI;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import in.iftas.sfms.auth.model.Attributes;
import in.iftas.sfms.auth.model.UserResponseAccess;
import java.util.ArrayList;
import java.util.List;
import org.openapitools.jackson.nullable.JsonNullable;
import java.time.OffsetDateTime;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


import java.util.*;
import jakarta.annotation.Generated;

/**
 * UserResponse
 */


public class UserResponse {

  private String id;

  private Long createdTimestamp;

  private String username;

  private Boolean enabled;

  private Boolean totp;

  private Boolean emailVerified;

  private String firstName;

  private String lastName;

  private String email;

  private Attributes attributes;

  @Valid
  private List<String> requiredActions;

  private Integer notBefore;

  private UserResponseAccess access;

  public UserResponse id(String id) {
    this.id = id;
    return this;
  }

  /**
   * Get id
   * @return id
   */
  
  @Schema(name = "id", example = "20a6a30f-b0e2-40a1-8572-94cbcd0c4cb5", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("id")
  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public UserResponse createdTimestamp(Long createdTimestamp) {
    this.createdTimestamp = createdTimestamp;
    return this;
  }

  /**
   * Get createdTimestamp
   * @return createdTimestamp
   */
  
  @Schema(name = "createdTimestamp", example = "1726661297215", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("createdTimestamp")
  public Long getCreatedTimestamp() {
    return createdTimestamp;
  }

  public void setCreatedTimestamp(Long createdTimestamp) {
    this.createdTimestamp = createdTimestamp;
  }

  public UserResponse username(String username) {
    this.username = username;
    return this;
  }

  /**
   * Get username
   * @return username
   */
  
  @Schema(name = "username", example = "manoj.illa", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("username")
  public String getUsername() {
    return username;
  }

  public void setUsername(String username) {
    this.username = username;
  }

  public UserResponse enabled(Boolean enabled) {
    this.enabled = enabled;
    return this;
  }

  /**
   * Get enabled
   * @return enabled
   */
  
  @Schema(name = "enabled", example = "true", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("enabled")
  public Boolean getEnabled() {
    return enabled;
  }

  public void setEnabled(Boolean enabled) {
    this.enabled = enabled;
  }

  public UserResponse totp(Boolean totp) {
    this.totp = totp;
    return this;
  }

  /**
   * Get totp
   * @return totp
   */
  
  @Schema(name = "totp", example = "false", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("totp")
  public Boolean getTotp() {
    return totp;
  }

  public void setTotp(Boolean totp) {
    this.totp = totp;
  }

  public UserResponse emailVerified(Boolean emailVerified) {
    this.emailVerified = emailVerified;
    return this;
  }

  /**
   * Get emailVerified
   * @return emailVerified
   */
  
  @Schema(name = "emailVerified", example = "true", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("emailVerified")
  public Boolean getEmailVerified() {
    return emailVerified;
  }

  public void setEmailVerified(Boolean emailVerified) {
    this.emailVerified = emailVerified;
  }

  public UserResponse firstName(String firstName) {
    this.firstName = firstName;
    return this;
  }

  /**
   * Get firstName
   * @return firstName
   */
  
  @Schema(name = "firstName", example = "Manoj", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("firstName")
  public String getFirstName() {
    return firstName;
  }

  public void setFirstName(String firstName) {
    this.firstName = firstName;
  }

  public UserResponse lastName(String lastName) {
    this.lastName = lastName;
    return this;
  }

  /**
   * Get lastName
   * @return lastName
   */
  
  @Schema(name = "lastName", example = "Anand", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("lastName")
  public String getLastName() {
    return lastName;
  }

  public void setLastName(String lastName) {
    this.lastName = lastName;
  }

  public UserResponse email(String email) {
    this.email = email;
    return this;
  }

  /**
   * Get email
   * @return email
   */
  
  @Schema(name = "email", example = "manoj.illa@iftas.in", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("email")
  public String getEmail() {
    return email;
  }

  public void setEmail(String email) {
    this.email = email;
  }

  public UserResponse attributes(Attributes attributes) {
    this.attributes = attributes;
    return this;
  }

  /**
   * Get attributes
   * @return attributes
   */
  @Valid 
  @Schema(name = "attributes", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("attributes")
  public Attributes getAttributes() {
    return attributes;
  }

  public void setAttributes(Attributes attributes) {
    this.attributes = attributes;
  }

  public UserResponse requiredActions(List<String> requiredActions) {
    this.requiredActions = requiredActions;
    return this;
  }

  public UserResponse addItem(String requiredActionsItem) {
    if (this.requiredActions == null) {
      this.requiredActions = new ArrayList<>();
    }
    this.requiredActions.add(requiredActionsItem);
    return this;
  }

  /**
   * Get requiredActions
   * @return requiredActions
   */
  
  @Schema(name = "requiredActions", example = "[]", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("requiredActions")
  public List<String> getRequiredActions() {
    return requiredActions;
  }

  public void setRequiredActions(List<String> requiredActions) {
    this.requiredActions = requiredActions;
  }

  public UserResponse notBefore(Integer notBefore) {
    this.notBefore = notBefore;
    return this;
  }

  /**
   * Get notBefore
   * @return notBefore
   */
  
  @Schema(name = "notBefore", example = "0", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("notBefore")
  public Integer getNotBefore() {
    return notBefore;
  }

  public void setNotBefore(Integer notBefore) {
    this.notBefore = notBefore;
  }

  public UserResponse access(UserResponseAccess access) {
    this.access = access;
    return this;
  }

  /**
   * Get access
   * @return access
   */
  @Valid 
  @Schema(name = "access", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("access")
  public UserResponseAccess getAccess() {
    return access;
  }

  public void setAccess(UserResponseAccess access) {
    this.access = access;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    UserResponse userResponse = (UserResponse) o;
    return Objects.equals(this.id, userResponse.id) &&
        Objects.equals(this.createdTimestamp, userResponse.createdTimestamp) &&
        Objects.equals(this.username, userResponse.username) &&
        Objects.equals(this.enabled, userResponse.enabled) &&
        Objects.equals(this.totp, userResponse.totp) &&
        Objects.equals(this.emailVerified, userResponse.emailVerified) &&
        Objects.equals(this.firstName, userResponse.firstName) &&
        Objects.equals(this.lastName, userResponse.lastName) &&
        Objects.equals(this.email, userResponse.email) &&
        Objects.equals(this.attributes, userResponse.attributes) &&
        Objects.equals(this.requiredActions, userResponse.requiredActions) &&
        Objects.equals(this.notBefore, userResponse.notBefore) &&
        Objects.equals(this.access, userResponse.access);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, createdTimestamp, username, enabled, totp, emailVerified, firstName, lastName, email, attributes, requiredActions, notBefore, access);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class UserResponse {\n");
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    createdTimestamp: ").append(toIndentedString(createdTimestamp)).append("\n");
    sb.append("    username: ").append(toIndentedString(username)).append("\n");
    sb.append("    enabled: ").append(toIndentedString(enabled)).append("\n");
    sb.append("    totp: ").append(toIndentedString(totp)).append("\n");
    sb.append("    emailVerified: ").append(toIndentedString(emailVerified)).append("\n");
    sb.append("    firstName: ").append(toIndentedString(firstName)).append("\n");
    sb.append("    lastName: ").append(toIndentedString(lastName)).append("\n");
    sb.append("    email: ").append(toIndentedString(email)).append("\n");
    sb.append("    attributes: ").append(toIndentedString(attributes)).append("\n");
    sb.append("    requiredActions: ").append(toIndentedString(requiredActions)).append("\n");
    sb.append("    notBefore: ").append(toIndentedString(notBefore)).append("\n");
    sb.append("    access: ").append(toIndentedString(access)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

