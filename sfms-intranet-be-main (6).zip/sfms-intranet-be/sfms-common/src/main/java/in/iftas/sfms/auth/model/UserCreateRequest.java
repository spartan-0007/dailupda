package in.iftas.sfms.auth.model;

import java.net.URI;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import in.iftas.sfms.auth.model.Attributes;
import in.iftas.sfms.auth.model.CredentialsRequest;
import in.iftas.sfms.auth.model.UserRoleResponse;
import java.util.ArrayList;
import java.util.List;
import org.openapitools.jackson.nullable.JsonNullable;
import java.time.OffsetDateTime;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


import java.util.*;
import jakarta.annotation.Generated;

/**
 * UserCreateRequest
 */


public class UserCreateRequest {

  private String username;

  private String email;

  private String firstName;

  private String lastName;

  private Boolean enabled;

  @Valid
  private List<@Valid CredentialsRequest> credentials;

  @Valid
  private List<@Valid UserRoleResponse> userRoles;

  private Attributes attributes;

  private Boolean emailVerified = true;

  public UserCreateRequest username(String username) {
    this.username = username;
    return this;
  }

  /**
   * Get username
   * @return username
   */
  
  @Schema(name = "username", example = "hemant.maurya", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("username")
  public String getUsername() {
    return username;
  }

  public void setUsername(String username) {
    this.username = username;
  }

  public UserCreateRequest email(String email) {
    this.email = email;
    return this;
  }

  /**
   * Get email
   * @return email
   */
  
  @Schema(name = "email", example = "hemant.maurya@iftas.in", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("email")
  public String getEmail() {
    return email;
  }

  public void setEmail(String email) {
    this.email = email;
  }

  public UserCreateRequest firstName(String firstName) {
    this.firstName = firstName;
    return this;
  }

  /**
   * Get firstName
   * @return firstName
   */
  
  @Schema(name = "firstName", example = "Hemant", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("firstName")
  public String getFirstName() {
    return firstName;
  }

  public void setFirstName(String firstName) {
    this.firstName = firstName;
  }

  public UserCreateRequest lastName(String lastName) {
    this.lastName = lastName;
    return this;
  }

  /**
   * Get lastName
   * @return lastName
   */
  
  @Schema(name = "lastName", example = "Maurya", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("lastName")
  public String getLastName() {
    return lastName;
  }

  public void setLastName(String lastName) {
    this.lastName = lastName;
  }

  public UserCreateRequest enabled(Boolean enabled) {
    this.enabled = enabled;
    return this;
  }

  /**
   * Get enabled
   * @return enabled
   */
  
  @Schema(name = "enabled", example = "true", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("enabled")
  public Boolean getEnabled() {
    return enabled;
  }

  public void setEnabled(Boolean enabled) {
    this.enabled = enabled;
  }

  public UserCreateRequest credentials(List<@Valid CredentialsRequest> credentials) {
    this.credentials = credentials;
    return this;
  }

  public UserCreateRequest addItem(CredentialsRequest credentialsItem) {
    if (this.credentials == null) {
      this.credentials = new ArrayList<>();
    }
    this.credentials.add(credentialsItem);
    return this;
  }

  /**
   * Get credentials
   * @return credentials
   */
  @Valid 
  @Schema(name = "credentials", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("credentials")
  public List<@Valid CredentialsRequest> getCredentials() {
    return credentials;
  }

  public void setCredentials(List<@Valid CredentialsRequest> credentials) {
    this.credentials = credentials;
  }

  public UserCreateRequest userRoles(List<@Valid UserRoleResponse> userRoles) {
    this.userRoles = userRoles;
    return this;
  }

  public UserCreateRequest addItem(UserRoleResponse userRolesItem) {
    if (this.userRoles == null) {
      this.userRoles = new ArrayList<>();
    }
    this.userRoles.add(userRolesItem);
    return this;
  }

  /**
   * Get userRoles
   * @return userRoles
   */
  @Valid 
  @Schema(name = "userRoles", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("userRoles")
  public List<@Valid UserRoleResponse> getUserRoles() {
    return userRoles;
  }

  public void setUserRoles(List<@Valid UserRoleResponse> userRoles) {
    this.userRoles = userRoles;
  }

  public UserCreateRequest attributes(Attributes attributes) {
    this.attributes = attributes;
    return this;
  }

  /**
   * Get attributes
   * @return attributes
   */
  @Valid 
  @Schema(name = "attributes", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("attributes")
  public Attributes getAttributes() {
    return attributes;
  }

  public void setAttributes(Attributes attributes) {
    this.attributes = attributes;
  }

  public UserCreateRequest emailVerified(Boolean emailVerified) {
    this.emailVerified = emailVerified;
    return this;
  }

  /**
   * Indicates whether the email is verified
   * @return emailVerified
   */
  
  @Schema(name = "emailVerified", example = "false", description = "Indicates whether the email is verified", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("emailVerified")
  public Boolean getEmailVerified() {
    return emailVerified;
  }

  public void setEmailVerified(Boolean emailVerified) {
    this.emailVerified = emailVerified;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    UserCreateRequest userCreateRequest = (UserCreateRequest) o;
    return Objects.equals(this.username, userCreateRequest.username) &&
        Objects.equals(this.email, userCreateRequest.email) &&
        Objects.equals(this.firstName, userCreateRequest.firstName) &&
        Objects.equals(this.lastName, userCreateRequest.lastName) &&
        Objects.equals(this.enabled, userCreateRequest.enabled) &&
        Objects.equals(this.credentials, userCreateRequest.credentials) &&
        Objects.equals(this.userRoles, userCreateRequest.userRoles) &&
        Objects.equals(this.attributes, userCreateRequest.attributes) &&
        Objects.equals(this.emailVerified, userCreateRequest.emailVerified);
  }

  @Override
  public int hashCode() {
    return Objects.hash(username, email, firstName, lastName, enabled, credentials, userRoles, attributes, emailVerified);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class UserCreateRequest {\n");
    sb.append("    username: ").append(toIndentedString(username)).append("\n");
    sb.append("    email: ").append(toIndentedString(email)).append("\n");
    sb.append("    firstName: ").append(toIndentedString(firstName)).append("\n");
    sb.append("    lastName: ").append(toIndentedString(lastName)).append("\n");
    sb.append("    enabled: ").append(toIndentedString(enabled)).append("\n");
    sb.append("    credentials: ").append(toIndentedString(credentials)).append("\n");
    sb.append("    userRoles: ").append(toIndentedString(userRoles)).append("\n");
    sb.append("    attributes: ").append(toIndentedString(attributes)).append("\n");
    sb.append("    emailVerified: ").append(toIndentedString(emailVerified)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

