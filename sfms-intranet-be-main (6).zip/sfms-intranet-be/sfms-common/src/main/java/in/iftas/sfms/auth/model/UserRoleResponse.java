package in.iftas.sfms.auth.model;

import java.net.URI;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import org.openapitools.jackson.nullable.JsonNullable;
import java.time.OffsetDateTime;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


import java.util.*;
import jakarta.annotation.Generated;

/**
 * UserRoleResponse
 */


public class UserRoleResponse {

  private String id;

  private String name;

  private String description;

  private Boolean composite;

  private Boolean clientRole;

  private String containerId;

  public UserRoleResponse id(String id) {
    this.id = id;
    return this;
  }

  /**
   * Role ID
   * @return id
   */
  
  @Schema(name = "id", description = "Role ID", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("id")
  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public UserRoleResponse name(String name) {
    this.name = name;
    return this;
  }

  /**
   * Role name
   * @return name
   */
  
  @Schema(name = "name", description = "Role name", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("name")
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public UserRoleResponse description(String description) {
    this.description = description;
    return this;
  }

  /**
   * Role description
   * @return description
   */
  
  @Schema(name = "description", description = "Role description", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("description")
  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public UserRoleResponse composite(Boolean composite) {
    this.composite = composite;
    return this;
  }

  /**
   * Get composite
   * @return composite
   */
  
  @Schema(name = "composite", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("composite")
  public Boolean getComposite() {
    return composite;
  }

  public void setComposite(Boolean composite) {
    this.composite = composite;
  }

  public UserRoleResponse clientRole(Boolean clientRole) {
    this.clientRole = clientRole;
    return this;
  }

  /**
   * Get clientRole
   * @return clientRole
   */
  
  @Schema(name = "clientRole", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("clientRole")
  public Boolean getClientRole() {
    return clientRole;
  }

  public void setClientRole(Boolean clientRole) {
    this.clientRole = clientRole;
  }

  public UserRoleResponse containerId(String containerId) {
    this.containerId = containerId;
    return this;
  }

  /**
   * Get containerId
   * @return containerId
   */
  
  @Schema(name = "containerId", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("containerId")
  public String getContainerId() {
    return containerId;
  }

  public void setContainerId(String containerId) {
    this.containerId = containerId;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    UserRoleResponse userRoleResponse = (UserRoleResponse) o;
    return Objects.equals(this.id, userRoleResponse.id) &&
        Objects.equals(this.name, userRoleResponse.name) &&
        Objects.equals(this.description, userRoleResponse.description) &&
        Objects.equals(this.composite, userRoleResponse.composite) &&
        Objects.equals(this.clientRole, userRoleResponse.clientRole) &&
        Objects.equals(this.containerId, userRoleResponse.containerId);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, name, description, composite, clientRole, containerId);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class UserRoleResponse {\n");
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    description: ").append(toIndentedString(description)).append("\n");
    sb.append("    composite: ").append(toIndentedString(composite)).append("\n");
    sb.append("    clientRole: ").append(toIndentedString(clientRole)).append("\n");
    sb.append("    containerId: ").append(toIndentedString(containerId)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

