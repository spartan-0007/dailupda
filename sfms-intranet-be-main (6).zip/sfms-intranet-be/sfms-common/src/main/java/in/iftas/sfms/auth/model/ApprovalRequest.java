package in.iftas.sfms.auth.model;

import java.net.URI;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;
import org.openapitools.jackson.nullable.JsonNullable;
import java.time.OffsetDateTime;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


import java.util.*;
import jakarta.annotation.Generated;

/**
 * ApprovalRequest
 */


public class ApprovalRequest {

  private Integer id;

  /**
   * Type of entity (BANK, BRANCH, etc.)
   */
  public enum EntityTypeEnum {
    BANK("BANK"),
    
    BRANCH("BRANCH"),
    
    CONTACT("CONTACT"),
    
    USER("USER");

    private String value;

    EntityTypeEnum(String value) {
      this.value = value;
    }

    @JsonValue
    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static EntityTypeEnum fromValue(String value) {
      for (EntityTypeEnum b : EntityTypeEnum.values()) {
        if (b.value.equals(value)) {
          return b;
        }
      }
      throw new IllegalArgumentException("Unexpected value '" + value + "'");
    }
  }

  private EntityTypeEnum entityType;

  private String entityId;

  /**
   * Type of action (CREATE, UPDATE, DELETE)
   */
  public enum ActionTypeEnum {
    CREATE("CREATE"),
    
    UPDATE("UPDATE"),
    
    DELETE("DELETE");

    private String value;

    ActionTypeEnum(String value) {
      this.value = value;
    }

    @JsonValue
    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static ActionTypeEnum fromValue(String value) {
      for (ActionTypeEnum b : ActionTypeEnum.values()) {
        if (b.value.equals(value)) {
          return b;
        }
      }
      throw new IllegalArgumentException("Unexpected value '" + value + "'");
    }
  }

  private ActionTypeEnum actionType;

  private Object requestData;

  private Object requestMetadata;

  /**
   * Status of the approval request
   */
  public enum StatusEnum {
    PENDING("PENDING"),
    
    APPROVED("APPROVED"),
    
    REJECTED("REJECTED");

    private String value;

    StatusEnum(String value) {
      this.value = value;
    }

    @JsonValue
    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static StatusEnum fromValue(String value) {
      for (StatusEnum b : StatusEnum.values()) {
        if (b.value.equals(value)) {
          return b;
        }
      }
      throw new IllegalArgumentException("Unexpected value '" + value + "'");
    }
  }

  private StatusEnum status;

  private String checkerId;

  private String checkerName;

  private String makerId;

  private String makerName;

  @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
  private Date approvalDate;

  private String rejectionReason;

  @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
  private Date createdDate;

  public ApprovalRequest id(Integer id) {
    this.id = id;
    return this;
  }

  /**
   * Get id
   * @return id
   */
  
  @Schema(name = "id", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("id")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public ApprovalRequest entityType(EntityTypeEnum entityType) {
    this.entityType = entityType;
    return this;
  }

  /**
   * Type of entity (BANK, BRANCH, etc.)
   * @return entityType
   */
  
  @Schema(name = "entityType", description = "Type of entity (BANK, BRANCH, etc.)", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("entityType")
  public EntityTypeEnum getEntityType() {
    return entityType;
  }

  public void setEntityType(EntityTypeEnum entityType) {
    this.entityType = entityType;
  }

  public ApprovalRequest entityId(String entityId) {
    this.entityId = entityId;
    return this;
  }

  /**
   * ID of the entity for updates/deletes
   * @return entityId
   */
  
  @Schema(name = "entityId", description = "ID of the entity for updates/deletes", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("entityId")
  public String getEntityId() {
    return entityId;
  }

  public void setEntityId(String entityId) {
    this.entityId = entityId;
  }

  public ApprovalRequest actionType(ActionTypeEnum actionType) {
    this.actionType = actionType;
    return this;
  }

  /**
   * Type of action (CREATE, UPDATE, DELETE)
   * @return actionType
   */
  
  @Schema(name = "actionType", description = "Type of action (CREATE, UPDATE, DELETE)", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("actionType")
  public ActionTypeEnum getActionType() {
    return actionType;
  }

  public void setActionType(ActionTypeEnum actionType) {
    this.actionType = actionType;
  }

  public ApprovalRequest requestData(Object requestData) {
    this.requestData = requestData;
    return this;
  }

  /**
   * JSON data containing the request details
   * @return requestData
   */
  
  @Schema(name = "requestData", description = "JSON data containing the request details", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("requestData")
  public Object getRequestData() {
    return requestData;
  }

  public void setRequestData(Object requestData) {
    this.requestData = requestData;
  }

  public ApprovalRequest requestMetadata(Object requestMetadata) {
    this.requestMetadata = requestMetadata;
    return this;
  }

  /**
   * Additional metadata for the request
   * @return requestMetadata
   */
  
  @Schema(name = "requestMetadata", description = "Additional metadata for the request", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("requestMetadata")
  public Object getRequestMetadata() {
    return requestMetadata;
  }

  public void setRequestMetadata(Object requestMetadata) {
    this.requestMetadata = requestMetadata;
  }

  public ApprovalRequest status(StatusEnum status) {
    this.status = status;
    return this;
  }

  /**
   * Status of the approval request
   * @return status
   */
  
  @Schema(name = "status", description = "Status of the approval request", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("status")
  public StatusEnum getStatus() {
    return status;
  }

  public void setStatus(StatusEnum status) {
    this.status = status;
  }

  public ApprovalRequest checkerId(String checkerId) {
    this.checkerId = checkerId;
    return this;
  }

  /**
   * ID of the user who approved/rejected the request
   * @return checkerId
   */
  
  @Schema(name = "checkerId", description = "ID of the user who approved/rejected the request", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("checkerId")
  public String getCheckerId() {
    return checkerId;
  }

  public void setCheckerId(String checkerId) {
    this.checkerId = checkerId;
  }

  public ApprovalRequest checkerName(String checkerName) {
    this.checkerName = checkerName;
    return this;
  }

  /**
   * name of the user who approved/rejected the request
   * @return checkerName
   */
  
  @Schema(name = "checkerName", description = "name of the user who approved/rejected the request", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("checkerName")
  public String getCheckerName() {
    return checkerName;
  }

  public void setCheckerName(String checkerName) {
    this.checkerName = checkerName;
  }

  public ApprovalRequest makerId(String makerId) {
    this.makerId = makerId;
    return this;
  }

  /**
   * ID of the user who created the request
   * @return makerId
   */
  
  @Schema(name = "makerId", description = "ID of the user who created the request", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("makerId")
  public String getMakerId() {
    return makerId;
  }

  public void setMakerId(String makerId) {
    this.makerId = makerId;
  }

  public ApprovalRequest makerName(String makerName) {
    this.makerName = makerName;
    return this;
  }

  /**
   * name of the user who created the request
   * @return makerName
   */
  
  @Schema(name = "makerName", description = "name of the user who created the request", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("makerName")
  public String getMakerName() {
    return makerName;
  }

  public void setMakerName(String makerName) {
    this.makerName = makerName;
  }

  public ApprovalRequest approvalDate(Date approvalDate) {
    this.approvalDate = approvalDate;
    return this;
  }

  /**
   * Date when the request was approved/rejected
   * @return approvalDate
   */
  @Valid 
  @Schema(name = "approvalDate", description = "Date when the request was approved/rejected", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("approvalDate")
  public Date getApprovalDate() {
    return approvalDate;
  }

  public void setApprovalDate(Date approvalDate) {
    this.approvalDate = approvalDate;
  }

  public ApprovalRequest rejectionReason(String rejectionReason) {
    this.rejectionReason = rejectionReason;
    return this;
  }

  /**
   * Reason for rejection if status is REJECTED
   * @return rejectionReason
   */
  
  @Schema(name = "rejectionReason", description = "Reason for rejection if status is REJECTED", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("rejectionReason")
  public String getRejectionReason() {
    return rejectionReason;
  }

  public void setRejectionReason(String rejectionReason) {
    this.rejectionReason = rejectionReason;
  }

  public ApprovalRequest createdDate(Date createdDate) {
    this.createdDate = createdDate;
    return this;
  }

  /**
   * Get createdDate
   * @return createdDate
   */
  @Valid 
  @Schema(name = "createdDate", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("createdDate")
  public Date getCreatedDate() {
    return createdDate;
  }

  public void setCreatedDate(Date createdDate) {
    this.createdDate = createdDate;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApprovalRequest approvalRequest = (ApprovalRequest) o;
    return Objects.equals(this.id, approvalRequest.id) &&
        Objects.equals(this.entityType, approvalRequest.entityType) &&
        Objects.equals(this.entityId, approvalRequest.entityId) &&
        Objects.equals(this.actionType, approvalRequest.actionType) &&
        Objects.equals(this.requestData, approvalRequest.requestData) &&
        Objects.equals(this.requestMetadata, approvalRequest.requestMetadata) &&
        Objects.equals(this.status, approvalRequest.status) &&
        Objects.equals(this.checkerId, approvalRequest.checkerId) &&
        Objects.equals(this.checkerName, approvalRequest.checkerName) &&
        Objects.equals(this.makerId, approvalRequest.makerId) &&
        Objects.equals(this.makerName, approvalRequest.makerName) &&
        Objects.equals(this.approvalDate, approvalRequest.approvalDate) &&
        Objects.equals(this.rejectionReason, approvalRequest.rejectionReason) &&
        Objects.equals(this.createdDate, approvalRequest.createdDate);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, entityType, entityId, actionType, requestData, requestMetadata, status, checkerId, checkerName, makerId, makerName, approvalDate, rejectionReason, createdDate);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApprovalRequest {\n");
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    entityType: ").append(toIndentedString(entityType)).append("\n");
    sb.append("    entityId: ").append(toIndentedString(entityId)).append("\n");
    sb.append("    actionType: ").append(toIndentedString(actionType)).append("\n");
    sb.append("    requestData: ").append(toIndentedString(requestData)).append("\n");
    sb.append("    requestMetadata: ").append(toIndentedString(requestMetadata)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    checkerId: ").append(toIndentedString(checkerId)).append("\n");
    sb.append("    checkerName: ").append(toIndentedString(checkerName)).append("\n");
    sb.append("    makerId: ").append(toIndentedString(makerId)).append("\n");
    sb.append("    makerName: ").append(toIndentedString(makerName)).append("\n");
    sb.append("    approvalDate: ").append(toIndentedString(approvalDate)).append("\n");
    sb.append("    rejectionReason: ").append(toIndentedString(rejectionReason)).append("\n");
    sb.append("    createdDate: ").append(toIndentedString(createdDate)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

