package in.iftas.sfms.core.mapper;

import in.iftas.sfms.core.entity.BankFeatureEntity;
import in.iftas.sfms.core.model.BranchFeature;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.factory.Mappers;

@Mapper(componentModel = "spring")
public interface BankFeatureMapper {
    BankFeatureMapper INSTANCE = Mappers.getMapper(BankFeatureMapper.class);

    @Mapping(source = "neftEnabled", target = "neftEnabled")
    @Mapping(source = "rtgsEnabled", target = "rtgsEnabled")
    @Mapping(source = "lcEnabled", target = "lcEnabled")
    @Mapping(source = "bgEnabled", target = "bgEnabled")
    @Mapping(source = "others", target = "others")
    @Mapping(source = "createdBy", target = "createdBy")
    @Mapping(source = "createdDate", target = "createdDate")
    @Mapping(source = "lastModifiedBy", target = "lastModifiedBy")
    @Mapping(source = "lastModifiedDate", target = "lastModifiedDate")
    BranchFeature toModel(BankFeatureEntity bankFeatureEntity);

    @Mapping(source = "neftEnabled", target = "neftEnabled")
    @Mapping(source = "rtgsEnabled", target = "rtgsEnabled")
    @Mapping(source = "lcEnabled", target = "lcEnabled")
    @Mapping(source = "bgEnabled", target = "bgEnabled")
    @Mapping(source = "others", target = "others")
    @Mapping(source = "createdBy", target = "createdBy")
    @Mapping(source = "createdDate", target = "createdDate")
    @Mapping(source = "lastModifiedBy", target = "lastModifiedBy")
    @Mapping(source = "lastModifiedDate", target = "lastModifiedDate")
    BankFeatureEntity toEntity(BranchFeature bankFeature);

    void toEntity(BranchFeature bankFeature, @MappingTarget BankFeatureEntity bankFeatureEntity);
}