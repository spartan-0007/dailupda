package in.iftas.sfms.core.model;

import java.net.URI;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import in.iftas.sfms.core.model.DepartmentMatrix;
import java.util.ArrayList;
import java.util.List;
import org.openapitools.jackson.nullable.JsonNullable;
import java.time.OffsetDateTime;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


import java.util.*;
import jakarta.annotation.Generated;

/**
 * EscalationMatrix
 */


public class EscalationMatrix {

  private Long bankId;

  private String bankName;

  @Valid
  private List<@Valid DepartmentMatrix> departments;

  public EscalationMatrix bankId(Long bankId) {
    this.bankId = bankId;
    return this;
  }

  /**
   * Unique identifier of the bank.
   * @return bankId
   */
  
  @Schema(name = "bankId", description = "Unique identifier of the bank.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("bankId")
  public Long getBankId() {
    return bankId;
  }

  public void setBankId(Long bankId) {
    this.bankId = bankId;
  }

  public EscalationMatrix bankName(String bankName) {
    this.bankName = bankName;
    return this;
  }

  /**
   * Name of the bank.
   * @return bankName
   */
  
  @Schema(name = "bankName", description = "Name of the bank.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("bankName")
  public String getBankName() {
    return bankName;
  }

  public void setBankName(String bankName) {
    this.bankName = bankName;
  }

  public EscalationMatrix departments(List<@Valid DepartmentMatrix> departments) {
    this.departments = departments;
    return this;
  }

  public EscalationMatrix addItem(DepartmentMatrix departmentsItem) {
    if (this.departments == null) {
      this.departments = new ArrayList<>();
    }
    this.departments.add(departmentsItem);
    return this;
  }

  /**
   * List of departments in the escalation matrix.
   * @return departments
   */
  @Valid 
  @Schema(name = "departments", description = "List of departments in the escalation matrix.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("departments")
  public List<@Valid DepartmentMatrix> getDepartments() {
    return departments;
  }

  public void setDepartments(List<@Valid DepartmentMatrix> departments) {
    this.departments = departments;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    EscalationMatrix escalationMatrix = (EscalationMatrix) o;
    return Objects.equals(this.bankId, escalationMatrix.bankId) &&
        Objects.equals(this.bankName, escalationMatrix.bankName) &&
        Objects.equals(this.departments, escalationMatrix.departments);
  }

  @Override
  public int hashCode() {
    return Objects.hash(bankId, bankName, departments);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class EscalationMatrix {\n");
    sb.append("    bankId: ").append(toIndentedString(bankId)).append("\n");
    sb.append("    bankName: ").append(toIndentedString(bankName)).append("\n");
    sb.append("    departments: ").append(toIndentedString(departments)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

