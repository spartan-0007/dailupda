package in.iftas.sfms.core.model;

import java.net.URI;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import org.openapitools.jackson.nullable.JsonNullable;
import java.time.OffsetDateTime;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


import java.util.*;
import jakarta.annotation.Generated;

/**
 * CrfIp
 */


public class CrfIp {

  private Integer id;

  private Long crfId;

  private String sourceIp;

  private String destinationIp;

  private String port;

  public CrfIp id(Integer id) {
    this.id = id;
    return this;
  }

  /**
   * Get id
   * @return id
   */
  
  @Schema(name = "id", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("id")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public CrfIp crfId(Long crfId) {
    this.crfId = crfId;
    return this;
  }

  /**
   * Get crfId
   * @return crfId
   */
  
  @Schema(name = "crfId", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("crfId")
  public Long getCrfId() {
    return crfId;
  }

  public void setCrfId(Long crfId) {
    this.crfId = crfId;
  }

  public CrfIp sourceIp(String sourceIp) {
    this.sourceIp = sourceIp;
    return this;
  }

  /**
   * Comma-separated source IPs
   * @return sourceIp
   */
  
  @Schema(name = "sourceIp", description = "Comma-separated source IPs", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("sourceIp")
  public String getSourceIp() {
    return sourceIp;
  }

  public void setSourceIp(String sourceIp) {
    this.sourceIp = sourceIp;
  }

  public CrfIp destinationIp(String destinationIp) {
    this.destinationIp = destinationIp;
    return this;
  }

  /**
   * Comma-separated destination IPs
   * @return destinationIp
   */
  
  @Schema(name = "destinationIp", description = "Comma-separated destination IPs", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("destinationIp")
  public String getDestinationIp() {
    return destinationIp;
  }

  public void setDestinationIp(String destinationIp) {
    this.destinationIp = destinationIp;
  }

  public CrfIp port(String port) {
    this.port = port;
    return this;
  }

  /**
   * Comma-separated Port IPs
   * @return port
   */
  
  @Schema(name = "port", description = "Comma-separated Port IPs", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("port")
  public String getPort() {
    return port;
  }

  public void setPort(String port) {
    this.port = port;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    CrfIp crfIp = (CrfIp) o;
    return Objects.equals(this.id, crfIp.id) &&
        Objects.equals(this.crfId, crfIp.crfId) &&
        Objects.equals(this.sourceIp, crfIp.sourceIp) &&
        Objects.equals(this.destinationIp, crfIp.destinationIp) &&
        Objects.equals(this.port, crfIp.port);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, crfId, sourceIp, destinationIp, port);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class CrfIp {\n");
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    crfId: ").append(toIndentedString(crfId)).append("\n");
    sb.append("    sourceIp: ").append(toIndentedString(sourceIp)).append("\n");
    sb.append("    destinationIp: ").append(toIndentedString(destinationIp)).append("\n");
    sb.append("    port: ").append(toIndentedString(port)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

