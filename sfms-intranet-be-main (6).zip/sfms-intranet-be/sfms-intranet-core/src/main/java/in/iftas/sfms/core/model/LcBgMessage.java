package in.iftas.sfms.core.model;

import java.net.URI;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;
import org.openapitools.jackson.nullable.JsonNullable;
import java.time.OffsetDateTime;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


import java.util.*;
import jakarta.annotation.Generated;

/**
 * LcBgMessage
 */


public class LcBgMessage {

  private Long id;

  private String senderIfsc;

  private String receiverIfsc;

  private String senderReferenceNumber;

  private String messageType;

  private String messageStatus;

  @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
  private Date messageDate;

  @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
  private Date uploadDate;

  public LcBgMessage id(Long id) {
    this.id = id;
    return this;
  }

  /**
   * Get id
   * @return id
   */
  
  @Schema(name = "id", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("id")
  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public LcBgMessage senderIfsc(String senderIfsc) {
    this.senderIfsc = senderIfsc;
    return this;
  }

  /**
   * Get senderIfsc
   * @return senderIfsc
   */
  @Pattern(regexp = "^[A-Z]{4}0[A-Z0-9]{6}$") 
  @Schema(name = "senderIfsc", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("senderIfsc")
  public String getSenderIfsc() {
    return senderIfsc;
  }

  public void setSenderIfsc(String senderIfsc) {
    this.senderIfsc = senderIfsc;
  }

  public LcBgMessage receiverIfsc(String receiverIfsc) {
    this.receiverIfsc = receiverIfsc;
    return this;
  }

  /**
   * Get receiverIfsc
   * @return receiverIfsc
   */
  @Pattern(regexp = "^[A-Z]{4}0[A-Z0-9]{6}$") 
  @Schema(name = "receiverIfsc", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("receiverIfsc")
  public String getReceiverIfsc() {
    return receiverIfsc;
  }

  public void setReceiverIfsc(String receiverIfsc) {
    this.receiverIfsc = receiverIfsc;
  }

  public LcBgMessage senderReferenceNumber(String senderReferenceNumber) {
    this.senderReferenceNumber = senderReferenceNumber;
    return this;
  }

  /**
   * Get senderReferenceNumber
   * @return senderReferenceNumber
   */
  
  @Schema(name = "senderReferenceNumber", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("senderReferenceNumber")
  public String getSenderReferenceNumber() {
    return senderReferenceNumber;
  }

  public void setSenderReferenceNumber(String senderReferenceNumber) {
    this.senderReferenceNumber = senderReferenceNumber;
  }

  public LcBgMessage messageType(String messageType) {
    this.messageType = messageType;
    return this;
  }

  /**
   * Get messageType
   * @return messageType
   */
  
  @Schema(name = "messageType", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("messageType")
  public String getMessageType() {
    return messageType;
  }

  public void setMessageType(String messageType) {
    this.messageType = messageType;
  }

  public LcBgMessage messageStatus(String messageStatus) {
    this.messageStatus = messageStatus;
    return this;
  }

  /**
   * Get messageStatus
   * @return messageStatus
   */
  
  @Schema(name = "messageStatus", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("messageStatus")
  public String getMessageStatus() {
    return messageStatus;
  }

  public void setMessageStatus(String messageStatus) {
    this.messageStatus = messageStatus;
  }

  public LcBgMessage messageDate(Date messageDate) {
    this.messageDate = messageDate;
    return this;
  }

  /**
   * Get messageDate
   * @return messageDate
   */
  @Valid 
  @Schema(name = "messageDate", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("messageDate")
  public Date getMessageDate() {
    return messageDate;
  }

  public void setMessageDate(Date messageDate) {
    this.messageDate = messageDate;
  }

  public LcBgMessage uploadDate(Date uploadDate) {
    this.uploadDate = uploadDate;
    return this;
  }

  /**
   * Get uploadDate
   * @return uploadDate
   */
  @Valid 
  @Schema(name = "uploadDate", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("uploadDate")
  public Date getUploadDate() {
    return uploadDate;
  }

  public void setUploadDate(Date uploadDate) {
    this.uploadDate = uploadDate;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    LcBgMessage lcBgMessage = (LcBgMessage) o;
    return Objects.equals(this.id, lcBgMessage.id) &&
        Objects.equals(this.senderIfsc, lcBgMessage.senderIfsc) &&
        Objects.equals(this.receiverIfsc, lcBgMessage.receiverIfsc) &&
        Objects.equals(this.senderReferenceNumber, lcBgMessage.senderReferenceNumber) &&
        Objects.equals(this.messageType, lcBgMessage.messageType) &&
        Objects.equals(this.messageStatus, lcBgMessage.messageStatus) &&
        Objects.equals(this.messageDate, lcBgMessage.messageDate) &&
        Objects.equals(this.uploadDate, lcBgMessage.uploadDate);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, senderIfsc, receiverIfsc, senderReferenceNumber, messageType, messageStatus, messageDate, uploadDate);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class LcBgMessage {\n");
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    senderIfsc: ").append(toIndentedString(senderIfsc)).append("\n");
    sb.append("    receiverIfsc: ").append(toIndentedString(receiverIfsc)).append("\n");
    sb.append("    senderReferenceNumber: ").append(toIndentedString(senderReferenceNumber)).append("\n");
    sb.append("    messageType: ").append(toIndentedString(messageType)).append("\n");
    sb.append("    messageStatus: ").append(toIndentedString(messageStatus)).append("\n");
    sb.append("    messageDate: ").append(toIndentedString(messageDate)).append("\n");
    sb.append("    uploadDate: ").append(toIndentedString(uploadDate)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

