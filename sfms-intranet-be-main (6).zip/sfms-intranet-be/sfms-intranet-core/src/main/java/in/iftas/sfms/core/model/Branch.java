package in.iftas.sfms.core.model;

import java.net.URI;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import in.iftas.sfms.core.model.BranchContact;
import in.iftas.sfms.core.model.BranchFeature;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;
import org.openapitools.jackson.nullable.JsonNullable;
import java.time.OffsetDateTime;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


import java.util.*;
import jakarta.annotation.Generated;

/**
 * Branch
 */


public class Branch {

  private String ifscCode;

  private String ifscType;

  private String micrCode;

  private String branchName;

  private String cityName;

  private String bankAddress;

  private String district;

  private String state;

  private Boolean isActive;

  private BranchContact branchContact;

  private BranchFeature branchFeature;

  private String createdBy;

  @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
  private Date createdDate;

  private String lastModifiedBy;

  @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
  private Date lastModifiedDate;

  public Branch ifscCode(String ifscCode) {
    this.ifscCode = ifscCode;
    return this;
  }

  /**
   * Get ifscCode
   * @return ifscCode
   */
  
  @Schema(name = "ifscCode", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("ifscCode")
  public String getIfscCode() {
    return ifscCode;
  }

  public void setIfscCode(String ifscCode) {
    this.ifscCode = ifscCode;
  }

  public Branch ifscType(String ifscType) {
    this.ifscType = ifscType;
    return this;
  }

  /**
   * Get ifscType
   * @return ifscType
   */
  
  @Schema(name = "ifscType", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("ifscType")
  public String getIfscType() {
    return ifscType;
  }

  public void setIfscType(String ifscType) {
    this.ifscType = ifscType;
  }

  public Branch micrCode(String micrCode) {
    this.micrCode = micrCode;
    return this;
  }

  /**
   * Get micrCode
   * @return micrCode
   */
  
  @Schema(name = "micrCode", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("micrCode")
  public String getMicrCode() {
    return micrCode;
  }

  public void setMicrCode(String micrCode) {
    this.micrCode = micrCode;
  }

  public Branch branchName(String branchName) {
    this.branchName = branchName;
    return this;
  }

  /**
   * Get branchName
   * @return branchName
   */
  
  @Schema(name = "branchName", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("branchName")
  public String getBranchName() {
    return branchName;
  }

  public void setBranchName(String branchName) {
    this.branchName = branchName;
  }

  public Branch cityName(String cityName) {
    this.cityName = cityName;
    return this;
  }

  /**
   * Get cityName
   * @return cityName
   */
  
  @Schema(name = "cityName", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("cityName")
  public String getCityName() {
    return cityName;
  }

  public void setCityName(String cityName) {
    this.cityName = cityName;
  }

  public Branch bankAddress(String bankAddress) {
    this.bankAddress = bankAddress;
    return this;
  }

  /**
   * Get bankAddress
   * @return bankAddress
   */
  
  @Schema(name = "bankAddress", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("bankAddress")
  public String getBankAddress() {
    return bankAddress;
  }

  public void setBankAddress(String bankAddress) {
    this.bankAddress = bankAddress;
  }

  public Branch district(String district) {
    this.district = district;
    return this;
  }

  /**
   * Get district
   * @return district
   */
  
  @Schema(name = "district", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("district")
  public String getDistrict() {
    return district;
  }

  public void setDistrict(String district) {
    this.district = district;
  }

  public Branch state(String state) {
    this.state = state;
    return this;
  }

  /**
   * Get state
   * @return state
   */
  
  @Schema(name = "state", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("state")
  public String getState() {
    return state;
  }

  public void setState(String state) {
    this.state = state;
  }

  public Branch isActive(Boolean isActive) {
    this.isActive = isActive;
    return this;
  }

  /**
   * Get isActive
   * @return isActive
   */
  
  @Schema(name = "isActive", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("isActive")
  public Boolean getIsActive() {
    return isActive;
  }

  public void setIsActive(Boolean isActive) {
    this.isActive = isActive;
  }

  public Branch branchContact(BranchContact branchContact) {
    this.branchContact = branchContact;
    return this;
  }

  /**
   * Get branchContact
   * @return branchContact
   */
  @Valid 
  @Schema(name = "branchContact", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("branchContact")
  public BranchContact getBranchContact() {
    return branchContact;
  }

  public void setBranchContact(BranchContact branchContact) {
    this.branchContact = branchContact;
  }

  public Branch branchFeature(BranchFeature branchFeature) {
    this.branchFeature = branchFeature;
    return this;
  }

  /**
   * Get branchFeature
   * @return branchFeature
   */
  @Valid 
  @Schema(name = "branchFeature", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("branchFeature")
  public BranchFeature getBranchFeature() {
    return branchFeature;
  }

  public void setBranchFeature(BranchFeature branchFeature) {
    this.branchFeature = branchFeature;
  }

  public Branch createdBy(String createdBy) {
    this.createdBy = createdBy;
    return this;
  }

  /**
   * Get createdBy
   * @return createdBy
   */
  
  @Schema(name = "createdBy", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("createdBy")
  public String getCreatedBy() {
    return createdBy;
  }

  public void setCreatedBy(String createdBy) {
    this.createdBy = createdBy;
  }

  public Branch createdDate(Date createdDate) {
    this.createdDate = createdDate;
    return this;
  }

  /**
   * Get createdDate
   * @return createdDate
   */
  @Valid 
  @Schema(name = "createdDate", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("createdDate")
  public Date getCreatedDate() {
    return createdDate;
  }

  public void setCreatedDate(Date createdDate) {
    this.createdDate = createdDate;
  }

  public Branch lastModifiedBy(String lastModifiedBy) {
    this.lastModifiedBy = lastModifiedBy;
    return this;
  }

  /**
   * Get lastModifiedBy
   * @return lastModifiedBy
   */
  
  @Schema(name = "lastModifiedBy", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("lastModifiedBy")
  public String getLastModifiedBy() {
    return lastModifiedBy;
  }

  public void setLastModifiedBy(String lastModifiedBy) {
    this.lastModifiedBy = lastModifiedBy;
  }

  public Branch lastModifiedDate(Date lastModifiedDate) {
    this.lastModifiedDate = lastModifiedDate;
    return this;
  }

  /**
   * Get lastModifiedDate
   * @return lastModifiedDate
   */
  @Valid 
  @Schema(name = "lastModifiedDate", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("lastModifiedDate")
  public Date getLastModifiedDate() {
    return lastModifiedDate;
  }

  public void setLastModifiedDate(Date lastModifiedDate) {
    this.lastModifiedDate = lastModifiedDate;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Branch branch = (Branch) o;
    return Objects.equals(this.ifscCode, branch.ifscCode) &&
        Objects.equals(this.ifscType, branch.ifscType) &&
        Objects.equals(this.micrCode, branch.micrCode) &&
        Objects.equals(this.branchName, branch.branchName) &&
        Objects.equals(this.cityName, branch.cityName) &&
        Objects.equals(this.bankAddress, branch.bankAddress) &&
        Objects.equals(this.district, branch.district) &&
        Objects.equals(this.state, branch.state) &&
        Objects.equals(this.isActive, branch.isActive) &&
        Objects.equals(this.branchContact, branch.branchContact) &&
        Objects.equals(this.branchFeature, branch.branchFeature) &&
        Objects.equals(this.createdBy, branch.createdBy) &&
        Objects.equals(this.createdDate, branch.createdDate) &&
        Objects.equals(this.lastModifiedBy, branch.lastModifiedBy) &&
        Objects.equals(this.lastModifiedDate, branch.lastModifiedDate);
  }

  @Override
  public int hashCode() {
    return Objects.hash(ifscCode, ifscType, micrCode, branchName, cityName, bankAddress, district, state, isActive, branchContact, branchFeature, createdBy, createdDate, lastModifiedBy, lastModifiedDate);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Branch {\n");
    sb.append("    ifscCode: ").append(toIndentedString(ifscCode)).append("\n");
    sb.append("    ifscType: ").append(toIndentedString(ifscType)).append("\n");
    sb.append("    micrCode: ").append(toIndentedString(micrCode)).append("\n");
    sb.append("    branchName: ").append(toIndentedString(branchName)).append("\n");
    sb.append("    cityName: ").append(toIndentedString(cityName)).append("\n");
    sb.append("    bankAddress: ").append(toIndentedString(bankAddress)).append("\n");
    sb.append("    district: ").append(toIndentedString(district)).append("\n");
    sb.append("    state: ").append(toIndentedString(state)).append("\n");
    sb.append("    isActive: ").append(toIndentedString(isActive)).append("\n");
    sb.append("    branchContact: ").append(toIndentedString(branchContact)).append("\n");
    sb.append("    branchFeature: ").append(toIndentedString(branchFeature)).append("\n");
    sb.append("    createdBy: ").append(toIndentedString(createdBy)).append("\n");
    sb.append("    createdDate: ").append(toIndentedString(createdDate)).append("\n");
    sb.append("    lastModifiedBy: ").append(toIndentedString(lastModifiedBy)).append("\n");
    sb.append("    lastModifiedDate: ").append(toIndentedString(lastModifiedDate)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

