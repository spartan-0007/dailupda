package in.iftas.sfms.core.model;

import java.net.URI;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;
import org.openapitools.jackson.nullable.JsonNullable;
import java.time.OffsetDateTime;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


import java.util.*;
import jakarta.annotation.Generated;

/**
 * DownloadLog
 */


public class DownloadLog {

  private Integer bankId;

  private String bankName;

  private String downloadedBy;

  @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
  private Date downloadedDate;

  public DownloadLog bankId(Integer bankId) {
    this.bankId = bankId;
    return this;
  }

  /**
   * Unique identifier of the bank that downloaded the patch.
   * @return bankId
   */
  
  @Schema(name = "bankId", description = "Unique identifier of the bank that downloaded the patch.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("bankId")
  public Integer getBankId() {
    return bankId;
  }

  public void setBankId(Integer bankId) {
    this.bankId = bankId;
  }

  public DownloadLog bankName(String bankName) {
    this.bankName = bankName;
    return this;
  }

  /**
   * Name of the bank that downloaded the patch.
   * @return bankName
   */
  
  @Schema(name = "bankName", description = "Name of the bank that downloaded the patch.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("bankName")
  public String getBankName() {
    return bankName;
  }

  public void setBankName(String bankName) {
    this.bankName = bankName;
  }

  public DownloadLog downloadedBy(String downloadedBy) {
    this.downloadedBy = downloadedBy;
    return this;
  }

  /**
   * The user who downloaded the patch.
   * @return downloadedBy
   */
  
  @Schema(name = "downloadedBy", description = "The user who downloaded the patch.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("downloadedBy")
  public String getDownloadedBy() {
    return downloadedBy;
  }

  public void setDownloadedBy(String downloadedBy) {
    this.downloadedBy = downloadedBy;
  }

  public DownloadLog downloadedDate(Date downloadedDate) {
    this.downloadedDate = downloadedDate;
    return this;
  }

  /**
   * Timestamp when the patch was downloaded by the bank.
   * @return downloadedDate
   */
  @Valid 
  @Schema(name = "downloadedDate", description = "Timestamp when the patch was downloaded by the bank.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("downloadedDate")
  public Date getDownloadedDate() {
    return downloadedDate;
  }

  public void setDownloadedDate(Date downloadedDate) {
    this.downloadedDate = downloadedDate;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    DownloadLog downloadLog = (DownloadLog) o;
    return Objects.equals(this.bankId, downloadLog.bankId) &&
        Objects.equals(this.bankName, downloadLog.bankName) &&
        Objects.equals(this.downloadedBy, downloadLog.downloadedBy) &&
        Objects.equals(this.downloadedDate, downloadLog.downloadedDate);
  }

  @Override
  public int hashCode() {
    return Objects.hash(bankId, bankName, downloadedBy, downloadedDate);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class DownloadLog {\n");
    sb.append("    bankId: ").append(toIndentedString(bankId)).append("\n");
    sb.append("    bankName: ").append(toIndentedString(bankName)).append("\n");
    sb.append("    downloadedBy: ").append(toIndentedString(downloadedBy)).append("\n");
    sb.append("    downloadedDate: ").append(toIndentedString(downloadedDate)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

