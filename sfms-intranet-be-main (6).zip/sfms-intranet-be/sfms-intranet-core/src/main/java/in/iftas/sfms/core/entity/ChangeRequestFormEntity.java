package in.iftas.sfms.core.entity;/*
 * Copyright (C) 2024 Iftas Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Iftas Inc. ("Confidential Information"). You shall not disclose
 * such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with Iftas Inc.
 *
 * Author: Manoj.Illa
 * Date: July 11, 2024
 */

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "i_crf", indexes = {
        @Index(name = "idx_svd_ticket_id", columnList = "svd_ticket_id"),
        @Index(name = "idx_priority", columnList = "priority"),
        @Index(name = "idx_bank_short_name", columnList = "bank_short_name")
})
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ChangeRequestFormEntity extends BaseEntity{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "crf_access")
    private String crfAccess;

    @Column(name = "crf_type")
    private String crfType;

    @Column(name = "crf_dept")
    private String crfDept;

    @Column(name = "requestor_date")
    private LocalDate requestedDate;

    @Column(name = "priority")
    private String priority;

    @Column(name = "open_date")
    private LocalDateTime openDate;

    @Column(name = "close_date")
    private LocalDateTime closeDate;

    @Column(name = "reason", length = 1000)
    private String reason;

    @Column(name = "svd_ticket_id")
    private String svdTicketId;

    @Column(name = "bank_short_name")
    private String bankShortName;

    @Column(name = "requestor_name")
    private String requestorName;

    @OneToMany(mappedBy = "crf", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<CrfIpEntity> crfIps;

}
