package in.iftas.sfms.core.exception;

public class IfscCodeAlreadyExistsException extends RuntimeException {
    
    public IfscCodeAlreadyExistsException(String ifscCode) {
        super(String.format("Upload properties step failed. IFSC code '%s' already exists.", ifscCode));
    }
}