package in.iftas.sfms.core.model;

import java.net.URI;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import in.iftas.sfms.core.model.CrfIp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.springframework.format.annotation.DateTimeFormat;
import org.openapitools.jackson.nullable.JsonNullable;
import java.time.OffsetDateTime;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


import java.util.*;
import jakarta.annotation.Generated;

/**
 * ChangeRequestForm
 */


public class ChangeRequestForm {

  private Long id;

  private String crfAccess;

  private String crfType;

  private String crfDept;

  @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
  private Date requestedDate;

  private String priority;

  @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
  private Date openDate;

  @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
  private Date closeDate;

  private String reason;

  private String svdTicketId;

  private String bankShortName;

  @Valid
  private List<@Valid CrfIp> crfIps;

  public ChangeRequestForm id(Long id) {
    this.id = id;
    return this;
  }

  /**
   * Get id
   * @return id
   */
  
  @Schema(name = "id", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("id")
  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public ChangeRequestForm crfAccess(String crfAccess) {
    this.crfAccess = crfAccess;
    return this;
  }

  /**
   * Get crfAccess
   * @return crfAccess
   */
  
  @Schema(name = "crfAccess", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("crfAccess")
  public String getCrfAccess() {
    return crfAccess;
  }

  public void setCrfAccess(String crfAccess) {
    this.crfAccess = crfAccess;
  }

  public ChangeRequestForm crfType(String crfType) {
    this.crfType = crfType;
    return this;
  }

  /**
   * Get crfType
   * @return crfType
   */
  
  @Schema(name = "crfType", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("crfType")
  public String getCrfType() {
    return crfType;
  }

  public void setCrfType(String crfType) {
    this.crfType = crfType;
  }

  public ChangeRequestForm crfDept(String crfDept) {
    this.crfDept = crfDept;
    return this;
  }

  /**
   * Get crfDept
   * @return crfDept
   */
  
  @Schema(name = "crfDept", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("crfDept")
  public String getCrfDept() {
    return crfDept;
  }

  public void setCrfDept(String crfDept) {
    this.crfDept = crfDept;
  }

  public ChangeRequestForm requestedDate(Date requestedDate) {
    this.requestedDate = requestedDate;
    return this;
  }

  /**
   * Get requestedDate
   * @return requestedDate
   */
  @Valid 
  @Schema(name = "requestedDate", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("requestedDate")
  public Date getRequestedDate() {
    return requestedDate;
  }

  public void setRequestedDate(Date requestedDate) {
    this.requestedDate = requestedDate;
  }

  public ChangeRequestForm priority(String priority) {
    this.priority = priority;
    return this;
  }

  /**
   * Get priority
   * @return priority
   */
  
  @Schema(name = "priority", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("priority")
  public String getPriority() {
    return priority;
  }

  public void setPriority(String priority) {
    this.priority = priority;
  }

  public ChangeRequestForm openDate(Date openDate) {
    this.openDate = openDate;
    return this;
  }

  /**
   * Get openDate
   * @return openDate
   */
  @Valid 
  @Schema(name = "openDate", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("openDate")
  public Date getOpenDate() {
    return openDate;
  }

  public void setOpenDate(Date openDate) {
    this.openDate = openDate;
  }

  public ChangeRequestForm closeDate(Date closeDate) {
    this.closeDate = closeDate;
    return this;
  }

  /**
   * Get closeDate
   * @return closeDate
   */
  @Valid 
  @Schema(name = "closeDate", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("closeDate")
  public Date getCloseDate() {
    return closeDate;
  }

  public void setCloseDate(Date closeDate) {
    this.closeDate = closeDate;
  }

  public ChangeRequestForm reason(String reason) {
    this.reason = reason;
    return this;
  }

  /**
   * Get reason
   * @return reason
   */
  
  @Schema(name = "reason", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("reason")
  public String getReason() {
    return reason;
  }

  public void setReason(String reason) {
    this.reason = reason;
  }

  public ChangeRequestForm svdTicketId(String svdTicketId) {
    this.svdTicketId = svdTicketId;
    return this;
  }

  /**
   * Get svdTicketId
   * @return svdTicketId
   */
  
  @Schema(name = "svdTicketId", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("svdTicketId")
  public String getSvdTicketId() {
    return svdTicketId;
  }

  public void setSvdTicketId(String svdTicketId) {
    this.svdTicketId = svdTicketId;
  }

  public ChangeRequestForm bankShortName(String bankShortName) {
    this.bankShortName = bankShortName;
    return this;
  }

  /**
   * Get bankShortName
   * @return bankShortName
   */
  
  @Schema(name = "bankShortName", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("bankShortName")
  public String getBankShortName() {
    return bankShortName;
  }

  public void setBankShortName(String bankShortName) {
    this.bankShortName = bankShortName;
  }

  public ChangeRequestForm crfIps(List<@Valid CrfIp> crfIps) {
    this.crfIps = crfIps;
    return this;
  }

  public ChangeRequestForm addItem(CrfIp crfIpsItem) {
    if (this.crfIps == null) {
      this.crfIps = new ArrayList<>();
    }
    this.crfIps.add(crfIpsItem);
    return this;
  }

  /**
   * Get crfIps
   * @return crfIps
   */
  @Valid 
  @Schema(name = "crfIps", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("crfIps")
  public List<@Valid CrfIp> getCrfIps() {
    return crfIps;
  }

  public void setCrfIps(List<@Valid CrfIp> crfIps) {
    this.crfIps = crfIps;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ChangeRequestForm changeRequestForm = (ChangeRequestForm) o;
    return Objects.equals(this.id, changeRequestForm.id) &&
        Objects.equals(this.crfAccess, changeRequestForm.crfAccess) &&
        Objects.equals(this.crfType, changeRequestForm.crfType) &&
        Objects.equals(this.crfDept, changeRequestForm.crfDept) &&
        Objects.equals(this.requestedDate, changeRequestForm.requestedDate) &&
        Objects.equals(this.priority, changeRequestForm.priority) &&
        Objects.equals(this.openDate, changeRequestForm.openDate) &&
        Objects.equals(this.closeDate, changeRequestForm.closeDate) &&
        Objects.equals(this.reason, changeRequestForm.reason) &&
        Objects.equals(this.svdTicketId, changeRequestForm.svdTicketId) &&
        Objects.equals(this.bankShortName, changeRequestForm.bankShortName) &&
        Objects.equals(this.crfIps, changeRequestForm.crfIps);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, crfAccess, crfType, crfDept, requestedDate, priority, openDate, closeDate, reason, svdTicketId, bankShortName, crfIps);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ChangeRequestForm {\n");
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    crfAccess: ").append(toIndentedString(crfAccess)).append("\n");
    sb.append("    crfType: ").append(toIndentedString(crfType)).append("\n");
    sb.append("    crfDept: ").append(toIndentedString(crfDept)).append("\n");
    sb.append("    requestedDate: ").append(toIndentedString(requestedDate)).append("\n");
    sb.append("    priority: ").append(toIndentedString(priority)).append("\n");
    sb.append("    openDate: ").append(toIndentedString(openDate)).append("\n");
    sb.append("    closeDate: ").append(toIndentedString(closeDate)).append("\n");
    sb.append("    reason: ").append(toIndentedString(reason)).append("\n");
    sb.append("    svdTicketId: ").append(toIndentedString(svdTicketId)).append("\n");
    sb.append("    bankShortName: ").append(toIndentedString(bankShortName)).append("\n");
    sb.append("    crfIps: ").append(toIndentedString(crfIps)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

