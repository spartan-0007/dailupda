package in.iftas.sfms.core.api.impl;

/*
 * Copyright (C) 2024 Iftas Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Iftas Inc. ("Confidential Information"). You shall not disclose
 * such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with Iftas Inc.
 *
 * Author: Manoj.Illa
 * Date: July 11, 2024
 */

import in.iftas.sfms.core.api.CrfApi;
import in.iftas.sfms.core.exception.ResourceNotFoundException;
import in.iftas.sfms.core.model.ChangeRequestForm;
import in.iftas.sfms.core.model.ModelApiResponse;
import in.iftas.sfms.core.service.ChangeRequestFormService;
import jakarta.persistence.EntityNotFoundException;
import org.apache.poi.ss.usermodel.Workbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.http.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;

@RestController
public class CrfApiImpl implements CrfApi {
    private static final Logger logger = LoggerFactory.getLogger(CrfApiImpl.class);

    private final ChangeRequestFormService changeRequestFormService;

    public CrfApiImpl(ChangeRequestFormService changeRequestFormService) {
        this.changeRequestFormService = changeRequestFormService;
    }

    @Override
    @PreAuthorize("hasAuthority('ROLE_operator-read-write')")
    public ResponseEntity<String> createCrf(ChangeRequestForm changeRequestForm) {
        logger.info("Entering createCrf method with changeRequestForm: {}", changeRequestForm);
        try {
            changeRequestFormService.saveChangeRequestForm(changeRequestForm);
            logger.info("Change request form created successfully");
            return new ResponseEntity<>("Change request form created successfully", HttpStatus.CREATED);
        } catch (EntityNotFoundException e) {
            logger.error("Change Request Form not found: {}", e.getMessage());
            return new ResponseEntity<>("Change Request Form not found", HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            logger.error("Internal server error: {}", e.getMessage());
            return new ResponseEntity<>("Internal server error", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    @PreAuthorize("hasAnyAuthority('ROLE_operator-read-write','ROLE_operator-read-only')")
    public ResponseEntity<List<ChangeRequestForm>> crfGet(Long crlId, String ipAddress, String bankShortName) {
        logger.info("Entering crfGet method with crlId: {}, ipAddress: {}, bankShortName: {}", crlId, ipAddress, bankShortName);
        try {
            List<ChangeRequestForm> changeRequestForms = changeRequestFormService.getChangeRequestForms(crlId, ipAddress, bankShortName);

            if (changeRequestForms.isEmpty()) {
                logger.warn("No change request forms found for crlId: {}, ipAddress: {}, bankShortName: {}", crlId, ipAddress, bankShortName);
                return new ResponseEntity<>(HttpStatus.NOT_FOUND);
            }
            logger.info("Returning {} change request forms", changeRequestForms.size());

            return new ResponseEntity<>(changeRequestForms, HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error occurred while getting change request forms. Error: {}", e.getMessage());
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

    @Override
    @PreAuthorize("hasAuthority('ROLE_operator-read-write')")
    public ResponseEntity<ModelApiResponse> updateCrf(ChangeRequestForm changeRequestForm) {
        ModelApiResponse modelApiResponse = new ModelApiResponse();
        logger.info("Attempting to update Change Request Form with ID: {}", changeRequestForm.getId());
        try {
            changeRequestFormService.updateChangeRequestForm(changeRequestForm);
            logger.info("Change Request Form with ID: {} updated successfully.", changeRequestForm.getId());
            modelApiResponse.setMessage("Change Request Form updated successfully.");
            modelApiResponse.setSuccess(true);
            return new ResponseEntity<>(modelApiResponse, HttpStatus.OK);
        } catch (ResourceNotFoundException e) {
            logger.error("Failed to update Change Request Form. {}", e.getMessage());
            modelApiResponse.setMessage("Failed to update CRF.");
            modelApiResponse.setSuccess(false);
            return new ResponseEntity<>(modelApiResponse, HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            logger.error("Internal server error during Change Request Form update: {}", e.getMessage(), e);
            modelApiResponse.setMessage("Internal Server Error.");
            modelApiResponse.setSuccess(false);
            return new ResponseEntity<>(modelApiResponse, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<Resource> downloadCrfExcel(@RequestParam(value = "crfId") Long crfId) {
        logger.info("Attempting to download Excel for CRF with ID: {}", crfId);

        try {
            Workbook workbook = changeRequestFormService.downloadCrf(crfId);
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();

            workbook.write(outputStream);
            workbook.close();

            InputStreamResource resource = new InputStreamResource(new ByteArrayInputStream(outputStream.toByteArray()));
            HttpHeaders headers = new HttpHeaders();
            headers.setContentDisposition(ContentDisposition.attachment().filename("CRFData_" + crfId + ".xls").build());
            headers.setContentLength(outputStream.size());
            headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);

            logger.info("Successfully retrieved Excel for CRF with ID: {}", crfId);
            return new ResponseEntity<>(resource, headers, HttpStatus.OK);
        } catch (ResourceNotFoundException e) {
            logger.error("Failed to find data for CRF with ID: {}. Error: {}", crfId, e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        } catch (IOException e) {
            logger.error("Error during file generation for CRF with ID: {}. Error: {}", crfId, e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        } catch (Exception e) {
            logger.error("Internal server error during download of CRF with ID: {}. Error: {}", crfId, e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
}
