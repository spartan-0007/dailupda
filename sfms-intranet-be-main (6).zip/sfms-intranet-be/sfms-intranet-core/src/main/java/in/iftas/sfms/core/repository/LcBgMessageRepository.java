package in.iftas.sfms.core.repository;/*
 * Copyright (C) 2024 Iftas Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Iftas Inc. ("Confidential Information"). You shall not disclose
 * such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with Iftas Inc.
 *
 * Author: Manoj.Illa
 * Date: July 11, 2024
 */

import in.iftas.sfms.core.dto.BankMessageCountDTO;
import in.iftas.sfms.core.entity.LcBgMessageEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface LcBgMessageRepository extends JpaRepository<LcBgMessageEntity, Long>, JpaSpecificationExecutor<LcBgMessageEntity> {

    @Query("SELECT new in.iftas.sfms.core.dto.BankMessageCountDTO(b.id, b.bankName, COUNT(m.id)) " +
            "FROM LcBgMessageEntity m " +
            "JOIN BranchEntity br ON m.senderIfsc = br.ifscCode " +
            "JOIN BankEntity b ON br.bank.id = b.id " +
            "WHERE m.messageDateTime BETWEEN :fromDate AND :toDate " +
            "AND (:bankId IS NULL OR b.id = :bankId) " +
            "GROUP BY b.id, b.bankName " +
            "ORDER BY b.bankName DESC")
    List<BankMessageCountDTO> findMessagesByBankNameAndDateRange(
            @Param("fromDate") LocalDateTime fromDate,
            @Param("toDate") LocalDateTime toDate,
            @Param("bankId") Long bankId);

    @Query("SELECT m FROM LcBgMessageEntity m " +
            "JOIN BranchEntity br ON m.senderIfsc = br.ifscCode " +
            "JOIN BankEntity b ON br.bank.id = b.id " +
            "WHERE (b.id = :bankId) " +
            "AND m.messageDateTime BETWEEN :fromDate AND :toDate " +
            "ORDER BY m.messageDateTime")
    List<LcBgMessageEntity> findLcBgMessagesBankWiseByDateRangeAndBankId(
            @Param("fromDate") LocalDateTime fromDate,
            @Param("toDate") LocalDateTime toDate,
            @Param("bankId") Long bankId);

    Optional<LcBgMessageEntity> findBySenderReferenceNumber(String senderReferenceNumber);

    List<LcBgMessageEntity> findBySenderReferenceNumberIn(List<String> senderReferences);
}
