package in.iftas.sfms.core.model;

import java.net.URI;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;
import org.openapitools.jackson.nullable.JsonNullable;
import java.time.OffsetDateTime;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


import java.util.*;
import jakarta.annotation.Generated;

/**
 * AuditLog
 */


public class AuditLog {

  private Long id;

  private String fileName;

  private String operation;

  @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
  private Date operationTimestamp;

  private String details;

  private String status;

  private Long lastSuccessfulBatch;

  private String errorDetails;

  public AuditLog id(Long id) {
    this.id = id;
    return this;
  }

  /**
   * Get id
   * @return id
   */
  
  @Schema(name = "id", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("id")
  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public AuditLog fileName(String fileName) {
    this.fileName = fileName;
    return this;
  }

  /**
   * Get fileName
   * @return fileName
   */
  
  @Schema(name = "fileName", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("fileName")
  public String getFileName() {
    return fileName;
  }

  public void setFileName(String fileName) {
    this.fileName = fileName;
  }

  public AuditLog operation(String operation) {
    this.operation = operation;
    return this;
  }

  /**
   * Get operation
   * @return operation
   */
  
  @Schema(name = "operation", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("operation")
  public String getOperation() {
    return operation;
  }

  public void setOperation(String operation) {
    this.operation = operation;
  }

  public AuditLog operationTimestamp(Date operationTimestamp) {
    this.operationTimestamp = operationTimestamp;
    return this;
  }

  /**
   * Get operationTimestamp
   * @return operationTimestamp
   */
  @Valid 
  @Schema(name = "operationTimestamp", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("operationTimestamp")
  public Date getOperationTimestamp() {
    return operationTimestamp;
  }

  public void setOperationTimestamp(Date operationTimestamp) {
    this.operationTimestamp = operationTimestamp;
  }

  public AuditLog details(String details) {
    this.details = details;
    return this;
  }

  /**
   * Get details
   * @return details
   */
  
  @Schema(name = "details", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("details")
  public String getDetails() {
    return details;
  }

  public void setDetails(String details) {
    this.details = details;
  }

  public AuditLog status(String status) {
    this.status = status;
    return this;
  }

  /**
   * Get status
   * @return status
   */
  
  @Schema(name = "status", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("status")
  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public AuditLog lastSuccessfulBatch(Long lastSuccessfulBatch) {
    this.lastSuccessfulBatch = lastSuccessfulBatch;
    return this;
  }

  /**
   * Get lastSuccessfulBatch
   * @return lastSuccessfulBatch
   */
  
  @Schema(name = "lastSuccessfulBatch", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("lastSuccessfulBatch")
  public Long getLastSuccessfulBatch() {
    return lastSuccessfulBatch;
  }

  public void setLastSuccessfulBatch(Long lastSuccessfulBatch) {
    this.lastSuccessfulBatch = lastSuccessfulBatch;
  }

  public AuditLog errorDetails(String errorDetails) {
    this.errorDetails = errorDetails;
    return this;
  }

  /**
   * Get errorDetails
   * @return errorDetails
   */
  
  @Schema(name = "errorDetails", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("errorDetails")
  public String getErrorDetails() {
    return errorDetails;
  }

  public void setErrorDetails(String errorDetails) {
    this.errorDetails = errorDetails;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    AuditLog auditLog = (AuditLog) o;
    return Objects.equals(this.id, auditLog.id) &&
        Objects.equals(this.fileName, auditLog.fileName) &&
        Objects.equals(this.operation, auditLog.operation) &&
        Objects.equals(this.operationTimestamp, auditLog.operationTimestamp) &&
        Objects.equals(this.details, auditLog.details) &&
        Objects.equals(this.status, auditLog.status) &&
        Objects.equals(this.lastSuccessfulBatch, auditLog.lastSuccessfulBatch) &&
        Objects.equals(this.errorDetails, auditLog.errorDetails);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, fileName, operation, operationTimestamp, details, status, lastSuccessfulBatch, errorDetails);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class AuditLog {\n");
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    fileName: ").append(toIndentedString(fileName)).append("\n");
    sb.append("    operation: ").append(toIndentedString(operation)).append("\n");
    sb.append("    operationTimestamp: ").append(toIndentedString(operationTimestamp)).append("\n");
    sb.append("    details: ").append(toIndentedString(details)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    lastSuccessfulBatch: ").append(toIndentedString(lastSuccessfulBatch)).append("\n");
    sb.append("    errorDetails: ").append(toIndentedString(errorDetails)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

