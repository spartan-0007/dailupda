package in.iftas.sfms.core.model;

import java.net.URI;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;
import org.openapitools.jackson.nullable.JsonNullable;
import java.time.OffsetDateTime;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


import java.util.*;
import jakarta.annotation.Generated;

/**
 * Marquee
 */


public class Marquee {

  private Long id;

  private String content;

  @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
  private Date startDate;

  @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
  private Date endDate;

  private String userType;

  private Boolean isGlobal;

  private String bankIds;

  public Marquee id(Long id) {
    this.id = id;
    return this;
  }

  /**
   * Unique identifier for the marquee
   * @return id
   */
  
  @Schema(name = "id", description = "Unique identifier for the marquee", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("id")
  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public Marquee content(String content) {
    this.content = content;
    return this;
  }

  /**
   * The content of the marquee
   * @return content
   */
  
  @Schema(name = "content", description = "The content of the marquee", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("content")
  public String getContent() {
    return content;
  }

  public void setContent(String content) {
    this.content = content;
  }

  public Marquee startDate(Date startDate) {
    this.startDate = startDate;
    return this;
  }

  /**
   * The start date of the marquee
   * @return startDate
   */
  @Valid 
  @Schema(name = "startDate", description = "The start date of the marquee", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("startDate")
  public Date getStartDate() {
    return startDate;
  }

  public void setStartDate(Date startDate) {
    this.startDate = startDate;
  }

  public Marquee endDate(Date endDate) {
    this.endDate = endDate;
    return this;
  }

  /**
   * The end date of the marquee
   * @return endDate
   */
  @Valid 
  @Schema(name = "endDate", description = "The end date of the marquee", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("endDate")
  public Date getEndDate() {
    return endDate;
  }

  public void setEndDate(Date endDate) {
    this.endDate = endDate;
  }

  public Marquee userType(String userType) {
    this.userType = userType;
    return this;
  }

  /**
   * The type of users who should see the marquee (e.g., bankers, operators)
   * @return userType
   */
  
  @Schema(name = "userType", description = "The type of users who should see the marquee (e.g., bankers, operators)", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("userType")
  public String getUserType() {
    return userType;
  }

  public void setUserType(String userType) {
    this.userType = userType;
  }

  public Marquee isGlobal(Boolean isGlobal) {
    this.isGlobal = isGlobal;
    return this;
  }

  /**
   * Whether the marquee is for all users
   * @return isGlobal
   */
  
  @Schema(name = "isGlobal", description = "Whether the marquee is for all users", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("isGlobal")
  public Boolean getIsGlobal() {
    return isGlobal;
  }

  public void setIsGlobal(Boolean isGlobal) {
    this.isGlobal = isGlobal;
  }

  public Marquee bankIds(String bankIds) {
    this.bankIds = bankIds;
    return this;
  }

  /**
   * Comma-separated list of bank IDs associated with the marquee
   * @return bankIds
   */
  
  @Schema(name = "bankIds", description = "Comma-separated list of bank IDs associated with the marquee", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("bankIds")
  public String getBankIds() {
    return bankIds;
  }

  public void setBankIds(String bankIds) {
    this.bankIds = bankIds;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Marquee marquee = (Marquee) o;
    return Objects.equals(this.id, marquee.id) &&
        Objects.equals(this.content, marquee.content) &&
        Objects.equals(this.startDate, marquee.startDate) &&
        Objects.equals(this.endDate, marquee.endDate) &&
        Objects.equals(this.userType, marquee.userType) &&
        Objects.equals(this.isGlobal, marquee.isGlobal) &&
        Objects.equals(this.bankIds, marquee.bankIds);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, content, startDate, endDate, userType, isGlobal, bankIds);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Marquee {\n");
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    content: ").append(toIndentedString(content)).append("\n");
    sb.append("    startDate: ").append(toIndentedString(startDate)).append("\n");
    sb.append("    endDate: ").append(toIndentedString(endDate)).append("\n");
    sb.append("    userType: ").append(toIndentedString(userType)).append("\n");
    sb.append("    isGlobal: ").append(toIndentedString(isGlobal)).append("\n");
    sb.append("    bankIds: ").append(toIndentedString(bankIds)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

