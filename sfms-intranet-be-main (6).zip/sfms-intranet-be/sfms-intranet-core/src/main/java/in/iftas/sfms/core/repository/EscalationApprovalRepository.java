package in.iftas.sfms.core.repository;

import in.iftas.sfms.core.entity.EscalationApprovalEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface EscalationApprovalRepository extends JpaRepository<EscalationApprovalEntity, Long> {

    /**
     * Find approvals by current checker and status
     * Used in: getPendingApprovalsForUser()
     */
    List<EscalationApprovalEntity> findByCurrentCheckerIdAndStatus(
            String currentCheckerId, 
            EscalationApprovalEntity.Status status
    );

    /**
     * Find existing pending approval for an escalation
     * Used in: validateApprovalRequest() to prevent duplicate approvals
     */
    Optional<EscalationApprovalEntity> findByEscalationIdAndStatus(
            Long escalationId, 
            EscalationApprovalEntity.Status status
    );

    /**
     * Find approvals by maker - useful for maker dashboard
     * Used in: UI to show maker's submitted requests
     */
    List<EscalationApprovalEntity> findByMakerIdOrderByCreatedDateDesc(String makerId);

    /**
     * Count pending approvals for a checker - dashboard metric
     * Used in: Dashboard to show workload
     */
    @Query("SELECT COUNT(ea) FROM EscalationApprovalEntity ea WHERE " +
           "ea.currentCheckerId = :checkerId AND ea.status = 'PENDING'")
    Long countPendingApprovalsByChecker(@Param("checkerId") String checkerId);
}