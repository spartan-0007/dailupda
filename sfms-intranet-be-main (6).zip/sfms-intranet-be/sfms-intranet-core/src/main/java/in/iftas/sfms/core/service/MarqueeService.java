package in.iftas.sfms.core.service;

/*
 * Copyright (C) 2024 Iftas Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Iftas Inc. ("Confidential Information"). You shall not disclose
 * such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with Iftas Inc.
 *
 * Author: Manoj.Illa
 * Date: July 11, 2024
 */

import in.iftas.sfms.core.entity.BankEntity;
import in.iftas.sfms.core.entity.MarqueeEntity;
import in.iftas.sfms.core.exception.GlobalMarqueeException;
import in.iftas.sfms.core.exception.ResourceNotFoundException;
import in.iftas.sfms.core.mapper.MarqueeMapper;
import in.iftas.sfms.core.model.Marquee;
import in.iftas.sfms.core.repository.BankRepository;
import in.iftas.sfms.core.repository.MarqueeRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class MarqueeService {

    private static final Logger logger = LoggerFactory.getLogger(MarqueeService.class);
    private final MarqueeMapper marqueeMapper;
    private final MarqueeRepository marqueeRepository;
    private final BankRepository bankRepository;

    @Autowired
    public MarqueeService(MarqueeMapper marqueeMapper, MarqueeRepository marqueeRepository, BankRepository bankRepository) {
        this.marqueeMapper = marqueeMapper;
        this.marqueeRepository = marqueeRepository;
        this.bankRepository = bankRepository;
    }

    public List<Marquee> getMarquees(Long bankId) {
        logger.info("Entering getMarquees method with bankId: {}", bankId);
        List<MarqueeEntity> marqueeEntities;

        if (bankId != null) {
            marqueeEntities = marqueeRepository.findByBanks_Id(bankId);
        } else {
            marqueeEntities = marqueeRepository.findAll();
        }

        return marqueeEntities.stream()
                .map(marqueeMapper::toModel)
                .collect(Collectors.toList());
    }

    @Transactional
    public Marquee createMarquee(Marquee marquee) {
        logger.info("Entering createMarquee method with marquee data: {}", marquee);

        MarqueeEntity marqueeEntity = marqueeMapper.toEntity(marquee);
        logger.debug("Mapped Marquee to MarqueeEntity: {}", marqueeEntity);

        if (Boolean.TRUE.equals(marquee.getIsGlobal())) {
            logger.info("Set IsGlobal is true");
            List<MarqueeEntity> existingGlobalMarquees = marqueeRepository.findByIsGlobalTrue();
            if (!existingGlobalMarquees.isEmpty()) {
                logger.error("Global marquee already exists. Cannot create another global marquee.");
                throw new GlobalMarqueeException("Global marquee already exists");
            }
        }

        if (marquee.getBankIds() != null && !marquee.getBankIds().isEmpty()) {
            List<BankEntity> banks = Arrays.stream(marquee.getBankIds().split(","))
                    .map(id -> {
                        return bankRepository.findById(Integer.parseInt(id))
                                .orElseThrow(() -> new ResourceNotFoundException("Bank not found: " + id));
                    })
                    .collect(Collectors.toList());
            marqueeEntity.setBanks(banks);
            logger.debug("Banks associated with marquee: {}", banks);
        }

        MarqueeEntity newMarqueeEntity = marqueeRepository.save(marqueeEntity);
        logger.info("MarqueeEntity saved successfully with ID: {}", newMarqueeEntity.getId());

        Marquee newMarquee = marqueeMapper.toModel(newMarqueeEntity);
        logger.info("Exiting createMarquee method with new marquee data: {}", newMarquee);

        return newMarquee;
    }

    public void deleteMarqueeById(Long marqueeId) {
        logger.info("Entering deleteMarqueeById with id: {}", marqueeId);

        if (marqueeRepository.existsById(marqueeId)) {
            logger.info("Marquee with id: {}, proceeding to delete", marqueeId);

            marqueeRepository.deleteById(marqueeId);
            logger.info("Marquee deleted successfully with id: {}", marqueeId);

        } else {
            logger.warn("Marquee not found with id: {}", marqueeId);

            throw new ResourceNotFoundException("Marquee not found with id " + marqueeId);
        }
        logger.info("Exiting deleteMarqueeById");
    }

    @Transactional
    public Marquee updateMarquee( Marquee marquee) {
        logger.info("Entering updateMarquee method with marquee data: {}", marquee);

        MarqueeEntity existingMarqueeEntity = marqueeRepository.findById(marquee.getId())
                .orElseThrow(() -> new ResourceNotFoundException("Marquee not found with id: " + marquee.getId()));
        logger.debug("Found existing marquee: {}", existingMarqueeEntity);

        if (Boolean.TRUE.equals(marquee.getIsGlobal())) {
            logger.info("Checking global marquee constraint");
            List<MarqueeEntity> existingGlobalMarquees = marqueeRepository.findByIsGlobalTrue();
            boolean hasConflict = existingGlobalMarquees.stream()
                    .anyMatch(m -> !m.getId().equals(marquee.getId()) && Boolean.TRUE.equals(m.getIsGlobal()));
            if (hasConflict) {
                logger.error("Another global marquee exists. Cannot update to global.");
                throw new GlobalMarqueeException("Another global marquee already exists");
            }
        }

        existingMarqueeEntity.setContent(marquee.getContent());
        existingMarqueeEntity.setStartDate(
                marquee.getStartDate().toInstant()
                        .atZone(ZoneId.systemDefault())
                        .toLocalDate()
        );

        existingMarqueeEntity.setEndDate(
                marquee.getEndDate().toInstant()
                        .atZone(ZoneId.systemDefault())
                        .toLocalDate()
        );
        existingMarqueeEntity.setUserType(marquee.getUserType());
        existingMarqueeEntity.setIsGlobal(marquee.getIsGlobal());

        if (marquee.getBankIds() != null && !marquee.getBankIds().isEmpty()) {
            List<BankEntity> banks = Arrays.stream(marquee.getBankIds().split(","))
                    .map(bankId -> {
                        return bankRepository.findById(Integer.parseInt(bankId))
                                .orElseThrow(() -> new ResourceNotFoundException("Bank not found: " + bankId));
                    })
                    .collect(Collectors.toList());
            existingMarqueeEntity.setBanks(banks);
            logger.debug("Updated banks associated with marquee: {}", banks);
        } else {
            existingMarqueeEntity.setBanks(new ArrayList<>());
        }

        MarqueeEntity updatedMarqueeEntity = marqueeRepository.save(existingMarqueeEntity);
        logger.info("MarqueeEntity updated successfully with ID: {}", updatedMarqueeEntity.getId());

        Marquee updatedMarquee = marqueeMapper.toModel(updatedMarqueeEntity);
        logger.info("Exiting updateMarquee method with updated marquee data: {}", updatedMarquee);

        return updatedMarquee;
    }
}