package in.iftas.sfms.core.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import in.iftas.sfms.common.entity.ApprovalRequestEntity;
import in.iftas.sfms.common.repository.ApprovalRequestRepository;
import in.iftas.sfms.core.entity.BankEntity;
import in.iftas.sfms.core.exception.BankAlreadyExistsException;
import in.iftas.sfms.core.exception.Branchalreadyexists;
import in.iftas.sfms.core.model.Bank;
import in.iftas.sfms.core.repository.BankRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.stereotype.Service;
import in.iftas.sfms.core.exception.ResourceNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import in.iftas.sfms.core.validations.BankValidator;
import org.springframework.web.server.ResponseStatusException;

@Service
@Slf4j
public class BankApprovalService {

    private final ObjectMapper objectMapper;
    private final ApprovalRequestRepository approvalRequestRepository;
    private final BankValidator bankValidator;
    private final BankRepository bankRepository;

    @Autowired
    public BankApprovalService(
            BankRepository bankRepository,
            ObjectMapper objectMapper,
            ApprovalRequestRepository approvalRequestRepository,
            BankValidator bankValidator) {
        this.objectMapper = objectMapper;
        this.approvalRequestRepository = approvalRequestRepository;
        this.bankValidator = bankValidator;
        this.bankRepository = bankRepository;
    }

    /**
     * Creates a bank approval request by converting Bank object to JSON string
     *
     * @param bank The bank details for approval
     * @throws IllegalArgumentException If validation fails
     * @throws IOException              If there's an error processing the bank data
     */
    public void createBankApproval(Bank bank) throws IllegalArgumentException, IOException {
        log.info("Creating bank approval request");

        try {
            bankValidator.validateBankCreation(bank);
            Jwt jwt = (Jwt) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
            String bankJson = objectMapper.writeValueAsString(bank);
            ApprovalRequestEntity entity = ApprovalRequestEntity.builder()
                    .entityType(ApprovalRequestEntity.EntityType.BANK.name())
                    .actionType(ApprovalRequestEntity.ActionType.CREATE.name())
                    .requestData(bankJson)
                    .status(ApprovalRequestEntity.Status.PENDING.name())
                    .makerName(jwt.getClaimAsString("name"))
                    .build();
            entity.setCreatedBy(jwt.getClaimAsString("sub"));
            approvalRequestRepository.save(entity);
            log.info("Bank approval request created successfully");

        } catch (BankAlreadyExistsException | Branchalreadyexists e) {
            log.error("Duplicate resource detected: {}", e.getMessage());
            throw e;
        }
        catch (IllegalArgumentException e) {
            log.error("Invalid approval request: {}", e.getMessage());
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage());
        }
    }
    /**
     * Creates a bank update approval request
     *
     * @param id   The ID of the bank to update
     * @param bank The updated bank details
     * @throws ResourceNotFoundException If the bank with the given ID doesn't exist
     * @throws IOException If there's an error processing the bank data
     */
    public void updateBankApproval(Integer id, Bank bank) throws ResourceNotFoundException, IOException {
        log.info("Creating bank update approval request for bank ID: {}", id);

        BankEntity bankEntity = bankRepository.findById(bank.getId()).orElseThrow(() -> {
            log.warn("Bank not found with id: {}", bank.getId());
            return new ResourceNotFoundException("Bank not found with id " + bank.getId());
        });

        try {
            Jwt jwt = (Jwt) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
            String bankJson = objectMapper.writeValueAsString(bank);
            ApprovalRequestEntity entity = ApprovalRequestEntity.builder()
                    .entityType(ApprovalRequestEntity.EntityType.BANK.name())
                    .actionType(ApprovalRequestEntity.ActionType.UPDATE.name())
                    .entityId(String.valueOf(bank.getId()))
                    .requestData(bankJson)
                    .status(ApprovalRequestEntity.Status.PENDING.name())
                    .makerName(jwt.getClaimAsString("name"))
                    .build();
            entity.setCreatedBy(jwt.getClaimAsString("sub"));
            approvalRequestRepository.save(entity);
            log.info("Bank update approval request created successfully for bank ID: {}", id);
        } catch (IOException e) {
            log.error("Error creating bank update approval request: {}", e.getMessage(), e);
            throw e;
        }
    }
    public void deleteBankApproval(Integer id) throws ResourceNotFoundException, IOException {
        log.info("Creating bank deletion approval request for bank ID: {}", id);
        BankEntity bankEntity = bankRepository.findById(id).orElseThrow(() -> {
            log.warn("Bank not found with id: {}", id);
            return new ResourceNotFoundException("Bank not found with id " + id);
        });

        try {
            Jwt jwt = (Jwt) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
            Map<String, Object> requestData = new HashMap<>();
            requestData.put("id", id);
            String requestDataJson = objectMapper.writeValueAsString(requestData);

            ApprovalRequestEntity entity = ApprovalRequestEntity.builder()
                    .entityType(ApprovalRequestEntity.EntityType.BANK.name())
                    .actionType(ApprovalRequestEntity.ActionType.DELETE.name())
                    .entityId(String.valueOf(id))
                    .requestData(requestDataJson)
                    .status(ApprovalRequestEntity.Status.PENDING.name())
                    .makerName(jwt.getClaimAsString("name"))
                    .build();
            entity.setCreatedBy(jwt.getClaimAsString("sub"));
            approvalRequestRepository.save(entity);
            log.info("Bank deletion approval request created successfully for bank ID: {}", id);
        } catch (Exception e) {
            log.error("Error creating bank deletion approval request: {}", e.getMessage(), e);
            throw e;
        }
    }
}