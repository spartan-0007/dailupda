package in.iftas.sfms.core.model;

import java.net.URI;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonTypeName;
import in.iftas.sfms.core.model.CGBSFileDetails;
import java.util.ArrayList;
import java.util.List;
import org.openapitools.jackson.nullable.JsonNullable;
import java.time.OffsetDateTime;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


import java.util.*;
import jakarta.annotation.Generated;

/**
 * GetCGBSFiles200Response
 */

@JsonTypeName("getCGBSFiles_200_response")

public class GetCGBSFiles200Response {

  @Valid
  private List<@Valid CGBSFileDetails> files;

  public GetCGBSFiles200Response files(List<@Valid CGBSFileDetails> files) {
    this.files = files;
    return this;
  }

  public GetCGBSFiles200Response addItem(CGBSFileDetails filesItem) {
    if (this.files == null) {
      this.files = new ArrayList<>();
    }
    this.files.add(filesItem);
    return this;
  }

  /**
   * Get files
   * @return files
   */
  @Valid 
  @Schema(name = "files", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("files")
  public List<@Valid CGBSFileDetails> getFiles() {
    return files;
  }

  public void setFiles(List<@Valid CGBSFileDetails> files) {
    this.files = files;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    GetCGBSFiles200Response getCGBSFiles200Response = (GetCGBSFiles200Response) o;
    return Objects.equals(this.files, getCGBSFiles200Response.files);
  }

  @Override
  public int hashCode() {
    return Objects.hash(files);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class GetCGBSFiles200Response {\n");
    sb.append("    files: ").append(toIndentedString(files)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

