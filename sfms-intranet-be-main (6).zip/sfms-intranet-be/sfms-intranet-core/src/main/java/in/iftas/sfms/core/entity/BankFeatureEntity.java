package in.iftas.sfms.core.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "i_bank_features", indexes = {
        @Index(name = "idx_bank_branch_ifsc_code", columnList = "bank_branch_ifsc_code"),
        @Index(name = "idx_neft_enabled", columnList = "neft_enabled"),
        @Index(name = "idx_rtgs_enabled", columnList = "rtgs_enabled"),
        @Index(name = "idx_lc_enabled", columnList = "lc_enabled"),
        @Index(name = "idx_bg_enabled", columnList = "bg_enabled"),
        @Index(name = "idx_others", columnList = "others")
})
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class BankFeatureEntity extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "bank_branch_ifsc_code", nullable = false)
    private BranchEntity bankBranch;

    @Column(name = "neft_enabled")
    private boolean neftEnabled;

    @Column(name = "rtgs_enabled")
    private boolean rtgsEnabled;

    @Column(name = "lc_enabled")
    private boolean lcEnabled;

    @Column(name = "bg_enabled")
    private boolean bgEnabled;

    @Column(name = "others")
    private boolean others;
}