package in.iftas.sfms.core.mapper;

import in.iftas.sfms.core.entity.EscalationContactEntity;
import in.iftas.sfms.core.model.EscalationContact;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.util.List;

@Mapper(componentModel = "spring") // Allows Spring to manage the mapper as a bean
public interface EscalationContactMapper {

    EscalationContactMapper INSTANCE = Mappers.getMapper(EscalationContactMapper.class);

    @Mapping(source = "level.id", target = "levelId")
        // Mapping level ID from entity to DTO
    EscalationContact toModel(EscalationContactEntity entity);

    @Mapping(source = "levelId", target = "level.id")
        // Mapping level ID from DTO to entity
    EscalationContactEntity toEntity(EscalationContact dto);

    // New method to convert a list of entities to a list of DTOs
    List<EscalationContact> toModelList(List<EscalationContactEntity> entities);

    // New method to convert a list of DTOs to a list of entities
    List<EscalationContactEntity> toEntityLst(List<EscalationContact> dtos);
}