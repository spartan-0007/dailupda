package in.iftas.sfms.core.mapper;

import in.iftas.sfms.core.entity.BankContactEntity;
import in.iftas.sfms.core.model.BranchContact;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.factory.Mappers;

@Mapper(componentModel = "spring")
public interface BankContactMapper {
    BankContactMapper INSTANCE = Mappers.getMapper(BankContactMapper.class);

    @Mapping(source = "id", target = "id")
    @Mapping(source = "email", target = "email")
    @Mapping(source = "mobile", target = "mobile")
    @Mapping(source = "landline", target = "landline")
    @Mapping(source = "createdBy", target = "createdBy")
    @Mapping(source = "createdDate", target = "createdDate")
    @Mapping(source = "lastModifiedBy", target = "lastModifiedBy")
    @Mapping(source = "lastModifiedDate", target = "lastModifiedDate")
    BranchContact toModel(BankContactEntity bankContactEntity);

    @Mapping(source = "id", target = "id")
    @Mapping(source = "email", target = "email")
    @Mapping(source = "mobile", target = "mobile")
    @Mapping(source = "landline", target = "landline")
    @Mapping(source = "createdBy", target = "createdBy")
    @Mapping(source = "createdDate", target = "createdDate")
    @Mapping(source = "lastModifiedBy", target = "lastModifiedBy")
    @Mapping(source = "lastModifiedDate", target = "lastModifiedDate")
    BankContactEntity toEntity(BranchContact bankContact);

    void toEntity(BranchContact bankContact, @MappingTarget BankContactEntity bankContactEntity);
}