package in.iftas.sfms.core.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "i_properties_file_details")
@Getter
@Setter
@Builder
@AllArgsConstructor
public class PropertiesFileEntity extends BaseEntity{
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "ifsc_code", nullable = false)
    private String ifscCode;

    @Column(name = "ifsc_types")
    private String ifscTypes;

    @Column(name = "bank_id")
    private Integer bankId;

}
