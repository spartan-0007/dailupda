package in.iftas.sfms.core.entity;

import jakarta.persistence.*;
import lombok.*;
import in.iftas.sfms.common.entity.BaseEntity;

import java.time.LocalDateTime;

@Entity
@Table(name = "i_escalation_approval_steps", indexes = {
        @Index(name = "idx_approval_level", columnList = "approval_id, level_number"),
        @Index(name = "idx_checker", columnList = "checker_id"),
        @Index(name = "idx_status", columnList = "status"),
        @Index(name = "idx_checker_status", columnList = "checker_id, status")
})
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class EscalationApprovalStepEntity extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "approval_id", nullable = false)
    private Long approvalId; // Links to EscalationApprovalEntity

    @Column(name = "level_number", nullable = false)
    private Integer levelNumber; // 1, 2, 3...

    @Column(name = "required_role", nullable = false)
    @Enumerated(EnumType.STRING)
    private Role requiredRole; // BANKER, OPERATOR

    // Checker details (person who needs to approve this step)
    @Column(name = "checker_id")
    private String checkerId;

    @Column(name = "checker_name")
    private String checkerName;

    @Column(name = "checker_role")
    @Enumerated(EnumType.STRING)
    private Role checkerRole;

    @Column(name = "status", nullable = false)
    @Enumerated(EnumType.STRING)
    private Status status;

    @Column(name = "action_date")
    private LocalDateTime actionDate;

    @Column(name = "comments", length = 1000)
    private String comments;

    @Column(name = "rejection_reason", length = 500)
    private String rejectionReason;

    @Column(name = "due_date")
    private LocalDateTime dueDate;

    public enum Status {
        PENDING, APPROVED, REJECTED
    }

    public enum Role {
        BANKER, OPERATOR, ADMIN
    }

    // Helper method for UI visibility
    public boolean shouldHideFromUser(String userId) {
        // Hide if this user already approved this step
        return userId.equals(checkerId) && Status.APPROVED.equals(status);
    }

    // Add foreign key relationship
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "approval_id", insertable = false, updatable = false)
    private EscalationApprovalEntity approval;
}