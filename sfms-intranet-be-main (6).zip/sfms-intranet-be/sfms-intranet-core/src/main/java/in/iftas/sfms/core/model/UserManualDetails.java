package in.iftas.sfms.core.model;

import java.net.URI;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import java.util.ArrayList;
import java.util.List;
import org.openapitools.jackson.nullable.JsonNullable;
import java.time.OffsetDateTime;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


import java.util.*;
import jakarta.annotation.Generated;

/**
 * UserManualDetails
 */


public class UserManualDetails {

  private String version;

  private String description;

  @Valid
  private List<Integer> bankIds = new ArrayList<>();

  // Add a no-args constructor
  public UserManualDetails() {

  }

  /**
   * Constructor with only required parameters
   */
  public UserManualDetails(String version, String description, List<Integer> bankIds) {
    this.version = version;
    this.description = description;
    this.bankIds = bankIds;
  }

  public UserManualDetails version(String version) {
    this.version = version;
    return this;
  }

  /**
   * The version of the user manual.
   * @return version
   */
  @NotNull 
  @Schema(name = "version", description = "The version of the user manual.", requiredMode = Schema.RequiredMode.REQUIRED)
  @JsonProperty("version")
  public String getVersion() {
    return version;
  }

  public void setVersion(String version) {
    this.version = version;
  }

  public UserManualDetails description(String description) {
    this.description = description;
    return this;
  }

  /**
   * A short description of the user manual.
   * @return description
   */
  @NotNull 
  @Schema(name = "description", description = "A short description of the user manual.", requiredMode = Schema.RequiredMode.REQUIRED)
  @JsonProperty("description")
  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public UserManualDetails bankIds(List<Integer> bankIds) {
    this.bankIds = bankIds;
    return this;
  }

  public UserManualDetails addItem(Integer bankIdsItem) {
    if (this.bankIds == null) {
      this.bankIds = new ArrayList<>();
    }
    this.bankIds.add(bankIdsItem);
    return this;
  }

  /**
   * List of bank IDs associated with the user manual.
   * @return bankIds
   */
  @NotNull 
  @Schema(name = "bankIds", description = "List of bank IDs associated with the user manual.", requiredMode = Schema.RequiredMode.REQUIRED)
  @JsonProperty("bankIds")
  public List<Integer> getBankIds() {
    return bankIds;
  }

  public void setBankIds(List<Integer> bankIds) {
    this.bankIds = bankIds;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    UserManualDetails userManualDetails = (UserManualDetails) o;
    return Objects.equals(this.version, userManualDetails.version) &&
        Objects.equals(this.description, userManualDetails.description) &&
        Objects.equals(this.bankIds, userManualDetails.bankIds);
  }

  @Override
  public int hashCode() {
    return Objects.hash(version, description, bankIds);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class UserManualDetails {\n");
    sb.append("    version: ").append(toIndentedString(version)).append("\n");
    sb.append("    description: ").append(toIndentedString(description)).append("\n");
    sb.append("    bankIds: ").append(toIndentedString(bankIds)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

