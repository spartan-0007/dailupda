package in.iftas.sfms.core.entity;/*
 * Copyright (C) 2024 Iftas Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Iftas Inc. ("Confidential Information"). You shall not disclose
 * such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with Iftas Inc.
 *
 * Author: Manoj.Illa
 * Date: July 11, 2024
 */

import jakarta.persistence.*;
import lombok.*;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDate;
import java.util.List;

@Entity
@Table(name = "i_marquee_global")
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class MarqueeEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @Column(name = "content", nullable = false)
    private String content;

    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    @Column(name = "start_date_time", nullable = false)
    private LocalDate startDate;

    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    @Column(name = "end_date_time", nullable = false)
    private LocalDate endDate;

    @Column(name = "user_type", nullable = false)
    private String userType;

    @Column(name = "is_global", nullable = false)
    private Boolean isGlobal;

    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(
            name = "i_marquee_bank",
            joinColumns = @JoinColumn(name = "marquee_id"),
            inverseJoinColumns = @JoinColumn(name = "bank_id")
    )
    private List<BankEntity> banks;


}
