package in.iftas.sfms.core.model;

import java.net.URI;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import in.iftas.sfms.core.model.EscalationApprovalStep;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.springframework.format.annotation.DateTimeFormat;
import org.openapitools.jackson.nullable.JsonNullable;
import java.time.OffsetDateTime;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


import java.util.*;
import jakarta.annotation.Generated;

/**
 * EscalationApproval
 */


public class EscalationApproval {

  private Long id;

  /**
   * Status of the approval request (auto-generated, ignore in requests)
   */
  public enum StatusEnum {
    PENDING("PENDING"),
    
    APPROVED("APPROVED"),
    
    REJECTED("REJECTED"),
    
    COMPLETED("COMPLETED");

    private String value;

    StatusEnum(String value) {
      this.value = value;
    }

    @JsonValue
    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static StatusEnum fromValue(String value) {
      for (StatusEnum b : StatusEnum.values()) {
        if (b.value.equals(value)) {
          return b;
        }
      }
      throw new IllegalArgumentException("Unexpected value '" + value + "'");
    }
  }

  private StatusEnum status;

  private String currentCheckerId;

  private String currentCheckerName;

  /**
   * Role of current checker (auto-generated, ignore in requests)
   */
  public enum CurrentCheckerRoleEnum {
    BANKER("BANKER"),
    
    OPERATOR("OPERATOR"),
    
    ADMIN("ADMIN");

    private String value;

    CurrentCheckerRoleEnum(String value) {
      this.value = value;
    }

    @JsonValue
    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static CurrentCheckerRoleEnum fromValue(String value) {
      for (CurrentCheckerRoleEnum b : CurrentCheckerRoleEnum.values()) {
        if (b.value.equals(value)) {
          return b;
        }
      }
      throw new IllegalArgumentException("Unexpected value '" + value + "'");
    }
  }

  private CurrentCheckerRoleEnum currentCheckerRole;

  private Integer currentLevel;

  private Integer totalLevels;

  @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
  private Date dueDate;

  @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
  private Date approvalDate;

  @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
  private Date completionDate;

  @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
  private Date createdDate;

  @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
  private Date updatedDate;

  private Double progressPercentage;

  private Boolean isOverdue;

  private String statusDisplayText;

  @Valid
  private List<@Valid EscalationApprovalStep> approvalSteps;

  private Long escalationId;

  /**
   * Type of action (CREATE, UPDATE, DELETE)
   */
  public enum ActionTypeEnum {
    CREATE("CREATE"),
    
    UPDATE("UPDATE"),
    
    DELETE("DELETE");

    private String value;

    ActionTypeEnum(String value) {
      this.value = value;
    }

    @JsonValue
    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static ActionTypeEnum fromValue(String value) {
      for (ActionTypeEnum b : ActionTypeEnum.values()) {
        if (b.value.equals(value)) {
          return b;
        }
      }
      throw new IllegalArgumentException("Unexpected value '" + value + "'");
    }
  }

  private ActionTypeEnum actionType;

  private Object requestData;

  private Object requestMetadata;

  private String makerId;

  private String makerName;

  /**
   * Role of maker
   */
  public enum MakerRoleEnum {
    BANKER("BANKER"),
    
    OPERATOR("OPERATOR"),
    
    ADMIN("ADMIN");

    private String value;

    MakerRoleEnum(String value) {
      this.value = value;
    }

    @JsonValue
    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static MakerRoleEnum fromValue(String value) {
      for (MakerRoleEnum b : MakerRoleEnum.values()) {
        if (b.value.equals(value)) {
          return b;
        }
      }
      throw new IllegalArgumentException("Unexpected value '" + value + "'");
    }
  }

  private MakerRoleEnum makerRole;

  private String rejectionReason;

  private String comments;

  private String reason;

  private String businessJustification;

  private String expectedImpact;

  // Add a no-args constructor
  public EscalationApproval() {

  }

  /**
   * Constructor with only required parameters
   */
  public EscalationApproval(ActionTypeEnum actionType, Object requestData, String makerId, String makerName, MakerRoleEnum makerRole) {
    this.actionType = actionType;
    this.requestData = requestData;
    this.makerId = makerId;
    this.makerName = makerName;
    this.makerRole = makerRole;
  }

  public EscalationApproval id(Long id) {
    this.id = id;
    return this;
  }

  /**
   * Unique identifier for the approval request (auto-generated, ignore in requests)
   * @return id
   */
  
  @Schema(name = "id", accessMode = Schema.AccessMode.READ_ONLY, description = "Unique identifier for the approval request (auto-generated, ignore in requests)", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("id")
  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public EscalationApproval status(StatusEnum status) {
    this.status = status;
    return this;
  }

  /**
   * Status of the approval request (auto-generated, ignore in requests)
   * @return status
   */
  
  @Schema(name = "status", accessMode = Schema.AccessMode.READ_ONLY, description = "Status of the approval request (auto-generated, ignore in requests)", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("status")
  public StatusEnum getStatus() {
    return status;
  }

  public void setStatus(StatusEnum status) {
    this.status = status;
  }

  public EscalationApproval currentCheckerId(String currentCheckerId) {
    this.currentCheckerId = currentCheckerId;
    return this;
  }

  /**
   * ID of the current checker (auto-generated, ignore in requests)
   * @return currentCheckerId
   */
  
  @Schema(name = "currentCheckerId", accessMode = Schema.AccessMode.READ_ONLY, description = "ID of the current checker (auto-generated, ignore in requests)", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("currentCheckerId")
  public String getCurrentCheckerId() {
    return currentCheckerId;
  }

  public void setCurrentCheckerId(String currentCheckerId) {
    this.currentCheckerId = currentCheckerId;
  }

  public EscalationApproval currentCheckerName(String currentCheckerName) {
    this.currentCheckerName = currentCheckerName;
    return this;
  }

  /**
   * Name of the current checker (auto-generated, ignore in requests)
   * @return currentCheckerName
   */
  
  @Schema(name = "currentCheckerName", accessMode = Schema.AccessMode.READ_ONLY, description = "Name of the current checker (auto-generated, ignore in requests)", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("currentCheckerName")
  public String getCurrentCheckerName() {
    return currentCheckerName;
  }

  public void setCurrentCheckerName(String currentCheckerName) {
    this.currentCheckerName = currentCheckerName;
  }

  public EscalationApproval currentCheckerRole(CurrentCheckerRoleEnum currentCheckerRole) {
    this.currentCheckerRole = currentCheckerRole;
    return this;
  }

  /**
   * Role of current checker (auto-generated, ignore in requests)
   * @return currentCheckerRole
   */
  
  @Schema(name = "currentCheckerRole", accessMode = Schema.AccessMode.READ_ONLY, description = "Role of current checker (auto-generated, ignore in requests)", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("currentCheckerRole")
  public CurrentCheckerRoleEnum getCurrentCheckerRole() {
    return currentCheckerRole;
  }

  public void setCurrentCheckerRole(CurrentCheckerRoleEnum currentCheckerRole) {
    this.currentCheckerRole = currentCheckerRole;
  }

  public EscalationApproval currentLevel(Integer currentLevel) {
    this.currentLevel = currentLevel;
    return this;
  }

  /**
   * Current approval level (auto-generated, ignore in requests)
   * @return currentLevel
   */
  
  @Schema(name = "currentLevel", accessMode = Schema.AccessMode.READ_ONLY, description = "Current approval level (auto-generated, ignore in requests)", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("currentLevel")
  public Integer getCurrentLevel() {
    return currentLevel;
  }

  public void setCurrentLevel(Integer currentLevel) {
    this.currentLevel = currentLevel;
  }

  public EscalationApproval totalLevels(Integer totalLevels) {
    this.totalLevels = totalLevels;
    return this;
  }

  /**
   * Total approval levels required (auto-generated, ignore in requests)
   * @return totalLevels
   */
  
  @Schema(name = "totalLevels", accessMode = Schema.AccessMode.READ_ONLY, description = "Total approval levels required (auto-generated, ignore in requests)", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("totalLevels")
  public Integer getTotalLevels() {
    return totalLevels;
  }

  public void setTotalLevels(Integer totalLevels) {
    this.totalLevels = totalLevels;
  }

  public EscalationApproval dueDate(Date dueDate) {
    this.dueDate = dueDate;
    return this;
  }

  /**
   * Due date for the current approval level (auto-generated, ignore in requests)
   * @return dueDate
   */
  @Valid 
  @Schema(name = "dueDate", accessMode = Schema.AccessMode.READ_ONLY, description = "Due date for the current approval level (auto-generated, ignore in requests)", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("dueDate")
  public Date getDueDate() {
    return dueDate;
  }

  public void setDueDate(Date dueDate) {
    this.dueDate = dueDate;
  }

  public EscalationApproval approvalDate(Date approvalDate) {
    this.approvalDate = approvalDate;
    return this;
  }

  /**
   * Date when the current level was approved/rejected (auto-generated, ignore in requests)
   * @return approvalDate
   */
  @Valid 
  @Schema(name = "approvalDate", accessMode = Schema.AccessMode.READ_ONLY, description = "Date when the current level was approved/rejected (auto-generated, ignore in requests)", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("approvalDate")
  public Date getApprovalDate() {
    return approvalDate;
  }

  public void setApprovalDate(Date approvalDate) {
    this.approvalDate = approvalDate;
  }

  public EscalationApproval completionDate(Date completionDate) {
    this.completionDate = completionDate;
    return this;
  }

  /**
   * Date when the approval workflow was completed (auto-generated, ignore in requests)
   * @return completionDate
   */
  @Valid 
  @Schema(name = "completionDate", accessMode = Schema.AccessMode.READ_ONLY, description = "Date when the approval workflow was completed (auto-generated, ignore in requests)", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("completionDate")
  public Date getCompletionDate() {
    return completionDate;
  }

  public void setCompletionDate(Date completionDate) {
    this.completionDate = completionDate;
  }

  public EscalationApproval createdDate(Date createdDate) {
    this.createdDate = createdDate;
    return this;
  }

  /**
   * Date when the approval request was created (auto-generated, ignore in requests)
   * @return createdDate
   */
  @Valid 
  @Schema(name = "createdDate", accessMode = Schema.AccessMode.READ_ONLY, description = "Date when the approval request was created (auto-generated, ignore in requests)", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("createdDate")
  public Date getCreatedDate() {
    return createdDate;
  }

  public void setCreatedDate(Date createdDate) {
    this.createdDate = createdDate;
  }

  public EscalationApproval updatedDate(Date updatedDate) {
    this.updatedDate = updatedDate;
    return this;
  }

  /**
   * Date when the approval request was last updated (auto-generated, ignore in requests)
   * @return updatedDate
   */
  @Valid 
  @Schema(name = "updatedDate", accessMode = Schema.AccessMode.READ_ONLY, description = "Date when the approval request was last updated (auto-generated, ignore in requests)", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("updatedDate")
  public Date getUpdatedDate() {
    return updatedDate;
  }

  public void setUpdatedDate(Date updatedDate) {
    this.updatedDate = updatedDate;
  }

  public EscalationApproval progressPercentage(Double progressPercentage) {
    this.progressPercentage = progressPercentage;
    return this;
  }

  /**
   * Progress percentage of the approval workflow 0-100 (response only)
   * @return progressPercentage
   */
  
  @Schema(name = "progressPercentage", accessMode = Schema.AccessMode.READ_ONLY, description = "Progress percentage of the approval workflow 0-100 (response only)", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("progressPercentage")
  public Double getProgressPercentage() {
    return progressPercentage;
  }

  public void setProgressPercentage(Double progressPercentage) {
    this.progressPercentage = progressPercentage;
  }

  public EscalationApproval isOverdue(Boolean isOverdue) {
    this.isOverdue = isOverdue;
    return this;
  }

  /**
   * Whether the approval is overdue (response only)
   * @return isOverdue
   */
  
  @Schema(name = "isOverdue", accessMode = Schema.AccessMode.READ_ONLY, description = "Whether the approval is overdue (response only)", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("isOverdue")
  public Boolean getIsOverdue() {
    return isOverdue;
  }

  public void setIsOverdue(Boolean isOverdue) {
    this.isOverdue = isOverdue;
  }

  public EscalationApproval statusDisplayText(String statusDisplayText) {
    this.statusDisplayText = statusDisplayText;
    return this;
  }

  /**
   * Human-readable status text for display (response only)
   * @return statusDisplayText
   */
  
  @Schema(name = "statusDisplayText", accessMode = Schema.AccessMode.READ_ONLY, description = "Human-readable status text for display (response only)", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("statusDisplayText")
  public String getStatusDisplayText() {
    return statusDisplayText;
  }

  public void setStatusDisplayText(String statusDisplayText) {
    this.statusDisplayText = statusDisplayText;
  }

  public EscalationApproval approvalSteps(List<@Valid EscalationApprovalStep> approvalSteps) {
    this.approvalSteps = approvalSteps;
    return this;
  }

  public EscalationApproval addItem(EscalationApprovalStep approvalStepsItem) {
    if (this.approvalSteps == null) {
      this.approvalSteps = new ArrayList<>();
    }
    this.approvalSteps.add(approvalStepsItem);
    return this;
  }

  /**
   * List of all approval steps in this workflow (response only)
   * @return approvalSteps
   */
  @Valid 
  @Schema(name = "approvalSteps", accessMode = Schema.AccessMode.READ_ONLY, description = "List of all approval steps in this workflow (response only)", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("approvalSteps")
  public List<@Valid EscalationApprovalStep> getApprovalSteps() {
    return approvalSteps;
  }

  public void setApprovalSteps(List<@Valid EscalationApprovalStep> approvalSteps) {
    this.approvalSteps = approvalSteps;
  }

  public EscalationApproval escalationId(Long escalationId) {
    this.escalationId = escalationId;
    return this;
  }

  /**
   * ID of the escalation (null for CREATE operations)
   * @return escalationId
   */
  
  @Schema(name = "escalationId", description = "ID of the escalation (null for CREATE operations)", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("escalationId")
  public Long getEscalationId() {
    return escalationId;
  }

  public void setEscalationId(Long escalationId) {
    this.escalationId = escalationId;
  }

  public EscalationApproval actionType(ActionTypeEnum actionType) {
    this.actionType = actionType;
    return this;
  }

  /**
   * Type of action (CREATE, UPDATE, DELETE)
   * @return actionType
   */
  @NotNull 
  @Schema(name = "actionType", description = "Type of action (CREATE, UPDATE, DELETE)", requiredMode = Schema.RequiredMode.REQUIRED)
  @JsonProperty("actionType")
  public ActionTypeEnum getActionType() {
    return actionType;
  }

  public void setActionType(ActionTypeEnum actionType) {
    this.actionType = actionType;
  }

  public EscalationApproval requestData(Object requestData) {
    this.requestData = requestData;
    return this;
  }

  /**
   * JSON data containing the escalation details
   * @return requestData
   */
  @NotNull 
  @Schema(name = "requestData", description = "JSON data containing the escalation details", requiredMode = Schema.RequiredMode.REQUIRED)
  @JsonProperty("requestData")
  public Object getRequestData() {
    return requestData;
  }

  public void setRequestData(Object requestData) {
    this.requestData = requestData;
  }

  public EscalationApproval requestMetadata(Object requestMetadata) {
    this.requestMetadata = requestMetadata;
    return this;
  }

  /**
   * Additional metadata for the request
   * @return requestMetadata
   */
  
  @Schema(name = "requestMetadata", description = "Additional metadata for the request", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("requestMetadata")
  public Object getRequestMetadata() {
    return requestMetadata;
  }

  public void setRequestMetadata(Object requestMetadata) {
    this.requestMetadata = requestMetadata;
  }

  public EscalationApproval makerId(String makerId) {
    this.makerId = makerId;
    return this;
  }

  /**
   * ID of the user who created the request
   * @return makerId
   */
  @NotNull 
  @Schema(name = "makerId", description = "ID of the user who created the request", requiredMode = Schema.RequiredMode.REQUIRED)
  @JsonProperty("makerId")
  public String getMakerId() {
    return makerId;
  }

  public void setMakerId(String makerId) {
    this.makerId = makerId;
  }

  public EscalationApproval makerName(String makerName) {
    this.makerName = makerName;
    return this;
  }

  /**
   * Name of the user who created the request
   * @return makerName
   */
  @NotNull 
  @Schema(name = "makerName", description = "Name of the user who created the request", requiredMode = Schema.RequiredMode.REQUIRED)
  @JsonProperty("makerName")
  public String getMakerName() {
    return makerName;
  }

  public void setMakerName(String makerName) {
    this.makerName = makerName;
  }

  public EscalationApproval makerRole(MakerRoleEnum makerRole) {
    this.makerRole = makerRole;
    return this;
  }

  /**
   * Role of maker
   * @return makerRole
   */
  @NotNull 
  @Schema(name = "makerRole", description = "Role of maker", requiredMode = Schema.RequiredMode.REQUIRED)
  @JsonProperty("makerRole")
  public MakerRoleEnum getMakerRole() {
    return makerRole;
  }

  public void setMakerRole(MakerRoleEnum makerRole) {
    this.makerRole = makerRole;
  }

  public EscalationApproval rejectionReason(String rejectionReason) {
    this.rejectionReason = rejectionReason;
    return this;
  }

  /**
   * Reason for rejection if status is REJECTED
   * @return rejectionReason
   */
  
  @Schema(name = "rejectionReason", description = "Reason for rejection if status is REJECTED", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("rejectionReason")
  public String getRejectionReason() {
    return rejectionReason;
  }

  public void setRejectionReason(String rejectionReason) {
    this.rejectionReason = rejectionReason;
  }

  public EscalationApproval comments(String comments) {
    this.comments = comments;
    return this;
  }

  /**
   * Additional comments for the request (request only)
   * @return comments
   */
  
  @Schema(name = "comments", description = "Additional comments for the request (request only)", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("comments")
  public String getComments() {
    return comments;
  }

  public void setComments(String comments) {
    this.comments = comments;
  }

  public EscalationApproval reason(String reason) {
    this.reason = reason;
    return this;
  }

  /**
   * Reason for the action (request only)
   * @return reason
   */
  
  @Schema(name = "reason", description = "Reason for the action (request only)", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("reason")
  public String getReason() {
    return reason;
  }

  public void setReason(String reason) {
    this.reason = reason;
  }

  public EscalationApproval businessJustification(String businessJustification) {
    this.businessJustification = businessJustification;
    return this;
  }

  /**
   * Business justification for the request (request only)
   * @return businessJustification
   */
  
  @Schema(name = "businessJustification", description = "Business justification for the request (request only)", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("businessJustification")
  public String getBusinessJustification() {
    return businessJustification;
  }

  public void setBusinessJustification(String businessJustification) {
    this.businessJustification = businessJustification;
  }

  public EscalationApproval expectedImpact(String expectedImpact) {
    this.expectedImpact = expectedImpact;
    return this;
  }

  /**
   * Expected impact of the change (request only)
   * @return expectedImpact
   */
  
  @Schema(name = "expectedImpact", description = "Expected impact of the change (request only)", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("expectedImpact")
  public String getExpectedImpact() {
    return expectedImpact;
  }

  public void setExpectedImpact(String expectedImpact) {
    this.expectedImpact = expectedImpact;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    EscalationApproval escalationApproval = (EscalationApproval) o;
    return Objects.equals(this.id, escalationApproval.id) &&
        Objects.equals(this.status, escalationApproval.status) &&
        Objects.equals(this.currentCheckerId, escalationApproval.currentCheckerId) &&
        Objects.equals(this.currentCheckerName, escalationApproval.currentCheckerName) &&
        Objects.equals(this.currentCheckerRole, escalationApproval.currentCheckerRole) &&
        Objects.equals(this.currentLevel, escalationApproval.currentLevel) &&
        Objects.equals(this.totalLevels, escalationApproval.totalLevels) &&
        Objects.equals(this.dueDate, escalationApproval.dueDate) &&
        Objects.equals(this.approvalDate, escalationApproval.approvalDate) &&
        Objects.equals(this.completionDate, escalationApproval.completionDate) &&
        Objects.equals(this.createdDate, escalationApproval.createdDate) &&
        Objects.equals(this.updatedDate, escalationApproval.updatedDate) &&
        Objects.equals(this.progressPercentage, escalationApproval.progressPercentage) &&
        Objects.equals(this.isOverdue, escalationApproval.isOverdue) &&
        Objects.equals(this.statusDisplayText, escalationApproval.statusDisplayText) &&
        Objects.equals(this.approvalSteps, escalationApproval.approvalSteps) &&
        Objects.equals(this.escalationId, escalationApproval.escalationId) &&
        Objects.equals(this.actionType, escalationApproval.actionType) &&
        Objects.equals(this.requestData, escalationApproval.requestData) &&
        Objects.equals(this.requestMetadata, escalationApproval.requestMetadata) &&
        Objects.equals(this.makerId, escalationApproval.makerId) &&
        Objects.equals(this.makerName, escalationApproval.makerName) &&
        Objects.equals(this.makerRole, escalationApproval.makerRole) &&
        Objects.equals(this.rejectionReason, escalationApproval.rejectionReason) &&
        Objects.equals(this.comments, escalationApproval.comments) &&
        Objects.equals(this.reason, escalationApproval.reason) &&
        Objects.equals(this.businessJustification, escalationApproval.businessJustification) &&
        Objects.equals(this.expectedImpact, escalationApproval.expectedImpact);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, status, currentCheckerId, currentCheckerName, currentCheckerRole, currentLevel, totalLevels, dueDate, approvalDate, completionDate, createdDate, updatedDate, progressPercentage, isOverdue, statusDisplayText, approvalSteps, escalationId, actionType, requestData, requestMetadata, makerId, makerName, makerRole, rejectionReason, comments, reason, businessJustification, expectedImpact);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class EscalationApproval {\n");
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    currentCheckerId: ").append(toIndentedString(currentCheckerId)).append("\n");
    sb.append("    currentCheckerName: ").append(toIndentedString(currentCheckerName)).append("\n");
    sb.append("    currentCheckerRole: ").append(toIndentedString(currentCheckerRole)).append("\n");
    sb.append("    currentLevel: ").append(toIndentedString(currentLevel)).append("\n");
    sb.append("    totalLevels: ").append(toIndentedString(totalLevels)).append("\n");
    sb.append("    dueDate: ").append(toIndentedString(dueDate)).append("\n");
    sb.append("    approvalDate: ").append(toIndentedString(approvalDate)).append("\n");
    sb.append("    completionDate: ").append(toIndentedString(completionDate)).append("\n");
    sb.append("    createdDate: ").append(toIndentedString(createdDate)).append("\n");
    sb.append("    updatedDate: ").append(toIndentedString(updatedDate)).append("\n");
    sb.append("    progressPercentage: ").append(toIndentedString(progressPercentage)).append("\n");
    sb.append("    isOverdue: ").append(toIndentedString(isOverdue)).append("\n");
    sb.append("    statusDisplayText: ").append(toIndentedString(statusDisplayText)).append("\n");
    sb.append("    approvalSteps: ").append(toIndentedString(approvalSteps)).append("\n");
    sb.append("    escalationId: ").append(toIndentedString(escalationId)).append("\n");
    sb.append("    actionType: ").append(toIndentedString(actionType)).append("\n");
    sb.append("    requestData: ").append(toIndentedString(requestData)).append("\n");
    sb.append("    requestMetadata: ").append(toIndentedString(requestMetadata)).append("\n");
    sb.append("    makerId: ").append(toIndentedString(makerId)).append("\n");
    sb.append("    makerName: ").append(toIndentedString(makerName)).append("\n");
    sb.append("    makerRole: ").append(toIndentedString(makerRole)).append("\n");
    sb.append("    rejectionReason: ").append(toIndentedString(rejectionReason)).append("\n");
    sb.append("    comments: ").append(toIndentedString(comments)).append("\n");
    sb.append("    reason: ").append(toIndentedString(reason)).append("\n");
    sb.append("    businessJustification: ").append(toIndentedString(businessJustification)).append("\n");
    sb.append("    expectedImpact: ").append(toIndentedString(expectedImpact)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

