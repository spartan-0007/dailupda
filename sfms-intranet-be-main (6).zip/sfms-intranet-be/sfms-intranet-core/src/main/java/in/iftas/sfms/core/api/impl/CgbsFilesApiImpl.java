package in.iftas.sfms.core.api.impl;

/*
 * Copyright (C) 2024 Iftas Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Iftas Inc. ("Confidential Information"). You shall not disclose
 * such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with Iftas Inc.
 *
 * Author: Manoj.Illa
 * Date: July 11, 2024
 */

import in.iftas.sfms.core.api.CgbsFilesApi;
import in.iftas.sfms.core.model.*;
import in.iftas.sfms.core.service.CgbsFileService;
import jakarta.validation.ValidationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.util.HashMap;
import java.util.List;

@RestController
public class CgbsFilesApiImpl implements CgbsFilesApi {
    private static final Logger logger = LoggerFactory.getLogger(CgbsFilesApiImpl.class);


    private final CgbsFileService cgbsFileService;

    public CgbsFilesApiImpl(CgbsFileService cgbsFileService) {
        this.cgbsFileService = cgbsFileService;
    }

    @Override
    public ResponseEntity<UploadCGBSFile201Response> uploadCGBSFile(@RequestPart(value = "file", required = false)
                                                                    MultipartFile file) {
        logger.info("Entering uploadCGBSFile method with file: {}", file != null ? file.getOriginalFilename() : "null");

        if (file == null || file.isEmpty()) {
            logger.warn("No file uploaded or file is empty");

            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }

        try {

            cgbsFileService.uploadCgbsFile(file);
            logger.info("File uploaded successfully: {}", file.getOriginalFilename());
            UploadCGBSFile201Response response = new UploadCGBSFile201Response();
            response.setMessage("Cgbs File Uploaded Successfully!");

            logger.info("Returning response with status CREATED");
            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch (ValidationException e) {

            logger.info("Returning response with status CREATED");
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        } catch (Exception e) {

            logger.error("Internal server error: {}", e.getMessage());
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    public ResponseEntity<GetCGBSFiles200Response> getCGBSFiles() {
        logger.info("Entering getCGBSFiles method");
        List<CGBSFileDetails> cgbsFileDetails = cgbsFileService.getCgbsFiles();
        logger.info("Retrieved {} CGBS files", cgbsFileDetails.size());
        GetCGBSFiles200Response getCGBSFiles200Response = new GetCGBSFiles200Response();
        getCGBSFiles200Response.setFiles(cgbsFileDetails);
        logger.info("Returning response with status OK");
        return ResponseEntity.status(HttpStatusCode.valueOf(200)).body(getCGBSFiles200Response);
    }

    
    @Override
    public ResponseEntity<Resource> downloadCGBSFileById(String fileName) {
        logger.info("Entering downloadCGBSFileById method with fileName: {}", fileName);
        Resource downloadCgbsFile = cgbsFileService.downloadCgbsFile(fileName);
        logger.info("Returning CGBS file for download: {}", fileName);
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + fileName + "\"")
                .header(HttpHeaders.CONTENT_TYPE, "application/zip")
                .body(downloadCgbsFile);
    }
        @Override
        public ResponseEntity<ModelApiResponse> cgbsFilesIdDelete(Long id) {
            logger.info("Received request to delete CGBS file with id: {}", id);

            ModelApiResponse apiResponse = new ModelApiResponse();

            try {

                cgbsFileService.deleteCGBSFile(id.intValue());

                apiResponse.setSuccess(true);
                apiResponse.setMessage("CGBS file deleted successfully.");
                apiResponse.setData(new HashMap<>());
                return ResponseEntity.ok(apiResponse);
            } catch (Exception e) {

                logger.error("Error while deleting CGBS file: {}", e.getMessage(), e);
                apiResponse.setSuccess(false);
                apiResponse.setMessage("An error occurred while deleting the CGBS file.");
                ApiResponseError error = new ApiResponseError();
                error.setCode("500");
                error.setMessage("Internal Server Error: " + e.getMessage());
                apiResponse.setError(error);
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(apiResponse);
            }
        }
}
