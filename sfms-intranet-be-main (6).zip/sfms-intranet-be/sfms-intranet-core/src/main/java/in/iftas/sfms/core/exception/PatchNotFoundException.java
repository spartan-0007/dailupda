package in.iftas.sfms.core.exception;

public class PatchNotFoundException extends RuntimeException {
    public PatchNotFoundException(String message) {
        super(message);
    }
}