package in.iftas.sfms.core.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@AllArgsConstructor
public class EscalationContactDTO {
    private String bankName;
    private String contactName;
    private String contactEmail;
    private String contactNumber;
    private String feature;
    private String levelName;

}
