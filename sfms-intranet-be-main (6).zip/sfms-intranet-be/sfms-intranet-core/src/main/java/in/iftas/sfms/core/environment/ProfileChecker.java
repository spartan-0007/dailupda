package in.iftas.sfms.core.environment;

import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import java.util.Arrays;

@Component
public class ProfileChecker {

    @Autowired
    private Environment environment;

    @PostConstruct
    public void init() {
        System.out.println("Active profiles: " + Arrays.toString(environment.getActiveProfiles()));
    }
}