package in.iftas.sfms.core.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "i_escalation_contacts", indexes = {
        @Index(name = "idx_bank_id", columnList = "bank_id"),
        @Index(name = "idx_level_id", columnList = "level_id"),
        @Index(name = "idx_contact_order", columnList = "level_id, contact_order"),
        @Index(name = "idx_contact_active", columnList = "is_active")
})
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class EscalationContactEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "bank_id", nullable = false)
    private Long bankId; // Keep for backward compatibility

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "level_id", referencedColumnName = "id", nullable = false)
    private EscalationLevelEntity level;

    @Column(name = "feature")
    private String feature;

    @Column(name = "designation")
    private String designation;

    @Column(name = "contact_name")
    private String contactName;

    @Column(name = "contact_number")
    private String contactNumber;

    @Column(name = "contact_email")
    private String contactEmail;
    
    @Column(name = "contact_order")
    @Builder.Default
    private Integer contactOrder = 1;
    
    @Column(name = "is_active")
    @Builder.Default
    private Boolean isActive = true;
    
    @Column(name = "business", length = 500)
    private String business; // New field to replace contact groups
    
    @Column(name = "created_date")
    private LocalDateTime createdDate;
    
    @Column(name = "created_by")
    private String createdBy;
    
    @Column(name = "last_modified_date")
    private LocalDateTime lastModifiedDate;
    
    @Column(name = "last_modified_by")
    private String lastModifiedBy;
}