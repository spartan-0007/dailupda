package in.iftas.sfms.core.repository;

import in.iftas.sfms.core.entity.BankContactEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface BankContactRepository extends JpaRepository<BankContactEntity, Long> {
}