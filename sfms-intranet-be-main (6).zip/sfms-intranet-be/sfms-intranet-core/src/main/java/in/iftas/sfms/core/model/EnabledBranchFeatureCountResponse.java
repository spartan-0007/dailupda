package in.iftas.sfms.core.model;

import java.net.URI;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import org.openapitools.jackson.nullable.JsonNullable;
import java.time.OffsetDateTime;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


import java.util.*;
import jakarta.annotation.Generated;

/**
 * EnabledBranchFeatureCountResponse
 */


public class EnabledBranchFeatureCountResponse {

  private Long totalRtgsEnabledBranches;

  private Long totalNeftEnabledBranches;

  private Long totalRtgsAndNeftEnabledBranches;

  private Long totalLcEnabledBranches;

  private Long totalBgEnabledBranches;

  private Long totalLcAndBgEnabledBranches;

  private Long totalBranches;

  private Long totalOthersBranches;

  private Long totalOwnBankWiseCount;

  public EnabledBranchFeatureCountResponse totalRtgsEnabledBranches(Long totalRtgsEnabledBranches) {
    this.totalRtgsEnabledBranches = totalRtgsEnabledBranches;
    return this;
  }

  /**
   * Total number of RTGS enabled branches.
   * @return totalRtgsEnabledBranches
   */
  
  @Schema(name = "totalRtgsEnabledBranches", description = "Total number of RTGS enabled branches.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("totalRtgsEnabledBranches")
  public Long getTotalRtgsEnabledBranches() {
    return totalRtgsEnabledBranches;
  }

  public void setTotalRtgsEnabledBranches(Long totalRtgsEnabledBranches) {
    this.totalRtgsEnabledBranches = totalRtgsEnabledBranches;
  }

  public EnabledBranchFeatureCountResponse totalNeftEnabledBranches(Long totalNeftEnabledBranches) {
    this.totalNeftEnabledBranches = totalNeftEnabledBranches;
    return this;
  }

  /**
   * Total number of NEFT enabled branches.
   * @return totalNeftEnabledBranches
   */
  
  @Schema(name = "totalNeftEnabledBranches", description = "Total number of NEFT enabled branches.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("totalNeftEnabledBranches")
  public Long getTotalNeftEnabledBranches() {
    return totalNeftEnabledBranches;
  }

  public void setTotalNeftEnabledBranches(Long totalNeftEnabledBranches) {
    this.totalNeftEnabledBranches = totalNeftEnabledBranches;
  }

  public EnabledBranchFeatureCountResponse totalRtgsAndNeftEnabledBranches(Long totalRtgsAndNeftEnabledBranches) {
    this.totalRtgsAndNeftEnabledBranches = totalRtgsAndNeftEnabledBranches;
    return this;
  }

  /**
   * Total number of RTGS & NEFT enabled branches.
   * @return totalRtgsAndNeftEnabledBranches
   */
  
  @Schema(name = "totalRtgsAndNeftEnabledBranches", description = "Total number of RTGS & NEFT enabled branches.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("totalRtgsAndNeftEnabledBranches")
  public Long getTotalRtgsAndNeftEnabledBranches() {
    return totalRtgsAndNeftEnabledBranches;
  }

  public void setTotalRtgsAndNeftEnabledBranches(Long totalRtgsAndNeftEnabledBranches) {
    this.totalRtgsAndNeftEnabledBranches = totalRtgsAndNeftEnabledBranches;
  }

  public EnabledBranchFeatureCountResponse totalLcEnabledBranches(Long totalLcEnabledBranches) {
    this.totalLcEnabledBranches = totalLcEnabledBranches;
    return this;
  }

  /**
   * Total number of LC enabled branches.
   * @return totalLcEnabledBranches
   */
  
  @Schema(name = "totalLcEnabledBranches", description = "Total number of LC enabled branches.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("totalLcEnabledBranches")
  public Long getTotalLcEnabledBranches() {
    return totalLcEnabledBranches;
  }

  public void setTotalLcEnabledBranches(Long totalLcEnabledBranches) {
    this.totalLcEnabledBranches = totalLcEnabledBranches;
  }

  public EnabledBranchFeatureCountResponse totalBgEnabledBranches(Long totalBgEnabledBranches) {
    this.totalBgEnabledBranches = totalBgEnabledBranches;
    return this;
  }

  /**
   * Total number of BG enabled branches.
   * @return totalBgEnabledBranches
   */
  
  @Schema(name = "totalBgEnabledBranches", description = "Total number of BG enabled branches.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("totalBgEnabledBranches")
  public Long getTotalBgEnabledBranches() {
    return totalBgEnabledBranches;
  }

  public void setTotalBgEnabledBranches(Long totalBgEnabledBranches) {
    this.totalBgEnabledBranches = totalBgEnabledBranches;
  }

  public EnabledBranchFeatureCountResponse totalLcAndBgEnabledBranches(Long totalLcAndBgEnabledBranches) {
    this.totalLcAndBgEnabledBranches = totalLcAndBgEnabledBranches;
    return this;
  }

  /**
   * Total number of LC & BG enabled branches.
   * @return totalLcAndBgEnabledBranches
   */
  
  @Schema(name = "totalLcAndBgEnabledBranches", description = "Total number of LC & BG enabled branches.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("totalLcAndBgEnabledBranches")
  public Long getTotalLcAndBgEnabledBranches() {
    return totalLcAndBgEnabledBranches;
  }

  public void setTotalLcAndBgEnabledBranches(Long totalLcAndBgEnabledBranches) {
    this.totalLcAndBgEnabledBranches = totalLcAndBgEnabledBranches;
  }

  public EnabledBranchFeatureCountResponse totalBranches(Long totalBranches) {
    this.totalBranches = totalBranches;
    return this;
  }

  /**
   * Total number of branches.
   * @return totalBranches
   */
  
  @Schema(name = "totalBranches", description = "Total number of branches.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("totalBranches")
  public Long getTotalBranches() {
    return totalBranches;
  }

  public void setTotalBranches(Long totalBranches) {
    this.totalBranches = totalBranches;
  }

  public EnabledBranchFeatureCountResponse totalOthersBranches(Long totalOthersBranches) {
    this.totalOthersBranches = totalOthersBranches;
    return this;
  }

  /**
   * Total number of other branches.
   * @return totalOthersBranches
   */
  
  @Schema(name = "totalOthersBranches", description = "Total number of other branches.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("totalOthersBranches")
  public Long getTotalOthersBranches() {
    return totalOthersBranches;
  }

  public void setTotalOthersBranches(Long totalOthersBranches) {
    this.totalOthersBranches = totalOthersBranches;
  }

  public EnabledBranchFeatureCountResponse totalOwnBankWiseCount(Long totalOwnBankWiseCount) {
    this.totalOwnBankWiseCount = totalOwnBankWiseCount;
    return this;
  }

  /**
   * Total number of own banks branches count.
   * @return totalOwnBankWiseCount
   */
  
  @Schema(name = "totalOwnBankWiseCount", description = "Total number of own banks branches count.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("totalOwnBankWiseCount")
  public Long getTotalOwnBankWiseCount() {
    return totalOwnBankWiseCount;
  }

  public void setTotalOwnBankWiseCount(Long totalOwnBankWiseCount) {
    this.totalOwnBankWiseCount = totalOwnBankWiseCount;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    EnabledBranchFeatureCountResponse enabledBranchFeatureCountResponse = (EnabledBranchFeatureCountResponse) o;
    return Objects.equals(this.totalRtgsEnabledBranches, enabledBranchFeatureCountResponse.totalRtgsEnabledBranches) &&
        Objects.equals(this.totalNeftEnabledBranches, enabledBranchFeatureCountResponse.totalNeftEnabledBranches) &&
        Objects.equals(this.totalRtgsAndNeftEnabledBranches, enabledBranchFeatureCountResponse.totalRtgsAndNeftEnabledBranches) &&
        Objects.equals(this.totalLcEnabledBranches, enabledBranchFeatureCountResponse.totalLcEnabledBranches) &&
        Objects.equals(this.totalBgEnabledBranches, enabledBranchFeatureCountResponse.totalBgEnabledBranches) &&
        Objects.equals(this.totalLcAndBgEnabledBranches, enabledBranchFeatureCountResponse.totalLcAndBgEnabledBranches) &&
        Objects.equals(this.totalBranches, enabledBranchFeatureCountResponse.totalBranches) &&
        Objects.equals(this.totalOthersBranches, enabledBranchFeatureCountResponse.totalOthersBranches) &&
        Objects.equals(this.totalOwnBankWiseCount, enabledBranchFeatureCountResponse.totalOwnBankWiseCount);
  }

  @Override
  public int hashCode() {
    return Objects.hash(totalRtgsEnabledBranches, totalNeftEnabledBranches, totalRtgsAndNeftEnabledBranches, totalLcEnabledBranches, totalBgEnabledBranches, totalLcAndBgEnabledBranches, totalBranches, totalOthersBranches, totalOwnBankWiseCount);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class EnabledBranchFeatureCountResponse {\n");
    sb.append("    totalRtgsEnabledBranches: ").append(toIndentedString(totalRtgsEnabledBranches)).append("\n");
    sb.append("    totalNeftEnabledBranches: ").append(toIndentedString(totalNeftEnabledBranches)).append("\n");
    sb.append("    totalRtgsAndNeftEnabledBranches: ").append(toIndentedString(totalRtgsAndNeftEnabledBranches)).append("\n");
    sb.append("    totalLcEnabledBranches: ").append(toIndentedString(totalLcEnabledBranches)).append("\n");
    sb.append("    totalBgEnabledBranches: ").append(toIndentedString(totalBgEnabledBranches)).append("\n");
    sb.append("    totalLcAndBgEnabledBranches: ").append(toIndentedString(totalLcAndBgEnabledBranches)).append("\n");
    sb.append("    totalBranches: ").append(toIndentedString(totalBranches)).append("\n");
    sb.append("    totalOthersBranches: ").append(toIndentedString(totalOthersBranches)).append("\n");
    sb.append("    totalOwnBankWiseCount: ").append(toIndentedString(totalOwnBankWiseCount)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

