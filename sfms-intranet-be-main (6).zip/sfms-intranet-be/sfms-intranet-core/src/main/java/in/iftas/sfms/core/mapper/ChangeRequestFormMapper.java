package in.iftas.sfms.core.mapper;

import in.iftas.sfms.core.entity.ChangeRequestFormEntity;
import in.iftas.sfms.core.entity.CrfIpEntity;
import in.iftas.sfms.core.model.ChangeRequestForm;
import in.iftas.sfms.core.model.CrfIp;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.stream.Stream;
import java.util.stream.Collectors;

@Mapper(componentModel = "spring", nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface ChangeRequestFormMapper {

    ChangeRequestFormMapper INSTANCE = Mappers.getMapper(ChangeRequestFormMapper.class);

    @Mapping(source = "id", target = "id")
    @Mapping(source = "crfAccess", target = "crfAccess")
    @Mapping(source = "crfType", target = "crfType")
    @Mapping(source = "crfDept", target = "crfDept")
    @Mapping(target = "requestedDate", expression = "java(convertToDate(entity.getRequestedDate()))")
    @Mapping(source = "priority", target = "priority")
    @Mapping(target = "openDate", expression = "java(convertToDate(entity.getOpenDate()))")
    @Mapping(target = "closeDate", expression = "java(convertToDate(entity.getCloseDate()))")
    @Mapping(source = "reason", target = "reason")
    @Mapping(source = "svdTicketId", target = "svdTicketId")
    @Mapping(source = "bankShortName", target = "bankShortName")
    @Mapping(source = "crfIps", target = "crfIps")
    ChangeRequestForm toModel(ChangeRequestFormEntity entity);

    @Mapping(source = "id", target = "id")
    @Mapping(source = "crfAccess", target = "crfAccess")
    @Mapping(source = "crfType", target = "crfType")
    @Mapping(source = "crfDept", target = "crfDept")
    @Mapping(target = "requestedDate", expression = "java(convertToLocalDate(form.getRequestedDate()))")
    @Mapping(source = "priority", target = "priority")
    @Mapping(target = "openDate", expression = "java(convertToLocalDateTime(form.getOpenDate()))")
    @Mapping(target = "closeDate", expression = "java(convertToLocalDateTime(form.getCloseDate()))")
    @Mapping(source = "reason", target = "reason")
    @Mapping(source = "svdTicketId", target = "svdTicketId")
    @Mapping(source = "bankShortName", target = "bankShortName")
    @Mapping(target = "crfIps", ignore = true) // Handle CRF IPs separately
    ChangeRequestFormEntity toEntity(ChangeRequestForm form);

    /**
     * Updates an existing ChangeRequestFormEntity with values from the ChangeRequestForm model.
     * This method preserves any fields not explicitly mapped, especially when nulls are provided.
     *
     * @param form The source ChangeRequestForm containing the updated values
     * @param entity The target ChangeRequestFormEntity to be updated
     */
    @Mapping(source = "id", target = "id")
    @Mapping(source = "crfAccess", target = "crfAccess")
    @Mapping(source = "crfType", target = "crfType")
    @Mapping(source = "crfDept", target = "crfDept")
    @Mapping(target = "requestedDate", expression = "java(convertToLocalDate(form.getRequestedDate()))")
    @Mapping(source = "priority", target = "priority")
    @Mapping(target = "openDate", expression = "java(convertToLocalDateTime(form.getOpenDate()))")
    @Mapping(target = "closeDate", expression = "java(convertToLocalDateTime(form.getCloseDate()))")
    @Mapping(source = "reason", target = "reason")
    @Mapping(source = "svdTicketId", target = "svdTicketId")
    @Mapping(source = "bankShortName", target = "bankShortName")
    @Mapping(target = "crfIps", ignore = true) // Handle CRF IPs separately
    void updateEntityFromModel(ChangeRequestForm form, @MappingTarget ChangeRequestFormEntity entity);

    /**
     * Maps CRF IPs from the ChangeRequestForm to the ChangeRequestFormEntity.
     * This method is called after the main entity mapping is complete.
     * It handles the deletion of removed IPs and addition of new ones.
     *
     * @param form The source ChangeRequestForm containing the IP information
     * @param entity The target ChangeRequestFormEntity to be updated with IP information
     */
    @AfterMapping
    default void mapCrfIps(ChangeRequestForm form, @MappingTarget ChangeRequestFormEntity entity) {
        if (form.getCrfIps() != null) {
            List<CrfIpEntity> existingCrfIps = entity.getCrfIps() != null ?
                    entity.getCrfIps() : new ArrayList<>();
            existingCrfIps.clear();
            if (!form.getCrfIps().isEmpty()) {
                form.getCrfIps().stream()
                        .map(crfIp -> convertCrfIpToEntity(crfIp, entity))
                        .forEach(existingCrfIps::add);
            }
            if (entity.getCrfIps() == null) {
                entity.setCrfIps(existingCrfIps);
            }
        } else {
            entity.setCrfIps(null);
        }
    }

    @Mapping(source = "id", target = "id")
    @Mapping(target = "crf", ignore = true)
    @Mapping(target = "sourceIp1", ignore = true)
    @Mapping(target = "sourceIp2", ignore = true)
    @Mapping(target = "sourceIp3", ignore = true)
    @Mapping(target = "sourceIp4", ignore = true)
    @Mapping(target = "sourceIp5", ignore = true)
    @Mapping(target = "sourceIp6", ignore = true)
    @Mapping(target = "sourceIp7", ignore = true)
    @Mapping(target = "destinationIp1", ignore = true)
    @Mapping(target = "destinationIp2", ignore = true)
    @Mapping(target = "destinationIp3", ignore = true)
    @Mapping(target = "destinationIp4", ignore = true)
    @Mapping(target = "destinationIp5", ignore = true)
    @Mapping(target = "destinationIp6", ignore = true)
    @Mapping(target = "destinationIp7", ignore = true)
    @Mapping(source = "port", target = "port")
    CrfIpEntity toCrfIpEntity(CrfIp crfIp);

    @Mapping(source = "id", target = "id")
    @Mapping(source = "crf.id", target = "crfId")
    @Mapping(target = "sourceIp", expression = "java(combineSourceIps(entity))")
    @Mapping(target = "destinationIp", expression = "java(combineDestinationIps(entity))")
    @Mapping(source = "port", target = "port")
    CrfIp toCrfIpModel(CrfIpEntity entity);

    default CrfIpEntity convertCrfIpToEntity(CrfIp crfIp, ChangeRequestFormEntity changeRequestForm) {
        if (crfIp == null) {
            return null;
        }

        CrfIpEntity.CrfIpEntityBuilder builder = CrfIpEntity.builder()
                .port(crfIp.getPort())
                .crf(changeRequestForm);

        if (crfIp.getId() != null) {
            builder.id(crfIp.getId());
        }

        String[] sourceIps = crfIp.getSourceIp() != null ? crfIp.getSourceIp().split(",") : new String[0];
        String[] destinationIps = crfIp.getDestinationIp() != null ? crfIp.getDestinationIp().split(",") : new String[0];

        // Set source IPs
        if (sourceIps.length > 0) builder.sourceIp1(sourceIps[0].trim());
        if (sourceIps.length > 1) builder.sourceIp2(sourceIps[1].trim());
        if (sourceIps.length > 2) builder.sourceIp3(sourceIps[2].trim());
        if (sourceIps.length > 3) builder.sourceIp4(sourceIps[3].trim());
        if (sourceIps.length > 4) builder.sourceIp5(sourceIps[4].trim());
        if (sourceIps.length > 5) builder.sourceIp6(sourceIps[5].trim());
        if (sourceIps.length > 6) builder.sourceIp7(sourceIps[6].trim());

        // Set destination IPs
        if (destinationIps.length > 0) builder.destinationIp1(destinationIps[0].trim());
        if (destinationIps.length > 1) builder.destinationIp2(destinationIps[1].trim());
        if (destinationIps.length > 2) builder.destinationIp3(destinationIps[2].trim());
        if (destinationIps.length > 3) builder.destinationIp4(destinationIps[3].trim());
        if (destinationIps.length > 4) builder.destinationIp5(destinationIps[4].trim());
        if (destinationIps.length > 5) builder.destinationIp6(destinationIps[5].trim());
        if (destinationIps.length > 6) builder.destinationIp7(destinationIps[6].trim());

        return builder.build();
    }

    default String combineSourceIps(CrfIpEntity entity) {
        return Stream.of(
                        entity.getSourceIp1(),
                        entity.getSourceIp2(),
                        entity.getSourceIp3(),
                        entity.getSourceIp4(),
                        entity.getSourceIp5(),
                        entity.getSourceIp6(),
                        entity.getSourceIp7())
                .filter(Objects::nonNull)
                .filter(ip -> !ip.isEmpty())
                .collect(Collectors.joining(","));
    }

    default String combineDestinationIps(CrfIpEntity entity) {
        return Stream.of(
                        entity.getDestinationIp1(),
                        entity.getDestinationIp2(),
                        entity.getDestinationIp3(),
                        entity.getDestinationIp4(),
                        entity.getDestinationIp5(),
                        entity.getDestinationIp6(),
                        entity.getDestinationIp7())
                .filter(Objects::nonNull)
                .filter(ip -> !ip.isEmpty())
                .collect(Collectors.joining(","));
    }

    default Date convertToDate(LocalDateTime dateTime) {
        return dateTime != null ?
                Date.from(dateTime.atZone(ZoneId.systemDefault()).toInstant()) : null;
    }

    default Date convertToDate(LocalDate date) {
        return date != null ?
                Date.from(date.atStartOfDay(ZoneId.systemDefault()).toInstant()) : null;
    }

    default LocalDateTime convertToLocalDateTime(Date date) {
        return date != null ?
                date.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime() : null;
    }

    default LocalDate convertToLocalDate(Date date) {
        return date != null ?
                date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate() : null;
    }
}