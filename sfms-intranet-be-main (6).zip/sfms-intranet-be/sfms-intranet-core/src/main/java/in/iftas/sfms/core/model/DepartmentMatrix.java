package in.iftas.sfms.core.model;

import java.net.URI;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import in.iftas.sfms.core.model.LevelMatrix;
import java.util.ArrayList;
import java.util.List;
import org.openapitools.jackson.nullable.JsonNullable;
import java.time.OffsetDateTime;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


import java.util.*;
import jakarta.annotation.Generated;

/**
 * DepartmentMatrix
 */


public class DepartmentMatrix {

  private Long departmentId;

  private String departmentName;

  private String departmentCode;

  private Integer displayOrder;

  @Valid
  private List<@Valid LevelMatrix> levels;

  public DepartmentMatrix departmentId(Long departmentId) {
    this.departmentId = departmentId;
    return this;
  }

  /**
   * Unique identifier of the department.
   * @return departmentId
   */
  
  @Schema(name = "departmentId", description = "Unique identifier of the department.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("departmentId")
  public Long getDepartmentId() {
    return departmentId;
  }

  public void setDepartmentId(Long departmentId) {
    this.departmentId = departmentId;
  }

  public DepartmentMatrix departmentName(String departmentName) {
    this.departmentName = departmentName;
    return this;
  }

  /**
   * Name of the department.
   * @return departmentName
   */
  
  @Schema(name = "departmentName", description = "Name of the department.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("departmentName")
  public String getDepartmentName() {
    return departmentName;
  }

  public void setDepartmentName(String departmentName) {
    this.departmentName = departmentName;
  }

  public DepartmentMatrix departmentCode(String departmentCode) {
    this.departmentCode = departmentCode;
    return this;
  }

  /**
   * Code of the department (e.g., PSO, PSB, TRY).
   * @return departmentCode
   */
  
  @Schema(name = "departmentCode", description = "Code of the department (e.g., PSO, PSB, TRY).", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("departmentCode")
  public String getDepartmentCode() {
    return departmentCode;
  }

  public void setDepartmentCode(String departmentCode) {
    this.departmentCode = departmentCode;
  }

  public DepartmentMatrix displayOrder(Integer displayOrder) {
    this.displayOrder = displayOrder;
    return this;
  }

  /**
   * Display order of the department for UI rendering.
   * @return displayOrder
   */
  
  @Schema(name = "displayOrder", description = "Display order of the department for UI rendering.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("displayOrder")
  public Integer getDisplayOrder() {
    return displayOrder;
  }

  public void setDisplayOrder(Integer displayOrder) {
    this.displayOrder = displayOrder;
  }

  public DepartmentMatrix levels(List<@Valid LevelMatrix> levels) {
    this.levels = levels;
    return this;
  }

  public DepartmentMatrix addItem(LevelMatrix levelsItem) {
    if (this.levels == null) {
      this.levels = new ArrayList<>();
    }
    this.levels.add(levelsItem);
    return this;
  }

  /**
   * List of escalation levels within the department.
   * @return levels
   */
  @Valid 
  @Schema(name = "levels", description = "List of escalation levels within the department.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("levels")
  public List<@Valid LevelMatrix> getLevels() {
    return levels;
  }

  public void setLevels(List<@Valid LevelMatrix> levels) {
    this.levels = levels;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    DepartmentMatrix departmentMatrix = (DepartmentMatrix) o;
    return Objects.equals(this.departmentId, departmentMatrix.departmentId) &&
        Objects.equals(this.departmentName, departmentMatrix.departmentName) &&
        Objects.equals(this.departmentCode, departmentMatrix.departmentCode) &&
        Objects.equals(this.displayOrder, departmentMatrix.displayOrder) &&
        Objects.equals(this.levels, departmentMatrix.levels);
  }

  @Override
  public int hashCode() {
    return Objects.hash(departmentId, departmentName, departmentCode, displayOrder, levels);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class DepartmentMatrix {\n");
    sb.append("    departmentId: ").append(toIndentedString(departmentId)).append("\n");
    sb.append("    departmentName: ").append(toIndentedString(departmentName)).append("\n");
    sb.append("    departmentCode: ").append(toIndentedString(departmentCode)).append("\n");
    sb.append("    displayOrder: ").append(toIndentedString(displayOrder)).append("\n");
    sb.append("    levels: ").append(toIndentedString(levels)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

