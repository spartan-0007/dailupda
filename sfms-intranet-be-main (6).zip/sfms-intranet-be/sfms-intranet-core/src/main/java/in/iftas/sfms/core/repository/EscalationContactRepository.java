package in.iftas.sfms.core.repository;

import in.iftas.sfms.core.dto.EscalationContactDTO;
import in.iftas.sfms.core.entity.EscalationContactEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface EscalationContactRepository extends JpaRepository<EscalationContactEntity, Long> {
    List<EscalationContactEntity> findByBankId(Long bankId);

    @Query("SELECT new in.iftas.sfms.core.dto.EscalationContactDTO(b.bankName, ec.contactName, ec.contactEmail, ec.contactNumber, ec.feature, el.levelName) " +
            "FROM EscalationContactEntity ec " +
            "JOIN ec.level el " +
            "JOIN BankEntity b ON b.id = ec.bankId " +
            "WHERE el.id = :levelId AND ec.bankId = :bankId")
    List<EscalationContactDTO> findDTOByLevelAndBankId(@Param("levelId") Long levelId, @Param("bankId") Long bankId);

    @Query("SELECT new in.iftas.sfms.core.dto.EscalationContactDTO(b.bankName, ec.contactName, ec.contactEmail, ec.contactNumber, ec.feature, el.levelName) " +
            "FROM EscalationContactEntity ec " +
            "JOIN ec.level el " +
            "JOIN BankEntity b ON b.id = ec.bankId " +
            "WHERE el.id = :levelId")
    List<EscalationContactDTO> findDTOByLevel(@Param("levelId") Long levelId);

    @Query("SELECT new in.iftas.sfms.core.dto.EscalationContactDTO(b.bankName, ec.contactName, ec.contactEmail, ec.contactNumber, ec.feature, el.levelName) " +
            "FROM EscalationContactEntity ec " +
            "JOIN ec.level el " +
            "JOIN BankEntity b ON b.id = ec.bankId " +
            "WHERE ec.bankId = :bankId")
    List<EscalationContactDTO> findDTOByBankId(@Param("bankId") Long bankId);

    @Query("SELECT new in.iftas.sfms.core.dto.EscalationContactDTO(b.bankName, ec.contactName, ec.contactEmail, ec.contactNumber, ec.feature, el.levelName) " +
            "FROM EscalationContactEntity ec " +
            "JOIN ec.level el " +
            "JOIN BankEntity b ON b.id = ec.bankId")
    List<EscalationContactDTO> findAllDTO();
    
    Optional<EscalationContactEntity> findByBankIdAndLevelIdAndContactNameAndContactEmailAndContactNumberAndFeature(Long bankId, Long levelId, String contactName, String contactEmail, String contactNumber, String feature);
}