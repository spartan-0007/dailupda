package in.iftas.sfms.core.model;

import java.net.URI;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import java.util.ArrayList;
import java.util.List;
import org.openapitools.jackson.nullable.JsonNullable;
import java.time.OffsetDateTime;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


import java.util.*;
import jakarta.annotation.Generated;

/**
 * ContactUs
 */


public class ContactUs {

  private Long levelId;

  private String contactName;

  @Valid
  private List<String> contactNumber;

  private String contactEmail;

  public ContactUs levelId(Long levelId) {
    this.levelId = levelId;
    return this;
  }

  /**
   * Get levelId
   * @return levelId
   */
  
  @Schema(name = "levelId", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("levelId")
  public Long getLevelId() {
    return levelId;
  }

  public void setLevelId(Long levelId) {
    this.levelId = levelId;
  }

  public ContactUs contactName(String contactName) {
    this.contactName = contactName;
    return this;
  }

  /**
   * Get contactName
   * @return contactName
   */
  
  @Schema(name = "contactName", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("contactName")
  public String getContactName() {
    return contactName;
  }

  public void setContactName(String contactName) {
    this.contactName = contactName;
  }

  public ContactUs contactNumber(List<String> contactNumber) {
    this.contactNumber = contactNumber;
    return this;
  }

  public ContactUs addItem(String contactNumberItem) {
    if (this.contactNumber == null) {
      this.contactNumber = new ArrayList<>();
    }
    this.contactNumber.add(contactNumberItem);
    return this;
  }

  /**
   * Get contactNumber
   * @return contactNumber
   */
  
  @Schema(name = "contactNumber", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("contactNumber")
  public List<String> getContactNumber() {
    return contactNumber;
  }

  public void setContactNumber(List<String> contactNumber) {
    this.contactNumber = contactNumber;
  }

  public ContactUs contactEmail(String contactEmail) {
    this.contactEmail = contactEmail;
    return this;
  }

  /**
   * Get contactEmail
   * @return contactEmail
   */
  
  @Schema(name = "contactEmail", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("contactEmail")
  public String getContactEmail() {
    return contactEmail;
  }

  public void setContactEmail(String contactEmail) {
    this.contactEmail = contactEmail;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ContactUs contactUs = (ContactUs) o;
    return Objects.equals(this.levelId, contactUs.levelId) &&
        Objects.equals(this.contactName, contactUs.contactName) &&
        Objects.equals(this.contactNumber, contactUs.contactNumber) &&
        Objects.equals(this.contactEmail, contactUs.contactEmail);
  }

  @Override
  public int hashCode() {
    return Objects.hash(levelId, contactName, contactNumber, contactEmail);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ContactUs {\n");
    sb.append("    levelId: ").append(toIndentedString(levelId)).append("\n");
    sb.append("    contactName: ").append(toIndentedString(contactName)).append("\n");
    sb.append("    contactNumber: ").append(toIndentedString(contactNumber)).append("\n");
    sb.append("    contactEmail: ").append(toIndentedString(contactEmail)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

