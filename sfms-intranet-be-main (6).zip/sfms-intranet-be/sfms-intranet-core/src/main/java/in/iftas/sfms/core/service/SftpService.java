package in.iftas.sfms.core.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.InputStream;

/**
 * Facade service for SFTP operations that delegates to the appropriate implementation
 * based on the active Spring profile.
 */
@Service
public class SftpService {
    private static final Logger logger = LoggerFactory.getLogger(SftpService.class);

    private final SftpClient sftpClient;

    public SftpService(SftpClient sftpClient) {
        this.sftpClient = sftpClient;
        logger.info("Initialized SftpService with client: {}", sftpClient.getClass().getSimpleName());
    }

    /**
     * Upload a file to the SFTP server
     *
     * @param filePath Path where the file will be stored on the server
     * @param inputStream Content of the file to upload
     * @throws Exception If any error occurs during upload
     */
    public void uploadFile(String filePath, InputStream inputStream) throws Exception {
        sftpClient.uploadFile(filePath, inputStream);
    }

    /**
     * Download a file from the SFTP server
     *
     * @param filePath Path of the file to download from the server
     * @return InputStream with the file content
     * @throws Exception If any error occurs during download
     */
    public InputStream downloadFile(String filePath) throws Exception {
        return sftpClient.downloadFile(filePath);
    }

    /**
     * Checks if a file exists on the SFTP server
     *
     * @param filePath Directory path on the server
     * @param originalFilename Filename to check
     * @return true if the file exists, false otherwise
     * @throws Exception If any error occurs during the check
     */
    public boolean fileExists(String filePath, String originalFilename) throws Exception {
        return sftpClient.fileExists(filePath, originalFilename);
    }

    /**
     * Upload a CRLCGBS file with backup capability (moves existing file to backup folder)
     *
     * @param filePath Directory path on the server
     * @param originalFilename Name of the file to upload
     * @param inputStream Content of the file to upload
     * @throws Exception If any error occurs during upload
     */
    public void uploadCRLCGBSFile(String filePath, String originalFilename, InputStream inputStream) throws Exception {
        sftpClient.uploadWithBackup(filePath, originalFilename, inputStream);
    }
}