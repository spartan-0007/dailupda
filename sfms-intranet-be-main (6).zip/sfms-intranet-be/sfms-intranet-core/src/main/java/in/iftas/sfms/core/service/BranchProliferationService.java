package in.iftas.sfms.core.service;

/*
 * Copyright (C) 2024 Iftas Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Iftas Inc. ("Confidential Information"). You shall not disclose
 * such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with Iftas Inc.
 *
 * Author: Manoj.Illa
 * Created Date: July 11, 2024.
 */

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import in.iftas.sfms.core.dto.BranchDTO;
import in.iftas.sfms.core.entity.*;
import in.iftas.sfms.core.exception.*;
import in.iftas.sfms.core.mapper.BranchDTOMapper;
import in.iftas.sfms.core.model.Branch;
import in.iftas.sfms.core.model.BranchProliferationResponse;
import in.iftas.sfms.core.repository.*;
import jakarta.transaction.Transactional;
import org.apache.commons.io.IOUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

@Service
public class BranchProliferationService {

    private static final Logger logger = LoggerFactory.getLogger(BranchProliferationService.class);

    private final BranchProliferationRepository branchProliferationRepository;
    private final ObjectMapper objectMapper;
    private final SftpService sftpService;
    private final BankRepository bankRepository;
    private final BankBranchRepository bankBranchRepository;
    private final PropertiesFileRepository propertiesFileRepository;
    private final ProliferationActivityLogRepository proliferationActivityLogRepository;

    @Value("${sample.template.path}")
    private String templatePath;

    @Autowired
    private Executor taskExecutor;


    @Autowired
    public BranchProliferationService(BranchProliferationRepository branchProliferationRepository,
                                      ObjectMapper objectMapper,
                                      SftpService sftpService,
                                      BankRepository bankRepository,
                                      BankBranchRepository bankBranchRepository,
                                      PropertiesFileRepository propertiesFileRepository,
                                      ProliferationActivityLogRepository proliferationActivityLogRepository) {
        this.branchProliferationRepository = branchProliferationRepository;
        this.objectMapper = objectMapper;
        this.sftpService = sftpService;
        this.bankRepository = bankRepository;
        this.bankBranchRepository = bankBranchRepository;
        this.propertiesFileRepository = propertiesFileRepository;
        this.proliferationActivityLogRepository = proliferationActivityLogRepository;
    }

    private void validateIfscCodes(List<Branch> branches, List<String> listOfIfsc) {
        Set<String> existingIfscCodes = branches.stream()
                .map(Branch::getIfscCode)
                .collect(Collectors.toSet());

        for (String ifscCode : listOfIfsc) {
            if (!existingIfscCodes.contains(ifscCode)) {
                throw new ResourceNotFoundException("Uploaded IFSC Code did not match with Branch Details: " + ifscCode);
            }
        }
    }

    // Method to store branch details
    public List<Long> proliferateBranches(String branchDetails, String createdBy, Integer bankId, List<MultipartFile> propertiesFiles) {
        logger.info("Starting branch proliferation for bank ID: {}", bankId);
        List<Long> savedIds = new ArrayList<>();
        try {

            BankEntity bankEntity = bankRepository.findById(bankId)
                    .orElseThrow(() -> new ResourceNotFoundException("Bank Not Found"));

            List<Branch> branches = objectMapper.readValue(branchDetails, new TypeReference<List<Branch>>() {
            });
            List<String> listOfIfsc = new ArrayList<>();

            for (MultipartFile propertiesFile : propertiesFiles) {
                List<String> lines = readLinesFromFile(propertiesFile);
                validateFileContent(lines);
                String ifscCode = extractIfscCode(lines.get(5));
                checkIfscCodeExists(ifscCode);
                listOfIfsc.add(ifscCode);
                //storeFileToSftp(propertiesFile);
                //savePropertiesFileDetailsToDatabase(ifscCode, lines);
            }

            validateIfscCodes(branches, listOfIfsc);

            List<BranchProliferationEntity> entities = branches.stream()
                    .map(branch -> {
                        String branchJson = convertBranchToJson(branch, bankEntity.getBankName());
                        BranchProliferationEntity entity = BranchProliferationEntity.builder()
                                .branchId(branch.getIfscCode())
                                .branchDetailsJson(branchJson)
                                .isProliferated(false)
                                .bankId(bankId)
                                .build();
                        entity.setCreatedBy(createdBy);
                        return entity;
                    })
                    .toList();

            for (MultipartFile propertiesFile : propertiesFiles) {
                List<String> lines = readLinesFromFile(propertiesFile);
                String ifscCode = extractIfscCode(lines.get(5));
                storeFileToSftp(propertiesFile);
                savePropertiesFileDetailsToDatabase(ifscCode, lines, bankId);
            }

            savedIds = branchProliferationRepository.saveAll(entities).stream()
                    .map(BranchProliferationEntity::getId).toList();
            logger.info("Proliferated branches with IDs: {}", savedIds);
        } catch (DataIntegrityViolationException | IfscCodeAlreadyExistsException e) {
            logger.error("Duplicate entry found: {}", e.getMessage());
            throw new IfscCodeAlreadyExistsException(" IFSC code already exists.");
        } catch (ResourceNotFoundException e) {
            logger.error("Uploaded IFSC Code did not match with Branch Details: {}", e.getMessage());
            throw new ResourceNotFoundException(e.getMessage());
        } catch (Exception e) {
            throw new RuntimeException("Exception while creating branch proliferation");
        }
        return savedIds;
    }

    public String convertBranchToJson(Branch branch, String bankName) {
        logger.debug("Converting branch to JSON: {}", branch);
        Map<String, String> branchMap = new HashMap<>();
        branchMap.put("IFSC_CODE", branch.getIfscCode());
        branchMap.put("IFSC_TYPE", branch.getIfscType());
        branchMap.put("MICR_CODE", branch.getMicrCode());
        branchMap.put("BANK_NAME", bankName);
        branchMap.put("BRANCH_NAME", branch.getBranchName());
        branchMap.put("CITY_NAME", branch.getCityName());
        branchMap.put("ADDRESS", branch.getBankAddress());
        branchMap.put("DISTRICT", branch.getDistrict());
        branchMap.put("STATE", branch.getState());

        if (branch.getBranchContact() != null) {
            branchMap.put("STD_CODE", branch.getBranchContact().getStdCode() != null ? branch.getBranchContact().getStdCode() : "");
            branchMap.put("PHONE_NO", branch.getBranchContact().getMobile() != null ? branch.getBranchContact().getMobile() : "");
        } else {
            branchMap.put("STD_CODE", "");
            branchMap.put("PHONE_NO", "");
        }

        if (branch.getBranchFeature() != null) {
            branchMap.put("NEFT_ENABLED", branch.getBranchFeature().getNeftEnabled() != null && branch.getBranchFeature().getNeftEnabled() ? "YES" : "NO");
            branchMap.put("RTGS_ENABLED", branch.getBranchFeature().getRtgsEnabled() != null && branch.getBranchFeature().getRtgsEnabled() ? "YES" : "NO");
            branchMap.put("LCS_ENABLED", branch.getBranchFeature().getLcEnabled() != null && branch.getBranchFeature().getLcEnabled() ? "YES" : "NO");
            branchMap.put("BGS_ENABLED", branch.getBranchFeature().getBgEnabled() != null && branch.getBranchFeature().getBgEnabled() ? "YES" : "NO");
            branchMap.put("OTHERS", branch.getBranchFeature().getOthers() != null && branch.getBranchFeature().getOthers() ? "YES" : "NO");
        } else {
            branchMap.put("NEFT_ENABLED", "NO");
            branchMap.put("RTGS_ENABLED", "NO");
            branchMap.put("LCS_ENABLED", "NO");
            branchMap.put("BGS_ENABLED", "NO");
            branchMap.put("OTHERS", "YES");
        }

        try {
            String json = objectMapper.writeValueAsString(branchMap);
            logger.debug("Converted branch to JSON: {}", json);
            return json;
        } catch (JsonProcessingException e) {
            logger.error("Error converting branch to JSON", e);
            throw new RuntimeException("Error converting branch to JSON", e);
        }
    }

    private void validateLine(String line, String expectedPrefix) {
        logger.debug("Validating line: {}", line);
        if (!line.startsWith(expectedPrefix)) {
            throw new IllegalArgumentException("Invalid file format: expected " + expectedPrefix + " but got " + line);
        }
    }

    private String extractIfscCode(String line) {
        logger.debug("Extracting IFSC code from line: {}", line);
        return line.split("=")[1];
    }

    private void storeFileToSftp(MultipartFile file) throws Exception {
        logger.info("Storing file to SFTP: {}", file.getOriginalFilename());
        List<String> lines = IOUtils.readLines(file.getInputStream(), "UTF-8");
        String ifscCode = extractIfscCode(lines.get(5));
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
        String timestamp = LocalDateTime.now().format(formatter);
        String filename = ifscCode + "CBS.properties-" + timestamp;
        String filePath = "/files/properties/" + filename;

        sftpService.uploadFile(filename, file.getInputStream());
        logger.info("File stored successfully: {}", filePath);
    }

    @Transactional
    public void validateAndUploadFile(MultipartFile file) throws Exception {
        logger.info("Validating and uploading file: {}", file.getOriginalFilename());
        List<String> lines = readLinesFromFile(file);
        validateFileContent(lines);

        String ifscCode = extractIfscCode(lines.get(5));
        checkIfscCodeExists(ifscCode);
        logger.info("File validation and upload complete for IFSC code: {}", ifscCode);
    }

    private void savePropertiesFileDetailsToDatabase(String ifscCode, List<String> lines, Integer bankId) {
        logger.info("Saving properties file details for IFSC code: {}", ifscCode);
        try {
            PropertiesFileEntity propertiesFileEntity = PropertiesFileEntity.builder()
                    .ifscCode(ifscCode)
                    .ifscTypes(lines.get(11).substring(lines.get(11).indexOf('=') + 1).trim())
                    .bankId(bankId)
                    .build();

            propertiesFileRepository.save(propertiesFileEntity);
            logger.info("Successfully saved properties file details for IFSC code: {}", ifscCode);

        } catch (DataIntegrityViolationException e) {
            logger.error("Data integrity violation while saving file details: {}", e.getMessage());
            throw new DatabaseOperationException("Failed to save file details due to data integrity violation: " + e.getMessage(), e);
        } catch (Exception e) {
            logger.error("Unexpected error while saving file details: {}", e.getMessage());
            throw new DatabaseOperationException("An unexpected error occurred while saving file details: " + e.getMessage(), e);
        }
    }

    private void checkIfscCodeExists(String ifscCode) {
        logger.debug("Checking if IFSC code exists: {}", ifscCode);
        if (propertiesFileRepository.existsByIfscCode(ifscCode) || bankBranchRepository.existsById(ifscCode)) {
            logger.error("IFSC code already exists: {}", ifscCode);
            throw new IfscCodeAlreadyExistsException(ifscCode);
        }
    }

    private List<String> readLinesFromFile(MultipartFile file) throws Exception {
        logger.info("Reading lines from file: {}", file.getOriginalFilename());
        try (InputStream inputStream = file.getInputStream()) {
            return IOUtils.readLines(inputStream, "UTF-8");
        } catch (Exception e) {
            logger.error("Error reading file: {}", e.getMessage());
            throw new InvalidFileFormatException("Error reading file: " + e.getMessage());
        }
    }

    private void validateFileContent(List<String> lines) {
        logger.info("Validating file content...");
        if (lines.size() < 12) {
            logger.error("Invalid file format: insufficient number of lines.");
            throw new InvalidFileFormatException("Invalid file format: insufficient number of lines.");
        }

        String ifscCode = extractIfscCode(lines.get(5));

        validateLine(lines.get(0), "# The Properties filename :" + ifscCode + "CBS.properties");
        validateLine(lines.get(5), "IFSC=" + ifscCode);
        validateLine(lines.get(7), "SUSER1=");
        validateLine(lines.get(9), "SUSER2=");
        validateLine(lines.get(11), "Ifsc Type=");
        logger.info("File content validation successful.");
    }

    private String sanitizeAndValidateAddress(String input) {
        logger.debug("Sanitizing and validating address: {}", input);
        if (input == null) {
            logger.error("ADDRESS cannot be null.");
            throw new RuntimeException("ADDRESS cannot be null.");
        }
        String sanitized = input.replaceAll("[^a-zA-Z0-9\\s./()&,-]", "");
        if (sanitized.length() > 200) {
            logger.error("ADDRESS exceeds maximum length of 200 characters.");
            throw new RuntimeException("ADDRESS should be max 200 characters.");
        }
        return sanitized;
    }

    @Transactional
    public String uploadBranchDetailsFromExcel(MultipartFile file, List<MultipartFile> propertiesFiles, Integer bankId) throws Exception {
        logger.info("Uploading branch details from Excel file: {}", file.getOriginalFilename());
        Jwt jwt = (Jwt) SecurityContextHolder.getContext().getAuthentication().getPrincipal();

        Map<String, String> propertiesIfscMap = new HashMap<>();

        if ("BANKER".equals(jwt.getClaimAsString("userType"))) {
            bankId = Integer.valueOf(jwt.getClaimAsString("bankId"));
        }
        if (ObjectUtils.isEmpty(bankId)) throw new ResourceNotFoundException("Bank Not Found");

        for (MultipartFile propertiesFile : propertiesFiles) {
            List<String> lines = readLinesFromFile(propertiesFile);
            String ifscCode = extractIfscCode(lines.get(5));
            String ifscTypes = extractIfscCode(lines.get(11));
            propertiesIfscMap.put(ifscCode, ifscTypes);
        }
        logger.info("Extracted ifscCode and ifscTypes from properties files and saved in a map");

        List<String> requiredColumns = List.of(
                "IFSC_CODE", "IFSC_TYPE", "MICR_CODE", "BANK_NAME", "BRANCH_NAME",
                "CITY_NAME", "ADDRESS", "DISTRICT", "STATE", "STD_CODE",
                "PHONE_NO", "NEFT_ENABLED", "RTGS_ENABLED", "LCS_ENABLED", "BGS_ENABLED", "CREATED_ON"
        );

        Map<String, String> columnToFeatureTypeMap = Map.of(
                "NEFT_ENABLED", "NEFT",
                "RTGS_ENABLED", "RTGS",
                "LCS_ENABLED", "LC",
                "BGS_ENABLED", "BG",
                "OTHERS", "OTHERS"
        );

        List<String> validationErrors = new ArrayList<>();
        List<BranchProliferationEntity> branchDataList = new ArrayList<>();
        Set<String> actualColumns = new HashSet<>();
        Set<String> micrCodesEncountered = new HashSet<>();

        try (InputStream is = file.getInputStream()) {
            Workbook workbook;
            String fileName = file.getOriginalFilename();
            if (fileName != null && fileName.toLowerCase().endsWith(".xls")) {
                logger.info("The type of excel sheet is .xls");
                workbook = new HSSFWorkbook(is);
            } else {
                logger.info("The type of excel sheet is .xlsx");
                workbook = new XSSFWorkbook(is);
            }

            Sheet sheet = workbook.getSheetAt(0);
            Row headerRow = sheet.getRow(0);
            for (Cell cell : headerRow) {
                String header = cell.getStringCellValue().trim();
                actualColumns.add(header);
                if (!requiredColumns.contains(header)) {
                    logger.error("Upload failed. Extra column found: {}", header);
                    throw new InvalidFileFormatException("Upload failed. Extra column found: " + header);
                }
            }
            for (String requiredColumn : requiredColumns) {
                if (!actualColumns.contains(requiredColumn)) {
                    logger.error("Upload failed. Missing required column: {}", requiredColumn);
                    throw new InvalidFileFormatException("Upload failed. Missing required column: " + requiredColumn);
                }
            }

            if (propertiesFiles.size() != sheet.getLastRowNum()) {
                logger.error("Upload failed. The number of properties files does not match the number of branch rows .");
                throw new RuntimeException("Upload failed. The number of properties files does not match the number of branch rows .");
            }

            for (int i = 1; i <= sheet.getLastRowNum(); i++) {
                Row row = sheet.getRow(i);
                if (row == null) {
                    continue;
                }
                BranchProliferationEntity branchData = BranchProliferationEntity.builder()
                        .isProliferated(false)
                        .bankId(bankId)
                        .build();
                branchData.setCreatedDate(LocalDateTime.now());
                StringBuilder branchDetailsJson = new StringBuilder("{");
                DataFormatter formatter = new DataFormatter();
                String ifscCode = null;
                String micrCode = null;
                String ifscType = null;

                for (int j = 0; j < requiredColumns.size(); j++) {
                    Cell cell = row.getCell(j);
                    String columnName = requiredColumns.get(j);
                    if (cell == null || cell.getCellType() == CellType.BLANK) {
                        if (!"STD_CODE".equals(columnName)) {
                            validationErrors.add("Missing value in row " + (i + 1) + " for column " + columnName);
                        } else {
                            branchDetailsJson.append("\"").append(columnName).append("\": \"\",");
                        }
                    } else {
                        String cellValue = formatter.formatCellValue(cell).trim();
                        logger.debug("Cell value for column {}: {}", columnName, cellValue);

                        if ("IFSC_CODE".equals(columnName)) {
                            ifscCode = cellValue;
                            branchData.setBranchId(ifscCode);
                            if (propertiesFileRepository.existsByIfscCode(ifscCode)) {
                                logger.error("Upload failed. IFSC code '{}' already exists Properties file.", ifscCode);
                                throw new RuntimeException("Upload failed. IFSC code '" + ifscCode + "' already exists Properties file.");
                            }
                            if (!propertiesIfscMap.containsKey(ifscCode)) {
                                logger.error("Upload failed. IFSC code '{}' did not match with uploaded Properties file.", ifscCode);
                                throw new RuntimeException("Upload failed. IFSC code '" + ifscCode + "' did not match with uploaded Properties file.");
                            }

                        } else if ("MICR_CODE".equals(columnName)) {
                            micrCode = cellValue;
                            
                            if (!( "NA".equalsIgnoreCase(micrCode) || "WAITING".equalsIgnoreCase(micrCode) )) {
                                if (!micrCode.matches("\\d{9}")) {
                                    logger.error("Upload failed. Invalid MICR Code '{}'.", micrCode);
                                    throw new RuntimeException("Upload failed. Invalid MICR Code '" + micrCode + "'. It must be either 'NA', 'WAITING', or exactly 9 digits.");
                                }
                                if (micrCodesEncountered.contains(micrCode)) {
                                    logger.error("Upload failed. Duplicate MICR code '{}' in the upload.", micrCode);
                                    throw new RuntimeException("Upload failed. Duplicate MICR code '" + micrCode + "'.");
                                } else {
                                    micrCodesEncountered.add(micrCode);
                                }
                                if (bankBranchRepository.existsByMicrCode(micrCode)) {
                                    logger.error("Upload failed. MICR code '{}' already exists in system.", micrCode);
                                    throw new RuntimeException("Upload failed. MICR code '" + micrCode + "' already exists.");
                                }
                            }

                        } else if ("IFSC_TYPE".equals(columnName)) {
                            ifscType = cellValue;
                            List<String> validTypeList = List.of("NEFT_SC", "RTGS-HO", "BRANCH");
                            String[] ifscTypes = ifscType.split(",");
                            Set<String> seenTypes = new HashSet<>();

                            for (String type : ifscTypes) {
                                String trimmedType = type.trim().toUpperCase();
                                if (!validTypeList.contains(trimmedType)) {
                                    throw new RuntimeException("Upload failed. Invalid IFSC TYPE '" + ifscType + "'");
                                }
                                if (!seenTypes.add(trimmedType)) {
                                    throw new RuntimeException("Upload failed. Duplicate IFSC TYPE '" + trimmedType + "' in '" + ifscType + "'");
                                }
                            }
                        } else if (columnToFeatureTypeMap.containsKey(columnName)) {
                            boolean isEnabled = cellValue.equals("YES");
                            String featureType = columnToFeatureTypeMap.get(columnName);
                            Set<String> allowedIfscTypes = Arrays.stream(
                                            propertiesIfscMap.get(ifscCode).substring(propertiesIfscMap.get(ifscCode).indexOf('=') + 1).trim().split(","))
                                    .map(String::trim)
                                    .collect(Collectors.toSet());

                            if (isEnabled) {
                                if (!allowedIfscTypes.contains(featureType)) {
                                    logger.error("Upload failed. {} is enabled in Excel, but it is not allowed according to IFSC types.", featureType);
                                    throw new RuntimeException("Upload failed. " + featureType + " is enabled in Excel, but it is not allowed according to IFSC types.");
                                }
                            } else {
                                if (allowedIfscTypes.contains(featureType)) {
                                    validationErrors.add("Warning: " + featureType + " is allowed by IFSC types but not enabled in Excel. Please check if this is intentional.");
                                }
                            }
                        } else if ("ADDRESS".equals(columnName)) {
                            cellValue = sanitizeAndValidateAddress(cellValue);
                        } else if ("CREATED_ON".equals(columnName)) {
                            if (!cellValue.matches("\\d{2}/\\d{2}/\\d{4}")) {
                                logger.error("Upload failed. CREATED_ON date '{}' is not in the required format (dd/mm/yyyy).", cellValue);
                                throw new RuntimeException("Upload failed. CREATED_ON date '" + cellValue + "' is not in the required format (dd/mm/yyyy).");
                            }
                            try {
                                DateTimeFormatter formatter1 = DateTimeFormatter.ofPattern("dd/MM/yyyy");
                                LocalDate createdOnDate = LocalDate.parse(cellValue, formatter1);
                                LocalDate currentDate = LocalDate.now();

                                if (createdOnDate.isBefore(currentDate)) {
                                    logger.error("Upload failed. CREATED_ON date '{}' cannot be before the current date '{}'.", cellValue, currentDate.format(formatter1));
                                    throw new RuntimeException("Upload failed. CREATED_ON date '" + cellValue + "' cannot be before the current date '" + currentDate.format(formatter1) + "'.");
                                }
                            } catch (DateTimeParseException e) {
                                logger.error("Upload failed. Invalid CREATED_ON date format: {}", e.getMessage());
                                throw new RuntimeException("Upload failed. Invalid CREATED_ON date format: " + e.getMessage());
                            }
                        } else if ("STATE".equals(columnName)) {
                            List<String> validStates = Arrays.asList(
                                    "Andhra Pradesh", "Arunachal Pradesh", "Assam", "Bihar", "Chhattisgarh",
                                    "Goa", "Gujarat", "Haryana", "Himachal Pradesh", "Jharkhand",
                                    "Karnataka", "Kerala", "Madhya Pradesh", "Maharashtra", "Manipur",
                                    "Meghalaya", "Mizoram", "Nagaland", "Odisha", "Punjab",
                                    "Rajasthan", "Sikkim", "Tamil Nadu", "Telangana", "Tripura",
                                    "Uttar Pradesh", "Uttarakhand", "West Bengal",
                                    "Andaman and Nicobar Islands", "Chandigarh", "Dadra and Nagar Haveli and Daman and Diu",
                                    "Delhi", "Jammu and Kashmir", "Ladakh", "Lakshadweep", "Puducherry"
                            );

                            if (cellValue.contains("  ")) {
                                throw new IllegalArgumentException("Multiple consecutive spaces are not allowed between State Name");
                            }

                            String normalizedCellValue = cellValue.trim().replaceAll("\\s+", " ").toLowerCase();

                            boolean isValidState = false;
                            String matchedState = null;

                            for (String state : validStates) {
                                String normalizedState = state.trim().replaceAll("\\s+", " ").toLowerCase();
                                if (normalizedState.equals(normalizedCellValue)) {
                                    isValidState = true;
                                    matchedState = state;
                                    break;
                                }
                            }

                            if (!isValidState) {
                                logger.error("Upload failed. Invalid STATE '{}'. Not in the list of valid states.", cellValue);
                                throw new RuntimeException("Upload failed. Invalid STATE '" + cellValue + "'. Not in the list of valid states.");
                            } else {
                                cellValue = matchedState.toUpperCase();
                                logger.debug("STATE name standardized to: {}", cellValue);
                            }
                        }
                        branchDetailsJson.append("\"").append(columnName).append("\": \"").append(cellValue).append("\",");
                    }
                }
                if (branchDetailsJson.length() > 1) {
                    branchDetailsJson.setLength(branchDetailsJson.length() - 1);
                }
                branchDetailsJson.append("}");

                logger.debug("Branch JSON {}", branchDetailsJson);
                branchData.setBranchDetailsJson(branchDetailsJson.toString());
                branchData.setCreatedBy(jwt.getClaimAsString("sub"));
                branchData.setCreatedDate(LocalDateTime.now());
                branchDataList.add(branchData);
            }
            String validationStatus = validationErrors.isEmpty() ? "Success" : "Failed";
            String errorMessage = String.join("; ", validationErrors);
            ProliferationActivityLogEntity activity = new ProliferationActivityLogEntity();
            activity.setValidationStatus(validationStatus);
            activity.setErrorMessage(errorMessage);
            activity.setCreatedDate(LocalDateTime.now());
            proliferationActivityLogRepository.save(activity);

            if (!validationErrors.isEmpty()) {
                logger.error("Validation failed with errors: {}", errorMessage);
                return "Validation failed with errors: " + errorMessage;
            }

            branchProliferationRepository.saveAll(branchDataList);
            try (InputStream backupIs = file.getInputStream()) {
                sftpService.uploadFile("/files/ifsc_excel_backups/" + file.getOriginalFilename(), backupIs);
            }
            logger.info("Branch details from the Excel file have been processed successfully.");
            return "Branch details from the Excel file have been processed successfully.";
        } catch (Exception e) {
            logger.error("Failed to process Excel file: {}", e.getMessage(), e);
            throw new RuntimeException("Failed to process Excel file: " + e.getMessage());
        }
    }

    public InputStreamResource proliferateAndDownloadExcel() {
        try {
            logger.info("Starting the process to proliferate and download Excel file.");
            Jwt jwt = (Jwt) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
            List<BranchProliferationEntity> branchProliferationList = branchProliferationRepository.findAllByIsProliferatedFalse();

            Set<Integer> bankIds = branchProliferationList.stream()
                    .map(BranchProliferationEntity::getBankId)
                    .collect(Collectors.toSet());

            Map<Long, BankEntity> bankEntityMap = bankRepository.findAllById(bankIds).stream()
                    .collect(Collectors.toMap(BankEntity::getId, bankEntity -> bankEntity));
            List<BranchEntity> branchEntities = branchProliferationList.stream()
                    .map(entity -> {
                        try {
                            BranchEntity branchEntity = convertJsonToBranchEntity(entity.getBranchDetailsJson());
                            branchEntity.getBranchContact().setBankBranch(branchEntity);
                            branchEntity.getBranchFeature().setBankBranch(branchEntity);
                            branchEntity.setIsActive(true);
                            BankEntity bankEntity = bankEntityMap.get(Long.valueOf(entity.getBankId()));
                            if (bankEntity == null) {
                                logger.error("Bank not found with id: {}", entity.getBankId());
                                throw new RuntimeException("Bank not found with id: " + entity.getBankId());
                            }
                            branchEntity.setBank(bankEntity);
                            branchEntity.setCreatedBy(jwt.getClaimAsString("sub"));
                            branchEntity.setCreatedDate(LocalDateTime.now());
                            return branchEntity;
                        } catch (IOException e) {
                            logger.error("Failed to convert JSON to BranchEntity: {}", e.getMessage());
                            throw new RuntimeException("Failed to convert JSON to BranchEntity", e);
                        }
                    })
                    .toList();

            bankBranchRepository.saveAll(branchEntities);
            Workbook workbook = generateExcelFile(branchProliferationList);

            ByteArrayOutputStream out = new ByteArrayOutputStream();
            workbook.write(out);
            workbook.close();

            ByteArrayInputStream in = new ByteArrayInputStream(out.toByteArray());

            List<BranchProliferationEntity> updatedList = new ArrayList<>();
            for (BranchProliferationEntity branch : branchProliferationList) {
                branch.setIsProliferated(true);
                branch.setLastModifiedDate(LocalDateTime.now());
                updatedList.add(branch);
            }

            branchProliferationRepository.saveAll(updatedList);
            logger.info("Successfully proliferated and downloaded the Excel file.");

            return new InputStreamResource(in);
        } catch (Exception e) {
            logger.error("Failed to generate Excel file: {}", e.getMessage());
            throw new RuntimeException("Failed to generate Excel file: " + e.getMessage(), e);
        }
    }

    public InputStreamResource downloadProliferatedExcel() {
        try {
            logger.info("Downloading proliferated Excel file.");
            List<BranchProliferationEntity> branchProliferationList = branchProliferationRepository.findProliferatedBranchesToday();
            Workbook workbook = generateExcelFile(branchProliferationList);

            ByteArrayOutputStream out = new ByteArrayOutputStream();
            workbook.write(out);
            workbook.close();
            ByteArrayInputStream in = new ByteArrayInputStream(out.toByteArray());

            logger.info("Proliferated Excel file downloaded successfully.");
            return new InputStreamResource(in);
        } catch (Exception e) {
            logger.error("Failed to generate Excel file: {}", e.getMessage());
            throw new RuntimeException("Failed to generate Excel file: " + e.getMessage(), e);
        }
    }

    private Workbook generateExcelFile(List<BranchProliferationEntity> branchProliferationList) throws Exception {
        logger.info("Generating Excel file for branch proliferation.");
        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("Branches");

        String[] columns = {
                "IFSC_CODE", "BANK_NAME", "BRANCH_NAME", "CITY_NAME", "ADDRESS",
                "MICR_CODE", "DISTRICT", "STATE", "STD_CODE", "PHONE_NO",
                "RTGS_ENABLED", "NEFT_ENABLED", "LCS_ENABLED", "BGS_ENABLED", "OTHERS"
        };

        for (int i = 0; i < columns.length; i++) {
            if (columns[i].equals("ADDRESS")) {
                sheet.setColumnWidth(i, 12000);
            } else if (columns[i].equals("BANK_NAME")) {
                sheet.setColumnWidth(i, 6000);
            } else {
                sheet.setColumnWidth(i, 4000);
            }
        }

        Row headerRow = sheet.createRow(0);
        for (int i = 0; i < columns.length; i++) {
            Cell cell = headerRow.createCell(i);
            cell.setCellValue(columns[i]);
        }
        int rowNum = 1;

        for (BranchProliferationEntity entity : branchProliferationList) {
            BranchEntity branchEntity = convertJsonToBranchEntity(entity.getBranchDetailsJson());
            Row row = sheet.createRow(rowNum++);
            row.createCell(0).setCellValue(convertToUpperCase(branchEntity.getIfscCode()));
            BankEntity bankEntity = bankRepository.findById(entity.getBankId()).orElseThrow(() -> {
                logger.error("Bank Not Found with id: {}", entity.getBankId());
                return new RuntimeException("Bank Not Found");
            });
            row.createCell(1).setCellValue(convertToUpperCase(bankEntity.getBankName()));
            row.createCell(2).setCellValue(convertToUpperCase(bankEntity.getBankName()));

            row.createCell(3).setCellValue(convertToUpperCase(branchEntity.getCityName()));
            row.createCell(4).setCellValue(convertToUpperCase(branchEntity.getBankAddress()));

            Cell micrCode = row.createCell(5);
            micrCode.setCellValue(String.valueOf(convertToUpperCase(branchEntity.getMicrCode())));

            row.createCell(6).setCellValue(convertToUpperCase(branchEntity.getDistrict()));
            row.createCell(7).setCellValue(convertToUpperCase(branchEntity.getState()));

            String stdCode = (branchEntity.getBranchContact() != null && branchEntity.getBranchContact().getStdCode() != null) ? branchEntity.getBranchContact().getStdCode() : "";
            String phoneNo = (branchEntity.getBranchContact() != null && branchEntity.getBranchContact().getMobile() != null) ? branchEntity.getBranchContact().getMobile() : "";

            Cell stdCodeCell = row.createCell(8);
            stdCodeCell.setCellValue(String.valueOf(convertToUpperCase(stdCode)));

            Cell phoneNoCell = row.createCell(9);
            phoneNoCell.setCellValue(String.valueOf(convertToUpperCase(phoneNo)));

            row.createCell(10).setCellValue(branchEntity.getBranchFeature().isNeftEnabled() ? "YES" : "NO");
            row.createCell(11).setCellValue(branchEntity.getBranchFeature().isRtgsEnabled() ? "YES" : "NO");
            row.createCell(12).setCellValue(branchEntity.getBranchFeature().isLcEnabled() ? "YES" : "NO");
            row.createCell(13).setCellValue(branchEntity.getBranchFeature().isBgEnabled() ? "YES" : "NO");
            row.createCell(14).setCellValue(branchEntity.getBranchFeature().isOthers() ? "YES" : "NO");
        }

        logger.info("Excel file generated successfully.");
        return workbook;
    }

    public static String convertToUpperCase(String input) {
        return Optional.ofNullable(input)
                .map(String::toUpperCase)
                .orElse("");
    }

    public BranchEntity convertJsonToBranchEntity(String jsonString) throws IOException {
        logger.debug("Converting JSON to BranchEntity.");
        BranchDTO branchDTO = objectMapper.readValue(jsonString, BranchDTO.class);
        branchDTO.setOthers("YES");
        return BranchDTOMapper.INSTANCE.branchDTOToBranchEntity(branchDTO);
    }

    public List<BranchProliferationResponse> getPendingProliferationBranches(Integer bankId) {
        logger.info("Fetching pending proliferation branches for bankId: {}", bankId);
        List<BranchProliferationEntity> proliferationEntities;

        if (bankId == null) {
            proliferationEntities = branchProliferationRepository.findAllByIsProliferatedFalse();
        } else {
            proliferationEntities = branchProliferationRepository.findAllByBankIdAndIsProliferatedFalse(bankId);
        }

        return proliferationEntities.stream().map(proliferationEntity -> {
            BranchProliferationResponse branchProliferationResponse = new BranchProliferationResponse();
            branchProliferationResponse.setBankId(proliferationEntity.getBankId());
            branchProliferationResponse.setBranchId(proliferationEntity.getBranchId());
            branchProliferationResponse.setBranchDetails(proliferationEntity.getBranchDetailsJson());
            return branchProliferationResponse;
        }).toList();
    }

    /**
     * Generates and returns an InputStreamResource for downloading an Excel file
     * based on the provided IFSC type. If the IFSC type is null, it fetches all branches.
     *
     * @param ifscType The IFSC type to filter branches by, or null to get all branches.
     * @return An InputStreamResource for downloading the generated Excel file.
     * @throws ExcelGenerationException If an error occurs during Excel file generation.
     */
    public InputStreamResource proliferateAndDownloadExcelTypeHO(String ifscType) throws ExcelGenerationException {
        try {
            logger.info("Proliferating and downloading Excel file for IFSC Type HO.");
            List<BranchDTO> ifscTypeListHO = fetchBranches(ifscType);

            try (Workbook workbook = generateExcelFileIfscTypeHO(ifscTypeListHO);
                 ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {
                workbook.write(outputStream);
                logger.info("Successfully generated Excel file for IFSC Type HO.");

                return new InputStreamResource(new ByteArrayInputStream(outputStream.toByteArray()));
            } catch (Exception e) {
                logger.error("Error while writing Excel file: {}", e.getMessage());
                throw new ExcelGenerationException("Error while writing Excel file", e);
            }
        } catch (Exception e) {
            logger.error("Failed to generate Excel file due to a database error: {}", e.getMessage());
            throw new ExcelGenerationException("Failed to generate Excel file due to a database error: " + e.getMessage(), e);
        }
    }

    /**
     * Fetches branches from the repository based on the provided IFSC type.
     * If the IFSC type is null, it fetches all branches.
     *
     * @param ifscType The IFSC type to filter branches by, or null to get all branches.
     * @return A list of BranchDTO objects.
     */

    public List<BranchDTO> fetchBranches(String ifscType) {
        int pageSize = 500;
        List<CompletableFuture<List<BranchDTO>>> futures = new ArrayList<>();
        Pageable firstPage = PageRequest.of(0, pageSize);
        Page<BranchDTO> firstPageResult = ifscType == null ?
                bankBranchRepository.findAllBranches(firstPage) :
                bankBranchRepository.findBranchesByIfscType("%"+ifscType+"%", firstPage);

        int totalPages = firstPageResult.getTotalPages();
        List<BranchDTO> allBranches = new ArrayList<>(firstPageResult.getContent());
        for (int pageNumber = 1; pageNumber < totalPages; pageNumber++) {
            final int currentPage = pageNumber;
            CompletableFuture<List<BranchDTO>> future = CompletableFuture.supplyAsync(() -> {
                Pageable pageable = PageRequest.of(currentPage, pageSize);
                Page<BranchDTO> page = ifscType == null ?
                        bankBranchRepository.findAllBranches(pageable) :
                        bankBranchRepository.findBranchesByIfscType("%"+ifscType+"%", pageable);
                return page.getContent();
            });
            futures.add(future);
        }
        CompletableFuture<Void> allFutures = CompletableFuture.allOf(
                futures.toArray(new CompletableFuture[0])
        );
        try {
            allFutures.join();

            for (CompletableFuture<List<BranchDTO>> future : futures) {
                allBranches.addAll(future.get()); // This shouldn't block since allOf already completed
            }
        } catch (InterruptedException | ExecutionException e) {
            throw new RuntimeException("Error fetching branch data", e);
        }

        return allBranches;
    }


    private Workbook generateExcelFileIfscTypeHO(List<BranchDTO> ifscTypeListHO) {
        logger.info("Generating Excel file for IFSC Type HO.");
        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("Branches HO");

        String[] columns = {
                "IFSC CODE", "IFSC TYPE", "MICR CODE", "BANK NAME", "BRANCH NAME",
                "CITY NAME", "ADDRESS", "DISTRICT", "STATE", "STD CODE",
                "PHONE NO", "NEFT ENABLED", "RTGS ENABLED", "LCS ENABLED", "BGS ENABLED", "OTHERS"
        };

        for (int i = 0; i < columns.length; i++) {
            if (columns[i].equals("ADDRESS")) {
                sheet.setColumnWidth(i, 12000);
            } else if (columns[i].equals("BANK NAME")) {
                sheet.setColumnWidth(i, 6000);
            } else {
                sheet.setColumnWidth(i, 4000);
            }
        }

        Row headerRow = sheet.createRow(0);
        for (int i = 0; i < columns.length; i++) {
            Cell cell = headerRow.createCell(i);
            cell.setCellValue(columns[i]);
        }

        int rowCount = 1;
        for (BranchDTO branch : ifscTypeListHO) {
            Row row = sheet.createRow(rowCount++);
            row.createCell(0).setCellValue(branch.getIfscCode());
            row.createCell(1).setCellValue(branch.getIfscType());
            row.createCell(2).setCellValue(branch.getMicrCode());

            String bankName = bankRepository.findById(branch.getBankId().intValue())
                    .map(BankEntity::getBankName)
                    .orElse("Bank not found with id:" + branch.getBankId());

            row.createCell(3).setCellValue(bankName);
            row.createCell(4).setCellValue(branch.getBranchName());
            row.createCell(5).setCellValue(branch.getCityName());
            row.createCell(6).setCellValue(branch.getBankAddress());
            row.createCell(7).setCellValue(branch.getDistrict());
            row.createCell(8).setCellValue(branch.getState());
            row.createCell(9).setCellValue(branch.getStdCode());
            row.createCell(10).setCellValue(branch.getPhoneNo());
            row.createCell(11).setCellValue(branch.getNeftEnabled());
            row.createCell(12).setCellValue(branch.getRtgsEnabled());
            row.createCell(13).setCellValue(branch.getLcEnabled());
            row.createCell(14).setCellValue(branch.getBgEnabled());
            row.createCell(15).setCellValue(branch.getOthers());
        }

        logger.info("Excel file for IFSC Type HO generated successfully.");
        return workbook;
    }

    public byte[] downloadTemplate(String template) throws IllegalArgumentException, FileNotFoundException, IOException {
        logger.info("Request to download template: {}", template);

        if ("proliferate".equalsIgnoreCase(template)) {
            logger.debug("Template found: {}", templatePath);
            template = templatePath;
        } else {
            logger.error("Template does not exist: {}", template);
            throw new IllegalArgumentException("Template does not exist");
        }
        try {
            InputStream input = sftpService.downloadFile(template);
            ByteArrayOutputStream output = new ByteArrayOutputStream();

            logger.info("Downloading template from SFTP...");
            IOUtils.copy(input, output);
            logger.info("Template downloaded successfully.");

            return output.toByteArray();
        } catch (FileNotFoundException e) {
            logger.error("Template not found at path: {}", templatePath, e);
            throw new FileNotFoundException("Template not found: " + template);
        } catch (Exception e) {
            logger.error("Error occurred while downloading the template: {}", e.getMessage(), e);
            throw new IOException("Failed to download template", e);
        }
    }

    public Resource streamProliferateAndDownloadExcelTypeHO(String ifscType) throws ExcelGenerationException {
        try {
            logger.info("Streaming Excel file for IFSC Type HO.");

            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();

            try (var workbook = new SXSSFWorkbook(100)) {
                var sheet = workbook.createSheet("Branches HO");
                setupExcelHeader(sheet);
                streamDataToExcel(sheet, ifscType);
                workbook.write(byteArrayOutputStream);
                workbook.dispose();
                logger.info("Successfully generated Excel file for IFSC Type HO.");

                byte[] excelBytes = byteArrayOutputStream.toByteArray();
                return new ByteArrayResource(excelBytes) {
                    @Override
                    public String getFilename() {
                        return "branches-" + System.currentTimeMillis() + ".xlsx";
                    }
                };
            }
        } catch (Exception e) {
            logger.error("Failed to generate Excel file: {}", e.getMessage(), e);
            throw new ExcelGenerationException("Failed to generate Excel file: " + e.getMessage(), e);
        }
    }

    /**
     * Set up the Excel header row
     */
    private void setupExcelHeader(Sheet sheet) {
        var columns = new String[]{
                "IFSC_CODE", "IFSC_TYPE", "MICR_CODE", "BANK_NAME", "BRANCH_NAME",
                "CITY_NAME", "ADDRESS", "DISTRICT", "STATE", "STD_CODE",
                "PHONE_NO", "NEFT_ENABLED", "RTGS_ENABLED", "LCS_ENABLED", "BGS_ENABLED", "OTHERS"
        };

        for (int i = 0; i < columns.length; i++) {
            sheet.setColumnWidth(i, switch (columns[i]) {
                case "ADDRESS" -> 12000;
                case "BANK NAME" -> 6000;
                default -> 4000;
            });
        }

        var headerRow = sheet.createRow(0);
        for (int i = 0; i < columns.length; i++) {
            var cell = headerRow.createCell(i);
            cell.setCellValue(columns[i]);
        }
    }

    /**
     * Stream data directly to Excel without keeping all records in memory, using parallel processing
     */
    private void streamDataToExcel(Sheet sheet, String ifscType) {
        final int pageSize = 1000; // Increased page size for better throughput
        var rowCount = new AtomicInteger(1);
        var bankNameCache = new ConcurrentHashMap<Long, String>();
        var firstPage = PageRequest.of(0, pageSize);
        var firstPageResult = ifscType == null ?
                bankBranchRepository.findAllBranches(firstPage) :
                bankBranchRepository.findBranchesByIfscType("%"+ifscType+"%", firstPage);

        int totalPages = firstPageResult.getTotalPages();
        logger.info("Total pages to process: {}", totalPages);
        processBranchChunk(sheet, firstPageResult.getContent(), rowCount, bankNameCache);

        if (totalPages > 1) {
            var pageQueue = IntStream.range(1, totalPages)
                    .boxed()
                    .collect(Collectors.toCollection(LinkedBlockingQueue::new));
            var latch = new CountDownLatch(pageQueue.size());
            var sheetLock = new Object();
            int workerCount = Math.min(10, pageQueue.size());
            IntStream.range(0, workerCount).forEach(i ->
                    taskExecutor.execute(() -> {
                        try {
                            Integer pageNumber;
                            while ((pageNumber = pageQueue.poll()) != null) {
                                var pageable = PageRequest.of(pageNumber, pageSize);
                                var page = ifscType == null ?
                                        bankBranchRepository.findAllBranches(pageable) :
                                        bankBranchRepository.findBranchesByIfscType("%"+ifscType+"%", pageable);

                                var branchChunk = page.getContent();
                                synchronized (sheetLock) {
                                    processBranchChunk(sheet, branchChunk, rowCount, bankNameCache);
                                }

                                latch.countDown();
                                long remaining = latch.getCount();
                                if (remaining % 10 == 0) {
                                    logger.info("Pages remaining: {} of {}", remaining, totalPages - 1);
                                }
                            }
                        } catch (Exception e) {
                            logger.error("Error processing page", e);
                        }
                    })
            );

            try {
                latch.await();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                logger.error("Interrupted while waiting for page processing", e);
            }
        }
        logger.info("Total records processed: {}", rowCount.get() - 1);
    }

    /**
     * Process a chunk of branch records and add them to the Excel sheet
     */
    private void processBranchChunk(Sheet sheet, List<BranchDTO> branchChunk, AtomicInteger rowCount,
                                    Map<Long, String> bankNameCache) {
        branchChunk.forEach(branch -> {
            int currentRow = rowCount.getAndIncrement();
            var row = sheet.createRow(currentRow);
            populateRow(row, branch, bankNameCache);
        });
    }

    /**
     * Populate a single row with branch data
     */
    private void populateRow(Row row, BranchDTO branch, Map<Long, String> bankNameCache) {
        String bankName = bankNameCache.computeIfAbsent(branch.getBankId(),
                id -> bankRepository.findById(id.intValue())
                        .map(BankEntity::getBankName)
                        .orElse("Bank not found with id:" + id)
        );
        row.createCell(0).setCellValue(branch.getIfscCode());
        row.createCell(1).setCellValue(branch.getIfscType());
        row.createCell(2).setCellValue(branch.getMicrCode());
        row.createCell(3).setCellValue(bankName);
        row.createCell(4).setCellValue(branch.getBranchName());
        row.createCell(5).setCellValue(branch.getCityName());
        row.createCell(6).setCellValue(branch.getBankAddress());
        row.createCell(7).setCellValue(branch.getDistrict());
        row.createCell(8).setCellValue(branch.getState());
        row.createCell(9).setCellValue(branch.getStdCode());
        row.createCell(10).setCellValue(branch.getPhoneNo());
        row.createCell(11).setCellValue(branch.getNeftEnabled());
        row.createCell(12).setCellValue(branch.getRtgsEnabled());
        row.createCell(13).setCellValue(branch.getLcEnabled());
        row.createCell(14).setCellValue(branch.getBgEnabled());
        row.createCell(15).setCellValue(branch.getOthers());
    }
}