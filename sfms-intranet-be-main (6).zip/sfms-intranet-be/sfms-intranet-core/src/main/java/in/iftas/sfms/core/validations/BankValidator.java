package in.iftas.sfms.core.validations;

import in.iftas.sfms.core.entity.BankEntity;
import in.iftas.sfms.core.exception.BankAlreadyExistsException;
import in.iftas.sfms.core.exception.Branchalreadyexists;
import in.iftas.sfms.core.model.Bank;
import in.iftas.sfms.core.model.Branch;
import in.iftas.sfms.core.repository.BankRepository;
import in.iftas.sfms.core.repository.BranchProliferationRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
@Slf4j
public class BankValidator {

    private final BankRepository bankRepository;
    private final BranchProliferationRepository branchProliferationRepository;

    public void validateBankCreation(Bank bank) {
        log.info("Add Bank Validation: {}", bank.getBankName());
        BankEntity existingBank = bankRepository.findByBankNameOrBankShortName(bank.getBankName(), bank.getBankShortName());
        if (existingBank != null) {
            log.info("Bank already exists with id: {}", existingBank.getId());
            throw new BankAlreadyExistsException(bank.getBankName(), bank.getBankShortName());
        }

        for (Branch branch : bank.getBranches()) {
            boolean exists = branchProliferationRepository.existsByBranchId(branch.getIfscCode());
            if (exists) {
                throw new Branchalreadyexists(branch.getIfscCode());
            }
        }

    }
}