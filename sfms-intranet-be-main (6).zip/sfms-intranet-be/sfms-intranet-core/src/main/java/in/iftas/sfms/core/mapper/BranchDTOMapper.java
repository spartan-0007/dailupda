package in.iftas.sfms.core.mapper;/*
 * Copyright (C) 2024 Iftas Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Iftas Inc. ("Confidential Information"). You shall not disclose
 * such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with Iftas Inc.
 *
 * Author: Manoj.Illa
 * Date: July 11, 2024
 */

import in.iftas.sfms.core.dto.BranchDTO;
import in.iftas.sfms.core.entity.BranchEntity;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper
public interface BranchDTOMapper {

    BranchDTOMapper INSTANCE = Mappers.getMapper(BranchDTOMapper.class);

    @Mapping(target = "branchContact.stdCode", source = "stdCode")
    @Mapping(target = "branchContact.mobile", source = "phoneNo")
    @Mapping(target = "branchFeature.neftEnabled", expression = "java(mapYesNoToBoolean(branchDTO.getNeftEnabled()))")
    @Mapping(target = "branchFeature.rtgsEnabled", expression = "java(mapYesNoToBoolean(branchDTO.getRtgsEnabled()))")
    @Mapping(target = "branchFeature.lcEnabled", expression = "java(mapYesNoToBoolean(branchDTO.getLcEnabled()))")
    @Mapping(target = "branchFeature.bgEnabled", expression = "java(mapYesNoToBoolean(branchDTO.getBgEnabled()))")
    @Mapping(target = "branchFeature.others", expression = "java(mapYesNoToBoolean(branchDTO.getOthers()))")
    BranchEntity branchDTOToBranchEntity(BranchDTO branchDTO);

    default Boolean mapYesNoToBoolean(String value) {
        return "YES".equalsIgnoreCase(value);
    }
}
