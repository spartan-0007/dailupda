package in.iftas.sfms.core.exception;

public class ExcelGenerationException extends Exception {
    public ExcelGenerationException(String message, Throwable cause) {
        super(message, cause);
    }
}