package in.iftas.sfms.core.service;

import java.io.InputStream;

/**
 * Common interface for SFTP operations for both JSch and Spring Integration implementations
 */
public interface SftpClient {
    /**
     * Upload a file to the SFTP server
     * 
     * @param filePath Path where the file will be stored on the server
     * @param inputStream Content of the file to upload
     * @throws Exception If any error occurs during upload
     */
    void uploadFile(String filePath, InputStream inputStream) throws Exception;
    
    /**
     * Download a file from the SFTP server
     * 
     * @param filePath Path of the file to download from the server
     * @return InputStream with the file content
     * @throws Exception If any error occurs during download
     */
    InputStream downloadFile(String filePath) throws Exception;
    
    /**
     * Checks if a file exists on the SFTP server
     * 
     * @param filePath Directory path on the server
     * @param originalFilename Filename to check
     * @return true if the file exists, false otherwise
     * @throws Exception If any error occurs during the check
     */
    boolean fileExists(String filePath, String originalFilename) throws Exception;
    
    /**
     * Upload a file with backup capability (moves existing file to backup folder)
     * 
     * @param filePath Directory path on the server
     * @param originalFilename Name of the file to upload
     * @param inputStream Content of the file to upload
     * @throws Exception If any error occurs during upload
     */
    void uploadWithBackup(String filePath, String originalFilename, InputStream inputStream) throws Exception;
}