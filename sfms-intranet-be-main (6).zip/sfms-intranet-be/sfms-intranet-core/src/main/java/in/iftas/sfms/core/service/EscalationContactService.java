package in.iftas.sfms.core.service;

import com.itextpdf.text.Element;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.ColumnText;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfStamper;
import in.iftas.sfms.core.dto.EscalationContactDTO;
import in.iftas.sfms.core.entity.EscalationContactEntity;
import in.iftas.sfms.core.entity.EscalationLevelEntity;
import in.iftas.sfms.core.exception.DuplicateEntryException;
import in.iftas.sfms.core.exception.FileProcessingException;
import in.iftas.sfms.core.exception.ResourceNotFoundException;
import in.iftas.sfms.core.mapper.EscalationContactMapper;
import in.iftas.sfms.core.model.EscalationContact;
import in.iftas.sfms.core.model.Level;
import in.iftas.sfms.core.repository.EscalationContactRepository;
import in.iftas.sfms.core.repository.EscalationLevelRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.FileCopyUtils;
import org.thymeleaf.context.Context;
import org.thymeleaf.spring6.SpringTemplateEngine;
import org.xhtmlrenderer.pdf.ITextRenderer;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class EscalationContactService {
    private static final Logger logger = LoggerFactory.getLogger(EscalationContactService.class);
    private final EscalationContactRepository escalationContactRepository;
    private final EscalationContactMapper escalationContactMapper;
    private final EscalationLevelRepository escalationLevelRepository;
    private final SpringTemplateEngine templateEngine;

    @Autowired
    public EscalationContactService(EscalationContactRepository escalationContactRepository,
                                    EscalationContactMapper escalationContactMapper,
                                    EscalationLevelRepository escalationLevelRepository, SpringTemplateEngine templateEngine) {
        this.templateEngine = templateEngine;
        logger.info("Initializing EscalationContactService");

        this.escalationContactRepository = escalationContactRepository;
        this.escalationContactMapper = escalationContactMapper;
        this.escalationLevelRepository = escalationLevelRepository;
        logger.info("EscalationContactService initialized with repositories and mapper");

    }

    /**
     * Saves an escalation contact after validating the associated escalation level.
     *
     * @param escalationContact the escalation contact to save
     * @throws IllegalArgumentException if the level ID does not correspond to an existing escalation level
     */
    @Transactional
    public void saveEscalationContact(EscalationContact escalationContact) {
        logger.info("Attempting to save escalation contact: {}", escalationContact);

        Optional<EscalationContactEntity> existingContact = escalationContactRepository.findByBankIdAndLevelIdAndContactNameAndContactEmailAndContactNumberAndFeature(
                escalationContact.getBankId(),
                escalationContact.getLevelId(),
                escalationContact.getContactName(),
                escalationContact.getContactEmail(),
                escalationContact.getContactNumber(),
                escalationContact.getFeature()
        );

        if (existingContact.isPresent()) {
            logger.error("Duplicate escalation contact found for bankId: {}, levelId: {}, contactName: {}",
                    escalationContact.getBankId(), escalationContact.getLevelId(), escalationContact.getContactName());
            throw new DuplicateEntryException("Duplicate escalation contact found for bankId: " + escalationContact.getBankId());
        }

        Optional<EscalationLevelEntity> escalationLevelEntity = escalationLevelRepository.findById(escalationContact.getLevelId());

        if (escalationLevelEntity.isPresent()) {
            EscalationContactEntity escalationContactEntity = escalationContactMapper.toEntity(escalationContact);
            escalationContactEntity.setLevel(escalationLevelEntity.get());
            escalationContactRepository.save(escalationContactEntity);
            logger.info("Escalation contact saved successfully: {}", escalationContact);
        } else {
            logger.error("Escalation level with ID {} not found", escalationContact.getLevelId());
            throw new IllegalArgumentException("Escalation level not found for ID: " + escalationContact.getLevelId());
        }
    }

    /**
     * Fetches all escalation contacts from the repository.
     *
     * @return a list of escalation contacts
     */
    public List<List<EscalationContact>> getAllEscalationContacts() {
        logger.info("Fetching all escalation contacts");

        List<EscalationContactEntity> escalationContactEntities = escalationContactRepository.findAll();
        List<EscalationContact> escalationContacts = escalationContactMapper.toModelList(escalationContactEntities);


        logger.info("Fetched {} escalation contacts", escalationContacts.size());

        return new ArrayList<>(escalationContacts.stream()
                .collect(Collectors.groupingBy(EscalationContact::getBankId))
                .values());
    }

    /**
     * Fetches Bank specific escalation contacts from the repository
     *
     * @return a list of escalation contacts
     */
    public List<EscalationContact> getEscalationMatrixByBankId(Long bankId) {
        logger.info("Fetching bank specific escalation contacts");
        List<EscalationContactEntity> escalationContacts = escalationContactRepository.findByBankId(bankId);
        logger.info("Fetched {} bank specific escalation contacts", escalationContacts.size());
        return escalationContactMapper.toModelList(escalationContacts);
    }

    public void updateEscalationMatrix(EscalationContact escalationContact) {
        logger.info("Entering updateEscalationMatrix with EscalationContact: {}", escalationContact);

        Optional<EscalationContactEntity> existingRecord = escalationContactRepository.findById(escalationContact.getId());
        if (existingRecord.isEmpty()) {
            logger.error("Escalation contact not found with id: {}", escalationContact.getId());
            throw new ResourceNotFoundException("Escalation not found with id " + escalationContact.getId());
        }

        Optional<EscalationContactEntity> duplicateContact = escalationContactRepository
                .findByBankIdAndLevelIdAndContactNameAndContactEmailAndContactNumberAndFeature(
                        escalationContact.getBankId(),
                        escalationContact.getLevelId(),
                        escalationContact.getContactName(),
                        escalationContact.getContactEmail(),
                        escalationContact.getContactNumber(),
                        escalationContact.getFeature()
                );

        if (duplicateContact.isPresent()) {
            logger.error("Duplicate escalation contact found for bankId: {}, levelId: {}, contactName: {}",
                    escalationContact.getBankId(), escalationContact.getLevelId(), escalationContact.getContactName());
            throw new DuplicateEntryException("Duplicate escalation contact found for bankId: " + escalationContact.getBankId());
        }

        EscalationContactEntity escalationContactEntity = escalationContactMapper.toEntity(escalationContact);
        escalationContactRepository.save(escalationContactEntity);
        logger.info("Escalation contact updated successfully: {}", escalationContact);
    }

    public void deleteEscalationMatrix(Long id) {
        logger.info("Entering deleteEscalationMatrix with id: {}", id);

        if (escalationContactRepository.existsById(id)) {
            logger.info("EscalationContact exists with id: {}, proceeding to delete", id);

            escalationContactRepository.deleteById(id);
            logger.info("EscalationContact deleted successfully with id: {}", id);

        } else {
            logger.warn("EscalationContact not found with id: {}", id);

            throw new ResourceNotFoundException("Escalation not found with id " + id);
        }
        logger.info("Exiting deleteEscalationMatrix");

    }

    public String getBase64Image() throws IOException {
        ClassPathResource imgFile = new ClassPathResource("static/images/iftas-logo.jpg");
        byte[] bytes = FileCopyUtils.copyToByteArray(imgFile.getInputStream());
        return Base64.getEncoder().encodeToString(bytes);
    }

    /**
     * Fetches Bank and Level specific escalation contacts from the repository
     *
     * @return a downloadable pdf escalation contacts based on parameters
     */
    public ByteArrayResource downloadEscalationMatrixAsPDF(Long level, Long bankId) throws IOException {
        try {
            logger.info("Attempting to retrieve Escalation Matrix with ID: {}", level);
            List<EscalationContactDTO> escalationContacts;

            if (level != null && bankId != null) {
                logger.debug("Retrieving contacts with both Level ID: {} and Bank ID: {}", level, bankId);
                escalationContacts = escalationContactRepository.findDTOByLevelAndBankId(level, bankId);
                if (escalationContacts.isEmpty()) {
                    throw new ResourceNotFoundException("No contacts found for Level ID: " + level + " and Bank ID: " + bankId);
                }
            } else if (level != null) {
                logger.debug("Retrieving contacts with Level ID: {}", level);
                escalationContacts = escalationContactRepository.findDTOByLevel(level);
                if (escalationContacts.isEmpty()) {
                    throw new ResourceNotFoundException("No contacts found for Level ID: " + level);
                }
            } else if (bankId != null) {
                logger.debug("Retrieving contacts with Bank ID: {}", bankId);
                escalationContacts = escalationContactRepository.findDTOByBankId(bankId);
                if (escalationContacts.isEmpty()) {
                    throw new ResourceNotFoundException("No contacts found for Bank ID: " + bankId);
                }
            } else {
                logger.debug("Retrieving all contacts since no specific criteria provided.");
                escalationContacts = escalationContactRepository.findAllDTO();
                if (escalationContacts.isEmpty()) {
                    throw new ResourceNotFoundException("No contacts found");
                }
            }
            logger.info("Retrieved contacts: {}", escalationContacts);

            Map<String, List<EscalationContactDTO>> groupedContacts = escalationContacts.stream()
                    .collect(Collectors.groupingBy(EscalationContactDTO::getLevelName));
            logger.info("Grouped contacts by level: {}", groupedContacts.keySet());

            Map<String, List<EscalationContactDTO>> sortedGroupedContacts = groupedContacts.entrySet().stream()
                    .sorted(Map.Entry.comparingByKey(levelComparator))
                    .collect(Collectors.toMap(
                            Map.Entry::getKey,
                            Map.Entry::getValue,
                            (oldValue, newValue) -> oldValue,
                            LinkedHashMap::new));
            logger.info("Sorted contacts by level: {}", sortedGroupedContacts.keySet());

            for (Map.Entry<String, List<EscalationContactDTO>> entry : sortedGroupedContacts.entrySet()) {
                List<EscalationContactDTO> sortedByBankName = entry.getValue().stream()
                        .sorted(Comparator.comparing(EscalationContactDTO::getBankName))
                        .collect(Collectors.toList());
                entry.setValue(sortedByBankName);
            }
            logger.info("Sorted contacts by level and then bank: {}", sortedGroupedContacts.keySet());

            String base64Image = getBase64Image();
            logger.debug("Retrieved base64 image for logo.");

            Context context = new Context();
            context.setVariable("groupedContacts", sortedGroupedContacts);
            context.setVariable("base64Image", base64Image);
            logger.info("Context for template prepared with grouped contacts and image.");

            String htmlContent = templateEngine.process("escalation-contact", context);
            logger.debug("Generated HTML content for the PDF.");

            try (ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream()) {
                ITextRenderer renderer = new ITextRenderer();
                renderer.setDocumentFromString(htmlContent);
                logger.debug("Document set to renderer, starting layout.");
                renderer.layout();
                logger.debug("PDF layout complete, starting PDF creation.");
                renderer.createPDF(byteArrayOutputStream);
                logger.debug("PDF Creation complete.");

                ByteArrayOutputStream outputWithPageNumbers = new ByteArrayOutputStream();
                PdfReader reader = new PdfReader(byteArrayOutputStream.toByteArray());
                PdfStamper stamper = new PdfStamper(reader, outputWithPageNumbers);

                int totalPages = reader.getNumberOfPages();
                logger.info("Total Pages are {}", totalPages);

                for (int i = 1; i <= totalPages; i++) {
                    ColumnText.showTextAligned(stamper.getOverContent(i), Element.ALIGN_CENTER,
                            new Phrase("Page " + i + " of " + totalPages, FontFactory.getFont(FontFactory.HELVETICA, 10)),
                            300, 30, 0);
                }
                stamper.close();
                reader.close();

                logger.info("PDF generation complete. Returning response.");

                return new ByteArrayResource(outputWithPageNumbers.toByteArray());
            }
        } catch (Exception e) {
            logger.error("Error generating PDF for Escalation Matrix with level: {}. Error: {}", level, e.getMessage(), e);
            throw new FileProcessingException("Failed to generate file (PDF) for Escalation Matrix with level: " + level, e);
        }
    }

    Comparator<String> levelComparator = (l1, l2) -> {
        int levelNumber1 = Integer.parseInt(l1.replaceAll("\\D+", ""));
        int levelNumber2 = Integer.parseInt(l2.replaceAll("\\D+", ""));
        return Integer.compare(levelNumber1, levelNumber2);
    };

    public List<Level> getAllLevels() {
        logger.debug("Fetching all escalation levels from repository");
        List<EscalationLevelEntity> entities = escalationLevelRepository.findAll();
        logger.debug("Found {} escalation level entities", entities.size());

        List<Level> levels = entities.stream()
                .map(entity -> {
                    Level level = new Level();
                    level.setLevelId(entity.getId());
                    level.setLevelName(entity.getLevelName());
                    return level;
                })
                .toList();

        logger.debug("Mapped {} escalation level entities to model objects", levels.size());
        return levels;
    }
}