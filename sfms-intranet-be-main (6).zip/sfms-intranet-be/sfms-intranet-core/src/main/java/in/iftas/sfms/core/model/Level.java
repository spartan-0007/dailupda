package in.iftas.sfms.core.model;

import java.net.URI;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import org.openapitools.jackson.nullable.JsonNullable;
import java.time.OffsetDateTime;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


import java.util.*;
import jakarta.annotation.Generated;

/**
 * Level
 */


public class Level {

  private Long levelId;

  private String levelName;

  public Level levelId(Long levelId) {
    this.levelId = levelId;
    return this;
  }

  /**
   * Get levelId
   * @return levelId
   */
  
  @Schema(name = "levelId", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("levelId")
  public Long getLevelId() {
    return levelId;
  }

  public void setLevelId(Long levelId) {
    this.levelId = levelId;
  }

  public Level levelName(String levelName) {
    this.levelName = levelName;
    return this;
  }

  /**
   * Get levelName
   * @return levelName
   */
  
  @Schema(name = "levelName", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("levelName")
  public String getLevelName() {
    return levelName;
  }

  public void setLevelName(String levelName) {
    this.levelName = levelName;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Level level = (Level) o;
    return Objects.equals(this.levelId, level.levelId) &&
        Objects.equals(this.levelName, level.levelName);
  }

  @Override
  public int hashCode() {
    return Objects.hash(levelId, levelName);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Level {\n");
    sb.append("    levelId: ").append(toIndentedString(levelId)).append("\n");
    sb.append("    levelName: ").append(toIndentedString(levelName)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

