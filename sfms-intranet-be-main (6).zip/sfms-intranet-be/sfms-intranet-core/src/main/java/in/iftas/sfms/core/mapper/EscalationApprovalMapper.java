package in.iftas.sfms.core.mapper;

import in.iftas.sfms.core.entity.EscalationApprovalEntity;
import in.iftas.sfms.core.entity.EscalationApprovalStepEntity;
import in.iftas.sfms.core.model.EscalationApproval;
import in.iftas.sfms.core.model.EscalationApprovalStep;
import org.mapstruct.*;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;

@Mapper(
    componentModel = "spring",
    unmappedTargetPolicy = ReportingPolicy.IGNORE,
    nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE
)
public interface EscalationApprovalMapper {

    // Entity to Model (Response) - Simple mapping without steps
    @Mapping(target = "approvalSteps", ignore = true) // Handle manually in service when needed
    @Mapping(target = "progressPercentage", expression = "java(calculateProgress(entity))")
    @Mapping(target = "isOverdue", expression = "java(isOverdue(entity))")
    @Mapping(target = "statusDisplayText", expression = "java(getStatusDisplayText(entity))")
    @Mapping(target = "comments", ignore = true)
    @Mapping(target = "reason", ignore = true)
    @Mapping(target = "businessJustification", ignore = true)
    @Mapping(target = "expectedImpact", ignore = true)
    @Mapping(target = "makerRole", source = "makerRole", qualifiedByName = "mapEntityMakerRoleToModel")
    @Mapping(target = "currentCheckerRole", source = "currentCheckerRole", qualifiedByName = "mapEntityCurrentCheckerRoleToModel")
    EscalationApproval toModel(EscalationApprovalEntity entity);

    // Model to Entity (Request)
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "status", constant = "PENDING") // Always start with PENDING
    @Mapping(target = "currentCheckerId", ignore = true)
    @Mapping(target = "currentCheckerName", ignore = true)
    @Mapping(target = "currentCheckerRole", ignore = true)
    @Mapping(target = "currentLevel", constant = "1") // Always start with level 1
    @Mapping(target = "totalLevels", ignore = true) // Set by service based on workflow
    @Mapping(target = "dueDate", ignore = true)
    @Mapping(target = "completionDate", ignore = true)
    @Mapping(target = "requestData", ignore = true)
    @Mapping(target = "makerRole", source = "makerRole", qualifiedByName = "mapModelMakerRoleToEntity")
    EscalationApprovalEntity toEntity(EscalationApproval model);

    // List mappings
    List<EscalationApproval> toModelList(List<EscalationApprovalEntity> entities);
    List<EscalationApprovalEntity> toEntityList(List<EscalationApproval> models);

    // Date conversion methods
    default Date localDateTimeToDate(LocalDateTime localDateTime) {
        return localDateTime != null ? 
            Date.from(localDateTime.atZone(ZoneId.systemDefault()).toInstant()) : null;
    }

    default LocalDateTime dateToLocalDateTime(Date date) {
        return date != null ? 
            LocalDateTime.ofInstant(date.toInstant(), ZoneId.systemDefault()) : null;
    }

    // Enum mappings for ActionType
    default EscalationApproval.ActionTypeEnum mapEntityActionTypeToModel(EscalationApprovalEntity.ActionType actionType) {
        return actionType != null ? EscalationApproval.ActionTypeEnum.valueOf(actionType.name()) : null;
    }

    default EscalationApprovalEntity.ActionType mapModelActionTypeToEntity(EscalationApproval.ActionTypeEnum actionType) {
        return actionType != null ? EscalationApprovalEntity.ActionType.valueOf(actionType.name()) : null;
    }

    // Enum mappings for Status
    default EscalationApproval.StatusEnum mapEntityStatusToModel(EscalationApprovalEntity.Status status) {
        return status != null ? EscalationApproval.StatusEnum.valueOf(status.name()) : null;
    }

    default EscalationApprovalEntity.Status mapModelStatusToEntity(EscalationApproval.StatusEnum status) {
        return status != null ? EscalationApprovalEntity.Status.valueOf(status.name()) : null;
    }

    // Enum mappings for Maker Role
    @Named("mapEntityMakerRoleToModel")
    default EscalationApproval.MakerRoleEnum mapEntityMakerRoleToModel(EscalationApprovalEntity.Role role) {
        return role != null ? EscalationApproval.MakerRoleEnum.valueOf(role.name()) : null;
    }

    @Named("mapModelMakerRoleToEntity")
    default EscalationApprovalEntity.Role mapModelMakerRoleToEntity(EscalationApproval.MakerRoleEnum role) {
        return role != null ? EscalationApprovalEntity.Role.valueOf(role.name()) : null;
    }

    // Enum mappings for Current Checker Role
    @Named("mapEntityCurrentCheckerRoleToModel")
    default EscalationApproval.CurrentCheckerRoleEnum mapEntityCurrentCheckerRoleToModel(EscalationApprovalEntity.Role role) {
        return role != null ? EscalationApproval.CurrentCheckerRoleEnum.valueOf(role.name()) : null;
    }

    default EscalationApprovalEntity.Role mapModelCurrentCheckerRoleToEntity(EscalationApproval.CurrentCheckerRoleEnum role) {
        return role != null ? EscalationApprovalEntity.Role.valueOf(role.name()) : null;
    }

    // Progress calculation
    default Double calculateProgress(EscalationApprovalEntity entity) {
        if (entity.getTotalLevels() == null || entity.getTotalLevels() == 0) {
            return 0.0;
        }
        
        if (EscalationApprovalEntity.Status.COMPLETED.equals(entity.getStatus())) {
            return 100.0;
        }
        
        if (EscalationApprovalEntity.Status.REJECTED.equals(entity.getStatus())) {
            return 0.0;
        }
        
        // For pending, calculate based on current level
        if (entity.getCurrentLevel() != null) {
            double progress = ((double) entity.getCurrentLevel() - 1) / entity.getTotalLevels() * 100;
            return Math.max(0.0, Math.min(100.0, progress));
        }
        
        return 0.0;
    }

    // Overdue check
    default Boolean isOverdue(EscalationApprovalEntity entity) {
        if (entity.getDueDate() == null) {
            return false;
        }
        
        if (EscalationApprovalEntity.Status.COMPLETED.equals(entity.getStatus()) ||
            EscalationApprovalEntity.Status.REJECTED.equals(entity.getStatus())) {
            return false;
        }
        
        return LocalDateTime.now().isAfter(entity.getDueDate());
    }

    // Status display text
    default String getStatusDisplayText(EscalationApprovalEntity entity) {
        if (entity.getStatus() == null) {
            return "Unknown";
        }
        
        Integer currentLevel = entity.getCurrentLevel() != null ? entity.getCurrentLevel() : 1;
        Integer totalLevels = entity.getTotalLevels() != null ? entity.getTotalLevels() : 1;
        
        switch (entity.getStatus()) {
            case PENDING:
                if (isOverdue(entity)) {
                    return String.format("Pending - Overdue (Level %d of %d)", currentLevel, totalLevels);
                } else {
                    return String.format("Pending Approval (Level %d of %d)", currentLevel, totalLevels);
                }
            case COMPLETED:
                return "Approved & Completed";
            case REJECTED:
                return "Rejected";
            default:
                return entity.getStatus().name();
        }
    }
}