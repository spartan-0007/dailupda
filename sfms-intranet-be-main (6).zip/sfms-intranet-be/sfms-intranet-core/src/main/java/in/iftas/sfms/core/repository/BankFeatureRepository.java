package in.iftas.sfms.core.repository;

import in.iftas.sfms.core.entity.BankFeatureEntity;
import in.iftas.sfms.core.entity.BranchEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BankFeatureRepository extends JpaRepository<BankFeatureEntity, Long> {

    @Query("SELECT " +

            "SUM(CASE WHEN bf.neftEnabled = true THEN 1 ELSE 0 END) AS totalNeftEnabledBranches, " +
            "SUM(CASE WHEN bf.rtgsEnabled = true THEN 1 ELSE 0 END) AS totalRtgsEnabledBranches, " +
            "SUM(CASE WHEN bf.rtgsEnabled = true AND bf.neftEnabled = true THEN 1 ELSE 0 END) AS totalRtgsAndNeftEnabledBranches, " +
            "SUM(CASE WHEN bf.lcEnabled = true THEN 1 ELSE 0 END) AS totalLcEnabledBranches, " +
            "SUM(CASE WHEN bf.bgEnabled = true THEN 1 ELSE 0 END) AS totalBgEnabledBranches, " +
            "SUM(CASE WHEN bf.bgEnabled = true AND bf.lcEnabled = true THEN 1 ELSE 0 END) AS totalLcAndBgEnabledBranches, " +
            "COUNT(br)  AS totalBranches, " +
            "SUM(CASE WHEN bf.others = true THEN 1 ELSE 0 END) AS totalOthersBranches " +
            "FROM BankFeatureEntity bf " +
            "LEFT JOIN bf.bankBranch br " +
            "LEFT JOIN br.bank b " +
            "WHERE b.isActive = true and br.isActive=true")
    List<Object[]> findEnabledBranchFeatureCounts();

    @Query(value = "SELECT bb.* FROM i_bank_features bf JOIN i_bank_branches bb ON bb.ifsc_code = bf.bank_branch_ifsc_code JOIN i_banks b ON b.id = bb.bank_id WHERE bf.rtgs_enabled = 1 AND b.is_active = 1", nativeQuery = true)
    List<BranchEntity> findActiveRtgsEnabledBranchesNative();

    @Query("SELECT " +
            "SUM(CASE WHEN bf.neftEnabled = true THEN 1 ELSE 0 END) AS totalNeftEnabledBranches, " +
            "SUM(CASE WHEN bf.rtgsEnabled = true THEN 1 ELSE 0 END) AS totalRtgsEnabledBranches, " +
            "SUM(CASE WHEN bf.rtgsEnabled = true AND bf.neftEnabled = true THEN 1 ELSE 0 END) AS totalRtgsAndNeftEnabledBranches, " +
            "SUM(CASE WHEN bf.lcEnabled = true THEN 1 ELSE 0 END) AS totalLcEnabledBranches, " +
            "SUM(CASE WHEN bf.bgEnabled = true THEN 1 ELSE 0 END) AS totalBgEnabledBranches, " +
            "SUM(CASE WHEN bf.bgEnabled = true AND bf.lcEnabled = true THEN 1 ELSE 0 END) AS totalLcAndBgEnabledBranches, " +
            "COUNT(br) AS totalBranches, " +
            "SUM(CASE WHEN bf.others = true THEN 1 ELSE 0 END) AS totalOthersBranches, " +
            "COUNT(CASE WHEN b.id =:bankId THEN br.ifscCode ELSE NULL END) AS totalBranchesByBankId " +
            "FROM BankFeatureEntity bf " +
            "INNER JOIN bf.bankBranch br " +
            "INNER JOIN br.bank b " +
            "WHERE b.isActive = true and br.isActive=true")
    List<Object[]> findEnabledBranchFeatureCountsWithOwnBank(@Param("bankId") Long bankId);
}
