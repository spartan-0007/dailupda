package in.iftas.sfms.core.repository;

import in.iftas.sfms.core.entity.ChangeRequestFormEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ChangeRequestFormRepository extends JpaRepository<ChangeRequestFormEntity, Long> {
    List<ChangeRequestFormEntity> findByBankShortNameOrderByOpenDateDesc(String bankShortName);
}