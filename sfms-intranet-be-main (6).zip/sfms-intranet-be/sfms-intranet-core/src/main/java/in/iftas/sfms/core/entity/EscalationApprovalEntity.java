package in.iftas.sfms.core.entity;

import jakarta.persistence.*;
import lombok.*;
import in.iftas.sfms.common.entity.BaseEntity;

import java.time.LocalDateTime;

@Entity
@Table(name = "i_escalation_approvals", indexes = {
        @Index(name = "idx_status", columnList = "status"),
        @Index(name = "idx_maker", columnList = "maker_id"),
        @Index(name = "idx_current_checker", columnList = "current_checker_id"),
        @Index(name = "idx_escalation", columnList = "escalation_id"),
        @Index(name = "idx_checker_status", columnList = "current_checker_id, status")
})
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class EscalationApprovalEntity extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "escalation_id", nullable = false)
    private Long escalationId;

    @Column(name = "action_type", nullable = false)
    @Enumerated(EnumType.STRING)
    private ActionType actionType;

    @Column(name = "request_data", nullable = false, columnDefinition = "LONGTEXT")
    private String requestData;

    // Current workflow status
    @Column(name = "status", nullable = false)
    @Enumerated(EnumType.STRING)
    private Status status;

    @Column(name = "current_level", nullable = false)
    private Integer currentLevel = 1;

    @Column(name = "total_levels", nullable = false)
    private Integer totalLevels;

    // Maker details
    @Column(name = "maker_id", nullable = false)
    private String makerId;

    @Column(name = "maker_name", nullable = false)
    private String makerName;

    @Column(name = "maker_role", nullable = false)
    @Enumerated(EnumType.STRING)
    private Role makerRole;

    // Current checker details
    @Column(name = "current_checker_id")
    private String currentCheckerId;

    @Column(name = "current_checker_name")
    private String currentCheckerName;

    @Column(name = "current_checker_role")
    @Enumerated(EnumType.STRING)
    private Role currentCheckerRole;

    // Dates
    @Column(name = "due_date")
    private LocalDateTime dueDate;

    @Column(name = "completion_date")
    private LocalDateTime completionDate;

    public enum ActionType {
        CREATE, UPDATE, DELETE
    }

    public enum Status {
        PENDING, COMPLETED, REJECTED
    }

    public enum Role {
        BANKER, OPERATOR, ADMIN
    }

    public boolean isVisibleToUser(String userId) {
        if (makerId.equals(userId) && Status.COMPLETED.equals(status)) {
            return false;
        }
        return true;
    }

    public boolean canApprove(String userId) {
        return Status.PENDING.equals(status) && 
               userId.equals(currentCheckerId);
    }

    public boolean isLastLevel() {
        return currentLevel.equals(totalLevels);
    }
}