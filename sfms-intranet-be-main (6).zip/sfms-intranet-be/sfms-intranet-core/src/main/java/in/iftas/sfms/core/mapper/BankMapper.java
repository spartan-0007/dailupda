package in.iftas.sfms.core.mapper;


import in.iftas.sfms.core.dto.BankDTO;
import in.iftas.sfms.core.entity.BankEntity;
import in.iftas.sfms.core.mapper.util.MappingUtils;
import in.iftas.sfms.core.model.Bank;
import in.iftas.sfms.core.model.Branch;
import org.mapstruct.AfterMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.factory.Mappers;

import java.util.List;

@Mapper(componentModel = "spring", uses = {BranchMapper.class, MappingUtils.class})
public interface BankMapper {

    BankMapper INSTANCE = Mappers.getMapper(BankMapper.class);

    @Mapping(source = "id", target = "id")
    @Mapping(source = "bankName", target = "bankName")
    @Mapping(source = "bankShortName", target = "bankShortName")
    @Mapping(source = "isActive", target = "isActive")
    @Mapping(source = "isHostedOnCloud", target = "isHostedOnCloud")
    @Mapping(source = "createdBy", target = "createdBy", ignore = true)
    @Mapping(source = "createdDate", target = "createdDate", dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX", ignore = true)
    @Mapping(source = "lastModifiedBy", target = "lastModifiedBy")
    @Mapping(source = "lastModifiedDate", target = "lastModifiedDate", dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX")
    @Mapping(source = "branches", target = "branches", ignore = true)
    Bank toModel(BankEntity bankEntity);

    default Bank toModelWithBranches(BankEntity bankEntity, boolean includeBranches, BranchMapper branchMapper) {
        Bank bank = toModel(bankEntity);
        if (includeBranches) {
            List<Branch> branches = bankEntity.getBranches().stream()
                    .map(branchMapper::toModel)
                    .toList();
            bank.setBranches(branches);
        }
        return bank;
    }

    @Mapping(source = "id", target = "id")
    @Mapping(source = "bankName", target = "bankName")
    @Mapping(source = "bankShortName", target = "bankShortName")
    @Mapping(source = "isActive", target = "isActive")
    @Mapping(source = "isHostedOnCloud", target = "isHostedOnCloud")
    @Mapping(source = "createdBy", target = "createdBy")
    @Mapping(source = "createdDate", target = "createdDate", dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX")
    @Mapping(source = "lastModifiedBy", target = "lastModifiedBy")
    @Mapping(source = "lastModifiedDate", target = "lastModifiedDate", dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX")
    @Mapping(source = "branches", target = "branches", ignore = true)
        // Optionally ignore branches if needed
    BankEntity toEntity(Bank bank);


    @Mapping(source = "id", target = "id")
    @Mapping(source = "bankName", target = "bankName")
    @Mapping(source = "bankShortName", target = "bankShortName")
    @Mapping(source = "isActive", target = "isActive")
    @Mapping(source = "isHostedOnCloud", target = "isHostedOnCloud")
    @Mapping(source = "createdBy", target = "createdBy", ignore = true)
    @Mapping(source = "createdDate", target = "createdDate", dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX", ignore = true)
    @Mapping(source = "lastModifiedBy", target = "lastModifiedBy")
    @Mapping(source = "lastModifiedDate", target = "lastModifiedDate", dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX")
    @Mapping(source = "branches", target = "branches", ignore = true)
        // Ignore branches if needed
    BankEntity updateBankEntityFromModel(Bank bank, @MappingTarget BankEntity entity);

    default void mapIfNotNull(Bank source, @MappingTarget BankEntity target) {
        if (source.getBankName() != null) {
            target.setBankName(source.getBankName());
        }
        if (source.getBankShortName() != null) {
            target.setBankShortName(source.getBankShortName());
        }
        if (source.getIsActive() != null || source.getIsActive() == Boolean.FALSE) {
            target.setIsActive(source.getIsActive());
        } else {
            target.setIsActive(Boolean.FALSE);
        }
        // Handling isHostedOnCloud to set even if it is false
        Boolean isHostedOnCloud = source.getIsHostedOnCloud();
        if (isHostedOnCloud != null || source.getIsHostedOnCloud() == Boolean.FALSE) {
            target.setIsHostedOnCloud(isHostedOnCloud);
        } else {
            target.setIsHostedOnCloud(Boolean.FALSE);
        }
    }

    @AfterMapping
    default void applyConditionalUpdates(Bank bank, @MappingTarget BankEntity bankEntity) {
        mapIfNotNull(bank, bankEntity);
    }

    @Mapping(target = "createdBy", ignore = true)
    @Mapping(target = "createdDate", ignore = true)
    @Mapping(target = "lastModifiedBy", ignore = true)
    @Mapping(target = "lastModifiedDate", ignore = true)
    @Mapping(target = "branches", ignore = true)
    @Mapping(source = "id", target = "id")
    @Mapping(source = "bankName", target = "bankName")
    @Mapping(source = "bankShortName", target = "bankShortName")
    @Mapping(source = "isActive", target = "isActive")
    @Mapping(source = "isHostedOnCloud", target = "isHostedOnCloud")
    Bank toModelFromDto(BankDTO bankDTO);

}
