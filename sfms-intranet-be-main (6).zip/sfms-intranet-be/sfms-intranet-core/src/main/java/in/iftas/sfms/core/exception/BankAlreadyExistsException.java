package in.iftas.sfms.core.exception;

public class BankAlreadyExistsException extends RuntimeException {
    public BankAlreadyExistsException(String bankname, String bankShortName) {
        super(String.format("Bank already exist with name "+ bankname+ " or short name "+ bankShortName));
    }
}
