package in.iftas.sfms.core.entity;/*
 * Copyright (C) 2024 Iftas Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Iftas Inc. ("Confidential Information"). You shall not disclose
 * such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with Iftas Inc.
 *
 * Author: Manoj.Illa
 * Date: July 11, 2024
 */

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "i_crl_details_history")
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class CrlFileDetailsHistoryEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "file_id", nullable = false)
    private CrlFileDetailsEntity fileDetails;

    @Column(name = "uploadedBy", nullable = false)
    private String uploadedBy;

    @Column(name = "uploadedDate", nullable = false)
    private LocalDateTime uploadedDate;

    @Column(name = "sftpPath", nullable = false)
    private String sftpPath;
}
