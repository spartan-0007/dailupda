package in.iftas.sfms.core.model;

import java.net.URI;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import org.openapitools.jackson.nullable.JsonNullable;
import java.time.OffsetDateTime;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


import java.util.*;
import jakarta.annotation.Generated;

/**
 * LcBgMessagesReportRequest
 */


public class LcBgMessagesReportRequest {

  private String fromDate;

  private String toDate;

  /**
   * The format of the report (pdf or excel).
   */
  public enum FormatEnum {
    PDF("pdf"),
    
    EXCEL("excel");

    private String value;

    FormatEnum(String value) {
      this.value = value;
    }

    @JsonValue
    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static FormatEnum fromValue(String value) {
      for (FormatEnum b : FormatEnum.values()) {
        if (b.value.equals(value)) {
          return b;
        }
      }
      throw new IllegalArgumentException("Unexpected value '" + value + "'");
    }
  }

  private FormatEnum format;

  private String fromBank;

  private String toBank;

  private Integer messageType;

  private String messageStatus;

  public LcBgMessagesReportRequest fromDate(String fromDate) {
    this.fromDate = fromDate;
    return this;
  }

  /**
   * Start date for the report (inclusive).
   * @return fromDate
   */
  
  @Schema(name = "fromDate", description = "Start date for the report (inclusive).", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("fromDate")
  public String getFromDate() {
    return fromDate;
  }

  public void setFromDate(String fromDate) {
    this.fromDate = fromDate;
  }

  public LcBgMessagesReportRequest toDate(String toDate) {
    this.toDate = toDate;
    return this;
  }

  /**
   * End date for the report (inclusive).
   * @return toDate
   */
  
  @Schema(name = "toDate", description = "End date for the report (inclusive).", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("toDate")
  public String getToDate() {
    return toDate;
  }

  public void setToDate(String toDate) {
    this.toDate = toDate;
  }

  public LcBgMessagesReportRequest format(FormatEnum format) {
    this.format = format;
    return this;
  }

  /**
   * The format of the report (pdf or excel).
   * @return format
   */
  
  @Schema(name = "format", description = "The format of the report (pdf or excel).", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("format")
  public FormatEnum getFormat() {
    return format;
  }

  public void setFormat(FormatEnum format) {
    this.format = format;
  }

  public LcBgMessagesReportRequest fromBank(String fromBank) {
    this.fromBank = fromBank;
    return this;
  }

  /**
   * The originating bank IFSC Code.
   * @return fromBank
   */
  @Pattern(regexp = "^[A-Z]{4}0[A-Z0-9]{6}$") 
  @Schema(name = "fromBank", description = "The originating bank IFSC Code.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("fromBank")
  public String getFromBank() {
    return fromBank;
  }

  public void setFromBank(String fromBank) {
    this.fromBank = fromBank;
  }

  public LcBgMessagesReportRequest toBank(String toBank) {
    this.toBank = toBank;
    return this;
  }

  /**
   * The destination bank Code.
   * @return toBank
   */
  @Pattern(regexp = "^[A-Z]{4}0[A-Z0-9]{6}$") 
  @Schema(name = "toBank", description = "The destination bank Code.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("toBank")
  public String getToBank() {
    return toBank;
  }

  public void setToBank(String toBank) {
    this.toBank = toBank;
  }

  public LcBgMessagesReportRequest messageType(Integer messageType) {
    this.messageType = messageType;
    return this;
  }

  /**
   * The type of message (integer, max 6 digits).
   * maximum: 999999
   * @return messageType
   */
  @Max(999999) 
  @Schema(name = "messageType", description = "The type of message (integer, max 6 digits).", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("messageType")
  public Integer getMessageType() {
    return messageType;
  }

  public void setMessageType(Integer messageType) {
    this.messageType = messageType;
  }

  public LcBgMessagesReportRequest messageStatus(String messageStatus) {
    this.messageStatus = messageStatus;
    return this;
  }

  /**
   * Get messageStatus
   * @return messageStatus
   */
  
  @Schema(name = "messageStatus", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("messageStatus")
  public String getMessageStatus() {
    return messageStatus;
  }

  public void setMessageStatus(String messageStatus) {
    this.messageStatus = messageStatus;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    LcBgMessagesReportRequest lcBgMessagesReportRequest = (LcBgMessagesReportRequest) o;
    return Objects.equals(this.fromDate, lcBgMessagesReportRequest.fromDate) &&
        Objects.equals(this.toDate, lcBgMessagesReportRequest.toDate) &&
        Objects.equals(this.format, lcBgMessagesReportRequest.format) &&
        Objects.equals(this.fromBank, lcBgMessagesReportRequest.fromBank) &&
        Objects.equals(this.toBank, lcBgMessagesReportRequest.toBank) &&
        Objects.equals(this.messageType, lcBgMessagesReportRequest.messageType) &&
        Objects.equals(this.messageStatus, lcBgMessagesReportRequest.messageStatus);
  }

  @Override
  public int hashCode() {
    return Objects.hash(fromDate, toDate, format, fromBank, toBank, messageType, messageStatus);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class LcBgMessagesReportRequest {\n");
    sb.append("    fromDate: ").append(toIndentedString(fromDate)).append("\n");
    sb.append("    toDate: ").append(toIndentedString(toDate)).append("\n");
    sb.append("    format: ").append(toIndentedString(format)).append("\n");
    sb.append("    fromBank: ").append(toIndentedString(fromBank)).append("\n");
    sb.append("    toBank: ").append(toIndentedString(toBank)).append("\n");
    sb.append("    messageType: ").append(toIndentedString(messageType)).append("\n");
    sb.append("    messageStatus: ").append(toIndentedString(messageStatus)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

