package in.iftas.sfms.core.repository;

import in.iftas.sfms.core.entity.EscalationLevelEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EscalationLevelRepository extends JpaRepository<EscalationLevelEntity, Long> {
    
    /**
     * Check if escalation level exists and is active (used for validation)
     */
    boolean existsByIdAndIsActive(Long id, Boolean isActive);
    
    /**
     * Get levels by department for specific scenarios
     */
    List<EscalationLevelEntity> findByDepartmentIdAndIsActiveTrueOrderByLevelOrder(Long departmentId);
}