package in.iftas.sfms.core.mapper;/*
 * Copyright (C) 2024 Iftas Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Iftas Inc. ("Confidential Information"). You shall not disclose
 * such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with Iftas Inc.
 *
 * Author: Manoj.Illa
 * Date: October 2, 2024
 */

import in.iftas.sfms.core.entity.ReleaseAccessEntity;
import in.iftas.sfms.core.entity.ReleaseDetailsEntity;
import in.iftas.sfms.core.model.PatchDetails;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;

import java.util.List;

@Mapper(componentModel = "spring")
public interface PatchMapper {

    PatchMapper INSTANCE = Mappers.getMapper(PatchMapper.class);

    @Mapping(source = "id", target = "patchId")
    @Mapping(source = "fileSize", target = "fileSize", qualifiedByName = "convertFileSize")
    PatchDetails toPatchDetails(ReleaseDetailsEntity releaseDetails);

    List<PatchDetails> toPatchDetailsList(List<ReleaseDetailsEntity> releaseDetails);

    // Custom mapping for bankIds using @AfterMapping
    @AfterMapping
    default void mapBankIds(ReleaseDetailsEntity releaseDetails, @MappingTarget PatchDetails patchDetails) {
        List<Long> bankIds = releaseDetails.getReleaseAccessEntities().stream()
                .map(ReleaseAccessEntity::getBankId)
                .toList();
        patchDetails.setBankIds(bankIds);
    }

    @Named("convertFileSize")
    default String convertFileSize(Long sizeInBytes) {
        final int ONE_MB = 1024 * 1024;
        final int ONE_KB = 1024;

        if (sizeInBytes >= ONE_MB) {
            double sizeInMB = (double) sizeInBytes / ONE_MB;
            return String.format("%.2f MB", sizeInMB);
        } else {
            double sizeInKB = (double) sizeInBytes / ONE_KB;
            return String.format("%.2f KB", sizeInKB);
        }
    }
}
