package in.iftas.sfms.core.api.impl;

/*
 * Copyright (C) 2024 Iftas Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Iftas Inc. ("Confidential Information"). You shall not disclose
 * such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with Iftas Inc.
 *
 * Author: Manoj.Illa
 * Date: November 06, 2024
 */

import in.iftas.sfms.core.api.MarqueesApi;
import in.iftas.sfms.core.exception.GlobalMarqueeException;
import in.iftas.sfms.core.exception.ResourceNotFoundException;
import in.iftas.sfms.core.model.ApiResponseError;
import in.iftas.sfms.core.model.Marquee;
import in.iftas.sfms.core.model.ModelApiResponse;
import in.iftas.sfms.core.service.MarqueeService;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.Collections;
import java.util.List;

@RestController
public class MarqueesApiImpl implements MarqueesApi {

    private static final Logger logger = LoggerFactory.getLogger(MarqueesApiImpl.class);
    private final MarqueeService marqueeService;

    @Autowired
    public MarqueesApiImpl(MarqueeService marqueeService) {
        this.marqueeService = marqueeService;
    }

    @Override
    public ResponseEntity<ModelApiResponse> getMarquees(Long bankId) {
        logger.info("Entering marqueesGet method with bankId: {}", bankId);
        ModelApiResponse response = new ModelApiResponse();

        try {
            List<Marquee> marquees = marqueeService.getMarquees(bankId);
            response.setSuccess(true);
            response.setMessage("Marquees retrieved successfully");
            response.setData(Collections.singletonMap("marquees", marquees));
        } catch (Exception e) {
            logger.error("Error retrieving marquees: {}", e.getMessage(), e);
            response.setSuccess(false);
            response.setMessage("Failed to retrieve marquees");
        }

        logger.info("Exiting marqueesGet method successfully");
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @Override
    public ResponseEntity<ModelApiResponse> createMarquee(@Valid @RequestBody Marquee marquee) {
        logger.info("Entering marqueesPost method with marquee data: {}", marquee);

        ModelApiResponse response = new ModelApiResponse();

        try {
            logger.debug("Calling marqueeService.createMarquee with marquee data: {}", marquee);

            Marquee createdMarquee = marqueeService.createMarquee(marquee);
            logger.info("Marquee created successfully with marquee data: {}", createdMarquee);

            response.setSuccess(true);
            response.setMessage("Marquee created successfully");
            response.setData(Collections.singletonMap("marquee", createdMarquee));
            logger.info("Exiting marqueesPost method successfully");
            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch (ResourceNotFoundException e) {
            logger.error("Bank ID associated with the marquee is not found");
            response.setSuccess(false);
            response.setMessage("Marquee failed to create as bank id associated with the marquee is not found");
            ApiResponseError apiResponseError = new ApiResponseError();
            apiResponseError.setCode("404");
            apiResponseError.setMessage("Message not found.");
            response.setError(apiResponseError);
            return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
        } catch (GlobalMarqueeException e) {
            logger.error("IsGlobal marquee already exists");
            response.setSuccess(false);
            response.setMessage("Marquee failed to create as IsGlobal marquee already exists");
            return new ResponseEntity<>(response, HttpStatus.CONFLICT);
        } catch (Exception e) {
            logger.error("Error creating marquee: {}", e.getMessage(), e);
            response.setSuccess(false);
            response.setMessage("Marquee failed to create");
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

    @Override
    public ResponseEntity<Void> deleteMarquee(Long marqueeId) {
        logger.info("Received request to delete user manual by id");
        marqueeService.deleteMarqueeById(marqueeId);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @Override
    public ResponseEntity<ModelApiResponse> updateMarquee(@Valid @RequestBody Marquee marquee) {
        logger.info("Entering updateMarquee method with marquee data: {}", marquee);

        ModelApiResponse response = new ModelApiResponse();

        try {
            logger.debug("Calling marqueeService.updateMarquee with marquee data: {}", marquee);

            Marquee updatedMarquee = marqueeService.updateMarquee( marquee);
            logger.info("Marquee updated successfully with marquee data: {}", updatedMarquee);

            response.setSuccess(true);
            response.setMessage("Marquee updated successfully");
            response.setData(Collections.singletonMap("marquee", updatedMarquee));
            logger.info("Exiting updateMarquee method successfully");
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (ResourceNotFoundException e) {
            logger.error("Marquee or Bank not found: {}", e.getMessage());
            response.setSuccess(false);
            response.setMessage(e.getMessage());
            ApiResponseError apiResponseError = new ApiResponseError();
            apiResponseError.setCode("404");
            apiResponseError.setMessage("Resource not found.");
            response.setError(apiResponseError);
            return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
        } catch (GlobalMarqueeException e) {
            logger.error("IsGlobal marquee conflict: {}", e.getMessage());
            response.setSuccess(false);
            response.setMessage("Marquee update failed as another global marquee already exists");
            return new ResponseEntity<>(response, HttpStatus.CONFLICT);
        } catch (Exception e) {
            logger.error("Error updating marquee: {}", e.getMessage(), e);
            response.setSuccess(false);
            response.setMessage("Marquee failed to update");
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

}
