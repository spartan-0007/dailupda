package in.iftas.sfms.core.enums;

public enum BranchFeatureType {
    NEFT,
    RTGS,
    RTGS_AND_NEFT,
    LC,
    BG,
    LC_AND_BG,
    OTHERS
}