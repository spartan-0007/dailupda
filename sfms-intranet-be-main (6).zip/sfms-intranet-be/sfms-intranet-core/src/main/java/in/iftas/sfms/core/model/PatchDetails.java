package in.iftas.sfms.core.model;

import java.net.URI;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.springframework.format.annotation.DateTimeFormat;
import org.openapitools.jackson.nullable.JsonNullable;
import java.time.OffsetDateTime;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


import java.util.*;
import jakarta.annotation.Generated;

/**
 * PatchDetails
 */


public class PatchDetails {

  private Long patchId;

  private String fileName;

  private String version;

  private String description;

  private String uploadedBy;

  @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
  private Date uploadedDate;

  private String sftpPath;

  private String fileSize;

  @Valid
  private List<Long> bankIds;

  public PatchDetails patchId(Long patchId) {
    this.patchId = patchId;
    return this;
  }

  /**
   * Unique identifier of the patch.
   * @return patchId
   */
  
  @Schema(name = "patchId", description = "Unique identifier of the patch.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("patchId")
  public Long getPatchId() {
    return patchId;
  }

  public void setPatchId(Long patchId) {
    this.patchId = patchId;
  }

  public PatchDetails fileName(String fileName) {
    this.fileName = fileName;
    return this;
  }

  /**
   * Name of the patch file.
   * @return fileName
   */
  
  @Schema(name = "fileName", description = "Name of the patch file.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("fileName")
  public String getFileName() {
    return fileName;
  }

  public void setFileName(String fileName) {
    this.fileName = fileName;
  }

  public PatchDetails version(String version) {
    this.version = version;
    return this;
  }

  /**
   * Version of the patch.
   * @return version
   */
  
  @Schema(name = "version", description = "Version of the patch.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("version")
  public String getVersion() {
    return version;
  }

  public void setVersion(String version) {
    this.version = version;
  }

  public PatchDetails description(String description) {
    this.description = description;
    return this;
  }

  /**
   * Short description of the patch.
   * @return description
   */
  
  @Schema(name = "description", description = "Short description of the patch.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("description")
  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public PatchDetails uploadedBy(String uploadedBy) {
    this.uploadedBy = uploadedBy;
    return this;
  }

  /**
   * User who uploaded the patch.
   * @return uploadedBy
   */
  
  @Schema(name = "uploadedBy", description = "User who uploaded the patch.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("uploadedBy")
  public String getUploadedBy() {
    return uploadedBy;
  }

  public void setUploadedBy(String uploadedBy) {
    this.uploadedBy = uploadedBy;
  }

  public PatchDetails uploadedDate(Date uploadedDate) {
    this.uploadedDate = uploadedDate;
    return this;
  }

  /**
   * Timestamp when the patch was uploaded.
   * @return uploadedDate
   */
  @Valid 
  @Schema(name = "uploadedDate", description = "Timestamp when the patch was uploaded.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("uploadedDate")
  public Date getUploadedDate() {
    return uploadedDate;
  }

  public void setUploadedDate(Date uploadedDate) {
    this.uploadedDate = uploadedDate;
  }

  public PatchDetails sftpPath(String sftpPath) {
    this.sftpPath = sftpPath;
    return this;
  }

  /**
   * Path of the patch file on the SFTP server.
   * @return sftpPath
   */
  
  @Schema(name = "sftpPath", description = "Path of the patch file on the SFTP server.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("sftpPath")
  public String getSftpPath() {
    return sftpPath;
  }

  public void setSftpPath(String sftpPath) {
    this.sftpPath = sftpPath;
  }

  public PatchDetails fileSize(String fileSize) {
    this.fileSize = fileSize;
    return this;
  }

  /**
   * Get fileSize
   * @return fileSize
   */
  
  @Schema(name = "fileSize", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("fileSize")
  public String getFileSize() {
    return fileSize;
  }

  public void setFileSize(String fileSize) {
    this.fileSize = fileSize;
  }

  public PatchDetails bankIds(List<Long> bankIds) {
    this.bankIds = bankIds;
    return this;
  }

  public PatchDetails addItem(Long bankIdsItem) {
    if (this.bankIds == null) {
      this.bankIds = new ArrayList<>();
    }
    this.bankIds.add(bankIdsItem);
    return this;
  }

  /**
   * Get bankIds
   * @return bankIds
   */
  
  @Schema(name = "bankIds", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("bankIds")
  public List<Long> getBankIds() {
    return bankIds;
  }

  public void setBankIds(List<Long> bankIds) {
    this.bankIds = bankIds;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    PatchDetails patchDetails = (PatchDetails) o;
    return Objects.equals(this.patchId, patchDetails.patchId) &&
        Objects.equals(this.fileName, patchDetails.fileName) &&
        Objects.equals(this.version, patchDetails.version) &&
        Objects.equals(this.description, patchDetails.description) &&
        Objects.equals(this.uploadedBy, patchDetails.uploadedBy) &&
        Objects.equals(this.uploadedDate, patchDetails.uploadedDate) &&
        Objects.equals(this.sftpPath, patchDetails.sftpPath) &&
        Objects.equals(this.fileSize, patchDetails.fileSize) &&
        Objects.equals(this.bankIds, patchDetails.bankIds);
  }

  @Override
  public int hashCode() {
    return Objects.hash(patchId, fileName, version, description, uploadedBy, uploadedDate, sftpPath, fileSize, bankIds);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class PatchDetails {\n");
    sb.append("    patchId: ").append(toIndentedString(patchId)).append("\n");
    sb.append("    fileName: ").append(toIndentedString(fileName)).append("\n");
    sb.append("    version: ").append(toIndentedString(version)).append("\n");
    sb.append("    description: ").append(toIndentedString(description)).append("\n");
    sb.append("    uploadedBy: ").append(toIndentedString(uploadedBy)).append("\n");
    sb.append("    uploadedDate: ").append(toIndentedString(uploadedDate)).append("\n");
    sb.append("    sftpPath: ").append(toIndentedString(sftpPath)).append("\n");
    sb.append("    fileSize: ").append(toIndentedString(fileSize)).append("\n");
    sb.append("    bankIds: ").append(toIndentedString(bankIds)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

