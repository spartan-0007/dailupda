package in.iftas.sfms.core.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "i_release_details")
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class ReleaseDetailsEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "file_name", nullable = false, unique = true)
    private String fileName;

    @Column(name = "version", nullable = false)
    private String version;

    @Column(name = "description", nullable = false)
    private String description;

    @Column(name = "uploaded_by", nullable = false)
    private String uploadedBy;

    @Column(name = "uploaded_date", nullable = false)
    private LocalDateTime uploadedDate;

    @Column(name = "sftp_path", nullable = false)
    private String sftpPath;

    @Column(name = "file_size")
    private Long fileSize;

    @OneToMany(mappedBy = "releaseDetails", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
    private Set<ReleaseAccessEntity> releaseAccessEntities = new HashSet<>();

    @OneToMany(mappedBy = "releaseDetails", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private Set<ReleaseDownloadLogEntity> downloadLogs;

    public void addReleaseAccess(ReleaseAccessEntity accessEntity) {
        accessEntity.setReleaseDetails(this);
        this.releaseAccessEntities.add(accessEntity);
    }

    public void removeReleaseAccess(ReleaseAccessEntity accessEntity) {
        accessEntity.setReleaseDetails(null);
        this.releaseAccessEntities.remove(accessEntity);
    }

}