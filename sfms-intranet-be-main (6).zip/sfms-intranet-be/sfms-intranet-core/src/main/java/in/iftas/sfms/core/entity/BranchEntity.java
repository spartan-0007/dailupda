package in.iftas.sfms.core.entity;

import jakarta.persistence.*;
import lombok.*;


@Entity
@Table(name = "i_bank_branches", indexes = {
        @Index(name = "idx_bank_id", columnList = "bank_id"),
        @Index(name = "idx_ifsc_code", columnList = "ifsc_code")

})
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class BranchEntity extends BaseEntity {

    @Id
    @Column(name = "ifsc_code", nullable = false, unique = true)
    private String ifscCode;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "bank_id")
    private BankEntity bank;

    @Column(name = "ifsc_type")
    private String ifscType;

    @Column(name = "micr_code")
    private String micrCode;

    @Column(name = "branch_name")
    private String branchName;

    @Column(name = "city_name")
    private String cityName;

    @Column(name = "address")
    private String bankAddress;

    @Column(name = "district")
    private String district;

    @Column(name = "state")
    private String state;

    @Column(name = "isActive")
    private Boolean isActive;

    //@OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "bank_contact_id", referencedColumnName = "id")
    @OneToOne(cascade = CascadeType.ALL, mappedBy = "bankBranch", orphanRemoval = true, fetch = FetchType.EAGER)
    private BankContactEntity branchContact;

    //@OneToOne(cascade = CascadeType.ALL, mappedBy = "bankBranch", orphanRemoval = true)
    @JoinColumn(name = "bank_feature_id", referencedColumnName = "id")
    @OneToOne(cascade = CascadeType.ALL, mappedBy = "bankBranch", orphanRemoval = true, fetch = FetchType.EAGER)
    private BankFeatureEntity branchFeature;
}