package in.iftas.sfms.core.validations;

import in.iftas.sfms.common.entity.ApprovalRequestEntity;
import in.iftas.sfms.common.repository.ApprovalRequestRepository;
import in.iftas.sfms.core.exception.FileProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.core.JsonProcessingException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.List;

@Slf4j
@Component
@RequiredArgsConstructor
public class FileUploadApprovalValidator {

    private final ApprovalRequestRepository approvalRequestRepository;
    private final ObjectMapper objectMapper;

    public void validateFileUpload(Object fileDetails, String entityType) {
        try {
            String fileName = extractFileName(fileDetails);
            validateFileName(fileName, entityType);
        } catch (JsonProcessingException e) {
            log.error("JSON processing error during validation", e);
            throw new FileProcessingException("Failed to process file details", e);
        }
    }

    private String extractFileName(Object fileDetails) throws JsonProcessingException {
        JsonNode rootNode = objectMapper.valueToTree(fileDetails);
        JsonNode fileDetailsNode = rootNode.path("fileDetails");

        if (fileDetailsNode.isMissingNode()) {
            fileDetailsNode = rootNode;
        }

        String fileName = fileDetailsNode.path("fileName").asText();

        if (fileName == null || fileName.isEmpty()) {
            throw new IllegalArgumentException("File name cannot be null or empty");
        }
        return fileName;
    }

    private void validateFileName(String fileName, String entityType) {
        List<ApprovalRequestEntity> existingApprovals =
                approvalRequestRepository.findByFileNameAndEntityType(fileName, entityType);

        if (!existingApprovals.isEmpty()) {
            throw new FileProcessingException(
                    String.format("File '%s' already has a pending %s approval request",
                            fileName, entityType)
            );
        }
    }
}