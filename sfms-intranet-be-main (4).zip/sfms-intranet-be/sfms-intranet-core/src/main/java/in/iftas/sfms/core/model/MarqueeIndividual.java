package in.iftas.sfms.core.model;

import java.net.URI;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;
import org.openapitools.jackson.nullable.JsonNullable;
import java.time.OffsetDateTime;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


import java.util.*;
import jakarta.annotation.Generated;

/**
 * MarqueeIndividual
 */

//@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = //"2024-11-05T20:58:00.302037+05:30[Asia/Calcutta]", comments = "Generator version: 6.6.0")
public class MarqueeIndividual {

  private String bankId;

  @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
  private Date startTime;

  @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
  private Date endTime;

  public MarqueeIndividual bankId(String bankId) {
    this.bankId = bankId;
    return this;
  }

  /**
   * The ID of the bank
   * @return bankId
   */
  
  @Schema(name = "bankId", description = "The ID of the bank", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("bankId")
  public String getBankId() {
    return bankId;
  }

  public void setBankId(String bankId) {
    this.bankId = bankId;
  }

  public MarqueeIndividual startTime(Date startTime) {
    this.startTime = startTime;
    return this;
  }

  /**
   * The start time of the marquee for this bank
   * @return startTime
   */
  @Valid 
  @Schema(name = "startTime", description = "The start time of the marquee for this bank", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("startTime")
  public Date getStartTime() {
    return startTime;
  }

  public void setStartTime(Date startTime) {
    this.startTime = startTime;
  }

  public MarqueeIndividual endTime(Date endTime) {
    this.endTime = endTime;
    return this;
  }

  /**
   * The end time of the marquee for this bank
   * @return endTime
   */
  @Valid 
  @Schema(name = "endTime", description = "The end time of the marquee for this bank", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("endTime")
  public Date getEndTime() {
    return endTime;
  }

  public void setEndTime(Date endTime) {
    this.endTime = endTime;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    MarqueeIndividual marqueeIndividual = (MarqueeIndividual) o;
    return Objects.equals(this.bankId, marqueeIndividual.bankId) &&
        Objects.equals(this.startTime, marqueeIndividual.startTime) &&
        Objects.equals(this.endTime, marqueeIndividual.endTime);
  }

  @Override
  public int hashCode() {
    return Objects.hash(bankId, startTime, endTime);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class MarqueeIndividual {\n");
    sb.append("    bankId: ").append(toIndentedString(bankId)).append("\n");
    sb.append("    startTime: ").append(toIndentedString(startTime)).append("\n");
    sb.append("    endTime: ").append(toIndentedString(endTime)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

