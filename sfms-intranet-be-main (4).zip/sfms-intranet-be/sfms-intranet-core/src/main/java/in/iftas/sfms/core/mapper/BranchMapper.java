package in.iftas.sfms.core.mapper;

import in.iftas.sfms.core.entity.BankContactEntity;
import in.iftas.sfms.core.entity.BankFeatureEntity;
import in.iftas.sfms.core.entity.BranchEntity;
import in.iftas.sfms.core.model.Branch;
import in.iftas.sfms.core.model.BranchBankActiveStatus;
import org.mapstruct.*;

@Mapper(componentModel = "spring",
        uses = {BankContactMapper.class, BankFeatureMapper.class},
        nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface BranchMapper {

    @Mapping(source = "ifscCode", target = "ifscCode")
    @Mapping(source = "ifscType", target = "ifscType")
    @Mapping(source = "micrCode", target = "micrCode")
    @Mapping(source = "branchName", target = "branchName")
    @Mapping(source = "cityName", target = "cityName")
    @Mapping(source = "bankAddress", target = "bankAddress")
    @Mapping(source = "district", target = "district")
    @Mapping(source = "state", target = "state")
    @Mapping(source = "isActive", target = "isActive")
    @Mapping(source = "branchContact", target = "branchContact")
    @Mapping(source = "branchFeature", target = "branchFeature")
    @Mapping(source = "createdBy", target = "createdBy")
    @Mapping(source = "createdDate", target = "createdDate")
    @Mapping(source = "lastModifiedBy", target = "lastModifiedBy")
    @Mapping(source = "lastModifiedDate", target = "lastModifiedDate")
    Branch toModel(BranchEntity branchEntity);

    @Mapping(source = "ifscCode", target = "ifscCode")
    @Mapping(source = "ifscType", target = "ifscType")
    @Mapping(source = "micrCode", target = "micrCode")
    @Mapping(source = "branchName", target = "branchName")
    @Mapping(source = "cityName", target = "cityName")
    @Mapping(source = "bankAddress", target = "bankAddress")
    @Mapping(source = "district", target = "district")
    @Mapping(source = "state", target = "state")
    @Mapping(source = "isActive", target = "isActive")
    @Mapping(source = "bank.isActive", target = "isBankActive")
    @Mapping(source = "branchContact", target = "branchContact")
    @Mapping(source = "branchFeature", target = "branchFeature")
    @Mapping(source = "createdBy", target = "createdBy")
    @Mapping(source = "createdDate", target = "createdDate")
    @Mapping(source = "lastModifiedBy", target = "lastModifiedBy")
    @Mapping(source = "lastModifiedDate", target = "lastModifiedDate")
    BranchBankActiveStatus toBranchBankActiveStatusModel(BranchEntity branchEntity);

    @Mapping(source = "ifscCode", target = "ifscCode")
    @Mapping(source = "ifscType", target = "ifscType")
    @Mapping(source = "micrCode", target = "micrCode")
    @Mapping(source = "branchName", target = "branchName")
    @Mapping(source = "cityName", target = "cityName")
    @Mapping(source = "bankAddress", target = "bankAddress")
    @Mapping(source = "district", target = "district")
    @Mapping(source = "state", target = "state")
    @Mapping(source = "isActive", target = "isActive")
    @Mapping(source = "branchContact", target = "branchContact")
    @Mapping(source = "branchFeature", target = "branchFeature")
    @Mapping(source = "createdBy", target = "createdBy")
    @Mapping(source = "createdDate", target = "createdDate")
    @Mapping(source = "lastModifiedBy", target = "lastModifiedBy")
    @Mapping(source = "lastModifiedDate", target = "lastModifiedDate")
    BranchEntity toEntity(Branch branch);


    @Mapping(source = "ifscCode", target = "ifscCode")
    @Mapping(source = "ifscType", target = "ifscType")
    @Mapping(source = "micrCode", target = "micrCode")
    @Mapping(source = "branchName", target = "branchName")
    @Mapping(source = "cityName", target = "cityName")
    @Mapping(source = "bankAddress", target = "bankAddress")
    @Mapping(source = "district", target = "district")
    @Mapping(source = "state", target = "state")
    @Mapping(source = "isActive", target = "isActive")
    @Mapping(source = "branchContact", target = "branchContact")
    @Mapping(source = "branchFeature", target = "branchFeature")
    @Mapping(source = "createdBy", target = "createdBy", ignore = true)
    @Mapping(source = "createdDate", target = "createdDate", dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX", ignore = true)
    @Mapping(source = "lastModifiedBy", target = "lastModifiedBy")
    @Mapping(source = "lastModifiedDate", target = "lastModifiedDate", dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX")
    BranchEntity updateBranchEntityFromModel(Branch branch, @MappingTarget BranchEntity entity);

    default void mapIfNotNull(Branch source, @MappingTarget BranchEntity target) {
        if (source.getIfscCode() != null) {
            target.setIfscCode(source.getIfscCode());
        }
        if (source.getIfscType() != null) {
            target.setIfscType(source.getIfscType());
        }
        if (source.getMicrCode() != null) {
            target.setMicrCode(source.getMicrCode());
        }
        if (source.getBranchName() != null) {
            target.setBranchName(source.getBranchName());
        }
        if (source.getCityName() != null) {
            target.setCityName(source.getCityName());
        }
        if (source.getBankAddress() != null) {
            target.setBankAddress(source.getBankAddress());
        }
        if (source.getDistrict() != null) {
            target.setDistrict(source.getDistrict());
        }
        if (source.getState() != null) {
            target.setState(source.getState());
        }

        if (source.getBranchContact() != null) {
            if (target.getBranchContact() == null) {
                target.setBranchContact(new BankContactEntity());
            }
            BankContactMapper.INSTANCE.toEntity(source.getBranchContact(), target.getBranchContact());
            target.getBranchContact().setBankBranch(target); // Ensure the relationship is set
        } else if (target.getBranchContact() != null) {
            target.setBranchContact(null); // Remove existing branchContact if source is null
        }
        if (source.getBranchFeature() != null) {
            if (target.getBranchFeature() == null) {
                target.setBranchFeature(new BankFeatureEntity());
            }
            BankFeatureMapper.INSTANCE.toEntity(source.getBranchFeature(), target.getBranchFeature());
            target.getBranchFeature().setBankBranch(target); // Ensure the relationship is set
        } else if (target.getBranchFeature() != null) {
            target.setBranchFeature(null); // Remove existing branchFeature if source is null
        }



    }

    @AfterMapping
    default void applyConditionalUpdates(Branch branch, @MappingTarget BranchEntity branchEntity) {
        mapIfNotNull(branch, branchEntity);
    }



}