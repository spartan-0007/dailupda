package in.iftas.sfms.core.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import in.iftas.sfms.core.entity.EscalationApprovalEntity;
import in.iftas.sfms.core.entity.EscalationApprovalStepEntity;
import in.iftas.sfms.core.exception.DuplicateEntryException;
import in.iftas.sfms.core.mapper.EscalationApprovalMapper;
import in.iftas.sfms.core.model.EscalationApproval;
import in.iftas.sfms.core.model.EscalationApprovalActionRequest;
import in.iftas.sfms.core.model.EscalationContact;
import in.iftas.sfms.core.model.RejectEscalationApproval;
import in.iftas.sfms.core.repository.EscalationApprovalRepository;
import in.iftas.sfms.core.repository.EscalationApprovalStepRepository;
import in.iftas.sfms.core.repository.EscalationContactRepository;
import jakarta.persistence.EntityNotFoundException;
import org.hibernate.service.spi.ServiceException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Service
@Transactional
public class EscalationApprovalService {

    private final EscalationApprovalRepository approvalRepository;

    private final EscalationApprovalStepRepository stepRepository;

    private final EscalationContactRepository escalationContactRepository;

    private final EscalationContactService escalationContactService;

    private final EscalationApprovalMapper approvalMapper;

    private final ObjectMapper objectMapper;

    private static final Logger logger = LoggerFactory.getLogger(EscalationApprovalService.class);

    public EscalationApprovalService(EscalationApprovalRepository approvalRepository, EscalationApprovalStepRepository stepRepository, EscalationContactRepository escalationContactRepository, EscalationContactService escalationContactService, EscalationApprovalMapper approvalMapper, ObjectMapper objectMapper) {
        this.approvalRepository = approvalRepository;
        this.stepRepository = stepRepository;
        this.escalationContactRepository = escalationContactRepository;
        this.escalationContactService = escalationContactService;
        this.approvalMapper = approvalMapper;
        this.objectMapper = objectMapper;
    }

    /**
     * Create a new escalation approval request
     * Takes EscalationContact model and creates approval workflow
     */
    /**
     * Create a new escalation approval request
     * Takes EscalationContact model and creates approval workflow
     */
    public void createApproval(EscalationContact request) throws JsonProcessingException {
        // Validate escalation contact data
        validateEscalationContactData(request);

        // Create new approval entity
        EscalationApprovalEntity approval = new EscalationApprovalEntity();

        // Set maker details from current user
        setMakerDetailsFromCurrentUser(approval);

        // Set approval details
        approval.setEscalationId(0L); // No specific escalation ID for contact creation
        approval.setActionType(EscalationApprovalEntity.ActionType.CREATE);
        approval.setStatus(EscalationApprovalEntity.Status.PENDING);
        approval.setCurrentLevel(1);

        // Convert EscalationContact to JSON and store in requestData
        try {
            approval.setRequestData(objectMapper.writeValueAsString(request));
        } catch (Exception e) {
            throw new RuntimeException("Failed to serialize escalation contact data", e);
        }
        // Initialize steps BEFORE saving
        initializeApprovalSteps(approval);

        // Assign checker to first step BEFORE saving
        assignCheckerToCurrentStep(approval);

        // SINGLE SAVE - JPA cascade will handle the steps
        approvalRepository.save(approval);
    }

    /**
     * Validate escalation contact data
     */
    private void validateEscalationContactData(EscalationContact request) throws JsonProcessingException {
            // 1. Check if the escalation contact already exists in the main table
            validateContactDoesNotExist(request);

            // 2. Check if there's already a pending approval for the same contact data
            validateNoPendingApprovalForSameContactData(request);

    }

    /**
     * Check if escalation contact already exists in the main table
     */
    private void validateContactDoesNotExist(EscalationContact escalationContact) {
        boolean contactExists = escalationContactRepository
                .existsByBankIdAndLevelIdAndContactNameAndContactEmailAndContactNumberAndFeatureAndBusinessAndDesignation(
                        escalationContact.getBankId(),
                        escalationContact.getLevelId(),
                        escalationContact.getContactName(),
                        escalationContact.getContactEmail(),
                        escalationContact.getContactNumber(),
                        escalationContact.getFeature(),
                        escalationContact.getBusiness(),
                        escalationContact.getDesignation()
                );
        if (contactExists) {
            throw new DuplicateEntryException(
                    String.format("Escalation contact already exists for bankId: %d, levelId: %d, contactName: %s",
                            escalationContact.getBankId(),
                            escalationContact.getLevelId(),
                            escalationContact.getContactName())
            );
        }
    }

    /**
     * Check if there's already a pending approval for the same contact data
     */
    private void validateNoPendingApprovalForSameContactData(EscalationContact escalationContact) throws JsonProcessingException {
        // Find all pending CREATE approvals
        List<EscalationApprovalEntity> pendingApprovals = approvalRepository
                .findByStatusAndActionType(EscalationApprovalEntity.Status.PENDING, EscalationApprovalEntity.ActionType.CREATE);

        // Check if any of them contains the same contact data
        for (EscalationApprovalEntity approval : pendingApprovals) {
            EscalationContact existingContact = objectMapper.readValue(
                    approval.getRequestData(), EscalationContact.class);

            if (isSameContactData(escalationContact, existingContact)) {
                throw new DuplicateEntryException(
                        String.format("A pending approval already exists for the same escalation contact data. ApprovalId: %d",
                                approval.getId())
                );
            }

        }
    }

    /**
     * Compare two escalation contacts to check if they represent the same data
     */
    private boolean isSameContactData(EscalationContact contact1, EscalationContact contact2) {
        return contact1.getBankId().equals(contact2.getBankId()) &&
                contact1.getLevelId().equals(contact2.getLevelId()) &&
                safeEquals(contact1.getContactName(), contact2.getContactName()) &&
                safeEquals(contact1.getContactEmail(), contact2.getContactEmail()) &&
                safeEquals(contact1.getContactNumber(), contact2.getContactNumber()) &&
                safeEquals(contact1.getFeature(), contact2.getFeature()) &&
                safeEquals(contact1.getBusiness(), contact2.getBusiness()) &&
                safeEquals(contact1.getDesignation(), contact2.getDesignation());
    }

    /**
     * Safe comparison for nullable strings
     */
    private boolean safeEquals(String str1, String str2) {
        if (str1 == null && str2 == null) return true;
        if (str1 == null || str2 == null) return false;
        return str1.equals(str2);
    }

    /**
     * Get current user details and set them as maker
     */
    private void setMakerDetailsFromCurrentUser(EscalationApprovalEntity entity) {
        Jwt jwt = (Jwt) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        String username = jwt.getClaimAsString("name");
        String userType = jwt.getClaimAsString("userType");
        String makerId = jwt.getClaimAsString("sub");

        entity.setMakerId(makerId);
        entity.setMakerName(username);

        if ("BANKER".equals(userType)) {
            entity.setMakerRole(EscalationApprovalEntity.Role.BANKER);
        } else if ("OPERATOR".equals(userType)) {
            entity.setMakerRole(EscalationApprovalEntity.Role.OPERATOR);
        } else {
            entity.setMakerRole(EscalationApprovalEntity.Role.ADMIN);
        }
    }

    /**
     * Process approval or rejection
     */
    public EscalationApproval processApproval(String checkerId, EscalationApprovalActionRequest request) {
        EscalationApprovalEntity approval = approvalRepository.findByIdWithSteps(request.getApprovalId())
                .orElseThrow(() -> new EntityNotFoundException("Approval not found with id: " + request.getApprovalId()));

        // Validate that the user can approve this request
        validateCanApprove(approval, checkerId);

        // Get current step
        EscalationApprovalStepEntity currentStep = getCurrentStep(approval);
        if (currentStep == null) {
            throw new IllegalStateException("No current step found for approval");
        }

        // Process the step
        if (request.getApproved()) {
            currentStep.setStatus(EscalationApprovalStepEntity.Status.APPROVED);
            currentStep.setActionDate(LocalDateTime.now());
            currentStep.setComments(request.getComments());

            if (approval.isLastLevel()) {
                // Complete the approval workflow
                approval.setStatus(EscalationApprovalEntity.Status.COMPLETED);
                approval.setCompletionDate(LocalDateTime.now());
                approval.setCurrentCheckerId(null);
                approval.setCurrentCheckerName(null);
                approval.setCurrentCheckerRole(null);

                // After completion, actually create the escalation contact
                createEscalationContactFromApproval(approval);
            } else {
                // Move to next level
                approval.setCurrentLevel(approval.getCurrentLevel() + 1);
                assignCheckerToCurrentStep(approval);
            }
        } else {
            // Reject the approval
            currentStep.setStatus(EscalationApprovalStepEntity.Status.REJECTED);
            currentStep.setActionDate(LocalDateTime.now());
            currentStep.setRejectionReason(request.getRejectionReason());
            currentStep.setComments(request.getComments());

            approval.setStatus(EscalationApprovalEntity.Status.REJECTED);
            approval.setCompletionDate(LocalDateTime.now());
            approval.setCurrentCheckerId(null);
            approval.setCurrentCheckerName(null);
            approval.setCurrentCheckerRole(null);
        }

        // Save and return
        approval = approvalRepository.save(approval);
        return approvalMapper.toModelWithSteps(approval);
    }

    /**
     * Create the actual escalation contact after approval is completed
     */
    private void createEscalationContactFromApproval(EscalationApprovalEntity approval) {
        try {
            // Parse the approved escalation contact data
            EscalationContact escalationContact = objectMapper.readValue(
                    approval.getRequestData(), EscalationContact.class);

            // TODO: Call EscalationContactService to create the contact
            // escalationContactService.saveEscalationContact(escalationContact, approval.getMakerId());

        } catch (Exception e) {
            // Log error - this is critical as the approval was completed but contact creation failed
            throw new RuntimeException("Failed to create escalation contact after approval completion", e);
        }
    }

    // Private helper methods
    private void initializeApprovalSteps(EscalationApprovalEntity approval) {
        approval.getSteps().clear();

        if (EscalationApprovalEntity.Role.BANKER.equals(approval.getMakerRole())) {
            addApprovalStep(approval, 1, EscalationApprovalEntity.Role.BANKER);
            addApprovalStep(approval, 2, EscalationApprovalEntity.Role.OPERATOR);
            approval.setTotalLevels(2);
        } else if (EscalationApprovalEntity.Role.OPERATOR.equals(approval.getMakerRole())) {
            addApprovalStep(approval, 1, EscalationApprovalEntity.Role.OPERATOR);
            approval.setTotalLevels(1);
        } else {
            throw new IllegalArgumentException("Unsupported maker role: " + approval.getMakerRole());
        }

    }

    private void addApprovalStep(EscalationApprovalEntity approval, Integer level, EscalationApprovalEntity.Role requiredRole) {
        EscalationApprovalStepEntity step = EscalationApprovalStepEntity.builder()
                .approvalId(approval.getId())
                .levelNumber(level)
                .requiredRole(convertToStepRole(requiredRole.toString()))
                .status(EscalationApprovalStepEntity.Status.PENDING)
                .build();

        approval.addStep(step);
    }

    private void assignCheckerToCurrentStep(EscalationApprovalEntity approval) {
        EscalationApprovalStepEntity currentStep = getCurrentStep(approval);
        if (currentStep == null) {
            throw new IllegalStateException("No current step found");
        }

        String checkerId = findCheckerForRole(convertToApprovalRole(currentStep.getRequiredRole()));
        String checkerName = getCheckerName(checkerId);

        currentStep.setCheckerId(checkerId);
        currentStep.setCheckerName(checkerName);
        currentStep.setCheckerRole(currentStep.getRequiredRole());

        approval.setCurrentCheckerId(checkerId);
        approval.setCurrentCheckerName(checkerName);
        approval.setCurrentCheckerRole(convertToApprovalRole(currentStep.getRequiredRole()));

        LocalDateTime dueDate = LocalDateTime.now().plusHours(24);
        currentStep.setDueDate(dueDate);
        approval.setDueDate(dueDate);
    }

    private String findCheckerForRole(EscalationApprovalEntity.Role role) {
        switch (role) {
            case BANKER:
                return "banker_checker_001";
            case OPERATOR:
                return "operator_checker_001";
            case ADMIN:
                return "admin_checker_001";
            default:
                throw new IllegalArgumentException("Unknown role: " + role);
        }
    }

    private String getCheckerName(String checkerId) {
        return "Checker Name"; // TODO: Get from user service
    }

    private EscalationApprovalStepEntity.Role convertToStepRole(String userType) {
        if (userType == null) return null;
        return EscalationApprovalStepEntity.Role.valueOf(userType);
    }

    private EscalationApprovalEntity.Role convertToApprovalRole(EscalationApprovalStepEntity.Role stepRole) {
        if (stepRole == null) return null;
        return EscalationApprovalEntity.Role.valueOf(stepRole.name());
    }

    private void validateCanApprove(EscalationApprovalEntity approval, String checkerId) {
        if (!EscalationApprovalEntity.Status.PENDING.equals(approval.getStatus())) {
            throw new IllegalStateException("Approval is not in pending status");
        }

        if (!checkerId.equals(approval.getCurrentCheckerId())) {
            throw new IllegalArgumentException("User not authorized to approve this request");
        }

        boolean hasApproved = stepRepository.hasUserApprovedAnyStep(approval.getId(), checkerId);
        if (hasApproved) {
            throw new IllegalStateException("User has already approved a step in this workflow");
        }
    }

    private EscalationApprovalStepEntity getCurrentStep(EscalationApprovalEntity approval) {
        try {
            return approval.getCurrentStep();
        } catch (Exception e) {
            return approval.getSteps().stream()
                    .filter(step -> step.getLevelNumber().equals(approval.getCurrentLevel()))
                    .findFirst()
                    .orElse(null);
        }
    }

    /**
     * Get approval details with steps
     */
    @Transactional(readOnly = true)
    public EscalationApproval getApproval(Long id) {
        EscalationApprovalEntity approval = approvalRepository.findByIdWithSteps(id)
                .orElseThrow(() -> new EntityNotFoundException("Approval not found with id: " + id));

        return approvalMapper.toModelWithSteps(approval);
    }

    /**
     * Get all approvals (for admin/operator view)
     */
    @Transactional(readOnly = true)
    public List<EscalationApproval> getAllApprovals() {
        List<EscalationApprovalEntity> approvals = approvalRepository.findAll();
        return approvalMapper.toModelList(approvals);
    }

    /**
     * Get approvals by status
     */
    @Transactional(readOnly = true)
    public List<EscalationApproval> getApprovalsByStatus(EscalationApproval.StatusEnum status) {
        EscalationApprovalEntity.Status entityStatus = convertToEntityStatus(status);
        List<EscalationApprovalEntity> approvals = approvalRepository.findByStatus(entityStatus);
        return approvalMapper.toModelList(approvals);
    }

    /**
     * Get approvals created by a specific maker
     */
    @Transactional(readOnly = true)
    public List<EscalationApproval> getApprovalsByMaker(String makerId) {
        List<EscalationApprovalEntity> approvals = approvalRepository.findByMakerIdOrderByCreatedDateDesc(makerId);
        return approvalMapper.toModelList(approvals);
    }

    /**
     * Get pending approvals for current user (as checker)
     */
    @Transactional(readOnly = true)
    public List<EscalationApproval> getPendingApprovalsForUser(String userId) {
        List<EscalationApprovalEntity> pendingApprovals =
                approvalRepository.findByCurrentCheckerIdAndStatus(userId, EscalationApprovalEntity.Status.PENDING);
        return approvalMapper.toModelList(pendingApprovals);
    }

    /**
     * Get approvals for current user (both made by user and pending for user)
     */
    @Transactional(readOnly = true)
    public List<EscalationApproval> getApprovalsForCurrentUser() {
        Jwt jwt = (Jwt) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        String currentUserId = jwt.getClaimAsString("sub");

        // Get approvals made by current user
        List<EscalationApprovalEntity> madeByUser = approvalRepository.findByMakerIdOrderByCreatedDateDesc(currentUserId);

        // Get pending approvals for current user
        List<EscalationApprovalEntity> pendingForUser =
                approvalRepository.findByCurrentCheckerIdAndStatus(currentUserId, EscalationApprovalEntity.Status.PENDING);

        // Combine both lists (you might want to handle duplicates if any)
        Set<EscalationApprovalEntity> allApprovals = new HashSet<>(madeByUser);
        allApprovals.addAll(pendingForUser);

        return allApprovals.stream()
                .sorted(Comparator.comparing(EscalationApprovalEntity::getCreatedDate).reversed())
                .map(approvalMapper::toModel)
                .toList();
    }


    private EscalationApprovalEntity.Status convertToEntityStatus(EscalationApproval.StatusEnum status) {
        return EscalationApprovalEntity.Status.valueOf(status.name());
    }

    public void deleteEscalationApproval(Long escalationApprovalId) {
        try {
            if (escalationApprovalId == null) {
                throw new IllegalArgumentException("Escalation approval ID cannot be null");
            }

            if (!approvalRepository.existsById(escalationApprovalId)) {
                throw new EntityNotFoundException("Escalation approval not found with ID: " + escalationApprovalId);
            }

            approvalRepository.deleteById(escalationApprovalId);

            if (approvalRepository.existsById(escalationApprovalId)) {
                throw new DataAccessException("Failed to delete escalation approval with ID: " + escalationApprovalId) {
                };
            }
        } catch (DataIntegrityViolationException e) {
            throw new DataIntegrityViolationException("Cannot delete escalation approval due to database constraints: " + e.getMessage(), e);
        }
    }

    public List<EscalationApproval> getAllApprovalslist() {
        try {
            Jwt jwt = (Jwt) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
            if (jwt == null) {
                throw new IllegalStateException("Authentication required. User is not authenticated.");
            }

            String username = jwt.getClaimAsString("name");
            String userType = jwt.getClaimAsString("userType");
            String userId = jwt.getClaimAsString("sub");

            if (username == null || userType == null || userId == null) {
                throw new IllegalArgumentException("Missing required user information in authentication token.");
            }

            logger.info("Fetching all approvals for user: {}, type: {}", username, userType);

            List<EscalationApprovalEntity> approvals;

            if ("BANKER".equals(userType)) {
                String bankIdStr = jwt.getClaimAsString("bankId");
                if (bankIdStr == null) {
                    throw new IllegalArgumentException("Bank ID not found in token for BANKER user.");
                }

                Integer bankId;
                try {
                    bankId = Integer.parseInt(bankIdStr);
                } catch (NumberFormatException e) {
                    throw new IllegalArgumentException("Invalid bank ID format in user token.");
                }

                logger.info("Fetching all approvals for BANKER with bankId: {}", bankId);

                List<EscalationApprovalEntity> allApprovals = approvalRepository.findAll();

                approvals = allApprovals.stream()
                        .filter(approval -> EscalationApprovalEntity.Role.BANKER.equals(approval.getMakerRole()))
                        .filter(approval -> {
                            try {
                                JsonNode requestData = objectMapper.readTree(approval.getRequestData());
                                if (requestData.has("bankId")) {
                                    int approvalBankId = requestData.get("bankId").asInt();
                                    return bankId == approvalBankId;
                                }
                                return false;
                            } catch (JsonProcessingException e) {
                                logger.error("Error parsing requestData for approval {}: {}",
                                        approval.getId(), e.getMessage());
                                return false;
                            }
                        })
                        .collect(Collectors.toList());

            } else if ("OPERATOR".equals(userType)) {
                logger.info("Fetching all approvals for OPERATOR");

                approvals = approvalRepository.findAll().stream()
                        .filter(approval ->
                                (approval.getTotalLevels() == 1 && approval.getCurrentLevel() == 1) ||
                                        (approval.getTotalLevels() == 2 && approval.getCurrentLevel() == 2)
                        )
                        .collect(Collectors.toList());
            } else {
                throw new IllegalArgumentException("Unsupported user type: " + userType);
            }

            logger.info("Found {} total approvals for user: {}", approvals.size(), username);

            return approvals.stream()
                    .map(approvalMapper::toModelWithSteps)
                    .collect(Collectors.toList());

        } catch (IllegalArgumentException | IllegalStateException e) {
            throw e;
        } catch (Exception e) {
            logger.error("Error fetching all approvals: {}", e.getMessage(), e);
            throw new ServiceException("Failed to retrieve all approvals", e);
        }
    }
    @Transactional
    public void approveEscalation(Long approvalId) {

        Jwt jwt = (Jwt) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        String loggedInuserType = jwt.getClaimAsString("userType");
        String loggedInuserId = jwt.getClaimAsString("sub");
        String loggedInUserName = jwt.getClaimAsString("name");

        EscalationApprovalEntity approval = approvalRepository.findById(approvalId)
                .orElseThrow(() -> new EntityNotFoundException("Escalation approval not found with id: " + approvalId));

        if (!EscalationApprovalEntity.Status.PENDING.equals(approval.getStatus())) {
            throw new IllegalArgumentException("Approval request is not in pending state");
        }

        EscalationApprovalStepEntity currentStep = approval.getCurrentStep();
        if (currentStep == null) {
            throw new IllegalArgumentException("No current step found for approval");
        }

        // 4. Validate user can approve this step
//        if (approval.canApprove(loggedInuserId)) {
//            throw new SecurityException("User not authorized to approve this request");
//        }

        if (approval.getMakerId().equals(loggedInuserId)) {
            throw new IllegalArgumentException("Maker cannot approve their own request");
        }

        validateApprovalPermissions(approval, loggedInuserType);

        currentStep.setStatus(EscalationApprovalStepEntity.Status.APPROVED);
        currentStep.setCheckerId(loggedInuserId);
        currentStep.setCheckerName(loggedInUserName);
        currentStep.setCheckerRole(convertToStepRole(loggedInuserType));
        currentStep.setActionDate(LocalDateTime.now());

        if (approval.isLastLevel()) {
            approval.setStatus(EscalationApprovalEntity.Status.COMPLETED);
            approval.setCompletionDate(LocalDateTime.now());

            executeApprovedAction(approval, loggedInuserId);

        } else {
            approval.setCurrentLevel(approval.getCurrentLevel() + 1);

            assignCheckerToCurrentStep(approval);
        }

        approvalRepository.save(approval);
    }

    private void validateApprovalPermissions(EscalationApprovalEntity approval, String loggedInUserType) {

        EscalationApprovalEntity.Role makerRole = approval.getMakerRole();
        EscalationApprovalStepEntity.Role approverRole = convertToStepRole(loggedInUserType);

        if (EscalationApprovalEntity.Role.BANKER.equals(makerRole)) {
            if (approval.getCurrentLevel() == 1) {
                if (!EscalationApprovalStepEntity.Role.BANKER.equals(approverRole)) {
                    throw new SecurityException("First level approval for banker requests must be done by another banker");
                }
            } else if (approval.getCurrentLevel() == 2) {
                if (!EscalationApprovalStepEntity.Role.OPERATOR.equals(approverRole)) {
                    throw new SecurityException("Second level approval for banker requests must be done by an operator");
                }
            }
        } else if (EscalationApprovalEntity.Role.OPERATOR.equals(makerRole)) {
            if (!EscalationApprovalStepEntity.Role.OPERATOR.equals(approverRole)) {
                throw new SecurityException("Operator requests must be approved by another operator");
            }
        }
    }

    private void executeApprovedAction(EscalationApprovalEntity approval, String loggedInuserId) {
        try {
            EscalationContact escalationContact = objectMapper.readValue(
                    approval.getRequestData(),
                    EscalationContact.class
            );

            switch (approval.getActionType()) {
                case CREATE:
                    escalationContactService.saveEscalationContact(escalationContact, loggedInuserId);
                    break;
                case UPDATE:
                    escalationContactService.updateEscalationMatrix(escalationContact);
                    break;
                case DELETE:
                    escalationContactService.deleteEscalationMatrix(escalationContact.getId());
                    break;
                default:
                    throw new IllegalArgumentException("Unsupported action type: " + approval.getActionType());
            }

        } catch (Exception e) {
            throw new RuntimeException("Failed to execute approved action", e);
        }
    }

    @Transactional
    public void rejectEscalation(Long approvalId, RejectEscalationApproval rejectEscalationApproval) {

        Jwt jwt = (Jwt) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        String loggedInuserType = jwt.getClaimAsString("userType");
        String loggedInuserId = jwt.getClaimAsString("sub");
        String loggedInUserName = jwt.getClaimAsString("name");

        EscalationApprovalEntity approval = approvalRepository.findById(approvalId)
                .orElseThrow(() -> new EntityNotFoundException("Escalation approval not found with id: " + approvalId));

        if (!EscalationApprovalEntity.Status.PENDING.equals(approval.getStatus())) {
            throw new IllegalArgumentException("Approval request is not in pending state");
        }

        EscalationApprovalStepEntity currentStep = approval.getCurrentStep();
        if (currentStep == null) {
            throw new IllegalArgumentException("No current step found for approval");
        }

        if (approval.getMakerId().equals(loggedInuserId)) {
            throw new IllegalArgumentException("Maker cannot reject their own request");
        }

        validateApprovalPermissions(approval, loggedInuserType);

        currentStep.setStatus(EscalationApprovalStepEntity.Status.REJECTED);
        currentStep.setCheckerId(loggedInuserId);
        currentStep.setCheckerName(loggedInUserName);
        currentStep.setCheckerRole(convertToStepRole(loggedInuserType));
        currentStep.setActionDate(LocalDateTime.now());
        currentStep.setRejectionReason(rejectEscalationApproval.getRejectionReason());
        currentStep.setComments(rejectEscalationApproval.getComments());
        approval.setStatus(EscalationApprovalEntity.Status.REJECTED);
        approval.setCompletionDate(LocalDateTime.now());

        approvalRepository.save(approval);
    }
}