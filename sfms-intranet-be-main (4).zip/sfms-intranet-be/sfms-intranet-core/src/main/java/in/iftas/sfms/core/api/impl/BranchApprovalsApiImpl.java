package in.iftas.sfms.core.api.impl;

/*
 * Copyright (C) 2024 Iftas Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Iftas Inc. ("Confidential Information"). You shall not disclose
 * such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with Iftas Inc.
 */

import in.iftas.sfms.core.api.BranchApprovalsApi;
import in.iftas.sfms.core.exception.InvalidRequestException;
import in.iftas.sfms.core.exception.ResourceNotFoundException;
import in.iftas.sfms.core.model.ApiResponseError;
import in.iftas.sfms.core.model.Branch;
import in.iftas.sfms.core.model.ModelApiResponse;
import in.iftas.sfms.core.service.BranchApprovalService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import java.util.Collections;

@RestController
@RequiredArgsConstructor
@Slf4j
public class BranchApprovalsApiImpl implements BranchApprovalsApi {

    private final BranchApprovalService branchApprovalService;

    @Override
    public ResponseEntity<ModelApiResponse> branchApprovalsPut(Branch branch) {
        log.info("Received request to create update approval for branch {}");
        ModelApiResponse modelApiResponse = new ModelApiResponse();

        try {
            String ifscCode = branchApprovalService.updateBranchApproval(branch);

            modelApiResponse.setSuccess(true);
            modelApiResponse.setMessage("Branch update approval request created successfully");
            modelApiResponse.setData(Collections.singletonMap("branchIfsc", ifscCode));
            log.info("Branch update approval request created successfully for branch IFSC: {}", ifscCode);

            return ResponseEntity.status(HttpStatus.OK).body(modelApiResponse);

        } catch (ResourceNotFoundException e) {
            log.error("Branch not found: {}", e.getMessage());

            modelApiResponse.setSuccess(false);
            modelApiResponse.setMessage(e.getMessage());

            ApiResponseError error = new ApiResponseError();
            error.setCode(HttpStatus.NOT_FOUND.toString());
            error.setMessage(e.getMessage());
            modelApiResponse.setError(error);

            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(modelApiResponse);

        } catch (InvalidRequestException e) {
            log.error("Invalid branch update request: {}", e.getMessage());

            modelApiResponse.setSuccess(false);
            modelApiResponse.setMessage(e.getMessage());

            ApiResponseError error = new ApiResponseError();
            error.setCode(HttpStatus.BAD_REQUEST.toString());
            error.setMessage(e.getMessage());
            modelApiResponse.setError(error);

            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(modelApiResponse);

        } catch (Exception e) {
            log.error("Error processing branch update approval request: {}", e.getMessage(), e);

            modelApiResponse.setSuccess(false);
            modelApiResponse.setMessage("Error processing request");

            ApiResponseError apiResponseError = new ApiResponseError();
            apiResponseError.setCode(HttpStatus.INTERNAL_SERVER_ERROR.toString());
            apiResponseError.setMessage(e.getMessage());
            modelApiResponse.setError(apiResponseError);

            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(modelApiResponse);
        }
    }
}