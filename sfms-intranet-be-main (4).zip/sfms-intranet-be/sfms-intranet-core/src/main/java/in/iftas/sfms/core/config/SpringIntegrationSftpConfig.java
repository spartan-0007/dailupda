package in.iftas.sfms.core.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.integration.file.remote.session.CachingSessionFactory;
import org.springframework.integration.file.remote.session.SessionFactory;
import org.springframework.integration.sftp.session.DefaultSftpSessionFactory;

/**
 * Configuration for Spring Integration SFTP in UAT environment
 */
@Configuration
@Profile("uat")
public class SpringIntegrationSftpConfig {
    private static final Logger logger = LoggerFactory.getLogger(SpringIntegrationSftpConfig.class);

    @Value("${sftp.host}")
    private String host;

    @Value("${sftp.port}")
    private int port;

    @Value("${sftp.username}")
    private String username;

    @Value("${sftp.password}")
    private String password;

    @Bean
    public SessionFactory<?> sftpSessionFactory() {
        DefaultSftpSessionFactory factory = new DefaultSftpSessionFactory(true);
        factory.setHost(host);
        factory.setPort(port);
        factory.setUser(username);
        factory.setPassword(password);
        factory.setAllowUnknownKeys(true);

        logger.info("Initialized Spring Integration SFTP Session Factory for host: {}", host);

        return new CachingSessionFactory<>(factory);
    }
}