package in.iftas.sfms.core.model;

import java.net.URI;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import in.iftas.sfms.core.model.MarqueeBank;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;
import org.openapitools.jackson.nullable.JsonNullable;
import java.time.OffsetDateTime;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


import java.util.*;
import jakarta.annotation.Generated;

/**
 * MarqueeGlobal
 */


public class MarqueeGlobal {

  private String id;

  private String content;

  @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
  private Date startTime;

  @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
  private Date endTime;

  private String userType;

  private Boolean isGlobal;

  private MarqueeBank childMarquee;

  public MarqueeGlobal id(String id) {
    this.id = id;
    return this;
  }

  /**
   * Unique identifier for the marquee
   * @return id
   */
  
  @Schema(name = "id", description = "Unique identifier for the marquee", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("id")
  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public MarqueeGlobal content(String content) {
    this.content = content;
    return this;
  }

  /**
   * The content of the marquee
   * @return content
   */
  
  @Schema(name = "content", description = "The content of the marquee", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("content")
  public String getContent() {
    return content;
  }

  public void setContent(String content) {
    this.content = content;
  }

  public MarqueeGlobal startTime(Date startTime) {
    this.startTime = startTime;
    return this;
  }

  /**
   * The start time of the marquee
   * @return startTime
   */
  @Valid 
  @Schema(name = "startTime", description = "The start time of the marquee", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("startTime")
  public Date getStartTime() {
    return startTime;
  }

  public void setStartTime(Date startTime) {
    this.startTime = startTime;
  }

  public MarqueeGlobal endTime(Date endTime) {
    this.endTime = endTime;
    return this;
  }

  /**
   * The end time of the marquee
   * @return endTime
   */
  @Valid 
  @Schema(name = "endTime", description = "The end time of the marquee", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("endTime")
  public Date getEndTime() {
    return endTime;
  }

  public void setEndTime(Date endTime) {
    this.endTime = endTime;
  }

  public MarqueeGlobal userType(String userType) {
    this.userType = userType;
    return this;
  }

  /**
   * The type of users who should see the marquee (e.g., bankers, operators)
   * @return userType
   */
  
  @Schema(name = "userType", description = "The type of users who should see the marquee (e.g., bankers, operators)", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("userType")
  public String getUserType() {
    return userType;
  }

  public void setUserType(String userType) {
    this.userType = userType;
  }

  public MarqueeGlobal isGlobal(Boolean isGlobal) {
    this.isGlobal = isGlobal;
    return this;
  }

  /**
   * Whether the marquee is for all users
   * @return isGlobal
   */
  
  @Schema(name = "isGlobal", description = "Whether the marquee is for all users", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("isGlobal")
  public Boolean getIsGlobal() {
    return isGlobal;
  }

  public void setIsGlobal(Boolean isGlobal) {
    this.isGlobal = isGlobal;
  }

  public MarqueeGlobal childMarquee(MarqueeBank childMarquee) {
    this.childMarquee = childMarquee;
    return this;
  }

  /**
   * Get childMarquee
   * @return childMarquee
   */
  @Valid 
  @Schema(name = "childMarquee", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("childMarquee")
  public MarqueeBank getChildMarquee() {
    return childMarquee;
  }

  public void setChildMarquee(MarqueeBank childMarquee) {
    this.childMarquee = childMarquee;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    MarqueeGlobal marqueeGlobal = (MarqueeGlobal) o;
    return Objects.equals(this.id, marqueeGlobal.id) &&
        Objects.equals(this.content, marqueeGlobal.content) &&
        Objects.equals(this.startTime, marqueeGlobal.startTime) &&
        Objects.equals(this.endTime, marqueeGlobal.endTime) &&
        Objects.equals(this.userType, marqueeGlobal.userType) &&
        Objects.equals(this.isGlobal, marqueeGlobal.isGlobal) &&
        Objects.equals(this.childMarquee, marqueeGlobal.childMarquee);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, content, startTime, endTime, userType, isGlobal, childMarquee);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class MarqueeGlobal {\n");
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    content: ").append(toIndentedString(content)).append("\n");
    sb.append("    startTime: ").append(toIndentedString(startTime)).append("\n");
    sb.append("    endTime: ").append(toIndentedString(endTime)).append("\n");
    sb.append("    userType: ").append(toIndentedString(userType)).append("\n");
    sb.append("    isGlobal: ").append(toIndentedString(isGlobal)).append("\n");
    sb.append("    childMarquee: ").append(toIndentedString(childMarquee)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

