package in.iftas.sfms.core.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import in.iftas.sfms.common.entity.ApprovalRequestEntity;
import in.iftas.sfms.common.repository.ApprovalRequestRepository;
import in.iftas.sfms.core.entity.BranchEntity;
import in.iftas.sfms.core.exception.InvalidRequestException;
import in.iftas.sfms.core.exception.ResourceNotFoundException;
import in.iftas.sfms.core.mapper.BranchMapper;
import in.iftas.sfms.core.model.Branch;
import in.iftas.sfms.core.repository.BankBranchRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.List;

@Service
@Slf4j
@RequiredArgsConstructor
public class BranchApprovalService {

    private final ObjectMapper objectMapper;
    private final ApprovalRequestRepository approvalRequestRepository;
    private final BankBranchRepository branchRepository;
    private final BranchMapper branchMapper;

    public String updateBranchApproval(Branch branch) throws ResourceNotFoundException, InvalidRequestException {
        log.info("Creating branch update approval request for branch IFSC: {}", branch.getIfscCode());

        branchRepository.findById(branch.getIfscCode())
                .orElseThrow(() -> {
                    log.warn("Branch not found with IFSC: {}", branch.getIfscCode());
                    return new ResourceNotFoundException("Branch not found with IFSC " + branch.getIfscCode());
                });

        LocalDateTime now = LocalDateTime.now();
        LocalDateTime cutoffDate = now.minusDays(15);

        List<ApprovalRequestEntity> existingRequests = approvalRequestRepository
                .findPendingRequestsByMicrCodeAndDate(branch.getMicrCode(), cutoffDate);

        if (!existingRequests.isEmpty()) {
            throw new InvalidRequestException("A pending update request already exists for this MICR code in the last 15 days.");
        }

        if (branch.getMicrCode() != null &&
                !branch.getMicrCode().equalsIgnoreCase("NA") &&
                !branch.getMicrCode().equalsIgnoreCase("WAITING")) {
            BranchEntity existingBranch = branchRepository.findById(branch.getIfscCode()).get();

            if (!branch.getMicrCode().equals(existingBranch.getMicrCode())) {
                boolean existsMicr = branchRepository.existsByMicrCodeAndIfscCodeNot(
                        branch.getMicrCode(), branch.getIfscCode());
                if (existsMicr) {
                    throw new InvalidRequestException("MICR code already exists for another branch.");
                }
            }
        }

        try {
            Jwt jwt = (Jwt) SecurityContextHolder.getContext().getAuthentication().getPrincipal();

            ApprovalRequestEntity entity = ApprovalRequestEntity.builder()
                    .entityType(ApprovalRequestEntity.EntityType.BRANCH.name())
                    .actionType(ApprovalRequestEntity.ActionType.UPDATE.name())
                    .entityId(branch.getIfscCode())
                    .requestData(objectMapper.writeValueAsString(branch))
                    .status(ApprovalRequestEntity.Status.PENDING.name())
                    .makerName(jwt.getClaimAsString("name"))
                    .build();
            entity.setCreatedBy(jwt.getClaimAsString("sub"));

            approvalRequestRepository.save(entity);
            log.info("Branch update approval request created successfully for branch IFSC: {}", branch.getIfscCode());

            return branch.getIfscCode();

        } catch (IOException e) {
            log.error("Error serializing branch data: {}", e.getMessage());
            throw new InvalidRequestException("Error processing branch data");
        } catch (Exception e) {
            log.error("Unexpected error: {}", e.getMessage(), e);
            throw new InvalidRequestException("Error creating approval request");
        }
    }
}
