package in.iftas.sfms.core.validations;

import com.fasterxml.jackson.databind.ObjectMapper;
import in.iftas.sfms.common.entity.ApprovalRequestEntity;
import in.iftas.sfms.common.repository.ApprovalRequestRepository;
import in.iftas.sfms.core.entity.BankEntity;
import in.iftas.sfms.core.exception.BankAlreadyExistsException;
import in.iftas.sfms.core.exception.Branchalreadyexists;
import in.iftas.sfms.core.model.Bank;
import in.iftas.sfms.core.model.Branch;
import in.iftas.sfms.core.repository.BankRepository;
import in.iftas.sfms.core.repository.BranchProliferationRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@RequiredArgsConstructor
@Slf4j
public class BankValidator {

    private final BankRepository bankRepository;
    private final BranchProliferationRepository branchProliferationRepository;
    private final ApprovalRequestRepository approvalRequestRepository;

    @Autowired
    private ObjectMapper objectMapper;

    public void validateBankCreation(Bank bank) {
        log.info("Add Bank Validation: {}", bank.getBankName());
        BankEntity existingBank = bankRepository.findByBankNameOrBankShortName(bank.getBankName(), bank.getBankShortName());
        if (existingBank != null) {
            log.info("Bank already exists with id: {}", existingBank.getId());
            throw new BankAlreadyExistsException(bank.getBankName(), bank.getBankShortName());
        }

        for (Branch branch : bank.getBranches()) {
            boolean exists = branchProliferationRepository.existsByBranchId(branch.getIfscCode());
            if (exists) {
                throw new Branchalreadyexists(branch.getIfscCode());
            }
        }

    }

    public void validateDuplicateApprovalRequest(Bank bank) {
        boolean duplicateFound = false;
        String message = "";
        List<ApprovalRequestEntity> existingApprovals = approvalRequestRepository.findByEntityType(ApprovalRequestEntity.EntityType.BANK.name());

        for (ApprovalRequestEntity approval : existingApprovals) {
            try {
                String requestData = approval.getRequestData();
                Bank tempBank = objectMapper.readValue(requestData, Bank.class);

                if (tempBank.getBankName().equalsIgnoreCase(bank.getBankName()) ||
                        tempBank.getBankShortName().equalsIgnoreCase(bank.getBankShortName())) {
                    duplicateFound = true;
                    message = "Approval request for this bank with the same name or short name already exists.";
                    break;
                }
            } catch (Exception e) {
                log.error("Error parsing approval request data: {}", e.getMessage());
            }
        }

        if (duplicateFound) {
            throw new IllegalArgumentException(message);
        }
    }
}