package in.iftas.sfms.core.api.impl;

import in.iftas.sfms.core.api.EscalationMatrixApi;
import in.iftas.sfms.core.exception.DuplicateEntryException;
import in.iftas.sfms.core.exception.FileProcessingException;
import in.iftas.sfms.core.exception.ResourceNotFoundException;
import in.iftas.sfms.core.model.EscalationContact;
import in.iftas.sfms.core.model.EscalationMatrix;
import in.iftas.sfms.core.service.EscalationContactService;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.*;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Slf4j
public class EscalationMatrixApiImpl implements EscalationMatrixApi {
    private static final Logger logger = LoggerFactory.getLogger(EscalationMatrixApiImpl.class);

    private final EscalationContactService escalationContactService;

    public EscalationMatrixApiImpl(EscalationContactService escalationContactService) {
        this.escalationContactService = escalationContactService;
    }

    @Override
    public ResponseEntity<Void> addEscalationContactForBank(Long bankId, EscalationContact escalationContact) {

        log.info("Received request to add escalation contact for bankId: {}", bankId);

        try {
            String currentUser = SecurityContextHolder.getContext().getAuthentication().getName();
            escalationContact.setBankId(bankId);
            escalationContactService.saveEscalationContact(escalationContact, currentUser);
            log.info("Successfully created escalation contact for bankId: {}", bankId);
            return new ResponseEntity<>(HttpStatus.CREATED);

        } catch (SecurityException e) {
            log.error("Security violation while adding escalation contact for bankId: {}", bankId, e);
            return new ResponseEntity<>(HttpStatus.FORBIDDEN);
        } catch (DuplicateEntryException e) {
            log.error("Duplicate escalation contact for bankId: {}", bankId, e);
            return new ResponseEntity<>(HttpStatus.CONFLICT);
        } catch (IllegalArgumentException e) {
            log.error("Invalid data provided for bankId: {}", bankId, e);
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        } catch (Exception e) {
            log.error("Unexpected error while adding escalation contact for bankId: {}", bankId, e);
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    /**
     * Updated Controller Method (if changing the return type)
     */
    @Override
    public ResponseEntity<EscalationMatrix> getAllEscalationMatrices(Long bankId) {
        log.info("Received request to get all escalation matrices");

        try {
            EscalationMatrix matrices = escalationContactService.getAllEscalationMatrices(bankId);

            log.info("Successfully retrieved escalation matrice");
            return new ResponseEntity<>(matrices, HttpStatus.OK);

        } catch (SecurityException e) {
            log.error("Security violation while getting escalation matrices", e);
            return new ResponseEntity<>(HttpStatus.FORBIDDEN);
        } catch (Exception e) {
            log.error("Unexpected error while getting escalation matrices", e);
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    @Override
    public ResponseEntity<Void> updateEscalationMatrixEntry(EscalationContact escalationContact) {
        try {
            escalationContactService.updateEscalationMatrix(escalationContact);
            logger.info("Escalation contact updated successfully ");
            return ResponseEntity.status(HttpStatusCode.valueOf(204)).build();
        } catch (DuplicateEntryException e) {
            logger.error("Duplicate Entry found for: {}", e.getMessage());
            return new ResponseEntity<>(HttpStatus.CONFLICT);
        } catch (IllegalArgumentException e) {
            logger.error("Error while processing escalation contact: {}", e.getMessage());
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        } catch (Exception e) {
            logger.error("Unexpected error while saving escalation contact: {}", e.getMessage());
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    @Override
    public ResponseEntity<Void> escalationMatrixDelete(Long id) {
        log.info("Request to delete escalation contact with id {}", id);
        escalationContactService.deleteEscalationMatrix(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @Override
    public ResponseEntity<Resource> downloadEscalationPdf(Long bankId, Long departmentId) {
        logger.info("Attempting to download Escalation Matrix with bankId: {} and departmentId: {}", bankId, departmentId);

        try {
            Resource pdfResource = escalationContactService.downloadEscalationMatrixAsPDF(bankId, departmentId);

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_PDF);
            headers.setContentDisposition(ContentDisposition.attachment().filename("EscalationMatrix.pdf").build());
            headers.setContentLength(pdfResource.contentLength());

            logger.info("Successfully generated Escalation Matrix PDF");
            return new ResponseEntity<>(pdfResource, headers, HttpStatus.OK);

        } catch (ResourceNotFoundException e) {
            logger.error("Failed to find Escalation Matrix: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(new ByteArrayResource(("Resource not found: " + e.getMessage()).getBytes()));

        } catch (FileProcessingException e) {
            logger.error("Error generating PDF for Escalation Matrix: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ByteArrayResource(("Error generating PDF: " + e.getMessage()).getBytes()));

        } catch (Exception e) {
            logger.error("Unexpected error during download of Escalation Matrix: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ByteArrayResource(("Unexpected error: " + e.getMessage()).getBytes()));
        }
    }
//
//    @Override
//    public ResponseEntity<List<Level>> getAllEscalationMatrixLevels() {
//        try {
//            logger.info("Getting all escalation matrix levels");
//            List<Level> levels = escalationContactService.getAllLevels();
//            logger.info("Successfully retrieved {} escalation levels", levels.size());
//            return new ResponseEntity<>(levels, HttpStatus.OK);
//        } catch (Exception e) {
//            logger.error("Error while retrieving escalation matrix levels", e);
//            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
//        }
//    }

}

