package in.iftas.sfms.core.service;

/*
 * Copyright (C) 2024 Iftas Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Iftas Inc. ("Confidential Information"). You shall not disclose
 * such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with Iftas Inc.
 *
 * Author: Manoj.Illa
 * Date: October 29, 2024
 */

import in.iftas.sfms.core.entity.UserManualEntity;
import in.iftas.sfms.core.entity.UserManualHistoryEntity;
import in.iftas.sfms.core.exception.ResourceNotFoundException;
import in.iftas.sfms.core.model.UserManual;
import in.iftas.sfms.core.repository.UserManualDetailsRepository;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;

@Service
public class UserManualFileService {

    private static final Logger logger = LoggerFactory.getLogger(UserManualFileService.class);

    private final UserManualDetailsRepository userManualDetailsRepository;

    private final SftpService sftpService;

    @Autowired
    public UserManualFileService(UserManualDetailsRepository userManualDetailsRepository, SftpService sftpService) {
        this.userManualDetailsRepository = userManualDetailsRepository;
        this.sftpService = sftpService;
    }

    public void uploadUserManualFile(UserManualEntity userManualEntity, String entityId) throws Exception {
        logger.info("Uploading user manual file: {}", userManualEntity.getFileName());
        try {

            Jwt jwt = (Jwt) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
            UserManualEntity fileDetails = userManualDetailsRepository.findByFileName(userManualEntity.getFileName());

            UserManualHistoryEntity history = UserManualHistoryEntity.builder()
                    .uploadedBy(jwt.getClaimAsString("sub"))
                    .sftpPath(userManualEntity.getSftpPath())
                    .build();

            if (ObjectUtils.isNotEmpty(fileDetails) && fileDetails.getFileName() != null) {
                fileDetails.setUploadedBy(entityId);
                fileDetails.setUploadedDate(LocalDateTime.now());
                fileDetails.setFileSize(Long.valueOf(userManualEntity.getFileSize()));
                history.setUploadedDate(fileDetails.getUploadedDate());
                history.setFileDetails(fileDetails);
                fileDetails.getHistoryEntities().add(history);
            } else {
                fileDetails = UserManualEntity.builder()
                        .fileName(userManualEntity.getFileName())
                        .uploadedBy(entityId)
                        .sftpPath(userManualEntity.getSftpPath())
                        .fileSize(Long.valueOf(userManualEntity.getFileSize()))
                        .uploadedDate(LocalDateTime.now())
                        .build();

                history.setUploadedDate(fileDetails.getUploadedDate());
                history.setFileDetails(fileDetails);
                fileDetails.setHistoryEntities(List.of(history));
            }
            userManualDetailsRepository.save(fileDetails);
            logger.info("User manual file uploaded successfully: {}", userManualEntity.getFileName());
        } catch (Exception e) {
            logger.error("Failed to upload file to SFTP.", e);
            throw new RuntimeException("Failed to upload file to SFTP.", e);
        }

    }
    public void uploadUserManualFile(UserManual userManual) throws Exception {}
    private String uploadFileToSftp(MultipartFile file) throws Exception {
        String sftpPath = "/files/user-manuals/";
        try (InputStream inputStream = file.getInputStream()) {
            sftpService.uploadCRLCGBSFile(sftpPath, file.getOriginalFilename(), inputStream);
            logger.info("File uploaded to SFTP: {}", sftpPath + file.getOriginalFilename());
        }
        return sftpPath + file.getOriginalFilename();
    }

    public List<UserManual> getUserManualFiles() {
        logger.info("Fetching all user manual files");
        List<UserManualEntity> userManualEntities = userManualDetailsRepository.findAllByOrderByUploadedDateDesc();
        return userManualEntities.stream()
                .map(this::convertToDto)
                .toList();
    }

    private UserManual convertToDto(UserManualEntity entity) {
        UserManual dto = new UserManual();
        dto.setFileName(entity.getFileName());
        dto.setFilePath(entity.getSftpPath());
        dto.setUploadedBy(entity.getUploadedBy());
        dto.setFileSize(convertFileSize(entity.getFileSize()));
        dto.setId(entity.getId());
        dto.setUploadedAt(Date.from(entity.getUploadedDate().atZone(ZoneId.systemDefault()).toInstant()));
        return dto;
    }

    public Resource downloadCrlFile(String fileName) {
        logger.info("Downloading CRL file: {}", fileName);
        UserManualEntity userManualEntity = userManualDetailsRepository.findByFileName(fileName);

        if (ObjectUtils.isNotEmpty(userManualEntity)) {
            String sftpPath = userManualEntity.getSftpPath();

            try {
                InputStream fileStream = sftpService.downloadFile(sftpPath);
                ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
                IOUtils.copy(fileStream, outputStream);
                ByteArrayInputStream inputStream = new ByteArrayInputStream(outputStream.toByteArray());

                logger.info("CRL file downloaded successfully: {}", fileName);
                return new ByteArrayResource(inputStream.readAllBytes());
            } catch (Exception e) {
                logger.error("Error downloading CRL file: {}", fileName, e);
                throw new RuntimeException(e);
            }
        } else {
            logger.warn("File not found: {}", fileName);
            throw new RuntimeException("File Not Found");
        }
    }

    public String convertFileSize(Long sizeInBytes) {
        final int ONE_MB = 1024 * 1024;
        final int ONE_KB = 1024;

        if (sizeInBytes >= ONE_MB) {
            double sizeInMB = (double) sizeInBytes / ONE_MB;
            return String.format("%.2f MB", sizeInMB);
        } else {
            double sizeInKB = (double) sizeInBytes / ONE_KB;
            return String.format("%.2f KB", sizeInKB);
        }
    }

    public void deleteManualByID(Long manualId) {
        logger.info("Entering deleteManualByID with id: {}", manualId);

        if (userManualDetailsRepository.existsById(manualId)) {
            logger.info("User Manual with id: {}, proceeding to delete", manualId);

            userManualDetailsRepository.deleteById(manualId);
            logger.info("User Manual deleted successfully with id: {}", manualId);

        } else {
            logger.warn("User Manual not found with id: {}", manualId);

            throw new ResourceNotFoundException("User Manual found with id " + manualId);
        }
        logger.info("Exiting deleteManualByID");

    }
}