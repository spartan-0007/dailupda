package in.iftas.sfms.core.service;

import com.itextpdf.text.Element;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.ColumnText;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfStamper;
import in.iftas.sfms.core.dto.EscalationContactDTO;
import in.iftas.sfms.core.entity.DepartmentEntity;
import in.iftas.sfms.core.entity.EscalationContactEntity;
import in.iftas.sfms.core.entity.EscalationLevelEntity;
import in.iftas.sfms.core.exception.DuplicateEntryException;
import in.iftas.sfms.core.exception.FileProcessingException;
import in.iftas.sfms.core.exception.ResourceNotFoundException;
import in.iftas.sfms.core.mapper.EscalationContactMapper;
import in.iftas.sfms.core.model.DepartmentMatrix;
import in.iftas.sfms.core.model.EscalationContact;
import in.iftas.sfms.core.model.EscalationMatrix;
import in.iftas.sfms.core.model.LevelMatrix;
import in.iftas.sfms.core.repository.DepartmentRepository;
import in.iftas.sfms.core.repository.EscalationContactRepository;
import in.iftas.sfms.core.repository.EscalationLevelRepository;
import in.iftas.sfms.core.repository.RoleDepartmentMappingRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.ClassPathResource;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.FileCopyUtils;
import org.springframework.util.StringUtils;
import org.thymeleaf.context.Context;
import org.thymeleaf.spring6.SpringTemplateEngine;
import org.xhtmlrenderer.pdf.ITextRenderer;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Service
@Slf4j
public class EscalationContactService {
    private final EscalationContactRepository escalationContactRepository;
    private final EscalationContactMapper escalationContactMapper;
    private final EscalationLevelRepository escalationLevelRepository;
    private final RoleDepartmentMappingRepository roleDepartmentMappingRepository;
    private final DepartmentRepository departmentRepository;
    private final SpringTemplateEngine templateEngine;

    @Autowired
    public EscalationContactService(EscalationContactRepository escalationContactRepository,
                                    EscalationContactMapper escalationContactMapper,
                                    EscalationLevelRepository escalationLevelRepository, RoleDepartmentMappingRepository roleDepartmentMappingRepository, DepartmentRepository departmentRepository, SpringTemplateEngine templateEngine) {
        this.roleDepartmentMappingRepository = roleDepartmentMappingRepository;
        this.departmentRepository = departmentRepository;
        this.templateEngine = templateEngine;
        log.info("Initializing EscalationContactService");

        this.escalationContactRepository = escalationContactRepository;
        this.escalationContactMapper = escalationContactMapper;
        this.escalationLevelRepository = escalationLevelRepository;
        log.info("EscalationContactService initialized with repositories and mapper");

    }

    /**
     * Saves an escalation contact after comprehensive validation
     *
     * @param escalationContact the escalation contact to save
     * @param currentUser       the current authenticated user
     * @throws IllegalArgumentException if validation fails
     * @throws DuplicateEntryException  if duplicate contact exists
     * @throws SecurityException        if user lacks access to department
     */
    @Transactional
    public void saveEscalationContact(EscalationContact escalationContact, String currentUser) {
        log.info("Attempting to save escalation contact for bankId: {}, levelId: {}",
                escalationContact.getBankId(), escalationContact.getLevelId());

        validateEscalationContactInput(escalationContact);

        EscalationLevelEntity levelEntity = fetchAndValidateLevel(escalationContact.getLevelId());

        //checkUserDepartmentAccess(levelEntity.getDepartment().getId());

        checkForDuplicateContact(escalationContact);

        EscalationContactEntity contactEntity = prepareContactEntity(escalationContact, levelEntity, currentUser);

        try {
            escalationContactRepository.save(contactEntity);
            log.info("Successfully saved escalation contact with ID: {} for bankId: {}",
                    contactEntity.getId(), escalationContact.getBankId());
        } catch (Exception e) {
            log.error("Database error while saving escalation contact", e);
            throw new RuntimeException("Failed to save escalation contact due to database error", e);
        }
    }

    private void validateEscalationContactInput(EscalationContact escalationContact) {
        log.debug("Validating escalation contact input");

        if (escalationContact.getBankId() == null) {
            throw new IllegalArgumentException("Bank ID is required");
        }

        if (escalationContact.getLevelId() == null) {
            throw new IllegalArgumentException("Level ID is required");
        }

        if (!StringUtils.hasText(escalationContact.getContactName()) &&
                !StringUtils.hasText(escalationContact.getContactEmail()) &&
                !StringUtils.hasText(escalationContact.getContactNumber())) {
            throw new IllegalArgumentException("At least one contact method (name, email, or number) is required");
        }

        if (StringUtils.hasText(escalationContact.getContactEmail()) &&
                !isValidEmail(escalationContact.getContactEmail())) {
            throw new IllegalArgumentException("Invalid email format");
        }

        log.debug("Escalation contact input validation passed");
    }

    private EscalationLevelEntity fetchAndValidateLevel(Long levelId) {
        log.debug("Fetching and validating escalation level: {}", levelId);

        if (!escalationLevelRepository.existsByIdAndIsActive(levelId, true)) {
            throw new IllegalArgumentException("Escalation level not found or inactive: " + levelId);
        }

        Optional<EscalationLevelEntity> levelEntity = escalationLevelRepository.findById(levelId);
        if (levelEntity.isEmpty()) {
            throw new IllegalArgumentException("Escalation level not found: " + levelId);
        }

        log.debug("Escalation level validation passed for levelId: {}", levelId);
        return levelEntity.get();
    }

    private void checkUserDepartmentAccess(Long departmentId) {
        log.debug("Checking user access for department: {}", departmentId);

        String currentUser = SecurityContextHolder.getContext().getAuthentication().getName();
        Collection<? extends GrantedAuthority> authorities =
                SecurityContextHolder.getContext().getAuthentication().getAuthorities();

        boolean hasAccess = authorities.stream()
                .map(GrantedAuthority::getAuthority)
                .anyMatch(role -> roleDepartmentMappingRepository
                        .existsByKeycloakRoleNameAndDepartmentIdAndIsActive(role, departmentId, true));

        if (!hasAccess) {
            log.error("User {} lacks access to department {}", currentUser, departmentId);
            throw new SecurityException("User does not have access to this department");
        }

        log.debug("User department access validation passed");
    }

    private void checkForDuplicateContact(EscalationContact escalationContact) {
        log.debug("Checking for duplicate contact");

        boolean isDuplicate = escalationContactRepository.existsByBankIdAndLevelIdAndContactNameAndContactEmailAndContactNumberAndFeatureAndBusinessAndDesignation(
                escalationContact.getBankId(),
                escalationContact.getLevelId(),
                escalationContact.getContactName(),
                escalationContact.getContactEmail(),
                escalationContact.getContactNumber(),
                escalationContact.getFeature(),
                escalationContact.getBusiness(),
                escalationContact.getDesignation()
        );

        if (isDuplicate) {
            log.error("Duplicate contact found for bankId: {}, levelId: {}",
                    escalationContact.getBankId(), escalationContact.getLevelId());
            throw new DuplicateEntryException(
                    String.format("Duplicate escalation contact found for bankId: %d, levelId: %d",
                            escalationContact.getBankId(), escalationContact.getLevelId())
            );
        }

        log.debug("Duplicate contact check passed");
    }

    private EscalationContactEntity prepareContactEntity(EscalationContact escalationContact,
                                                         EscalationLevelEntity levelEntity,
                                                         String currentUser) {
        log.debug("Preparing contact entity for save");
        EscalationContactEntity contactEntity = escalationContactMapper.toEntity(escalationContact);
        contactEntity.setLevel(levelEntity);
        if (contactEntity.getContactOrder() == null) {
            contactEntity.setContactOrder(1);
        }
        if (contactEntity.getIsActive() == null) {
            contactEntity.setIsActive(true);
        }
        LocalDateTime now = LocalDateTime.now();
        contactEntity.setCreatedDate(now);
        contactEntity.setCreatedBy(currentUser);
        contactEntity.setLastModifiedDate(now);
        contactEntity.setLastModifiedBy(currentUser);

        log.debug("Contact entity prepared for save");
        return contactEntity;
    }

    private boolean isValidEmail(String email) {
        // Simple email validation - you might want to use a more robust solution
        return email != null && email.matches("^[A-Za-z0-9+_.-]+@(.+)$");
    }



    /**
     * Main method to get all escalation matrices based on user permissions
     */
    @Transactional(readOnly = true)
    public EscalationMatrix getAllEscalationMatrices(Long bankId) {
        log.info("Getting escalation matrices for bankId: {} ", bankId);
        try {
            EscalationMatrix matrix;

            matrix = getSingleBankEscalationMatrix(bankId);
            log.info("Successfully retrieved escalation matrices ");

            return matrix;
        } catch (Exception e) {
            log.error("Error retrieving escalation matrices for user", e);
            throw e;
        }
    }

    /**
     * Get escalation matrices for all banks (operator view)
     */
    private List<EscalationMatrix> getAllBanksEscalationMatrices() {
        log.debug("Fetching escalation matrices for all banks");

        List<DepartmentEntity> departments = departmentRepository.findActiveDepartmentsWithActiveLevels();
        log.debug("Found {} active departments", departments.size());

        List<EscalationContactEntity> allContacts = escalationContactRepository.findAllContactsOrderedByBankDepartmentAndLevel();
        log.debug("Found {} total contacts across all banks", allContacts.size());

        Map<Long, List<EscalationContactEntity>> contactsByBank = allContacts.stream()
                .collect(Collectors.groupingBy(EscalationContactEntity::getBankId));

        List<EscalationMatrix> matrices = contactsByBank.entrySet().stream()
                .sorted(Map.Entry.comparingByKey())
                .map(entry -> buildEscalationMatrix(entry.getKey(), entry.getValue(), departments))
                .filter(Objects::nonNull)
                .collect(Collectors.toList());

        log.debug("Successfully built {} escalation matrices", matrices.size());
        return matrices;
    }

    /**
     * Get escalation matrix for a single bank
     */
    private EscalationMatrix getSingleBankEscalationMatrix(Long bankId) {
        log.debug("Fetching escalation matrix for bankId: {}", bankId);

        Jwt jwt = (Jwt) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        if (jwt == null) {
            throw new IllegalStateException("Authentication required. User is not authenticated.");
        }
        String roleType = jwt.getClaimAsString("realm_access");

        if (bankId == null) {
            throw new SecurityException("Unable to determine bank");
        }

        List<Long> excludedIds = null;
        if (roleType != null &&
                roleType.contains("operator-read-write") &&
                !roleType.contains("operator-admin-read-write")) {
            excludedIds = List.of(5L, 6L, 7L);
        }

        List<DepartmentEntity> departments = departmentRepository.findActiveDepartmentsWithActiveLevelsByFilter(excludedIds);
        List<EscalationContactEntity> contacts = escalationContactRepository.findContactsByBankWithFilter(bankId, excludedIds);

        return buildEscalationMatrix(bankId, contacts, departments);
    }

    /**
     * Build escalation matrix for a specific bank
     */
    private EscalationMatrix buildEscalationMatrix(Long bankId, List<EscalationContactEntity> bankContacts, List<DepartmentEntity> departments) {
        log.debug("Building escalation matrix for bankId: {} with {} contacts", bankId, bankContacts.size());

        Map<Long, Map<Long, List<EscalationContactEntity>>> contactsByDeptAndLevel = bankContacts.stream()
                .collect(Collectors.groupingBy(
                        contact -> contact.getLevel().getDepartment().getId(),
                        Collectors.groupingBy(contact -> contact.getLevel().getId(),
                                Collectors.collectingAndThen(Collectors.toList(),
                                        list -> list.stream()
                                                .sorted(Comparator.comparing(EscalationContactEntity::getContactOrder))
                                                .toList()
                                ))
                ));


        List<DepartmentMatrix> departmentMatrices = departments.stream()
                .sorted(Comparator.comparing(DepartmentEntity::getDisplayOrder))
                .map(dept -> buildDepartmentMatrix(dept, contactsByDeptAndLevel.get(dept.getId())))
                .toList();

        EscalationMatrix escalationMatrix = new EscalationMatrix();
        escalationMatrix.setBankId(bankId);
        escalationMatrix.setDepartments(departmentMatrices);
        return escalationMatrix;
    }

    /**
     * Build department matrix with its levels and contacts
     */
    private DepartmentMatrix buildDepartmentMatrix(DepartmentEntity department, Map<Long, List<EscalationContactEntity>> contactsByLevel) {
        log.debug("Building department matrix for department: {} (ID: {})", department.getDepartmentName(), department.getId());

        // If no contacts found for this department, initialize empty map
        if (contactsByLevel == null) {
            contactsByLevel = new HashMap<>();
        }

        // Build level matrices from the department's escalation levels
        Map<Long, List<EscalationContactEntity>> finalContactsByLevel = contactsByLevel;
        List<LevelMatrix> levelMatrices = department.getEscalationLevels().stream()
                .filter(level -> level.getIsActive()) // Only active levels
                .sorted(Comparator.comparing(EscalationLevelEntity::getLevelOrder))
                .map(level -> buildLevelMatrix(level, finalContactsByLevel.get(level.getId())))
                .toList();

        DepartmentMatrix matrix = new DepartmentMatrix();
        matrix.setDepartmentId(department.getId());
        matrix.setDepartmentName(department.getDepartmentName());
        matrix.setDepartmentCode(department.getDepartmentCode());
        matrix.setDisplayOrder(department.getDisplayOrder());
        matrix.setLevels(levelMatrices);
        return matrix;
    }

    /**
     * Build level matrix with its contacts
     */
    private LevelMatrix buildLevelMatrix(EscalationLevelEntity level, List<EscalationContactEntity> contacts) {
        log.debug("Building level matrix for level: {} (ID: {})", level.getLevelName(), level.getId());

        // If no contacts found for this level, initialize empty list
        if (contacts == null) {
            contacts = new ArrayList<>();
        }

        // Convert contact entities to DTOs
        List<EscalationContact> contactDTOs = contacts.stream()
                .map(escalationContactMapper::toModel)
                .toList();


        LevelMatrix levelMatrix = new LevelMatrix();
        levelMatrix.setLevelId(level.getId());
        levelMatrix.setLevelName(level.getLevelName());
        levelMatrix.setLevelOrder(level.getLevelOrder());
        levelMatrix.setContacts(contactDTOs);
        return levelMatrix;
    }


    /**
     * Check if user has operator-level access
     */
    private boolean isOperatorRole() {
        Jwt jwt = (Jwt) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return "OPERATOR".equals(jwt.getClaimAsString("userType"));
    }

    /**
     * Get bank ID for the current user
     */
    private Long getUserBankId(String currentUser) {
        Jwt jwt = (Jwt) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return Long.parseLong(jwt.getClaimAsString("bankId"));
    }

    /**
     * Get accessible department IDs for user roles
     */
    private List<Long> getAccessibleDepartmentIds(List<String> userRoles) {
        return userRoles.stream()
                .flatMap(role -> roleDepartmentMappingRepository.findDepartmentIdsByRoleName(role).stream())
                .distinct()
                .collect(Collectors.toList());
    }

    /**
     * Validate user roles
     */
    private void validateUserRoles(List<String> userRoles) {
        if (userRoles == null || userRoles.isEmpty()) {
            throw new SecurityException("User roles not found");
        }
    }

    /**
     * Validate user has access to at least one department
     */
    private void validateUserDepartmentAccess(List<String> userRoles) {
        List<Long> accessibleDepartments = getAccessibleDepartmentIds(userRoles);
        if (accessibleDepartments.isEmpty()) {
            throw new SecurityException("User does not have access to any departments");
        }
    }

    public void deleteEscalationMatrix(Long id) {
        log.info("Entering deleteEscalationMatrix with id: {}", id);

        if (escalationContactRepository.existsById(id)) {
            log.info("EscalationContact exists with id: {}, proceeding to delete", id);

            escalationContactRepository.deleteById(id);
            log.info("EscalationContact deleted successfully with id: {}", id);

        } else {
            log.warn("EscalationContact not found with id: {}", id);

            throw new ResourceNotFoundException("Escalation not found with id " + id);
        }
        log.info("Exiting deleteEscalationMatrix");
    }

    public void updateEscalationMatrix(EscalationContact escalationContact) {
        log.info("Entering updateEscalationMatrix with EscalationContact: {}", escalationContact);

        Optional<EscalationContactEntity> existingRecord = escalationContactRepository.findById(escalationContact.getId());
        if (existingRecord.isEmpty()) {
            log.error("Escalation contact not found with id: {}", escalationContact.getId());
            throw new ResourceNotFoundException("Escalation not found with id " + escalationContact.getId());
        }

        boolean duplicateContactExists = escalationContactRepository
                .existsByBankIdAndLevelIdAndContactNameAndContactEmailAndContactNumberAndFeatureAndBusinessAndDesignation(
                        escalationContact.getBankId(),
                        escalationContact.getLevelId(),
                        escalationContact.getContactName(),
                        escalationContact.getContactEmail(),
                        escalationContact.getContactNumber(),
                        escalationContact.getFeature(),
                        escalationContact.getBusiness(),
                        escalationContact.getDesignation()
                );

        if (duplicateContactExists) {
            log.error("Duplicate escalation contact found for bankId: {}, levelId: {}, contactName: {}",
                    escalationContact.getBankId(), escalationContact.getLevelId(), escalationContact.getContactName());
            throw new DuplicateEntryException("Duplicate escalation contact found for bankId: " + escalationContact.getBankId());
        }

        EscalationContactEntity escalationContactEntity = escalationContactMapper.toEntity(escalationContact);
        escalationContactRepository.save(escalationContactEntity);
        log.info("Escalation contact updated successfully: {}", escalationContact);
    }

    public ByteArrayResource downloadEscalationMatrixAsPDF(Long bankId, Long departmentId)  {
        try {
            log.info("Attempting to retrieve Escalation Matrix");
            List<EscalationContactDTO> escalationContacts;

            if (departmentId != null && bankId != null) {
                log.debug("Retrieving contacts with both department ID: {} and Bank ID: {}", departmentId, bankId);
                escalationContacts = escalationContactRepository.findDTOByDepartmentIdAndBankId(departmentId, bankId);
                if (escalationContacts.isEmpty()) {
                    throw new ResourceNotFoundException("No contacts found for department ID: " + departmentId + " and Bank ID: " + bankId);
                }
            } else if (bankId != null) {
                log.debug("Retrieving contacts with Bank ID: {}", bankId);
                escalationContacts = escalationContactRepository.findDTOByBankId(bankId);
                if (escalationContacts.isEmpty()) {
                    throw new ResourceNotFoundException("No contacts found for Bank ID: " + bankId);
                }
            } else {
                log.debug("Retrieving all contacts since no specific criteria provided.");
                escalationContacts = escalationContactRepository.findAllDTO();
                if (escalationContacts.isEmpty()) {
                    throw new ResourceNotFoundException("No contacts found");
                }
            }
            log.info("Retrieved contacts: {}", escalationContacts);

            Map<String, List<EscalationContactDTO>> departmentGroupedContacts = escalationContacts.stream()
                    .collect(Collectors.groupingBy(
                            contact -> contact.getDepartmentCode() + "|" + contact.getDisplayOrder() + "|" + contact.getDepartmentName()
                    ));
            log.debug("Grouped contacts by department: {}", departmentGroupedContacts.keySet());

            Map<String, List<EscalationContactDTO>> sortedDepartments = departmentGroupedContacts.entrySet().stream()
                    .sorted(Map.Entry.comparingByKey((key1, key2) -> {
                        Integer order1 = Integer.parseInt(key1.split("\\|")[1]);
                        Integer order2 = Integer.parseInt(key2.split("\\|")[1]);
                        return order1.compareTo(order2);
                    }))
                    .collect(Collectors.toMap(
                            Map.Entry::getKey,
                            Map.Entry::getValue,
                            (oldValue, newValue) -> oldValue,
                            LinkedHashMap::new
                    ));
            log.debug("Sorted departments by displayOrder: {}", sortedDepartments.keySet());

            Map<String, Map<String, List<EscalationContactDTO>>> hierarchicalData = new LinkedHashMap<>();

            for (Map.Entry<String, List<EscalationContactDTO>> deptEntry : sortedDepartments.entrySet()) {
                String[] deptParts = deptEntry.getKey().split("\\|");
                String departmentInfo = deptParts[2] + " (" + deptParts[0] + ")"; // Format: "Department Name (Code)"

                Map<String, List<EscalationContactDTO>> levelGroupedContacts = deptEntry.getValue().stream()
                        .collect(Collectors.groupingBy(
                                contact -> contact.getLevelName() + "|" + contact.getLevelOrder()
                        ));

                Map<String, List<EscalationContactDTO>> sortedLevels = levelGroupedContacts.entrySet().stream()
                        .sorted(Map.Entry.comparingByKey((key1, key2) -> {
                            Integer order1 = Integer.parseInt(key1.split("\\|")[1]);
                            Integer order2 = Integer.parseInt(key2.split("\\|")[1]);
                            return order1.compareTo(order2);
                        }))
                        .collect(Collectors.toMap(
                                entry -> entry.getKey().split("\\|")[0], // Just keep the level name for display
                                Map.Entry::getValue,
                                (oldValue, newValue) -> oldValue,
                                LinkedHashMap::new
                        ));

                for (Map.Entry<String, List<EscalationContactDTO>> levelEntry : sortedLevels.entrySet()) {
                    List<EscalationContactDTO> sortedByBankName = levelEntry.getValue().stream()
                            .sorted(Comparator.comparing(EscalationContactDTO::getBankName))
                            .collect(Collectors.toList());
                    levelEntry.setValue(sortedByBankName);
                }

                hierarchicalData.put(departmentInfo, sortedLevels);
            }
            log.info("Organized contacts hierarchically by department and level");

            String base64Image = getBase64Image();
            log.debug("Retrieved base64 image for logo.");

            Context context = new Context();
            context.setVariable("hierarchicalData", hierarchicalData);
            context.setVariable("base64Image", base64Image);
            log.info("Context for template prepared with hierarchical data and image.");

            String htmlContent = templateEngine.process("escalation-contact", context);
            log.debug("Generated HTML content for the PDF.");

            try (ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream()) {
                ITextRenderer renderer = new ITextRenderer();
                renderer.setDocumentFromString(htmlContent);
                log.debug("Document set to renderer, starting layout.");
                renderer.layout();
                log.debug("PDF layout complete, starting PDF creation.");
                renderer.createPDF(byteArrayOutputStream);
                log.debug("PDF Creation complete.");

                ByteArrayOutputStream outputWithPageNumbers = new ByteArrayOutputStream();
                PdfReader reader = new PdfReader(byteArrayOutputStream.toByteArray());
                PdfStamper stamper = new PdfStamper(reader, outputWithPageNumbers);

                int totalPages = reader.getNumberOfPages();
                log.info("Total Pages are {}", totalPages);

                for (int i = 1; i <= totalPages; i++) {
                    ColumnText.showTextAligned(stamper.getOverContent(i), Element.ALIGN_CENTER,
                            new Phrase("Page " + i + " of " + totalPages, FontFactory.getFont(FontFactory.HELVETICA, 10)),
                            300, 30, 0);
                }
                stamper.close();
                reader.close();

                log.info("PDF generation complete. Returning response.");
                return new ByteArrayResource(outputWithPageNumbers.toByteArray());
            }
        } catch (ResourceNotFoundException e) {
            log.error("No contacts found: {}", e.getMessage());
            throw e;
        } catch (Exception e) {
            log.error("Error generating PDF for Escalation Matrix Error: {}", e.getMessage(), e);
            throw new FileProcessingException("Failed to generate file (PDF) for Escalation Matrix: " + e);
        }
    }

    private String getBase64Image() throws IOException {
        ClassPathResource imgFile = new ClassPathResource("static/images/iftas-logo.jpg");
        byte[] bytes = FileCopyUtils.copyToByteArray(imgFile.getInputStream());
        return Base64.getEncoder().encodeToString(bytes);
    }

}