package in.iftas.sfms.core.repository;

import in.iftas.sfms.core.entity.RoleDepartmentMappingEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface RoleDepartmentMappingRepository extends JpaRepository<RoleDepartmentMappingEntity, Long> {
    
    /**
     * Get department IDs accessible by a role
     */
    @Query("SELECT rdm.department.id FROM RoleDepartmentMappingEntity rdm " +
           "WHERE rdm.keycloakRoleName = :roleName AND rdm.isActive = true")
    List<Long> findDepartmentIdsByRoleName(@Param("roleName") String roleName);
    
    /**
     * Check if user has access to specific department
     */
    boolean existsByKeycloakRoleNameAndDepartmentIdAndIsActive(String keycloakRoleName, Long departmentId, Boolean isActive);
}