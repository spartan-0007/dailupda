package in.iftas.sfms.core.model;

import java.net.URI;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonTypeName;
import in.iftas.sfms.core.model.DownloadLog;
import java.util.ArrayList;
import java.util.List;
import org.openapitools.jackson.nullable.JsonNullable;
import java.time.OffsetDateTime;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


import java.util.*;
import jakarta.annotation.Generated;

/**
 * GetPatchDownloadLog200Response
 */

@JsonTypeName("getPatchDownloadLog_200_response")

public class GetPatchDownloadLog200Response {

  private Long patchId;

  private String fileName;

  @Valid
  private List<@Valid DownloadLog> downloadLog;

  public GetPatchDownloadLog200Response patchId(Long patchId) {
    this.patchId = patchId;
    return this;
  }

  /**
   * Get patchId
   * @return patchId
   */
  
  @Schema(name = "patchId", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("patchId")
  public Long getPatchId() {
    return patchId;
  }

  public void setPatchId(Long patchId) {
    this.patchId = patchId;
  }

  public GetPatchDownloadLog200Response fileName(String fileName) {
    this.fileName = fileName;
    return this;
  }

  /**
   * Get fileName
   * @return fileName
   */
  
  @Schema(name = "fileName", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("fileName")
  public String getFileName() {
    return fileName;
  }

  public void setFileName(String fileName) {
    this.fileName = fileName;
  }

  public GetPatchDownloadLog200Response downloadLog(List<@Valid DownloadLog> downloadLog) {
    this.downloadLog = downloadLog;
    return this;
  }

  public GetPatchDownloadLog200Response addItem(DownloadLog downloadLogItem) {
    if (this.downloadLog == null) {
      this.downloadLog = new ArrayList<>();
    }
    this.downloadLog.add(downloadLogItem);
    return this;
  }

  /**
   * Get downloadLog
   * @return downloadLog
   */
  @Valid 
  @Schema(name = "downloadLog", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("downloadLog")
  public List<@Valid DownloadLog> getDownloadLog() {
    return downloadLog;
  }

  public void setDownloadLog(List<@Valid DownloadLog> downloadLog) {
    this.downloadLog = downloadLog;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    GetPatchDownloadLog200Response getPatchDownloadLog200Response = (GetPatchDownloadLog200Response) o;
    return Objects.equals(this.patchId, getPatchDownloadLog200Response.patchId) &&
        Objects.equals(this.fileName, getPatchDownloadLog200Response.fileName) &&
        Objects.equals(this.downloadLog, getPatchDownloadLog200Response.downloadLog);
  }

  @Override
  public int hashCode() {
    return Objects.hash(patchId, fileName, downloadLog);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class GetPatchDownloadLog200Response {\n");
    sb.append("    patchId: ").append(toIndentedString(patchId)).append("\n");
    sb.append("    fileName: ").append(toIndentedString(fileName)).append("\n");
    sb.append("    downloadLog: ").append(toIndentedString(downloadLog)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

