package in.iftas.sfms.core.repository;

import in.iftas.sfms.core.entity.EscalationApprovalStepEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface EscalationApprovalStepRepository extends JpaRepository<EscalationApprovalStepEntity, Long> {

    /**
     * Find step by approval ID and level number
     * Used in: processApproval() to get current step
     */
    Optional<EscalationApprovalStepEntity> findByApprovalIdAndLevelNumber(
            Long approvalId, 
            Integer levelNumber
    );

    /**
     * Get all steps for an approval in order
     * Used in: getApprovalHistory() for audit trail
     */
    List<EscalationApprovalStepEntity> findByApprovalIdOrderByLevelNumber(Long approvalId);

    /**
     * Check if user has approved any step in this workflow
     * Used in: hasUserAlreadyApproved() to filter out completed actions
     */
    @Query("SELECT CASE WHEN COUNT(step) > 0 THEN true ELSE false END " +
           "FROM EscalationApprovalStepEntity step WHERE " +
           "step.approvalId = :approvalId AND step.checkerId = :checkerId " +
           "AND step.status = 'APPROVED'")
    boolean hasUserApprovedAnyStep(@Param("approvalId") Long approvalId, @Param("checkerId") String checkerId);
}