package in.iftas.sfms.core.service;

import in.iftas.sfms.core.entity.BankEntity;
import in.iftas.sfms.core.entity.BranchEntity;
import in.iftas.sfms.core.mapper.BranchMapper;
import in.iftas.sfms.core.repository.BankBranchRepository;
import in.iftas.sfms.core.repository.BankRepository;
import jakarta.annotation.PostConstruct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

@Service
@Transactional(readOnly = true)
public class SmartBranchSearchService {

    private static final Logger logger = LoggerFactory.getLogger(SmartBranchSearchService.class);

    @Autowired
    private BankBranchRepository branchRepository;

    @Autowired
    private BranchMapper branchMapper;

    @Autowired
    private BankRepository bankRepository;

    private Set<String> knownBankCodes;

    @PostConstruct
    public void initializeBankCodes() {
        knownBankCodes = bankRepository.findAll().stream()
                .map(BankEntity::getBankShortName)
                .map(String::toUpperCase)
                .collect(Collectors.toSet());

        logger.info("Initialized {} bank codes from database", knownBankCodes.size());
    }

    private static final Set<String> LOCATION_KEYWORDS = Set.of(
            "road", "street", "avenue", "colony", "sector", "block",
            "near", "opposite", "behind", "front", "beside",
            "city", "area", "locality", "mall", "market", "tower",
            "building", "complex", "nagar", "gram", "village"
    );

    public Map<String, Object> smartSearch(Integer bankId, String searchTerm, Integer page, Integer size, String sort) {
        logger.info("Smart search - bankId: {}, searchTerm: {}, page: {}, size: {}", bankId, searchTerm, page, size);

        Pageable pageable = PageRequest.of(page, size, Sort.by(sort));

        // Handle bank-specific search first
        if (bankId != null) {
            return getBranchesByBankId(bankId, pageable);
        }

        // If no search term, return all
        if (searchTerm == null || searchTerm.trim().isEmpty()) {
            return getAllBranches(pageable);
        }

        // Analyze search term and determine type
        SearchType analysis = analyzeSearchTerm(searchTerm.trim());
        logger.debug("Search Type detected as : {}", analysis);

        // Execute the detected search type
        return executeSearch(searchTerm.trim(), analysis, pageable);
    }

    private SearchType analyzeSearchTerm(String searchTerm) {
        String cleanTerm = searchTerm.replaceAll("\\s+", "").toUpperCase();
        String lowerTerm = searchTerm.toLowerCase();

        // 1. Complete IFSC pattern (11 characters exactly)
        if (cleanTerm.matches("^[A-Z]{4}0[A-Z0-9]{6}$")) {
            return SearchType.IFSC;
        }

        // 2. Partial IFSC with 5th character as '0' (strong indicator)
        if (cleanTerm.length() >= 5 && cleanTerm.charAt(4) == '0') {
            return SearchType.IFSC;
        }

        // 3. Check for exact bank code patterns (4 chars + something)
        if (cleanTerm.length() >= 4) {
            String potentialBankCode = cleanTerm.substring(0, 4);
            if (knownBankCodes.contains(potentialBankCode)) {
                // If more than 4 chars with bank code, likely IFSC
                return SearchType.IFSC;
            } else {
                return SearchType.LOCATION;
            }
        }

        // 4. Strong location indicators
        boolean hasLocationKeywords = LOCATION_KEYWORDS.stream()
                .anyMatch(keyword -> lowerTerm.contains(keyword));

        if (hasLocationKeywords) {
            return SearchType.LOCATION;
        }

        // 5. Check for address patterns (PIN codes, etc.)
        if (searchTerm.matches(".*\\d{6}.*") || searchTerm.matches(".*\\d+[/-]\\d+.*")) {
            return SearchType.LOCATION;
        }

        // 6. Multiple words strongly suggest location
        if (searchTerm.split("\\s+").length > 1) {
            return SearchType.LOCATION;
        }

        // 7. IFSC-like characteristics (all caps, contains numbers)
        if (cleanTerm.equals(searchTerm.toUpperCase()) && cleanTerm.matches(".*[0-9].*")) {
            return SearchType.IFSC;
        }

        // 8. Default to location search for ambiguous cases
        return SearchType.LOCATION;
    }

    private Map<String, Object> executeSearch(String searchTerm, SearchType analysis, Pageable pageable) {
        Page<BranchEntity> branches;
        Long totalElements;

        if (analysis == SearchType.IFSC) {
            // Execute IFSC search
            branches = branchRepository.findByIfscCodeWithRelevance(searchTerm, pageable);
            totalElements = branchRepository.countByIfscCodeWithRelevance(searchTerm);
            logger.debug("IFSC search executed, found {} results", totalElements);
        } else {
            // Execute location search
            branches = branchRepository.findByLocationWithRelevance(searchTerm, pageable);
            totalElements = branchRepository.countByLocationWithRelevance(searchTerm);
            logger.debug("Location search executed, found {} results", totalElements);
        }

        return buildResult(branches, totalElements, analysis);
    }

    private Map<String, Object> buildResult(Page<BranchEntity> branches, Long totalElements, SearchType analysis) {
        Map<String, Object> result = new HashMap<>();
        result.put("branches", branches.getContent().stream()
                .map(branchMapper::toBranchBankActiveStatusModel)
                .collect(Collectors.toList()));
        result.put("totalElements", totalElements);
        result.put("searchAnalysis", analysis);

        return result;
    }

    private Map<String, Object> getBranchesByBankId(Integer bankId, Pageable pageable) {
        Page<BranchEntity> branches = branchRepository.findByBankId(bankId, pageable);
        Long totalElements = branchRepository.countByBankId(bankId);

        Map<String, Object> result = new HashMap<>();
        result.put("branches", branches.getContent().stream()
                .map(branchMapper::toBranchBankActiveStatusModel)
                .collect(Collectors.toList()));
        result.put("totalElements", totalElements);
        result.put("searchType", "BANK_FILTER");

        return result;
    }

    private Map<String, Object> getAllBranches(Pageable pageable) {
        Page<BranchEntity> branches = branchRepository.findAll(pageable);

        Map<String, Object> result = new HashMap<>();
        result.put("branches", branches.getContent().stream()
                .map(branchMapper::toBranchBankActiveStatusModel)
                .collect(Collectors.toList()));
        result.put("totalElements", branches.getTotalElements());
        result.put("searchType", "ALL");

        return result;
    }

    public enum SearchType {
        IFSC, LOCATION
    }
}