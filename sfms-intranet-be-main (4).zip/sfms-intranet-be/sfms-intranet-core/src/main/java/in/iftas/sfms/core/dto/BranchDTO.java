package in.iftas.sfms.core.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class BranchDTO {

    @JsonProperty("IFSC_CODE")
    private String ifscCode;

    @JsonProperty("IFSC_TYPE")
    private String ifscType;

    @JsonProperty("MICR_CODE")
    private String micrCode;

    @JsonProperty("BRANCH_NAME")
    private String branchName;

    @JsonProperty("CITY_NAME")
    private String cityName;

    @JsonProperty("ADDRESS")
    private String bankAddress;

    @JsonProperty("BANK_ID")
    private Long bankId;

    @JsonProperty("DISTRICT")
    private String district;

    @JsonProperty("STATE")
    private String state;

    @JsonProperty("STD_CODE")
    private String stdCode;

    @JsonProperty("PHONE_NO")
    private String phoneNo;

    @JsonProperty("NEFT_ENABLED")
    private String neftEnabled;

    @JsonProperty("RTGS_ENABLED")
    private String rtgsEnabled;

    @JsonProperty("LCS_ENABLED")
    private String lcEnabled;

    @JsonProperty("BGS_ENABLED")
    private String bgEnabled;

    @JsonProperty("OTHERS")
    private String others;

    @JsonProperty("isActive")
    private Boolean isActive;

    public BranchDTO(String ifscCode, String branchName) {
        this.ifscCode = ifscCode;
        this.branchName = branchName;
    }
    public BranchDTO(
            String ifscCode,
            String ifscType,
            String micrCode,
            String branchName,
            String cityName,
            String bankAddress,
            Long bankId,
            String district,
            String state,
            String stdCode,
            String phoneNo,
            String neftEnabled,
            String rtgsEnabled,
            String lcEnabled,
            String bgEnabled,
            String others
    ) {
        this.ifscCode = ifscCode;
        this.ifscType = ifscType;
        this.micrCode = micrCode;
        this.branchName = branchName;
        this.cityName = cityName;
        this.bankAddress = bankAddress;
        this.bankId = bankId;
        this.district = district;
        this.state = state;
        this.stdCode = stdCode;
        this.phoneNo = phoneNo;
        this.neftEnabled = neftEnabled;
        this.rtgsEnabled = rtgsEnabled;
        this.lcEnabled = lcEnabled;
        this.bgEnabled = bgEnabled;
        this.others = others;
    }

}