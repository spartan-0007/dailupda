package in.iftas.sfms.core.model;

import java.net.URI;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;
import org.openapitools.jackson.nullable.JsonNullable;
import java.time.OffsetDateTime;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


import java.util.*;
import jakarta.annotation.Generated;

/**
 * EscalationApprovalStep
 */


public class EscalationApprovalStep {

  private Long id;

  private Long approvalId;

  private Integer levelNumber;

  /**
   * Role required for this approval level
   */
  public enum RequiredRoleEnum {
    BANKER("BANKER"),
    
    OPERATOR("OPERATOR"),
    
    ADMIN("ADMIN");

    private String value;

    RequiredRoleEnum(String value) {
      this.value = value;
    }

    @JsonValue
    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static RequiredRoleEnum fromValue(String value) {
      for (RequiredRoleEnum b : RequiredRoleEnum.values()) {
        if (b.value.equals(value)) {
          return b;
        }
      }
      throw new IllegalArgumentException("Unexpected value '" + value + "'");
    }
  }

  private RequiredRoleEnum requiredRole;

  private String checkerId;

  private String checkerName;

  /**
   * Role of the checker
   */
  public enum CheckerRoleEnum {
    BANKER("BANKER"),
    
    OPERATOR("OPERATOR"),
    
    ADMIN("ADMIN");

    private String value;

    CheckerRoleEnum(String value) {
      this.value = value;
    }

    @JsonValue
    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static CheckerRoleEnum fromValue(String value) {
      for (CheckerRoleEnum b : CheckerRoleEnum.values()) {
        if (b.value.equals(value)) {
          return b;
        }
      }
      throw new IllegalArgumentException("Unexpected value '" + value + "'");
    }
  }

  private CheckerRoleEnum checkerRole;

  /**
   * Status of this approval step
   */
  public enum StatusEnum {
    PENDING("PENDING"),
    
    APPROVED("APPROVED"),
    
    REJECTED("REJECTED");

    private String value;

    StatusEnum(String value) {
      this.value = value;
    }

    @JsonValue
    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static StatusEnum fromValue(String value) {
      for (StatusEnum b : StatusEnum.values()) {
        if (b.value.equals(value)) {
          return b;
        }
      }
      throw new IllegalArgumentException("Unexpected value '" + value + "'");
    }
  }

  private StatusEnum status;

  @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
  private Date actionDate;

  private String comments;

  private String rejectionReason;

  @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
  private Date dueDate;

  @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
  private Date createdDate;

  public EscalationApprovalStep id(Long id) {
    this.id = id;
    return this;
  }

  /**
   * Unique identifier for the approval step
   * @return id
   */
  
  @Schema(name = "id", description = "Unique identifier for the approval step", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("id")
  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public EscalationApprovalStep approvalId(Long approvalId) {
    this.approvalId = approvalId;
    return this;
  }

  /**
   * ID of the parent approval request
   * @return approvalId
   */
  
  @Schema(name = "approvalId", description = "ID of the parent approval request", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("approvalId")
  public Long getApprovalId() {
    return approvalId;
  }

  public void setApprovalId(Long approvalId) {
    this.approvalId = approvalId;
  }

  public EscalationApprovalStep levelNumber(Integer levelNumber) {
    this.levelNumber = levelNumber;
    return this;
  }

  /**
   * Level number in the approval workflow
   * @return levelNumber
   */
  
  @Schema(name = "levelNumber", description = "Level number in the approval workflow", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("levelNumber")
  public Integer getLevelNumber() {
    return levelNumber;
  }

  public void setLevelNumber(Integer levelNumber) {
    this.levelNumber = levelNumber;
  }

  public EscalationApprovalStep requiredRole(RequiredRoleEnum requiredRole) {
    this.requiredRole = requiredRole;
    return this;
  }

  /**
   * Role required for this approval level
   * @return requiredRole
   */
  
  @Schema(name = "requiredRole", description = "Role required for this approval level", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("requiredRole")
  public RequiredRoleEnum getRequiredRole() {
    return requiredRole;
  }

  public void setRequiredRole(RequiredRoleEnum requiredRole) {
    this.requiredRole = requiredRole;
  }

  public EscalationApprovalStep checkerId(String checkerId) {
    this.checkerId = checkerId;
    return this;
  }

  /**
   * ID of the checker assigned to this step
   * @return checkerId
   */
  
  @Schema(name = "checkerId", description = "ID of the checker assigned to this step", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("checkerId")
  public String getCheckerId() {
    return checkerId;
  }

  public void setCheckerId(String checkerId) {
    this.checkerId = checkerId;
  }

  public EscalationApprovalStep checkerName(String checkerName) {
    this.checkerName = checkerName;
    return this;
  }

  /**
   * Name of the checker assigned to this step
   * @return checkerName
   */
  
  @Schema(name = "checkerName", description = "Name of the checker assigned to this step", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("checkerName")
  public String getCheckerName() {
    return checkerName;
  }

  public void setCheckerName(String checkerName) {
    this.checkerName = checkerName;
  }

  public EscalationApprovalStep checkerRole(CheckerRoleEnum checkerRole) {
    this.checkerRole = checkerRole;
    return this;
  }

  /**
   * Role of the checker
   * @return checkerRole
   */
  
  @Schema(name = "checkerRole", description = "Role of the checker", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("checkerRole")
  public CheckerRoleEnum getCheckerRole() {
    return checkerRole;
  }

  public void setCheckerRole(CheckerRoleEnum checkerRole) {
    this.checkerRole = checkerRole;
  }

  public EscalationApprovalStep status(StatusEnum status) {
    this.status = status;
    return this;
  }

  /**
   * Status of this approval step
   * @return status
   */
  
  @Schema(name = "status", description = "Status of this approval step", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("status")
  public StatusEnum getStatus() {
    return status;
  }

  public void setStatus(StatusEnum status) {
    this.status = status;
  }

  public EscalationApprovalStep actionDate(Date actionDate) {
    this.actionDate = actionDate;
    return this;
  }

  /**
   * Date when the action was taken
   * @return actionDate
   */
  @Valid 
  @Schema(name = "actionDate", description = "Date when the action was taken", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("actionDate")
  public Date getActionDate() {
    return actionDate;
  }

  public void setActionDate(Date actionDate) {
    this.actionDate = actionDate;
  }

  public EscalationApprovalStep comments(String comments) {
    this.comments = comments;
    return this;
  }

  /**
   * Comments from the checker
   * @return comments
   */
  
  @Schema(name = "comments", description = "Comments from the checker", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("comments")
  public String getComments() {
    return comments;
  }

  public void setComments(String comments) {
    this.comments = comments;
  }

  public EscalationApprovalStep rejectionReason(String rejectionReason) {
    this.rejectionReason = rejectionReason;
    return this;
  }

  /**
   * Reason for rejection if step was rejected
   * @return rejectionReason
   */
  
  @Schema(name = "rejectionReason", description = "Reason for rejection if step was rejected", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("rejectionReason")
  public String getRejectionReason() {
    return rejectionReason;
  }

  public void setRejectionReason(String rejectionReason) {
    this.rejectionReason = rejectionReason;
  }

  public EscalationApprovalStep dueDate(Date dueDate) {
    this.dueDate = dueDate;
    return this;
  }

  /**
   * Due date for this approval step
   * @return dueDate
   */
  @Valid 
  @Schema(name = "dueDate", description = "Due date for this approval step", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("dueDate")
  public Date getDueDate() {
    return dueDate;
  }

  public void setDueDate(Date dueDate) {
    this.dueDate = dueDate;
  }

  public EscalationApprovalStep createdDate(Date createdDate) {
    this.createdDate = createdDate;
    return this;
  }

  /**
   * Date when the step was created
   * @return createdDate
   */
  @Valid 
  @Schema(name = "createdDate", description = "Date when the step was created", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("createdDate")
  public Date getCreatedDate() {
    return createdDate;
  }

  public void setCreatedDate(Date createdDate) {
    this.createdDate = createdDate;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    EscalationApprovalStep escalationApprovalStep = (EscalationApprovalStep) o;
    return Objects.equals(this.id, escalationApprovalStep.id) &&
        Objects.equals(this.approvalId, escalationApprovalStep.approvalId) &&
        Objects.equals(this.levelNumber, escalationApprovalStep.levelNumber) &&
        Objects.equals(this.requiredRole, escalationApprovalStep.requiredRole) &&
        Objects.equals(this.checkerId, escalationApprovalStep.checkerId) &&
        Objects.equals(this.checkerName, escalationApprovalStep.checkerName) &&
        Objects.equals(this.checkerRole, escalationApprovalStep.checkerRole) &&
        Objects.equals(this.status, escalationApprovalStep.status) &&
        Objects.equals(this.actionDate, escalationApprovalStep.actionDate) &&
        Objects.equals(this.comments, escalationApprovalStep.comments) &&
        Objects.equals(this.rejectionReason, escalationApprovalStep.rejectionReason) &&
        Objects.equals(this.dueDate, escalationApprovalStep.dueDate) &&
        Objects.equals(this.createdDate, escalationApprovalStep.createdDate);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, approvalId, levelNumber, requiredRole, checkerId, checkerName, checkerRole, status, actionDate, comments, rejectionReason, dueDate, createdDate);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class EscalationApprovalStep {\n");
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    approvalId: ").append(toIndentedString(approvalId)).append("\n");
    sb.append("    levelNumber: ").append(toIndentedString(levelNumber)).append("\n");
    sb.append("    requiredRole: ").append(toIndentedString(requiredRole)).append("\n");
    sb.append("    checkerId: ").append(toIndentedString(checkerId)).append("\n");
    sb.append("    checkerName: ").append(toIndentedString(checkerName)).append("\n");
    sb.append("    checkerRole: ").append(toIndentedString(checkerRole)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    actionDate: ").append(toIndentedString(actionDate)).append("\n");
    sb.append("    comments: ").append(toIndentedString(comments)).append("\n");
    sb.append("    rejectionReason: ").append(toIndentedString(rejectionReason)).append("\n");
    sb.append("    dueDate: ").append(toIndentedString(dueDate)).append("\n");
    sb.append("    createdDate: ").append(toIndentedString(createdDate)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

