package in.iftas.sfms.core.service.impl;

import in.iftas.sfms.core.dto.BankDTO;
import in.iftas.sfms.core.entity.BankEntity;
import in.iftas.sfms.core.entity.BranchEntity;
import in.iftas.sfms.core.entity.BranchProliferationEntity;
import in.iftas.sfms.core.exception.ResourceNotFoundException;
import in.iftas.sfms.core.mapper.BankDTOMapper;
import in.iftas.sfms.core.mapper.BankMapper;
import in.iftas.sfms.core.mapper.BranchMapper;
import in.iftas.sfms.core.model.Bank;
import in.iftas.sfms.core.model.Branch;
import in.iftas.sfms.core.repository.BankBranchRepository;
import in.iftas.sfms.core.repository.BankRepository;
import in.iftas.sfms.core.repository.BranchProliferationRepository;
import in.iftas.sfms.core.service.BankService;
import in.iftas.sfms.core.service.BranchProliferationService;
import in.iftas.sfms.core.service.SmartBranchSearchService;
import in.iftas.sfms.core.validations.BankValidator;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

@Service
public class BankServiceImpl implements BankService {

    private static final Logger logger = LoggerFactory.getLogger(BankServiceImpl.class);

    private final BankRepository bankRepository;
    private final BankMapper bankMapper;
    private final BranchMapper branchMapper;
    private final BankBranchRepository branchRepository;
    private final BankDTOMapper bankDTOMapper;
    private final BranchProliferationService branchProliferationService;
    private final BranchProliferationRepository branchProliferationRepository;
    private final BankValidator bankValidator;
    private final SmartBranchSearchService smartBranchSearchService;


    @Autowired
    public BankServiceImpl(BankRepository bankRepository, BankMapper bankMapper, BranchMapper branchMapper,BranchProliferationService branchProliferationService,BranchProliferationRepository branchProliferationRepository,
                           BankBranchRepository branchRepository, BankDTOMapper bankDTOMapper,BankValidator bankValidator,SmartBranchSearchService smartBranchSearchService) {
        this.bankRepository = bankRepository;
        this.bankMapper = bankMapper;
        this.branchMapper = branchMapper;
        this.branchRepository = branchRepository;
        this.bankDTOMapper = bankDTOMapper;
        this.branchProliferationService = branchProliferationService;
        this.branchProliferationRepository = branchProliferationRepository;
        this.bankValidator = bankValidator;
        this.smartBranchSearchService = smartBranchSearchService;
    }

    @Override
    public List<Branch> getBranchesByBankId(Integer bankId, Integer page, Integer size, String sort) {
        logger.info("Fetching branches for bankId: {}", bankId);
        Pageable pageable = PageRequest.of(page, size, Sort.by(sort));
        Page<BranchEntity> branchPage = branchRepository.findByBankId(bankId, pageable);
        logger.debug("Found {} branches for bankId: {}", branchPage.getTotalElements(), bankId);
        return branchPage.getContent()
                .stream()
                .map(branchMapper::toModel)
                .toList();
    }

    @Override
    public void deleteBank(Integer bankId) {
        logger.info("Deleting bank with id: {}", bankId);
        Optional<BankEntity> bankEntityOptional = bankRepository.findById(bankId);
        bankEntityOptional.ifPresentOrElse(bankEntity -> {
                    bankEntity.setIsActive(false);
                    bankRepository.save(bankEntity);
                    logger.info("Bank with id: {} marked as inactive", bankId);
                },
                () -> {
                    logger.warn("Bank not found with id: {}", bankId);
                    throw new ResourceNotFoundException("Bank not found with id " + bankId);
                });
    }

    @Override
    public List<Bank> getAllBanks(Integer page, Integer size, String sort) {
        logger.info("Fetching all banks with pagination - page: {}, size: {}, sort: {}", page, size, sort);
        Pageable pageable = PageRequest.of(page, size, Sort.by(sort));
        Page<BankDTO> bankDTOsPage = bankRepository.findAllBanks(pageable);

        logger.debug("Found {} banks", bankDTOsPage.getTotalElements());
        return bankDTOsPage.getContent()
                .stream()
                .map(bankMapper::toModelFromDto)
                .toList();
    }

    @Override
    public Long addBank(Bank bank) {
        logger.info("Adding new bank: {}", bank.getBankName());
        Jwt jwt = (Jwt) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
  try{
            bankValidator.validateBankCreation(bank);
            bankValidator.validateDuplicateApprovalRequest(bank);
    } catch (IllegalArgumentException e) {
        logger.warn("Duplicate or invalid resource: {}", e.getMessage());
        throw e; // or handle accordingly
    }

        BankEntity bankEntity = bankMapper.toEntity(bank);
            bankEntity.setCreatedBy(jwt.getClaimAsString("sub"));
            bankEntity.setCreatedDate(LocalDateTime.now());
            BankEntity newBankEntity = bankRepository.save(bankEntity);

            List<BranchProliferationEntity> proliferationEntities = bank.getBranches().stream()
                    .map(branch -> {
                        String branchJson = branchProliferationService.convertBranchToJson(branch, bankEntity.getBankName());
                        BranchProliferationEntity entity = BranchProliferationEntity.builder()
                                .branchId(branch.getIfscCode())
                                .branchDetailsJson(branchJson)
                                .isProliferated(false)
                                .bankId(Integer.valueOf(bankEntity.getId().toString()))
                                .build();
                        entity.setCreatedBy(jwt.getClaimAsString("sub"));
                        return entity;
                    })
                    .toList();

            branchProliferationRepository.saveAll(proliferationEntities);

            logger.info("Bank added with id: {}", newBankEntity.getId());
            return newBankEntity.getId();

    }

    @Override
    public void updateBank(Bank bank) {
        logger.info("Updating bank with id: {}", bank.getId());

        Jwt jwt = (Jwt) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        BankEntity bankEntity = bankRepository.findById(bank.getId()).orElseThrow(() -> {
            logger.warn("Bank not found with id: {}", bank.getId());
            return new ResourceNotFoundException("Bank not found with id " + bank.getId());
        });
        bankMapper.updateBankEntityFromModel(bank, bankEntity);
        bankEntity.setLastModifiedBy(jwt.getClaimAsString("sub"));
        bankEntity.setLastModifiedDate(LocalDateTime.now());
        bankRepository.save(bankEntity);

        logger.info("Bank with id: {} updated successfully", bank.getId());
    }

    @Override
    public Map<String, Object> getBanksWithBranches(Integer bankId, Integer page, Integer size, String sort, String ifscCode) {
        logger.info("Fetching banks with branches - bankId: {}, page: {}, size: {}, sort: {}, ifscCode: {}",
                bankId, page, size, sort, ifscCode);

        // Determine search term based on provided parameters
        String searchTerm = null;
        if (!Objects.isNull(ifscCode) && !ifscCode.trim().isEmpty()) {
            searchTerm = ifscCode;
        }
        // Leverage the smartSearch method from SmartBranchSearchService
        return smartBranchSearchService.smartSearch(bankId, searchTerm, page, size, sort);
    }

    @Override
    public ResponseEntity<Resource> downloadBanksReport() {
        try {
            Page<BankDTO> bankDTOsPage = bankRepository.findAllBanks(Pageable.unpaged());
            List<BankDTO> banks = bankDTOsPage.getContent();

            ByteArrayResource resource = generateExcelResource(banks);

            String filename = "Banks_Report_" +
                    LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss")) + ".xlsx";

            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + filename)
                    .contentType(MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
                    .body(resource);

        } catch (Exception e) {
            throw new RuntimeException("Failed to generate banks report", e);
        }
    }

    private ByteArrayResource generateExcelResource(List<BankDTO> banks) throws IOException {
        try (Workbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("Banks Report");

            Row headerRow = sheet.createRow(0);
            CellStyle headerStyle = createHeaderStyle(workbook);

            String[] headers = {"Bank Name", "Ifsc", "Hosted", "Business", "Status"};

            for (int i = 0; i < headers.length; i++) {
                Cell cell = headerRow.createCell(i);
                cell.setCellValue(headers[i]);
                cell.setCellStyle(headerStyle);
                sheet.autoSizeColumn(i);
            }

            int rowNum = 1;
            CellStyle dataStyle = createDataStyle(workbook);

            for (BankDTO bank : banks) {
                Row row = sheet.createRow(rowNum++);

                createCell(row, 0, bank.getBankName(), dataStyle);
                createCell(row, 1, bank.getBankShortName(), dataStyle);
                createCell(row, 2, bank.getIsHostedOnCloud() ? "On Cloud" : "On Prem", dataStyle);
                createCell(row, 3, bank.getBusiness(), dataStyle);
                createCell(row, 4, bank.getIsActive() ? "Active" : "Inactive", dataStyle);
            }

            for (int i = 0; i < headers.length; i++) {
                sheet.autoSizeColumn(i);
            }

            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            workbook.write(outputStream);
            return new ByteArrayResource(outputStream.toByteArray());
        }
    }

    private void createCell(Row row, int column, String value, CellStyle style) {
        Cell cell = row.createCell(column);
        cell.setCellValue(value != null ? value : "");
        cell.setCellStyle(style);
    }

    private CellStyle createHeaderStyle(Workbook workbook) {
        CellStyle style = workbook.createCellStyle();

        style.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
        style.setFillPattern(FillPatternType.SOLID_FOREGROUND);

        style.setBorderBottom(BorderStyle.THIN);
        style.setBorderLeft(BorderStyle.THIN);
        style.setBorderRight(BorderStyle.THIN);
        style.setBorderTop(BorderStyle.THIN);

        Font font = workbook.createFont();
        font.setBold(true);
        style.setFont(font);

        style.setAlignment(HorizontalAlignment.CENTER);

        return style;
    }

    private CellStyle createDataStyle(Workbook workbook) {
        CellStyle style = workbook.createCellStyle();

        style.setBorderBottom(BorderStyle.THIN);
        style.setBorderLeft(BorderStyle.THIN);
        style.setBorderRight(BorderStyle.THIN);
        style.setBorderTop(BorderStyle.THIN);

        return style;
    }
}