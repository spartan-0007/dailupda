package in.iftas.sfms.core.service.impl;

import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;
import in.iftas.sfms.core.service.SftpClient;
import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Properties;

/**
 * JSch implementation of the SFTP client for dev and default profiles
 * Works with the existing Apache SSHD in-memory server
 */
@Service
@Profile({"dev", "default"})
@Primary
public class JschSftpClient implements SftpClient {
    private static final Logger logger = LoggerFactory.getLogger(JschSftpClient.class);

    @Value("${sftp.host}")
    private String sftpHost;

    @Value("${sftp.port}")
    private int sftpPort;

    @Value("${sftp.username}")
    private String sftpUsername;

    @Value("${sftp.password}")
    private String sftpPassword;

    @Value("${sftp.remote.dir}")
    private String sftpRemoteDir;

    @Override
    public void uploadFile(String filePath, InputStream inputStream) throws Exception {
        logger.info("Uploading file to SFTP: {}", filePath);
        Session session = null;
        ChannelSftp channelSftp = null;
        try {
            session = setupJschSession();
            session.connect();
            channelSftp = (ChannelSftp) session.openChannel("sftp");
            channelSftp.connect();
            channelSftp.cd(sftpRemoteDir);
            channelSftp.put(inputStream, filePath);
            logger.info("File uploaded successfully to SFTP: {}", filePath);
        } catch (Exception e) {
            logger.error("Error uploading file to SFTP: {}", filePath, e);
            throw e;
        } finally {
            closeResources(inputStream, channelSftp, session);
        }
    }

    @Override
    public InputStream downloadFile(String filePath) throws Exception {
        logger.info("Downloading file from SFTP: {}", filePath);
        Session session = null;
        ChannelSftp channelSftp = null;
        InputStream inputStream = null;
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        try {
            session = setupJschSession();
            session.connect();
            channelSftp = (ChannelSftp) session.openChannel("sftp");
            channelSftp.connect();
            channelSftp.cd(sftpRemoteDir);
            inputStream = channelSftp.get(filePath);
            IOUtils.copy(inputStream, outputStream);
            logger.info("File downloaded successfully from SFTP: {}", filePath);
            return new ByteArrayInputStream(outputStream.toByteArray());
        } catch (Exception e) {
            logger.error("Error downloading file from SFTP: {}", filePath, e);
            throw e;
        } finally {
            if (inputStream != null) {
                inputStream.close();
            }
            if (outputStream != null) {
                outputStream.close();
            }
            closeResources(null, channelSftp, session);
        }
    }

    @Override
    public boolean fileExists(String filePath, String originalFilename) throws Exception {
        logger.info("Checking if file exists on SFTP: {}", filePath + originalFilename);
        Session session = null;
        ChannelSftp channelSftp = null;
        try {
            session = setupJschSession();
            session.connect();
            channelSftp = (ChannelSftp) session.openChannel("sftp");
            channelSftp.connect();
            channelSftp.cd(sftpRemoteDir);

            try {
                List<ChannelSftp.LsEntry> files = (List<ChannelSftp.LsEntry>) channelSftp.ls(filePath + originalFilename);
                boolean exists = !files.isEmpty();
                logger.info("File exists: {}", exists);
                return exists;
            } catch (com.jcraft.jsch.SftpException e) {
                if (e.id == 2) {
                    logger.debug("File not found: {}", filePath + originalFilename);
                    return false;
                } else {
                    logger.error("SFTP error while checking if file exists: {}", filePath + originalFilename, e);
                    return false;
                }
            }
        } catch (Exception e) {
            logger.error("Error checking if file exists on SFTP: {}", filePath + originalFilename, e);
            return false;
        } finally {
            closeResources(null, channelSftp, session);
        }
    }

    @Override
    public void uploadWithBackup(String filePath, String originalFilename, InputStream inputStream) throws Exception {
        logger.info("Uploading file with backup to SFTP: {}", filePath + originalFilename);
        Session session = null;
        ChannelSftp channelSftp = null;
        try {
            session = setupJschSession();
            session.connect();
            channelSftp = (ChannelSftp) session.openChannel("sftp");
            channelSftp.connect();
            channelSftp.cd(sftpRemoteDir);

            if (fileExists(filePath, originalFilename)) {
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
                String timestamp = LocalDateTime.now().format(formatter);
                String[] originalFilenameStrings = originalFilename.split("\\.");
                
                // Create backup directory if it doesn't exist
                try {
                    channelSftp.mkdir(filePath + "backup/");
                } catch (Exception e) {
                    // Directory might already exist
                    logger.debug("Backup directory might already exist", e);
                }
                
                String backupFilePath = filePath + "backup/" + originalFilenameStrings[0] + "_"
                        + timestamp + "." + originalFilenameStrings[1];
                channelSftp.rename(filePath + originalFilename, backupFilePath);
                logger.info("Existing file moved to backup: {}", backupFilePath);
            }
            channelSftp.put(inputStream, filePath + originalFilename);
            logger.info("File uploaded successfully with backup to SFTP: {}", filePath + originalFilename);
        } catch (Exception e) {
            logger.error("Error uploading file with backup to SFTP: {}", filePath + originalFilename, e);
            throw e;
        } finally {
            closeResources(inputStream, channelSftp, session);
        }
    }

    private Session setupJschSession() throws Exception {
        JSch jsch = new JSch();
        Session session = jsch.getSession(sftpUsername, sftpHost, sftpPort);
        session.setPassword(sftpPassword);

        Properties config = new Properties();
        config.put("StrictHostKeyChecking", "no");
        session.setConfig(config);

        logger.info("JSch session setup complete for SFTP host: {}", sftpHost);
        return session;
    }
    
    private void closeResources(InputStream inputStream, ChannelSftp channelSftp, Session session) {
        try {
            if (inputStream != null) {
                inputStream.close();
            }
            if (channelSftp != null) {
                channelSftp.disconnect();
            }
            if (session != null) {
                session.disconnect();
            }
        } catch (Exception e) {
            logger.warn("Error closing SFTP resources", e);
        }
    }
}