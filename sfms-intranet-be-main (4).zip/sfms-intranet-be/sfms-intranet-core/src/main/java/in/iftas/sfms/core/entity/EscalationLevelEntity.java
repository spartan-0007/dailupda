package in.iftas.sfms.core.entity;

import jakarta.persistence.*;
import lombok.*;
import java.util.List;

@Entity
@Table(name = "i_escalation_levels", indexes = {
        @Index(name = "idx_level_dept_order", columnList = "department_id, level_order"),
        @Index(name = "idx_level_active", columnList = "is_active")
})
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class EscalationLevelEntity {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(name = "level_name", nullable = false)
    private String levelName;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "department_id", referencedColumnName = "id", nullable = false)
    private DepartmentEntity department;
    
    @Column(name = "level_order")
    @Builder.Default
    private Integer levelOrder = 1;
    
    @Column(name = "level_description", length = 500)
    private String levelDescription;
    
    @Column(name = "is_active")
    @Builder.Default
    private Boolean isActive = true;
    
    // Relationships
    @OneToMany(mappedBy = "level", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<EscalationContactEntity> contacts;
}