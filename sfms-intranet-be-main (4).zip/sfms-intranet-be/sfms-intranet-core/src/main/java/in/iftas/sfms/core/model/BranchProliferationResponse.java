package in.iftas.sfms.core.model;

import java.net.URI;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import org.openapitools.jackson.nullable.JsonNullable;
import java.time.OffsetDateTime;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


import java.util.*;
import jakarta.annotation.Generated;

/**
 * BranchProliferationResponse
 */


public class BranchProliferationResponse {

  private Integer bankId;

  private String branchId;

  private String branchDetails;

  public BranchProliferationResponse bankId(Integer bankId) {
    this.bankId = bankId;
    return this;
  }

  /**
   * Get bankId
   * @return bankId
   */
  
  @Schema(name = "bankId", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("bankId")
  public Integer getBankId() {
    return bankId;
  }

  public void setBankId(Integer bankId) {
    this.bankId = bankId;
  }

  public BranchProliferationResponse branchId(String branchId) {
    this.branchId = branchId;
    return this;
  }

  /**
   * Get branchId
   * @return branchId
   */
  
  @Schema(name = "branchId", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("branchId")
  public String getBranchId() {
    return branchId;
  }

  public void setBranchId(String branchId) {
    this.branchId = branchId;
  }

  public BranchProliferationResponse branchDetails(String branchDetails) {
    this.branchDetails = branchDetails;
    return this;
  }

  /**
   * Get branchDetails
   * @return branchDetails
   */
  
  @Schema(name = "branchDetails", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("branchDetails")
  public String getBranchDetails() {
    return branchDetails;
  }

  public void setBranchDetails(String branchDetails) {
    this.branchDetails = branchDetails;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    BranchProliferationResponse branchProliferationResponse = (BranchProliferationResponse) o;
    return Objects.equals(this.bankId, branchProliferationResponse.bankId) &&
        Objects.equals(this.branchId, branchProliferationResponse.branchId) &&
        Objects.equals(this.branchDetails, branchProliferationResponse.branchDetails);
  }

  @Override
  public int hashCode() {
    return Objects.hash(bankId, branchId, branchDetails);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BranchProliferationResponse {\n");
    sb.append("    bankId: ").append(toIndentedString(bankId)).append("\n");
    sb.append("    branchId: ").append(toIndentedString(branchId)).append("\n");
    sb.append("    branchDetails: ").append(toIndentedString(branchDetails)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

