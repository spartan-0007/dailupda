package in.iftas.sfms.core.model;

import java.net.URI;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import org.openapitools.jackson.nullable.JsonNullable;
import java.time.OffsetDateTime;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


import java.util.*;
import jakarta.annotation.Generated;

/**
 * RejectEscalationApproval
 */


public class RejectEscalationApproval {

  private String rejectionReason;

  private String comments;

  // Add a no-args constructor
  public RejectEscalationApproval() {

  }

  /**
   * Constructor with only required parameters
   */
  public RejectEscalationApproval(String rejectionReason) {
    this.rejectionReason = rejectionReason;
  }

  public RejectEscalationApproval rejectionReason(String rejectionReason) {
    this.rejectionReason = rejectionReason;
    return this;
  }

  /**
   * Reason for rejecting the escalation approval request
   * @return rejectionReason
   */
  @NotNull @Size(max = 500) 
  @Schema(name = "rejectionReason", example = "The provided contact information does not meet our security requirements", description = "Reason for rejecting the escalation approval request", requiredMode = Schema.RequiredMode.REQUIRED)
  @JsonProperty("rejectionReason")
  public String getRejectionReason() {
    return rejectionReason;
  }

  public void setRejectionReason(String rejectionReason) {
    this.rejectionReason = rejectionReason;
  }

  public RejectEscalationApproval comments(String comments) {
    this.comments = comments;
    return this;
  }

  /**
   * Additional comments (optional)
   * @return comments
   */
  @Size(max = 1000) 
  @Schema(name = "comments", example = "Please review the contact verification process and resubmit with proper documentation", description = "Additional comments (optional)", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("comments")
  public String getComments() {
    return comments;
  }

  public void setComments(String comments) {
    this.comments = comments;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    RejectEscalationApproval rejectEscalationApproval = (RejectEscalationApproval) o;
    return Objects.equals(this.rejectionReason, rejectEscalationApproval.rejectionReason) &&
        Objects.equals(this.comments, rejectEscalationApproval.comments);
  }

  @Override
  public int hashCode() {
    return Objects.hash(rejectionReason, comments);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class RejectEscalationApproval {\n");
    sb.append("    rejectionReason: ").append(toIndentedString(rejectionReason)).append("\n");
    sb.append("    comments: ").append(toIndentedString(comments)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

