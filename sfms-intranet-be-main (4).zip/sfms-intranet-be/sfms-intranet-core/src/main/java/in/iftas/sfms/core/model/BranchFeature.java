package in.iftas.sfms.core.model;

import java.net.URI;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;
import org.openapitools.jackson.nullable.JsonNullable;
import java.time.OffsetDateTime;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


import java.util.*;
import jakarta.annotation.Generated;

/**
 * BranchFeature
 */


public class BranchFeature {

  private Boolean neftEnabled;

  private Boolean rtgsEnabled;

  private Boolean lcEnabled;

  private Boolean bgEnabled;

  private Boolean others;

  private String createdBy;

  @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
  private Date createdDate;

  private String lastModifiedBy;

  @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
  private Date lastModifiedDate;

  public BranchFeature neftEnabled(Boolean neftEnabled) {
    this.neftEnabled = neftEnabled;
    return this;
  }

  /**
   * Get neftEnabled
   * @return neftEnabled
   */
  
  @Schema(name = "neftEnabled", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("neftEnabled")
  public Boolean getNeftEnabled() {
    return neftEnabled;
  }

  public void setNeftEnabled(Boolean neftEnabled) {
    this.neftEnabled = neftEnabled;
  }

  public BranchFeature rtgsEnabled(Boolean rtgsEnabled) {
    this.rtgsEnabled = rtgsEnabled;
    return this;
  }

  /**
   * Get rtgsEnabled
   * @return rtgsEnabled
   */
  
  @Schema(name = "rtgsEnabled", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("rtgsEnabled")
  public Boolean getRtgsEnabled() {
    return rtgsEnabled;
  }

  public void setRtgsEnabled(Boolean rtgsEnabled) {
    this.rtgsEnabled = rtgsEnabled;
  }

  public BranchFeature lcEnabled(Boolean lcEnabled) {
    this.lcEnabled = lcEnabled;
    return this;
  }

  /**
   * Get lcEnabled
   * @return lcEnabled
   */
  
  @Schema(name = "lcEnabled", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("lcEnabled")
  public Boolean getLcEnabled() {
    return lcEnabled;
  }

  public void setLcEnabled(Boolean lcEnabled) {
    this.lcEnabled = lcEnabled;
  }

  public BranchFeature bgEnabled(Boolean bgEnabled) {
    this.bgEnabled = bgEnabled;
    return this;
  }

  /**
   * Get bgEnabled
   * @return bgEnabled
   */
  
  @Schema(name = "bgEnabled", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("bgEnabled")
  public Boolean getBgEnabled() {
    return bgEnabled;
  }

  public void setBgEnabled(Boolean bgEnabled) {
    this.bgEnabled = bgEnabled;
  }

  public BranchFeature others(Boolean others) {
    this.others = others;
    return this;
  }

  /**
   * Get others
   * @return others
   */
  
  @Schema(name = "others", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("others")
  public Boolean getOthers() {
    return others;
  }

  public void setOthers(Boolean others) {
    this.others = others;
  }

  public BranchFeature createdBy(String createdBy) {
    this.createdBy = createdBy;
    return this;
  }

  /**
   * Get createdBy
   * @return createdBy
   */
  
  @Schema(name = "createdBy", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("createdBy")
  public String getCreatedBy() {
    return createdBy;
  }

  public void setCreatedBy(String createdBy) {
    this.createdBy = createdBy;
  }

  public BranchFeature createdDate(Date createdDate) {
    this.createdDate = createdDate;
    return this;
  }

  /**
   * Get createdDate
   * @return createdDate
   */
  @Valid 
  @Schema(name = "createdDate", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("createdDate")
  public Date getCreatedDate() {
    return createdDate;
  }

  public void setCreatedDate(Date createdDate) {
    this.createdDate = createdDate;
  }

  public BranchFeature lastModifiedBy(String lastModifiedBy) {
    this.lastModifiedBy = lastModifiedBy;
    return this;
  }

  /**
   * Get lastModifiedBy
   * @return lastModifiedBy
   */
  
  @Schema(name = "lastModifiedBy", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("lastModifiedBy")
  public String getLastModifiedBy() {
    return lastModifiedBy;
  }

  public void setLastModifiedBy(String lastModifiedBy) {
    this.lastModifiedBy = lastModifiedBy;
  }

  public BranchFeature lastModifiedDate(Date lastModifiedDate) {
    this.lastModifiedDate = lastModifiedDate;
    return this;
  }

  /**
   * Get lastModifiedDate
   * @return lastModifiedDate
   */
  @Valid 
  @Schema(name = "lastModifiedDate", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("lastModifiedDate")
  public Date getLastModifiedDate() {
    return lastModifiedDate;
  }

  public void setLastModifiedDate(Date lastModifiedDate) {
    this.lastModifiedDate = lastModifiedDate;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    BranchFeature branchFeature = (BranchFeature) o;
    return Objects.equals(this.neftEnabled, branchFeature.neftEnabled) &&
        Objects.equals(this.rtgsEnabled, branchFeature.rtgsEnabled) &&
        Objects.equals(this.lcEnabled, branchFeature.lcEnabled) &&
        Objects.equals(this.bgEnabled, branchFeature.bgEnabled) &&
        Objects.equals(this.others, branchFeature.others) &&
        Objects.equals(this.createdBy, branchFeature.createdBy) &&
        Objects.equals(this.createdDate, branchFeature.createdDate) &&
        Objects.equals(this.lastModifiedBy, branchFeature.lastModifiedBy) &&
        Objects.equals(this.lastModifiedDate, branchFeature.lastModifiedDate);
  }

  @Override
  public int hashCode() {
    return Objects.hash(neftEnabled, rtgsEnabled, lcEnabled, bgEnabled, others, createdBy, createdDate, lastModifiedBy, lastModifiedDate);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BranchFeature {\n");
    sb.append("    neftEnabled: ").append(toIndentedString(neftEnabled)).append("\n");
    sb.append("    rtgsEnabled: ").append(toIndentedString(rtgsEnabled)).append("\n");
    sb.append("    lcEnabled: ").append(toIndentedString(lcEnabled)).append("\n");
    sb.append("    bgEnabled: ").append(toIndentedString(bgEnabled)).append("\n");
    sb.append("    others: ").append(toIndentedString(others)).append("\n");
    sb.append("    createdBy: ").append(toIndentedString(createdBy)).append("\n");
    sb.append("    createdDate: ").append(toIndentedString(createdDate)).append("\n");
    sb.append("    lastModifiedBy: ").append(toIndentedString(lastModifiedBy)).append("\n");
    sb.append("    lastModifiedDate: ").append(toIndentedString(lastModifiedDate)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

