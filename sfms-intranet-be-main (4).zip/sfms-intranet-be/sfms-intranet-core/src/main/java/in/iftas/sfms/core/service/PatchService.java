package in.iftas.sfms.core.service;

/*
 * Copyright (C) 2024 Iftas Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Iftas Inc. ("Confidential Information"). You shall not disclose
 * such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with Iftas Inc.
 *
 * Author: Manoj.Illa
 * Date: July 11, 2024
 */

import com.fasterxml.jackson.databind.ObjectMapper;
import in.iftas.sfms.core.dto.PatchAccessDTO;
import in.iftas.sfms.core.entity.*;
import in.iftas.sfms.core.exception.AccessDeniedException;
import in.iftas.sfms.core.exception.PatchNotFoundException;
import in.iftas.sfms.core.exception.ResourceNotFoundException;
import in.iftas.sfms.core.mapper.PatchMapper;
import in.iftas.sfms.core.model.*;
import in.iftas.sfms.core.repository.BankRepository;
import in.iftas.sfms.core.repository.DownloadLogRepository;
import in.iftas.sfms.core.repository.ReleaseAccessRepository;
import in.iftas.sfms.core.repository.ReleaseDetailsRepository;
import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class PatchService {

    private static final Logger logger = LoggerFactory.getLogger(PatchService.class);

    private final SftpService sftpService;

    private final ReleaseDetailsRepository releaseDetailsRepository;

    private final ObjectMapper objectMapper;

    private final DownloadLogRepository downloadLogRepository;

    private final ReleaseAccessRepository releaseAccessRepository;

    private final PatchMapper patchMapper;

    private final BankRepository bankRepository;

    public PatchService(SftpService sftpService, ReleaseDetailsRepository releaseDetailsRepository,
                        ObjectMapper objectMapper, DownloadLogRepository downloadLogRepository,
                        ReleaseAccessRepository releaseAccessRepository, PatchMapper patchMapper, BankRepository bankRepository) {
        this.sftpService = sftpService;
        this.releaseDetailsRepository = releaseDetailsRepository;
        this.objectMapper = objectMapper;
        this.downloadLogRepository = downloadLogRepository;
        this.releaseAccessRepository = releaseAccessRepository;
        this.patchMapper = patchMapper;
        this.bankRepository = bankRepository;
    }


    public GetPatches200Response getPatches(int page, int size) {

        logger.info("Fetching patches for page: {}, size: {}", page, size);
        PageRequest pageRequest = PageRequest.of(page - 1, size);
        Jwt jwt = (Jwt) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        String userType = jwt.getClaimAsString("userType");
        Page<ReleaseDetailsEntity> releasePage;

        if ("BANKER".equals(userType)) {
            Long bankId = Long.parseLong(jwt.getClaimAsString("bankId"));
            releasePage = releaseDetailsRepository.findByBankId(bankId, pageRequest);
        } else {
            releasePage = releaseDetailsRepository.findAllByOrderByUploadedDateDesc(pageRequest);
        }

        List<PatchDetails> patchDetailsList = patchMapper.toPatchDetailsList(releasePage.getContent());

        GetPatches200Response response = new GetPatches200Response();
        response.setPatches(patchDetailsList);
        response.setCurrentPage(releasePage.getNumber() + 1); // +1 to adjust to 1-based index
        response.setTotalPages(releasePage.getTotalPages());

        logger.info("Fetched {} patches", patchDetailsList.size());
        return response;
    }

    @Transactional
    public void uploadPatch(MultipartFile file, String detailsJson) throws IOException {
        logger.info("Uploading patch with details: {}", detailsJson);
        PatchUploadRequest patchUploadRequest = objectMapper.readValue(detailsJson, PatchUploadRequest.class);
        Jwt jwt = (Jwt) SecurityContextHolder.getContext().getAuthentication().getPrincipal();

        if (file != null && !releaseDetailsRepository.existsByFileName(file.getOriginalFilename())) {
            try {
                String sftpPath = uploadFileToSftp(file);
                ReleaseDetailsEntity releaseDetails = new ReleaseDetailsEntity();
                releaseDetails.setFileName(file.getOriginalFilename());
                releaseDetails.setVersion(patchUploadRequest.getVersion());
                releaseDetails.setDescription(patchUploadRequest.getDescription());
                releaseDetails.setUploadedBy(jwt.getClaimAsString("sub"));
                releaseDetails.setUploadedDate(LocalDateTime.now());
                releaseDetails.setSftpPath(sftpPath);
                releaseDetails.setFileSize(file.getSize());

                for (Long bankId : patchUploadRequest.getBankIds()) {
                    ReleaseAccessEntity accessEntity = new ReleaseAccessEntity();
                    accessEntity.setBankId(bankId);
                    accessEntity.setAccessGrantedDate(LocalDateTime.now());
                    accessEntity.setAccessRevoked(false);
                    releaseDetails.addReleaseAccess(accessEntity);
                }

                releaseDetailsRepository.save(releaseDetails);
                logger.info("Patch uploaded successfully: {}", file.getOriginalFilename());
            } catch (Exception e) {
                logger.error("Failed to upload the file to SFTP.", e);
                throw new RuntimeException("Failed to upload the file to SFTP.", e);
            }
        } else {
            logger.warn("File already exists or is null: {}", file != null ? file.getOriginalFilename() : "null");
            throw new RuntimeException("File already exists or is null");
        }
    }

    @Transactional
    public void uploadPatchApproved(String requestData, String entityId) throws IOException {
        logger.info("Uploading patch with details: {}", requestData);
        ReleaseDetailsEntity releaseDetailsEntity = objectMapper.readValue(requestData, ReleaseDetailsEntity.class);
        Jwt jwt = (Jwt) SecurityContextHolder.getContext().getAuthentication().getPrincipal();

        if (releaseDetailsEntity != null && !releaseDetailsRepository.existsByFileName(releaseDetailsEntity.getFileName())) {
            try {
                ReleaseDetailsEntity releaseDetails = new ReleaseDetailsEntity();
                releaseDetails.setFileName(releaseDetailsEntity.getFileName());
                releaseDetails.setVersion(releaseDetailsEntity.getVersion());
                releaseDetails.setDescription(releaseDetailsEntity.getDescription());
                releaseDetails.setUploadedBy(entityId);
                releaseDetails.setUploadedDate(LocalDateTime.now());
                releaseDetails.setSftpPath(releaseDetailsEntity.getSftpPath());
                releaseDetails.setFileSize(releaseDetailsEntity.getFileSize());

                if (releaseDetailsEntity.getReleaseAccessEntities() != null) {
                    for (ReleaseAccessEntity accessEntityData : releaseDetailsEntity.getReleaseAccessEntities()) {
                        ReleaseAccessEntity accessEntity = new ReleaseAccessEntity();
                        accessEntity.setBankId(accessEntityData.getBankId());
                        accessEntity.setAccessGrantedDate(LocalDateTime.now());
                        accessEntity.setAccessRevoked(false);
                        releaseDetails.addReleaseAccess(accessEntity);
                    }
                }

                releaseDetailsRepository.save(releaseDetails);
                logger.info("Patch uploaded successfully: {}", releaseDetailsEntity.getFileName());
            } catch (Exception e) {
                logger.error("Failed to upload the file to SFTP.", e);
                throw new RuntimeException("Failed to upload the file to SFTP.", e);
            }
        } else {
            logger.warn("File already exists or is null: {}", releaseDetailsEntity != null ? releaseDetailsEntity.getFileName() : "null");
            throw new RuntimeException("File already exists or is null");
        }
    }

    private String uploadFileToSftp(MultipartFile file) throws Exception {
        String sftpPath = "/files/releases/" + file.getOriginalFilename();
        try (InputStream inputStream = file.getInputStream()) {
            sftpService.uploadFile(sftpPath, inputStream);
            logger.info("File uploaded to SFTP: {}", sftpPath);
        }
        return sftpPath;
    }

    public GetPatchDownloadLog200Response getPatchDownloadLog(Long patchId) {
        logger.info("Fetching download logs for patch ID: {}", patchId);
        List<DownloadLog> downloadLogs = downloadLogRepository.findByPatchId(patchId);

        if (downloadLogs.isEmpty()) {
            logger.warn("No downloads found for patch ID: {}", patchId);
            throw new PatchNotFoundException("No downloads found for patch ID: " + patchId);
        }

        GetPatchDownloadLog200Response response = new GetPatchDownloadLog200Response();
        response.setPatchId(patchId);
        response.setDownloadLog(downloadLogs);

        logger.info("Fetched {} download logs for patch ID: {}", downloadLogs.size(), patchId);
        return response;
    }

    @Transactional
    public Resource downloadPatchFile(Long patchId) throws PatchNotFoundException, AccessDeniedException, RuntimeException {
        Jwt jwt = (Jwt) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        String userType = jwt.getClaimAsString("userType");
        Long bankId = null;
        if ("BANKER".equals(userType)) {
            bankId = Long.parseLong(jwt.getClaimAsString("bankId"));
            Optional<ReleaseAccessEntity> accessEntityOptional = releaseAccessRepository.findAccessByPatchIdAndBankId(patchId, bankId);

            if (accessEntityOptional.isEmpty()) {
                logger.error("Bank with ID {} does not have access to patch {}", bankId, patchId);
                throw new AccessDeniedException("Bank with ID " + bankId + " does not have access to patch " + patchId);
            }
        }
        String downloadedBy = jwt.getClaimAsString("sub");
        logger.info("Downloading patch file for patch ID: {}, bank ID: {}", patchId, bankId);
        Optional<ReleaseDetailsEntity> patchEntityOptional = releaseDetailsRepository.findById(patchId);

        if (patchEntityOptional.isEmpty()) {
            logger.error("Patch with ID {} not found.", patchId);
            throw new PatchNotFoundException("Patch with ID " + patchId + " not found.");
        }
        ReleaseDetailsEntity patchEntity = patchEntityOptional.get();
        String sftpPath = patchEntity.getSftpPath();

        try {
            InputStream fileStream = sftpService.downloadFile(sftpPath);
            logDownloadDetails(patchEntity, bankId, downloadedBy);

            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            IOUtils.copy(fileStream, outputStream);
            ByteArrayInputStream inputStream = new ByteArrayInputStream(outputStream.toByteArray());

            logger.info("Patch file downloaded successfully for patch ID: {}, bank ID: {}", patchId, bankId);
            return new ByteArrayResource(inputStream.readAllBytes());
        } catch (Exception e) {
            logger.error("Error downloading file from SFTP server: {}", sftpPath, e);
            throw new RuntimeException("Error downloading file from SFTP server: " + sftpPath, e);
        }
    }

    private void logDownloadDetails(ReleaseDetailsEntity patchEntity, Long bankId, String downloadedBy) {
        logger.info("Logging download details for patch ID: {}, bank ID: {}", patchEntity.getId(), bankId);
        ReleaseDownloadLogEntity.ReleaseDownloadLogEntityBuilder logBuilder = ReleaseDownloadLogEntity.builder()
                .releaseDetails(patchEntity)
                .downloadedBy(downloadedBy)
                .downloadedDate(LocalDateTime.now());

        if (bankId != null) {
            logBuilder.bankId(bankId);
        }
        logBuilder.bankId(0L);

        ReleaseDownloadLogEntity downloadLog = logBuilder.build();
        downloadLogRepository.save(downloadLog);
        logger.info("Download details logged successfully for patch ID: {}, bank ID: {}", patchEntity.getId(), bankId);
    }

    public PatchAccessDTO getBanksWithAccess(Long patchId) {
        logger.info("Fetching bank access for patchId: {}", patchId);

        ReleaseDetailsEntity releaseDetails = releaseDetailsRepository.findById(patchId)
                .orElseThrow(() -> new PatchNotFoundException("Patch not found"));

        List<ReleaseAccessEntity> accessEntities = releaseAccessRepository.findByReleaseDetails_Id(patchId);
        if (accessEntities.isEmpty()) {
            logger.warn("No access entities found for patchId: {}", patchId);
        } else {
            logger.info("Found {} access entities for patchId: {}", accessEntities.size(), patchId);
        }

        Map<Long, ReleaseAccessEntity> accessMap = accessEntities.stream()
                .collect(Collectors.toMap(ReleaseAccessEntity::getBankId, accessEntity -> accessEntity));

        Set<Long> bankIds = accessMap.keySet();

        logger.info("Extracted unique bank IDs: {}", bankIds);

        List<BankEntity> banks = bankRepository.findByIdIn(bankIds);
        if (banks.isEmpty()) {
            logger.warn("No banks found for the extracted bank IDs: {}", bankIds);

        }

        logger.info("Found {} banks for the extracted bank IDs", banks.size());

        List<BankAccess> bankAccessList = banks.stream()
                .map(bank -> {
                    BankAccess bankAccess = new BankAccess();
                    bankAccess.setBankId(bank.getId().intValue());
                    bankAccess.setBankName(bank.getBankName());

                    ReleaseAccessEntity releaseAccess = accessMap.get(bank.getId());

                    if (releaseAccess != null) {
                        Date grantedDate = Date.from(releaseAccess.getAccessGrantedDate().atZone(ZoneId.systemDefault()).toInstant());
                        bankAccess.setAccessGrantedDate(grantedDate);
                        bankAccess.setAccessRevoked(releaseAccess.getAccessRevoked());
                    }

                    return bankAccess;
                })
                .collect(Collectors.toList());

        PatchAccessDTO response = new PatchAccessDTO();
        response.setPatchId(releaseDetails.getId());
        response.setFileName(releaseDetails.getFileName());
        response.setVersion(releaseDetails.getVersion());
        response.setUploadedBy(releaseDetails.getUploadedBy());
        response.setUploadedDate(releaseDetails.getUploadedDate());
        response.setBanksWithAccess(bankAccessList);

        logger.info("Extracted bank names: {}", response);

        return response;
    }

    public void deletePatchByID(Long id) {
        logger.info("Entering deletePatchByID with id: {}", id);

        if (releaseDetailsRepository.existsById(id)) {
            logger.info("Patch with id: {}, proceeding to delete", id);

            releaseDetailsRepository.deleteById(id);
            logger.info("Release Patch deleted successfully with id: {}", id);

        } else {
            logger.warn("Release Patch not found with id: {}", id);

            throw new ResourceNotFoundException("Release Patch found with id " + id);
        }
        logger.info("Exiting deletePatchByID Patch");

    }

    public void updatePatchApproval(Long patchId, String requestData) throws IOException {
        logger.info("Entering updatePatchApproval with ID: " + patchId);

        ReleaseDetailsEntity updatedDetailsEntity = objectMapper.readValue(requestData, ReleaseDetailsEntity.class);

        ReleaseDetailsEntity patchDetails = releaseDetailsRepository.findById(patchId)
                .orElseThrow(() -> {
                    logger.error("Patch with ID " + patchId + " not found.");
                    return new ResourceNotFoundException("Patch with ID " + patchId + " not found.");
                });

        Optional.ofNullable(updatedDetailsEntity.getDescription())
                .ifPresent(description -> {
                    logger.info("Updating description to: " + description);
                    patchDetails.setDescription(description);
                });

        Optional.ofNullable(updatedDetailsEntity.getVersion())
                .ifPresent(version -> {
                    logger.info("Updating version to: " + version);
                    patchDetails.setVersion(version);
                });

        if (updatedDetailsEntity.getReleaseAccessEntities() != null) {
            List<Long> updatedBankIds = updatedDetailsEntity.getReleaseAccessEntities().stream()
                    .map(ReleaseAccessEntity::getBankId)
                    .collect(Collectors.toList());

            updatedBankIds.forEach(bankId -> {
                if (patchDetails.getReleaseAccessEntities().stream().noneMatch(access -> access.getBankId().equals(bankId))) {
                    ReleaseAccessEntity accessEntity = new ReleaseAccessEntity();
                    accessEntity.setBankId(bankId);
                    accessEntity.setAccessGrantedDate(LocalDateTime.now());
                    accessEntity.setAccessRevoked(false);
                    patchDetails.addReleaseAccess(accessEntity);
                    logger.info("Added new bank ID: " + bankId);
                }
            });

            patchDetails.getReleaseAccessEntities().removeIf(access -> {
                boolean shouldRemove = !updatedBankIds.contains(access.getBankId());
                if (shouldRemove) {
                    access.setReleaseDetails(null);
                    logger.info("Removed bank ID: " + access.getBankId());
                }
                return shouldRemove;
            });
        }

        releaseDetailsRepository.save(patchDetails);
        logger.info("Patch with ID " + patchId + " updated successfully.");
    }


    public void updatePatch(Long patchId, PatchUploadRequest patchUploadRequest) {

        logger.info("Entering updatePatch with ID: " + patchId);

        // Fetch the existing patch details from the repository
        ReleaseDetailsEntity patchDetails = releaseDetailsRepository.findById(patchId)
                .orElseThrow(() -> {
                    logger.error("Patch with ID " + patchId + " not found.");
                    return new ResourceNotFoundException("Patch with ID " + patchId + " not found.");
                });

        // Update the description if provided
        Optional.ofNullable(patchUploadRequest.getDescription())
                .ifPresent(description -> {
                    logger.info("Updating description to: " + description);
                    patchDetails.setDescription(description);
                });

        if (patchUploadRequest.getBankIds() != null) {

            patchUploadRequest.getBankIds().forEach(bankId -> {
                if (patchDetails.getReleaseAccessEntities().stream().noneMatch(access -> access.getBankId().equals(bankId))) {
                    ReleaseAccessEntity accessEntity = new ReleaseAccessEntity();
                    accessEntity.setBankId(bankId);
                    accessEntity.setAccessGrantedDate(LocalDateTime.now());
                    accessEntity.setAccessRevoked(false);
                    patchDetails.addReleaseAccess(accessEntity);
                    logger.info("Added new bank ID: " + bankId);
                }
            });

            patchDetails.getReleaseAccessEntities().removeIf(access -> {
                boolean shouldRemove = !patchUploadRequest.getBankIds().contains(access.getBankId());
                if (shouldRemove) {
                    access.setReleaseDetails(null);
                    logger.info("Removed bank ID: " + access.getBankId());
                }
                return shouldRemove;
            });
        }

        // Save the updated patch details back to the repository
        releaseDetailsRepository.save(patchDetails);
        logger.info("Patch with ID " + patchId + " updated successfully.");
    }
}