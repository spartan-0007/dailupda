package in.iftas.sfms.core.api.impl;

import in.iftas.sfms.core.api.EscalationApprovalsApi;
import in.iftas.sfms.core.exception.DuplicateEntryException;
import in.iftas.sfms.core.model.*;
import in.iftas.sfms.core.service.EscalationApprovalService;
import jakarta.persistence.EntityNotFoundException;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.service.spi.ServiceException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@RestController
@Slf4j
public class EscalationApprovalApiImpl implements EscalationApprovalsApi {
    private static final Logger logger = LoggerFactory.getLogger(EscalationApprovalApiImpl.class);

    private final EscalationApprovalService escalationApprovalService;

    @Autowired
    public EscalationApprovalApiImpl(EscalationApprovalService escalationApprovalService) {
        this.escalationApprovalService = escalationApprovalService;
    }

    @Override
    public ResponseEntity<ModelApiResponse> escalationApprovalsPost(EscalationContact escalationContact) {
        logger.info("Creating new escalation contact approval request");

        try {
            escalationApprovalService.createApproval(escalationContact);

            ModelApiResponse response = new ModelApiResponse();
            response.setSuccess(true);
            response.setMessage("Escalation approval request created successfully");

            return ResponseEntity.status(HttpStatus.CREATED).body(response);
        } catch (IllegalArgumentException e) {
            logger.error("Bad request when creating escalation contact approval: {}", e.getMessage(), e);

            ApiResponseError error = new ApiResponseError();
            error.setCode("400");
            error.setMessage(e.getMessage());

            ModelApiResponse response = new ModelApiResponse();
            response.setSuccess(false);
            response.setError(error);

            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
        } catch (IllegalStateException e) {
            logger.error("Conflict when creating escalation contact approval: {}", e.getMessage(), e);

            ApiResponseError error = new ApiResponseError();
            error.setCode("409");
            error.setMessage(e.getMessage());

            ModelApiResponse response = new ModelApiResponse();
            response.setSuccess(false);
            response.setError(error);

            return ResponseEntity.status(HttpStatus.CONFLICT).body(response);
        } catch (DuplicateEntryException e) {
            logger.error("Duplicate entry found: {}", e.getMessage(), e);

            ApiResponseError error = new ApiResponseError();
            error.setCode("409");
            error.setMessage(e.getMessage());

            ModelApiResponse response = new ModelApiResponse();
            response.setSuccess(false);
            response.setError(error);

            return ResponseEntity.status(HttpStatus.CONFLICT).body(response);
        } catch (Exception e) {
            logger.error("Error creating escalation contact approval: {}", e.getMessage(), e);

            ApiResponseError error = new ApiResponseError();
            error.setCode("500");
            error.setMessage("An unexpected error occurred while processing your request");

            ModelApiResponse response = new ModelApiResponse();
            response.setSuccess(false);
            response.setError(error);

            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    public ResponseEntity<EscalationApproval> escalationApprovalsIdDelete(Long escalationApprovalId) {
        try {
            if (escalationApprovalId == null) {
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Escalation approval ID cannot be null");
            }

            escalationApprovalService.deleteEscalationApproval(escalationApprovalId);
            return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
        } catch (EntityNotFoundException e) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND,
                    "Escalation approval not found with ID: " + escalationApprovalId, e);
        } catch (DataAccessException e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                    "Database error while deleting escalation approval: " + e.getMessage(), e);
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unexpected error occurred: " + e.getMessage(), e);
        }
    }

    @Override
    public ResponseEntity<ModelApiResponse> escalationApprovalsGet() {
        try {
            List<EscalationApproval> approvals = escalationApprovalService.getAllApprovalslist();

            ModelApiResponse response = new ModelApiResponse()
                    .success(true)
                    .message("Successfully retrieved all escalation approvals")
                    .putItem("approvals", approvals);

            return ResponseEntity.ok(response);

        } catch (IllegalArgumentException e) {
            logger.error("Bad request when fetching escalation approvals: {}", e.getMessage(), e);

            ApiResponseError error = new ApiResponseError()
                    .code("400")
                    .message(e.getMessage());

            ModelApiResponse response = new ModelApiResponse()
                    .success(false)
                    .message("Failed to retrieve escalation approvals")
                    .error(error);

            return ResponseEntity
                    .status(HttpStatus.BAD_REQUEST)
                    .body(response);

        } catch (IllegalStateException e) {
            logger.error("Conflict when fetching escalation approvals: {}", e.getMessage(), e);

            ApiResponseError error = new ApiResponseError()
                    .code("409")
                    .message(e.getMessage());

            ModelApiResponse response = new ModelApiResponse()
                    .success(false)
                    .message("Conflict occurred while retrieving escalation approvals")
                    .error(error);

            return ResponseEntity
                    .status(HttpStatus.CONFLICT)
                    .body(response);

        } catch (ServiceException e) {
            logger.error("Service error when fetching escalation approvals: {}", e.getMessage(), e);

            ApiResponseError error = new ApiResponseError()
                    .code("500")
                    .message("An error occurred while processing your request");

            ModelApiResponse response = new ModelApiResponse()
                    .success(false)
                    .message("Service error occurred while retrieving escalation approvals")
                    .error(error);

            return ResponseEntity
                    .status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(response);

        } catch (Exception e) {
            logger.error("Unexpected error fetching escalation approvals: {}", e.getMessage(), e);

            ApiResponseError error = new ApiResponseError()
                    .code("500")
                    .message("An unexpected error occurred while processing your request");

            ModelApiResponse response = new ModelApiResponse()
                    .success(false)
                    .message("Unexpected error occurred while retrieving escalation approvals")
                    .error(error);

            return ResponseEntity
                    .status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(response);
        }
    }
    public ResponseEntity<ModelApiResponse> escalationApprovalsIdApprovePost(@PathVariable("id") Long id) {
        try {
            escalationApprovalService.approveEscalation(id);

            ModelApiResponse response = new ModelApiResponse();
            response.setSuccess(true);
            response.setMessage("Escalation approval request approved successfully");

            return ResponseEntity.ok(response);
        } catch (EntityNotFoundException e) {
            logger.error("Escalation approval not found: {}", e.getMessage());

            ApiResponseError error = new ApiResponseError();
            error.setCode("404");
            error.setMessage(e.getMessage());

            ModelApiResponse response = new ModelApiResponse();
            response.setSuccess(false);
            response.setError(error);

            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
        } catch (SecurityException e) {
            logger.error("Unauthorized approval attempt: {}", e.getMessage());

            ApiResponseError error = new ApiResponseError();
            error.setCode("403");
            error.setMessage(e.getMessage());

            ModelApiResponse response = new ModelApiResponse();
            response.setSuccess(false);
            response.setError(error);

            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(response);
        } catch (IllegalArgumentException e) {
            logger.error("Invalid approval request: {}", e.getMessage());

            ApiResponseError error = new ApiResponseError();
            error.setCode("400");
            error.setMessage(e.getMessage());

            ModelApiResponse response = new ModelApiResponse();
            response.setSuccess(false);
            response.setError(error);

            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
        } catch (Exception e) {
            logger.error("Error approving escalation: {}", e.getMessage(), e);

            ApiResponseError error = new ApiResponseError();
            error.setCode("500");
            error.setMessage("An unexpected error occurred while processing your request");

            ModelApiResponse response = new ModelApiResponse();
            response.setSuccess(false);
            response.setError(error);

            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    public ResponseEntity<ModelApiResponse> escalationApprovalsIdRejectPost(Long id, RejectEscalationApproval rejectEscalationApproval) {
        try {
            escalationApprovalService.rejectEscalation(id,rejectEscalationApproval);

            ModelApiResponse response = new ModelApiResponse();
            response.setSuccess(true);
            response.setMessage("Escalation approval request approved successfully");

            return ResponseEntity.ok(response);
        } catch (EntityNotFoundException e) {
            logger.error("Escalation approval not found: {}", e.getMessage());

            ApiResponseError error = new ApiResponseError();
            error.setCode("404");
            error.setMessage(e.getMessage());

            ModelApiResponse response = new ModelApiResponse();
            response.setSuccess(false);
            response.setError(error);

            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
        } catch (SecurityException e) {
            logger.error("Unauthorized approval attempt: {}", e.getMessage());

            ApiResponseError error = new ApiResponseError();
            error.setCode("403");
            error.setMessage(e.getMessage());

            ModelApiResponse response = new ModelApiResponse();
            response.setSuccess(false);
            response.setError(error);

            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(response);
        } catch (IllegalArgumentException e) {
            logger.error("Invalid approval request: {}", e.getMessage());

            ApiResponseError error = new ApiResponseError();
            error.setCode("400");
            error.setMessage(e.getMessage());

            ModelApiResponse response = new ModelApiResponse();
            response.setSuccess(false);
            response.setError(error);

            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
        } catch (Exception e) {
            logger.error("Error approving escalation: {}", e.getMessage(), e);

            ApiResponseError error = new ApiResponseError();
            error.setCode("500");
            error.setMessage("An unexpected error occurred while processing your request");

            ModelApiResponse response = new ModelApiResponse();
            response.setSuccess(false);
            response.setError(error);

            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

}

