package in.iftas.sfms.core.dto;

import lombok.*;

@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class BankMessageCountDTO {

    private String bankName;
    private Long messageCount;
    private Long bankId;

    public BankMessageCountDTO(Long bankId, String bankName, Long messageCount) {
        this.bankId = bankId;
        this.bankName = bankName;
        this.messageCount = messageCount;
    }

}
