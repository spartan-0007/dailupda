package in.iftas.sfms.core.api.impl;

/*
 * Copyright (C) 2024 Iftas Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Iftas Inc. ("Confidential Information"). You shall not disclose
 * such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with Iftas Inc.
 *
 * Author: Manoj.Illa
 * Date: July 11, 2024
 */

import in.iftas.sfms.core.api.CrlFilesApi;
import in.iftas.sfms.core.model.*;
import in.iftas.sfms.core.service.CrlFileService;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.ValidationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.util.HashMap;
import java.util.List;

@RestController
public class CrlFilesApiImpl implements CrlFilesApi {

    private static final Logger logger = LoggerFactory.getLogger(CrlFilesApiImpl.class);

    private final CrlFileService crlFileService;

    public CrlFilesApiImpl(CrlFileService crlFileService) {
        this.crlFileService = crlFileService;
    }

    @Override
    public ResponseEntity<UploadCRLFile201Response> uploadCRLFile(MultipartFile file) {
        logger.info("Entering uploadCRLFile with CRLFileDetails:");
        try {
          // crlFileService.uploadCrlFile(crlFileDetails);
            logger.info("CRL file uploaded successfully.");

            //Chance the reponse to ModelApiResponse
            UploadCRLFile201Response response = new UploadCRLFile201Response();
            response.setMessage("CRL File Uploaded Successfully!");

            logger.info("Returning response with status CREATED.");
            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch (ValidationException ve) {
            logger.error("Validation error: {}", ve.getMessage());
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        } catch (Exception ex) {
            logger.error("Internal server error: {}", ex.getMessage());
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    @Override

    public ResponseEntity<GetCRLFiles200Response> getCRLFiles() {
        List<CRLFileDetails> crlFileDetails = crlFileService.getCrlFiles();
        GetCRLFiles200Response getCRLFiles200Response = new GetCRLFiles200Response();
        getCRLFiles200Response.setFiles(crlFileDetails);
        return ResponseEntity.status(HttpStatusCode.valueOf(200)).body(getCRLFiles200Response);
    }

    @Override
    public ResponseEntity<Resource> downloadCRLFileById(String fileName) {
        logger.info("Entering downloadCRLFileById method with fileName: {}", fileName);


        Resource downloadCgbsFile = crlFileService.downloadCrlFile(fileName);

        logger.info("Returning CRL file for download: {}", fileName);
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + fileName + "\"")
                .header(HttpHeaders.CONTENT_TYPE, "application/zip")
                .body(downloadCgbsFile);
    }


    @Override
    public ResponseEntity<ModelApiResponse> crlFilesIdDelete(Long id) {
        logger.info("Received request to delete CRL file with id: {}", id);

        ModelApiResponse apiResponse = new ModelApiResponse();

        try {
            crlFileService.deleteCrlFile(id.intValue());
            apiResponse.setSuccess(true);
            apiResponse.setMessage("CGBS file deleted successfully.");
            apiResponse.setData(new HashMap<>());
            return ResponseEntity.ok(apiResponse);
        } catch (Exception e) {
            logger.error("Error while deleting CGBS file: {}", e.getMessage(), e);
            apiResponse.setSuccess(false);
            apiResponse.setMessage("An error occurred while deleting the CGBS file.");
            ApiResponseError error = new ApiResponseError();
            error.setCode("500");
            error.setMessage("Internal Server Error: " + e.getMessage());
            apiResponse.setError(error);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(apiResponse);
        }
    }
}
