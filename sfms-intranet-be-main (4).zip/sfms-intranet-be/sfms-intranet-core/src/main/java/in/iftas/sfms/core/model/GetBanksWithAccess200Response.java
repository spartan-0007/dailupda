package in.iftas.sfms.core.model;

import java.net.URI;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonTypeName;
import in.iftas.sfms.core.model.BankAccess;
import java.util.ArrayList;
import java.util.List;
import org.openapitools.jackson.nullable.JsonNullable;
import java.time.OffsetDateTime;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


import java.util.*;
import jakarta.annotation.Generated;

/**
 * GetBanksWithAccess200Response
 */

@JsonTypeName("getBanksWithAccess_200_response")

public class GetBanksWithAccess200Response {

  private Long patchId;

  private String fileName;

  private String version;

  private String uploadedBy;

  private String uploadedDate;

  @Valid
  private List<@Valid BankAccess> banksWithAccess;

  public GetBanksWithAccess200Response patchId(Long patchId) {
    this.patchId = patchId;
    return this;
  }

  /**
   * Get patchId
   * @return patchId
   */
  
  @Schema(name = "patchId", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("patchId")
  public Long getPatchId() {
    return patchId;
  }

  public void setPatchId(Long patchId) {
    this.patchId = patchId;
  }

  public GetBanksWithAccess200Response fileName(String fileName) {
    this.fileName = fileName;
    return this;
  }

  /**
   * Get fileName
   * @return fileName
   */
  
  @Schema(name = "fileName", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("fileName")
  public String getFileName() {
    return fileName;
  }

  public void setFileName(String fileName) {
    this.fileName = fileName;
  }

  public GetBanksWithAccess200Response version(String version) {
    this.version = version;
    return this;
  }

  /**
   * Get version
   * @return version
   */
  
  @Schema(name = "version", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("version")
  public String getVersion() {
    return version;
  }

  public void setVersion(String version) {
    this.version = version;
  }

  public GetBanksWithAccess200Response uploadedBy(String uploadedBy) {
    this.uploadedBy = uploadedBy;
    return this;
  }

  /**
   * Get uploadedBy
   * @return uploadedBy
   */
  
  @Schema(name = "uploadedBy", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("uploadedBy")
  public String getUploadedBy() {
    return uploadedBy;
  }

  public void setUploadedBy(String uploadedBy) {
    this.uploadedBy = uploadedBy;
  }

  public GetBanksWithAccess200Response uploadedDate(String uploadedDate) {
    this.uploadedDate = uploadedDate;
    return this;
  }

  /**
   * Get uploadedDate
   * @return uploadedDate
   */
  
  @Schema(name = "uploadedDate", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("uploadedDate")
  public String getUploadedDate() {
    return uploadedDate;
  }

  public void setUploadedDate(String uploadedDate) {
    this.uploadedDate = uploadedDate;
  }

  public GetBanksWithAccess200Response banksWithAccess(List<@Valid BankAccess> banksWithAccess) {
    this.banksWithAccess = banksWithAccess;
    return this;
  }

  public GetBanksWithAccess200Response addItem(BankAccess banksWithAccessItem) {
    if (this.banksWithAccess == null) {
      this.banksWithAccess = new ArrayList<>();
    }
    this.banksWithAccess.add(banksWithAccessItem);
    return this;
  }

  /**
   * Get banksWithAccess
   * @return banksWithAccess
   */
  @Valid 
  @Schema(name = "banksWithAccess", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("banksWithAccess")
  public List<@Valid BankAccess> getBanksWithAccess() {
    return banksWithAccess;
  }

  public void setBanksWithAccess(List<@Valid BankAccess> banksWithAccess) {
    this.banksWithAccess = banksWithAccess;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    GetBanksWithAccess200Response getBanksWithAccess200Response = (GetBanksWithAccess200Response) o;
    return Objects.equals(this.patchId, getBanksWithAccess200Response.patchId) &&
        Objects.equals(this.fileName, getBanksWithAccess200Response.fileName) &&
        Objects.equals(this.version, getBanksWithAccess200Response.version) &&
        Objects.equals(this.uploadedBy, getBanksWithAccess200Response.uploadedBy) &&
        Objects.equals(this.uploadedDate, getBanksWithAccess200Response.uploadedDate) &&
        Objects.equals(this.banksWithAccess, getBanksWithAccess200Response.banksWithAccess);
  }

  @Override
  public int hashCode() {
    return Objects.hash(patchId, fileName, version, uploadedBy, uploadedDate, banksWithAccess);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class GetBanksWithAccess200Response {\n");
    sb.append("    patchId: ").append(toIndentedString(patchId)).append("\n");
    sb.append("    fileName: ").append(toIndentedString(fileName)).append("\n");
    sb.append("    version: ").append(toIndentedString(version)).append("\n");
    sb.append("    uploadedBy: ").append(toIndentedString(uploadedBy)).append("\n");
    sb.append("    uploadedDate: ").append(toIndentedString(uploadedDate)).append("\n");
    sb.append("    banksWithAccess: ").append(toIndentedString(banksWithAccess)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

