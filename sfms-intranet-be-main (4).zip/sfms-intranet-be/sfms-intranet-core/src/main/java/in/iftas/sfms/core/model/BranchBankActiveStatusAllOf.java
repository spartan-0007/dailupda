package in.iftas.sfms.core.model;

import java.net.URI;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonTypeName;
import org.openapitools.jackson.nullable.JsonNullable;
import java.time.OffsetDateTime;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


import java.util.*;
import jakarta.annotation.Generated;

/**
 * BranchBankActiveStatusAllOf
 */

@JsonTypeName("BranchBankActiveStatus_allOf")

public class BranchBankActiveStatusAllOf {

  private Boolean isBankActive;

  public BranchBankActiveStatusAllOf isBankActive(Boolean isBankActive) {
    this.isBankActive = isBankActive;
    return this;
  }

  /**
   * Get isBankActive
   * @return isBankActive
   */
  
  @Schema(name = "isBankActive", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("isBankActive")
  public Boolean getIsBankActive() {
    return isBankActive;
  }

  public void setIsBankActive(Boolean isBankActive) {
    this.isBankActive = isBankActive;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    BranchBankActiveStatusAllOf branchBankActiveStatusAllOf = (BranchBankActiveStatusAllOf) o;
    return Objects.equals(this.isBankActive, branchBankActiveStatusAllOf.isBankActive);
  }

  @Override
  public int hashCode() {
    return Objects.hash(isBankActive);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BranchBankActiveStatusAllOf {\n");
    sb.append("    isBankActive: ").append(toIndentedString(isBankActive)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

