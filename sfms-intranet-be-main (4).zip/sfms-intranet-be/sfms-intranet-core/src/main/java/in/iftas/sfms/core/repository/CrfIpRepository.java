package in.iftas.sfms.core.repository;

import in.iftas.sfms.core.entity.ChangeRequestFormEntity;
import in.iftas.sfms.core.entity.CrfIpEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CrfIpRepository extends JpaRepository<CrfIpEntity, Long> {

    @Query("SELECT c.crf FROM CrfIpEntity c WHERE " +
            "c.sourceIp1 = :ip OR c.sourceIp2 = :ip OR c.sourceIp3 = :ip OR c.sourceIp4 = :ip OR " +
            "c.sourceIp5 = :ip OR c.sourceIp6 = :ip OR c.sourceIp7 = :ip OR " +
            "c.destinationIp1 = :ip OR c.destinationIp2 = :ip OR c.destinationIp3 = :ip OR c.destinationIp4 = :ip OR " +
            "c.destinationIp5 = :ip OR c.destinationIp6 = :ip OR c.destinationIp7 = :ip " +
            "ORDER BY c.crf.openDate DESC")
    List<ChangeRequestFormEntity> findCrfByIpAddress(@Param("ip") String ip);

    @Query("SELECT ip FROM CrfIpEntity ip WHERE ip.crf.id = :crfId " +
            "ORDER BY ip.crf.openDate DESC")
    List<CrfIpEntity> findByCrfID(@Param("crfId") Long crfId);

}