package in.iftas.sfms.core.handler;

import com.fasterxml.jackson.databind.ObjectMapper;
import in.iftas.sfms.common.handler.ApprovalHandler;
import in.iftas.sfms.core.model.Branch;
import in.iftas.sfms.core.service.BankService;
import in.iftas.sfms.core.service.BranchService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class BranchApprovalHandler implements ApprovalHandler {

    private final BranchService branchService;
    private final ObjectMapper objectMapper;

    @Autowired
    public BranchApprovalHandler(BankService bankService, BranchService branchService, ObjectMapper objectMapper) {
        this.branchService = branchService;
        this.objectMapper = objectMapper;
    }

    @Override
    public String getEntityType() {
        return "BRANCH";
    }


    @Override
    public void handleApproval(Long approvalId, String actionType, String requestData, String entityId) {
        log.info("Processing bank approval - ID: {}, Action: {}", approvalId, actionType);

        try {
            Branch branch = objectMapper.readValue(requestData, Branch.class);

            switch (actionType.toUpperCase()) {
                case "UPDATE":
                    branchService.updateBranch(branch);
                    log.info("Branch updated successfully: {}", entityId);
                    break;
                default:
                    throw new UnsupportedOperationException("Unsupported action type: " + actionType);
            }
        } catch (Exception e) {
            log.error("Error handling Branch approval: {}", e.getMessage(), e);
            throw new RuntimeException("Failed to process bank approval", e);
        }
    }

    @Override
    public void handleRejection(Long approvalId, String rejectionReason, String entityType) {
        log.info("Branch approval {} rejected with reason: {}", approvalId, rejectionReason);

    }
}