package in.iftas.sfms.core.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "i_lc_bg_messages",
       uniqueConstraints = @UniqueConstraint(columnNames = {"sender_reference_number", "half_year"}),
       indexes = {
           @Index(name = "idx_sender_ifsc", columnList = "sender_ifsc"),
           @Index(name = "idx_receiver_ifsc", columnList = "receiver_ifsc"),
           @Index(name = "idx_message_date", columnList = "message_date"),
           @Index(name = "idx_sender_reference_number", columnList = "sender_reference_number")
       }
)
public class LcBgMessageEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @Column(name = "sender_ifsc", nullable = false, length = 11)
    private String senderIfsc;

    @Column(name = "receiver_ifsc", nullable = false, length = 11)
    private String receiverIfsc;

    @Column(name = "sender_reference_number", nullable = false, length = 255, unique = true)
    private String senderReferenceNumber;

    @Column(name = "message_type", nullable = false, length = 50)
    private String messageType;

    @Column(name = "message_status", nullable = false, length = 50)
    private String messageStatus;

    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
    @Column(name = "message_date", nullable = false, columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
    private LocalDateTime messageDateTime;

    @Column(name = "half_year", nullable = false)
    private Integer halfYear;

    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
    @Column(name = "upload_date", nullable = false, columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
    private LocalDate uploadDate;

    // No need to include the composite key in @Id as JPA doesn't support composite keys directly in annotations.
    // Instead, you would manage the composite key logic in the application or use an embeddable key if required.

}