package in.iftas.sfms.core.api.impl;

import in.iftas.sfms.core.api.BranchesApi;
import in.iftas.sfms.core.enums.BranchFeatureType;
import in.iftas.sfms.core.exception.ExcelGenerationException;
import in.iftas.sfms.core.exception.IfscCodeAlreadyExistsException;
import in.iftas.sfms.core.exception.ResourceNotFoundException;
import in.iftas.sfms.core.model.Branch;
import in.iftas.sfms.core.model.BranchProliferationResponse;
import in.iftas.sfms.core.model.EnabledBranchFeatureCountResponse;
import in.iftas.sfms.core.model.ModelApiResponse;
import in.iftas.sfms.core.service.BranchProliferationService;
import in.iftas.sfms.core.service.BranchService;
import in.iftas.sfms.core.service.SftpService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.util.Collections;
import java.util.List;

@RestController
public class BranchApiImpl implements BranchesApi {

    private final BranchProliferationService branchProliferationService;
    private final BranchService branchService;
    private static final Logger logger = LoggerFactory.getLogger(BranchApiImpl.class);
    private final SftpService sftpService;

    @Value("${sample.template.path}")
    private String templatePath;

    @Autowired
    public BranchApiImpl(BranchProliferationService branchProliferationService, BranchService branchService, SftpService sftpService) {
        this.branchProliferationService = branchProliferationService;
        this.branchService = branchService;
        this.sftpService = sftpService;
    }

    @Override
    public ResponseEntity<Void> branchesDelete(String ifscCode) {
        // Implement logic to delete a branch based on IFSC code.
        boolean deleted = false;// service call to delete the branch by IFSC code
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    // ToDo Need to update the method with best practices and implement loggers as well as handle exceptional scenarios
    @Override
    public ResponseEntity<ModelApiResponse> branchesPut(Branch branch) {
        String ifsccode = branchService.updateBranch(branch);
        ModelApiResponse response = new ModelApiResponse();
        if (ifsccode != null) {
            response.setSuccess(true);
            response.setMessage("Branch with ID updated successfully");
            response.setData(Collections.singletonMap("BranchId", ifsccode));
            return ResponseEntity.ok(response);
        } else {
            response.setSuccess(false);
            response.setMessage("Failed to update Branch");
            response.setData(Collections.singletonMap("data", Collections.emptyList()));
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    @Override
    @PreAuthorize("hasAnyAuthority('ROLE_operator-read-write','ROLE_banker-neft-read-write')")
    public ResponseEntity<ModelApiResponse> branchesProliferatePost(String branchDetails,Integer bankId, List<MultipartFile> propertiesFiles ) {
        ModelApiResponse apiResponse = new ModelApiResponse();
        try {
            Jwt jwt = (Jwt) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
            if(branchDetails.isEmpty()){
                throw new IllegalArgumentException("Branch Details cannot be empty");
            }
            if("BANKER".equals(jwt.getClaimAsString("userType"))){
                bankId = Integer.valueOf(jwt.getClaimAsString("bankId"));
            }
            if(ObjectUtils.isEmpty(bankId)) throw new ResourceNotFoundException("Bank Not Found");
            List<Long> proliferationIds = branchProliferationService.proliferateBranches(branchDetails, jwt.getClaimAsString("sub"), bankId, propertiesFiles);

            apiResponse.setMessage("Branch details successfully stored for proliferation.");
            apiResponse.setSuccess(true);
            apiResponse.setData(Collections.singletonMap("proliferationId", proliferationIds));

            return new ResponseEntity<>(apiResponse, HttpStatus.CREATED);
        } catch (IfscCodeAlreadyExistsException | ResourceNotFoundException ie) {
            apiResponse.setMessage(ie.getMessage());
            apiResponse.setSuccess(false);
            return new ResponseEntity<>(apiResponse, HttpStatus.CONFLICT);
        } catch (IllegalArgumentException e) {
            apiResponse.setMessage(e.getMessage());
            apiResponse.setSuccess(false);
            return new ResponseEntity<>(apiResponse, HttpStatus.BAD_REQUEST);
        } catch (Exception e) {
            apiResponse.setMessage("Internal server error.");
            apiResponse.setSuccess(false);
            return new ResponseEntity<>(apiResponse, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    @PreAuthorize("hasAnyAuthority('ROLE_banker-neft-read-write','ROLE_banker-rtgs-read-write')")
    public ResponseEntity<String> uploadPropertiesFiles(@RequestParam("files") List<MultipartFile> files) {
        if (files == null || files.isEmpty()) {
            return ResponseEntity.badRequest().body("No files uploaded.");
        }
        try {
            for (MultipartFile file : files) {
                if (file.isEmpty()) {
                    return ResponseEntity.badRequest().body("No files uploaded.");
                }
                branchProliferationService.validateAndUploadFile(file);
            }
            return ResponseEntity.ok("Files are validated successfully.");
        } catch (IfscCodeAlreadyExistsException ie) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body(ie.getMessage());
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Internal server error.");
        }
    }


    @Override
    @PreAuthorize("hasAnyAuthority('ROLE_banker-neft-read-write','ROLE_banker-rtgs-read-write')")
    public ResponseEntity<String> uploadBranchDetailsFromExcel(Integer bankId, MultipartFile excelFile, List<MultipartFile> propertiesFile) {
        try {
            String result = branchProliferationService.uploadBranchDetailsFromExcel(excelFile, propertiesFile, bankId);
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to process Excel file." + e.getMessage());
        }
    }

    @Override
    @PreAuthorize("hasAuthority('ROLE_operator-read-write')")
    public ResponseEntity<Resource> downloadProliferationExcel() {
        Resource inputStreamResource = branchProliferationService.proliferateAndDownloadExcel();

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"));
        headers.setContentDisposition(ContentDisposition.attachment().filename("branches.xlsx").build());

        return ResponseEntity.ok().headers(headers).body(inputStreamResource);
    }

    @Override
    @PreAuthorize("hasAnyAuthority('ROLE_operator-read-write','ROLE_operator-read-only','ROLE_banker-neft-read-write')")
    public ResponseEntity<List<BranchProliferationResponse>> getPendingProliferationBranches(Integer bankId) {
        List<BranchProliferationResponse> branchList = branchProliferationService.getPendingProliferationBranches(bankId);
        return ResponseEntity.status(HttpStatusCode.valueOf(200)).body(branchList);
    }

    @Override
    public ResponseEntity<EnabledBranchFeatureCountResponse> getBranchFeatureEnabledCount() {
        EnabledBranchFeatureCountResponse enabledFeatureCount = branchService.getEnabledFeatureCount();
        return ResponseEntity.status(HttpStatusCode.valueOf(200)).body(enabledFeatureCount);
    }

    @Override
    public ResponseEntity<Resource> generateBranchesReport(Boolean rtgs, Boolean neft,
                                                           Boolean rtgsNeft, Boolean lc, Boolean bg, Boolean lcBg, Boolean others) {

        BranchFeatureType featureType = determineFeatureType(rtgs, neft, rtgsNeft, lc, bg, lcBg, others);

        if (featureType == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }

        try {
            Resource resource = branchService.getBranchesByFeature(featureType);

            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=enabled_branches_report.txt")
                    .contentLength(resource.contentLength())
                    .contentType(org.springframework.http.MediaType.TEXT_PLAIN)
                    .body(resource);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    @PreAuthorize("hasAnyAuthority('ROLE_operator-read-write','ROLE_operator-read-only')")
    public ResponseEntity<Resource> generateProliferatedBranchesReport() {

        Resource inputStreamResource = branchProliferationService.downloadProliferatedExcel();

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"));
        headers.setContentDisposition(ContentDisposition.attachment().filename("branches.xlsx").build());

        return ResponseEntity.ok().headers(headers).body(inputStreamResource);

    }

    @Override
    @PreAuthorize("hasAnyAuthority('ROLE_operator-read-write','ROLE_operator-read-only')")
    public ResponseEntity<List<Branch>> getProliferatedBranches(Integer page, Integer size, String sort) {
        try {
            List<Branch> branches = branchService.getBranches(page, size, sort);
            return new ResponseEntity<>(branches, HttpStatus.OK);
        } catch (Exception e) {
            // Log the exception (use a logger in real applications)
            return new ResponseEntity<>(List.of(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    public ResponseEntity<Resource> downloadProliferationExcelIfscTypeHO(String ifscType) {

        Resource inputStreamResource = null;
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"));
            headers.setContentDisposition(ContentDisposition.attachment().filename("branches.xlsx").build());
            inputStreamResource = branchProliferationService.streamProliferateAndDownloadExcelTypeHO(ifscType);
            return ResponseEntity.ok().headers(headers).body(inputStreamResource);
        } catch (ExcelGenerationException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    private BranchFeatureType determineFeatureType(Boolean rtgs, Boolean neft, Boolean rtgsNeft,
                                                   Boolean lc, Boolean bg, Boolean lcBg, Boolean others) {
        if (Boolean.TRUE.equals(rtgs)) {
            return BranchFeatureType.RTGS;
        } else if (Boolean.TRUE.equals(neft)) {
            return BranchFeatureType.NEFT;
        } else if (Boolean.TRUE.equals(rtgsNeft)) {
            return BranchFeatureType.RTGS_AND_NEFT;
        } else if (Boolean.TRUE.equals(lc)) {
            return BranchFeatureType.LC;
        } else if (Boolean.TRUE.equals(bg)) {
            return BranchFeatureType.BG;
        } else if (Boolean.TRUE.equals(lcBg)) {
            return BranchFeatureType.LC_AND_BG;
        }else if (Boolean.TRUE.equals(others)) {
            return BranchFeatureType.OTHERS;
        } else {
            return null;
        }
    }

    public ResponseEntity<Resource> downloadProliferationExcelTemplate(String template) {
        logger.info("API call to download Excel template with parameter: {}", template);
        try {
            byte[] templateBytes = branchProliferationService.downloadTemplate(template);
            logger.info("Successfully retrieved template bytes.");

            ByteArrayResource resource = new ByteArrayResource(templateBytes);

            HttpHeaders headers = new HttpHeaders();
            headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"SFMS0000001.xlsx\"");
            headers.add(HttpHeaders.CONTENT_TYPE, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
            headers.add(HttpHeaders.CONTENT_LENGTH, String.valueOf(templateBytes.length));

            logger.info("Returning ResponseEntity with headers for the template.");
            return ResponseEntity.ok()
                    .headers(headers)
                    .body(resource);
        } catch (IllegalArgumentException e) {
            logger.warn("Bad request for download sample template: {}", e.getMessage());
            ModelApiResponse apiResponse = new ModelApiResponse()
                    .success(false)
                    .message("Bad Request: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ByteArrayResource(apiResponse.toString().getBytes()));
        } catch (Exception e) {
            logger.error("Internal server error for download sample template: {}", e.getMessage(), e);
            ModelApiResponse apiResponse = new ModelApiResponse()
                    .success(false)
                    .message("Internal server error: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new ByteArrayResource(apiResponse.toString().getBytes()));
        }
    }

}