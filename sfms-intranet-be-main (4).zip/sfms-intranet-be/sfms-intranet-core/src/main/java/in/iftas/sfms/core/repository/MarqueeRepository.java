package in.iftas.sfms.core.repository;

/*
 * Copyright (C) 2024 Iftas Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Iftas Inc. ("Confidential Information"). You shall not disclose
 * such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with Iftas Inc.
 *
 * Author: Manoj.Illa
 * Date: November 06, 2024
 */

import in.iftas.sfms.core.entity.MarqueeEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public  interface MarqueeRepository extends JpaRepository<MarqueeEntity, Long> {

    List<MarqueeEntity> findByIsGlobalTrue();

    List<MarqueeEntity> findByBanks_Id(Long bankId);
}
