package in.iftas.sfms.core.entity;

import jakarta.persistence.*;
import lombok.*;

import java.util.List;


@Entity
@Table(name = "i_banks", indexes = {
        @Index(name = "idx_bank_id", columnList = "id"),
        @Index(name = "idx_bank_short_name", columnList = "bank_short_name"),
        @Index(name = "idx_bank_name", columnList = "bank_name")
})
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class BankEntity extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "bank_name", nullable = false, unique = true)
    private String bankName;

    @Column(name = "bank_short_name", nullable = false, unique = true)
    private String bankShortName;

    @OneToMany(mappedBy = "bank", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
    private List<BranchEntity> branches;

    @Column(name = "isActive", nullable = false, columnDefinition = "TINYINT(1) DEFAULT 0")
    private Boolean isActive;

    @Column(name = "isHostedOnCloud", nullable = false, columnDefinition = "TINYINT(1) DEFAULT 0")
    private Boolean isHostedOnCloud;

}