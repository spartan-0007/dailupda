package in.iftas.sfms.core.entity;/*
 * Copyright (C) 2024 Iftas Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Iftas Inc. ("Confidential Information"). You shall not disclose
 * such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with Iftas Inc.
 *
 * Author: Manoj.Illa
 * Date: July 11, 2024
 */

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "i_contact_us")
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class ContactUsEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "level_id", nullable = false)
    private ContactUsLevelEntity level;

    private String contactName;

    private String contactEmail;

    private String responseTime;

    private String contactNumber1;
    private String contactNumber2;
    private String contactNumber3;

}
