package in.iftas.sfms.core.model;

import java.net.URI;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import in.iftas.sfms.core.model.EscalationContact;
import java.util.ArrayList;
import java.util.List;
import org.openapitools.jackson.nullable.JsonNullable;
import java.time.OffsetDateTime;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


import java.util.*;
import jakarta.annotation.Generated;

/**
 * LevelMatrix
 */


public class LevelMatrix {

  private Long levelId;

  private String levelName;

  private Integer levelOrder;

  @Valid
  private List<@Valid EscalationContact> contacts;

  public LevelMatrix levelId(Long levelId) {
    this.levelId = levelId;
    return this;
  }

  /**
   * Unique identifier of the escalation level.
   * @return levelId
   */
  
  @Schema(name = "levelId", description = "Unique identifier of the escalation level.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("levelId")
  public Long getLevelId() {
    return levelId;
  }

  public void setLevelId(Long levelId) {
    this.levelId = levelId;
  }

  public LevelMatrix levelName(String levelName) {
    this.levelName = levelName;
    return this;
  }

  /**
   * Name of the escalation level (e.g., Level 1, Level 2).
   * @return levelName
   */
  
  @Schema(name = "levelName", description = "Name of the escalation level (e.g., Level 1, Level 2).", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("levelName")
  public String getLevelName() {
    return levelName;
  }

  public void setLevelName(String levelName) {
    this.levelName = levelName;
  }

  public LevelMatrix levelOrder(Integer levelOrder) {
    this.levelOrder = levelOrder;
    return this;
  }

  /**
   * Order of the level within the department.
   * @return levelOrder
   */
  
  @Schema(name = "levelOrder", description = "Order of the level within the department.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("levelOrder")
  public Integer getLevelOrder() {
    return levelOrder;
  }

  public void setLevelOrder(Integer levelOrder) {
    this.levelOrder = levelOrder;
  }

  public LevelMatrix contacts(List<@Valid EscalationContact> contacts) {
    this.contacts = contacts;
    return this;
  }

  public LevelMatrix addItem(EscalationContact contactsItem) {
    if (this.contacts == null) {
      this.contacts = new ArrayList<>();
    }
    this.contacts.add(contactsItem);
    return this;
  }

  /**
   * List of escalation contacts for this level.
   * @return contacts
   */
  @Valid 
  @Schema(name = "contacts", description = "List of escalation contacts for this level.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("contacts")
  public List<@Valid EscalationContact> getContacts() {
    return contacts;
  }

  public void setContacts(List<@Valid EscalationContact> contacts) {
    this.contacts = contacts;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    LevelMatrix levelMatrix = (LevelMatrix) o;
    return Objects.equals(this.levelId, levelMatrix.levelId) &&
        Objects.equals(this.levelName, levelMatrix.levelName) &&
        Objects.equals(this.levelOrder, levelMatrix.levelOrder) &&
        Objects.equals(this.contacts, levelMatrix.contacts);
  }

  @Override
  public int hashCode() {
    return Objects.hash(levelId, levelName, levelOrder, contacts);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class LevelMatrix {\n");
    sb.append("    levelId: ").append(toIndentedString(levelId)).append("\n");
    sb.append("    levelName: ").append(toIndentedString(levelName)).append("\n");
    sb.append("    levelOrder: ").append(toIndentedString(levelOrder)).append("\n");
    sb.append("    contacts: ").append(toIndentedString(contacts)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

