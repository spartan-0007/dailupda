package in.iftas.sfms.core.service;

import in.iftas.sfms.core.enums.BranchFeatureType;
import in.iftas.sfms.core.exception.InvalidRequestException;
import in.iftas.sfms.core.exception.ResourceNotFoundException;
import in.iftas.sfms.core.model.Branch;
import in.iftas.sfms.core.model.EnabledBranchFeatureCountResponse;
import org.springframework.core.io.Resource;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

public interface BranchService {
    void deleteBranch(String ifscCode) throws ResourceNotFoundException;
    void addBranch(Branch branch) throws InvalidRequestException;
    String updateBranch(Branch branch) throws InvalidRequestException, ResourceNotFoundException;
    void uploadBranches(MultipartFile file) throws InvalidRequestException;
    EnabledBranchFeatureCountResponse getEnabledFeatureCount();
    Resource getBranchesByFeature(BranchFeatureType feature);

    List<Branch> getBranches(Integer page, Integer size, String sort);
}