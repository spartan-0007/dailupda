package in.iftas.sfms.core.exception;

public class GlobalMarqueeException extends RuntimeException {
    public GlobalMarqueeException(String message) {
        super(message);
    }
}
