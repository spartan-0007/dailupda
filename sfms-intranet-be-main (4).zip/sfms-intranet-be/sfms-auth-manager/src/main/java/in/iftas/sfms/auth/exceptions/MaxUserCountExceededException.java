package in.iftas.sfms.auth.exceptions;

public class MaxUserCountExceededException extends RuntimeException {
    public MaxUserCountExceededException(String message) {
        super(message);
    }
}
