package in.iftas.sfms.auth.api.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import in.iftas.sfms.auth.api.UserApprovalsApi;
import in.iftas.sfms.auth.exceptions.MaxUserCountExceededException;
import in.iftas.sfms.auth.exceptions.ResourceNotFoundException;
import in.iftas.sfms.auth.exceptions.UserAlreadyPresentException;
import in.iftas.sfms.auth.model.ApiResponseError;
import in.iftas.sfms.auth.model.ModelApiResponse;
import in.iftas.sfms.auth.model.UserCreateRequest;
import in.iftas.sfms.auth.service.UserApprovalService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import java.io.IOException;

@RestController
@RequiredArgsConstructor
@Slf4j
public class UserApprovalsApiImpl implements UserApprovalsApi {

    private final UserApprovalService userApprovalService;

    public ResponseEntity<ModelApiResponse> userApprovalsPost(UserCreateRequest userCreateRequest) {
        log.info("Received request to create User approval");
        ModelApiResponse modelApiResponse = new ModelApiResponse();
        try {
            userApprovalService.createUserApproval(userCreateRequest);
            modelApiResponse.setSuccess(true);
            modelApiResponse.setMessage("User approval request created successfully");
            log.info("User approval request created successfully");
            return ResponseEntity.status(HttpStatus.CREATED).body(modelApiResponse);
        }
        catch (MaxUserCountExceededException e) {
            log.error("Max user count exceeded: {}", e.getMessage());
            modelApiResponse.setSuccess(false);
            modelApiResponse.setMessage(e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(modelApiResponse);
        }
        catch (UserAlreadyPresentException e) {
            log.error("User already exists: {}", e.getMessage());
            modelApiResponse.setSuccess(false);
            modelApiResponse.setMessage(e.getMessage());
            return ResponseEntity.status(HttpStatus.CONFLICT).body(modelApiResponse);
        }
        catch (ResponseStatusException e) {
            log.error("Validation error: {}", e.getMessage());
            modelApiResponse.setSuccess(false);
            modelApiResponse.setMessage(e.getReason());
            return ResponseEntity.status(e.getStatusCode()).body(modelApiResponse);
        }
        catch (IllegalArgumentException e) {
            log.error("Invalid request: {}", e.getMessage());
            modelApiResponse.setSuccess(false);
            modelApiResponse.setMessage(e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(modelApiResponse);
        }
        catch (Exception e) {
            log.error("Unexpected error processing user approval request: {}", e.getMessage(), e);
            modelApiResponse.setSuccess(false);
            modelApiResponse.setMessage("An internal error occurred while processing the request");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(modelApiResponse);
        }
    }
    @Override
    public ResponseEntity<ModelApiResponse> userApprovalsIdPut(String id, UserCreateRequest userCreateRequest) {
        log.info("Received request to create update approval for user with ID: {}", id);
        ModelApiResponse modelApiResponse = new ModelApiResponse();

        try {
            userApprovalService.updateUserApproval(id, userCreateRequest);
            modelApiResponse.setSuccess(true);
            modelApiResponse.setMessage("User update approval request created successfully");
            log.info("user update approval request created successfully for bank ID: {}", id);

            return ResponseEntity.status(HttpStatus.OK).body(modelApiResponse);

        } catch (ResourceNotFoundException e) {
            log.error("User not found: {}", e.getMessage());

            modelApiResponse.setSuccess(false);
            modelApiResponse.setMessage(e.getMessage());

            ApiResponseError error = new ApiResponseError();
            error.setCode(HttpStatus.NOT_FOUND.toString());
            error.setMessage(e.getMessage());
            modelApiResponse.setError(error);

            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(modelApiResponse);

        } catch (Exception e) {
            log.error("Error processing user update approval request: {}", e.getMessage(), e);

            modelApiResponse.setSuccess(false);
            modelApiResponse.setMessage("Error processing request");

            ApiResponseError apiResponseError = new ApiResponseError();
            apiResponseError.setCode(HttpStatus.INTERNAL_SERVER_ERROR.toString());
            apiResponseError.setMessage(e.getMessage());
            modelApiResponse.setError(apiResponseError);

            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(modelApiResponse);
        }
    }
    @Override
    public ResponseEntity<ModelApiResponse> userApprovalsIdDelete(String id) {
        log.info("Received request to create delete approval for User with ID: {}", id);
        ModelApiResponse modelApiResponse = new ModelApiResponse();

        try {
            userApprovalService.deleteUserApproval(id);
            modelApiResponse.setSuccess(true);
            modelApiResponse.setMessage("User deletion approval request created successfully");
            log.info("User deletion approval request created successfully for bank ID: {}", id);

            return ResponseEntity.status(HttpStatus.OK).body(modelApiResponse);

        } catch (ResourceNotFoundException e) {
            log.error("User not found: {}", e.getMessage());

            modelApiResponse.setSuccess(false);
            modelApiResponse.setMessage(e.getMessage());

            ApiResponseError error = new ApiResponseError();
            error.setCode(HttpStatus.NOT_FOUND.toString());
            error.setMessage(e.getMessage());
            modelApiResponse.setError(error);

            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(modelApiResponse);

        } catch (IOException e) {
            log.error("Error processing user deletion data: {}", e.getMessage(), e);

            modelApiResponse.setSuccess(false);
            modelApiResponse.setMessage("Error processing request data");

            ApiResponseError apiResponseError = new ApiResponseError();
            apiResponseError.setCode(HttpStatus.INTERNAL_SERVER_ERROR.toString());
            apiResponseError.setMessage("Error processing request data");
            modelApiResponse.setError(apiResponseError);

            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(modelApiResponse);
        } catch (Exception e) {
            log.error("Error processing user deletion approval request: {}", e.getMessage(), e);

            modelApiResponse.setSuccess(false);
            modelApiResponse.setMessage("Error processing request");

            ApiResponseError apiResponseError = new ApiResponseError();
            apiResponseError.setCode(HttpStatus.INTERNAL_SERVER_ERROR.toString());
            apiResponseError.setMessage(e.getMessage());
            modelApiResponse.setError(apiResponseError);

            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(modelApiResponse);
        }
    }

}
