//package in.iftas.sfms.auth.filter;
//
//import in.iftas.sfms.auth.converter.CustomJwtAuthenticationConverter;
//import io.jsonwebtoken.JwtException;
//import jakarta.servlet.FilterChain;
//import jakarta.servlet.ServletException;
//import jakarta.servlet.http.Cookie;
//import jakarta.servlet.http.HttpServletRequest;
//import jakarta.servlet.http.HttpServletResponse;
//import org.springframework.security.authentication.AbstractAuthenticationToken;
//import org.springframework.security.core.context.SecurityContextHolder;
//import org.springframework.security.oauth2.jwt.Jwt;
//import org.springframework.security.oauth2.jwt.JwtDecoder;
//import org.springframework.stereotype.Component;
//import org.springframework.web.filter.OncePerRequestFilter;
//import org.springframework.web.util.WebUtils;
//
//import java.io.IOException;
//
//@Component
//public class JwtTokenFilter extends OncePerRequestFilter {
//
//    private final JwtDecoder jwtDecoder;
//    private final CustomJwtAuthenticationConverter customJwtAuthenticationConverter;
//
//    public JwtTokenFilter(JwtDecoder jwtDecoder, CustomJwtAuthenticationConverter customJwtAuthenticationConverter) {
//        this.jwtDecoder = jwtDecoder;
//        this.customJwtAuthenticationConverter = customJwtAuthenticationConverter;
//    }
//
//    @Override
//    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
//            throws ServletException, IOException {
//        String accessToken = extractTokenFromCookies(request);
//        if (accessToken != null) {
//            try {
//                Jwt jwt = jwtDecoder.decode(accessToken);
//                AbstractAuthenticationToken authentication = customJwtAuthenticationConverter.convert(jwt);
//                SecurityContextHolder.getContext().setAuthentication(authentication);
//            } catch (JwtException e) {
//                SecurityContextHolder.clearContext();
//            }
//        }
//
//        filterChain.doFilter(request, response);
//    }
//
//    private String extractTokenFromCookies(HttpServletRequest request) {
//        Cookie cookie = WebUtils.getCookie(request, "access_token");
//        return cookie != null ? cookie.getValue() : null;
//    }
//}