package in.iftas.sfms.auth.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import in.iftas.sfms.auth.entity.UserQuotaEntity;
import in.iftas.sfms.auth.exceptions.ResourceNotFoundException;
import in.iftas.sfms.auth.exceptions.MaxUserCountExceededException;
import in.iftas.sfms.auth.exceptions.UserAlreadyPresentException;
import in.iftas.sfms.auth.model.UserCreateRequest;
import in.iftas.sfms.auth.model.UserResponse;
import in.iftas.sfms.auth.repository.UserQuotaRepository;
import in.iftas.sfms.auth.validation.UserValidationService;
import in.iftas.sfms.common.entity.ApprovalRequestEntity;
import in.iftas.sfms.common.repository.ApprovalRequestRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@Slf4j
public class UserApprovalService {

    private final ApprovalRequestRepository approvalRequestRepository;
    private final ObjectMapper objectMapper;
    private final UserValidationService userValidationService;
    private final KeycloakTokenService keycloakTokenService;
    private final AuthService authService;

    @Autowired
    public UserApprovalService(ApprovalRequestRepository approvalRequestRepository, ObjectMapper objectMapper, UserValidationService userValidationService, KeycloakTokenService keycloakTokenService, AuthService authService) {
        this.approvalRequestRepository = approvalRequestRepository;
        this.objectMapper = objectMapper;
        this.userValidationService = userValidationService;
        this.keycloakTokenService = keycloakTokenService;
        this.authService = authService;
    }

    public void createUserApproval(UserCreateRequest user) {
        try {
            String adminToken = keycloakTokenService.getAdminToken();
            userValidationService.validateUserCreation(user,adminToken);
            Jwt jwt = (Jwt) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
            String userJson = objectMapper.writeValueAsString(user);

            ApprovalRequestEntity entity = ApprovalRequestEntity.builder()
                    .entityType(ApprovalRequestEntity.EntityType.USER.name())
                    .actionType(ApprovalRequestEntity.ActionType.CREATE.name())
                    .requestData(userJson)
                    .status(ApprovalRequestEntity.Status.PENDING.name())
                    .makerName(jwt.getClaimAsString("name"))
                    .build();
            entity.setCreatedBy(jwt.getClaimAsString("sub"));
            approvalRequestRepository.save(entity);
            log.info("User approval request created successfully");
        } catch (MaxUserCountExceededException | UserAlreadyPresentException e) {
            log.error("Validation failure: {}", e.getMessage());
            throw e;
        } catch (ResponseStatusException e) {
            throw e;
        }catch (IllegalArgumentException e) {
            log.error("Invalid approval request: {}", e.getMessage());
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage());
        } catch (JsonProcessingException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage());
        }
    }

    public void updateUserApproval(String id, UserCreateRequest user) throws ResourceNotFoundException, IOException {
        log.info("Creating user update approval request for user ID: {}", id);
        List<UserResponse> userResponses = authService.getUsersById(keycloakTokenService.getAdminToken(), id);
        if (userResponses == null || userResponses.isEmpty()) {
            throw new ResourceNotFoundException("User not found with id: " + id);
        }

        try {
            Jwt jwt = (Jwt) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
            String userJson = objectMapper.writeValueAsString(user);
            ApprovalRequestEntity entity = ApprovalRequestEntity.builder()
                    .entityType(ApprovalRequestEntity.EntityType.USER.name())
                    .actionType(ApprovalRequestEntity.ActionType.UPDATE.name())
                    .entityId(id)
                    .requestData(userJson)
                    .status(ApprovalRequestEntity.Status.PENDING.name())
                    .makerName(jwt.getClaimAsString("name"))
                    .build();
            entity.setCreatedBy(jwt.getClaimAsString("sub"));
            approvalRequestRepository.save(entity);
            log.info("User update approval request created successfully for user ID: {}", id);
        } catch (IOException e) {
            log.error("Error creating user update approval request: {}", e.getMessage(), e);
            throw e;
        }
    }

    public void deleteUserApproval(String id) throws ResourceNotFoundException, IOException {

        log.info("Creating User deletion approval request for bank ID: {}", id);
        List<UserResponse> userResponses = authService.getUsersById(keycloakTokenService.getAdminToken(), String.valueOf(id));
        if (userResponses == null || userResponses.isEmpty()) {
            throw new ResourceNotFoundException("User not found with id: " + id);
        }

        try {
            Jwt jwt = (Jwt) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
            Map<String, Object> requestData = new HashMap<>();
            requestData.put("id", id);
            String requestDataJson = objectMapper.writeValueAsString(requestData);

            ApprovalRequestEntity entity = ApprovalRequestEntity.builder()
                    .entityType(ApprovalRequestEntity.EntityType.USER.name())
                    .actionType(ApprovalRequestEntity.ActionType.DELETE.name())
                    .entityId(String.valueOf(id))
                    .requestData(requestDataJson)
                    .status(ApprovalRequestEntity.Status.PENDING.name())
                    .makerName(jwt.getClaimAsString("name"))
                    .build();
            entity.setCreatedBy(jwt.getClaimAsString("sub"));
            approvalRequestRepository.save(entity);
            log.info("User deletion approval request created successfully for user ID: {}", id);
        } catch (Exception e) {
            log.error("Error creating user deletion approval request: {}", e.getMessage(), e);
            throw e;
        }
    }
}