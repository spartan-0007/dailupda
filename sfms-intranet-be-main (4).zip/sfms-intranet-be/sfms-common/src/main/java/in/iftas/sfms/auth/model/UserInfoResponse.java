package in.iftas.sfms.auth.model;

import java.net.URI;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.openapitools.jackson.nullable.JsonNullable;
import java.time.OffsetDateTime;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


import java.util.*;
import jakarta.annotation.Generated;

/**
 * User Info Response containing user profile and token details
 */

@Schema(name = "UserInfoResponse", description = "User Info Response containing user profile and token details")

public class UserInfoResponse {

  private String sub;

  private String name;

  private String preferredUsername;

  private String givenName;

  private String familyName;

  private String email;

  private Boolean emailVerified;

  private String userType;

  private Integer bankId = null;

  @Valid
  private List<String> realmRoles;

  @Valid
  private Map<String, List<String>> clientRoles = new HashMap<>();

  private String scope;

  private Long exp;

  private Long iat;

  private String jti;

  private String iss;

  private String aud;

  private String typ;

  private String azp;

  private String sid;

  private String acr;

  public UserInfoResponse sub(String sub) {
    this.sub = sub;
    return this;
  }

  /**
   * User ID (Subject)
   * @return sub
   */
  
  @Schema(name = "sub", example = "72e8db98-b02b-476a-98ec-699485348159", description = "User ID (Subject)", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("sub")
  public String getSub() {
    return sub;
  }

  public void setSub(String sub) {
    this.sub = sub;
  }

  public UserInfoResponse name(String name) {
    this.name = name;
    return this;
  }

  /**
   * Full name of the user
   * @return name
   */
  
  @Schema(name = "name", example = "manoj anand", description = "Full name of the user", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("name")
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public UserInfoResponse preferredUsername(String preferredUsername) {
    this.preferredUsername = preferredUsername;
    return this;
  }

  /**
   * Preferred username of the user
   * @return preferredUsername
   */
  
  @Schema(name = "preferredUsername", example = "manoj.illa", description = "Preferred username of the user", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("preferredUsername")
  public String getPreferredUsername() {
    return preferredUsername;
  }

  public void setPreferredUsername(String preferredUsername) {
    this.preferredUsername = preferredUsername;
  }

  public UserInfoResponse givenName(String givenName) {
    this.givenName = givenName;
    return this;
  }

  /**
   * Given name (first name) of the user
   * @return givenName
   */
  
  @Schema(name = "givenName", example = "manoj", description = "Given name (first name) of the user", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("givenName")
  public String getGivenName() {
    return givenName;
  }

  public void setGivenName(String givenName) {
    this.givenName = givenName;
  }

  public UserInfoResponse familyName(String familyName) {
    this.familyName = familyName;
    return this;
  }

  /**
   * Family name (last name) of the user
   * @return familyName
   */
  
  @Schema(name = "familyName", example = "anand", description = "Family name (last name) of the user", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("familyName")
  public String getFamilyName() {
    return familyName;
  }

  public void setFamilyName(String familyName) {
    this.familyName = familyName;
  }

  public UserInfoResponse email(String email) {
    this.email = email;
    return this;
  }

  /**
   * Email address of the user
   * @return email
   */
  
  @Schema(name = "email", example = "manoj.illa@iftas.in", description = "Email address of the user", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("email")
  public String getEmail() {
    return email;
  }

  public void setEmail(String email) {
    this.email = email;
  }

  public UserInfoResponse emailVerified(Boolean emailVerified) {
    this.emailVerified = emailVerified;
    return this;
  }

  /**
   * Indicates whether the email is verified
   * @return emailVerified
   */
  
  @Schema(name = "emailVerified", example = "false", description = "Indicates whether the email is verified", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("emailVerified")
  public Boolean getEmailVerified() {
    return emailVerified;
  }

  public void setEmailVerified(Boolean emailVerified) {
    this.emailVerified = emailVerified;
  }

  public UserInfoResponse userType(String userType) {
    this.userType = userType;
    return this;
  }

  /**
   * Indicates whether the User is an Operator or Banker
   * @return userType
   */
  
  @Schema(name = "userType", description = "Indicates whether the User is an Operator or Banker", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("userType")
  public String getUserType() {
    return userType;
  }

  public void setUserType(String userType) {
    this.userType = userType;
  }

  public UserInfoResponse bankId(Integer bankId) {
    this.bankId = bankId;
    return this;
  }

  /**
   * Bank ID of the user if User Type is Banker and is Null if is an Operator
   * @return bankId
   */
  
  @Schema(name = "bankId", description = "Bank ID of the user if User Type is Banker and is Null if is an Operator", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("bankId")
  public Integer getBankId() {
    return bankId;
  }

  public void setBankId(Integer bankId) {
    this.bankId = bankId;
  }

  public UserInfoResponse realmRoles(List<String> realmRoles) {
    this.realmRoles = realmRoles;
    return this;
  }

  public UserInfoResponse addItem(String realmRolesItem) {
    if (this.realmRoles == null) {
      this.realmRoles = new ArrayList<>();
    }
    this.realmRoles.add(realmRolesItem);
    return this;
  }

  /**
   * Roles assigned to the user at the realm level
   * @return realmRoles
   */
  
  @Schema(name = "realmRoles", description = "Roles assigned to the user at the realm level", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("realmRoles")
  public List<String> getRealmRoles() {
    return realmRoles;
  }

  public void setRealmRoles(List<String> realmRoles) {
    this.realmRoles = realmRoles;
  }

  public UserInfoResponse clientRoles(Map<String, List<String>> clientRoles) {
    this.clientRoles = clientRoles;
    return this;
  }

  public UserInfoResponse putItem(String key, List<String> clientRolesItem) {
    if (this.clientRoles == null) {
      this.clientRoles = new HashMap<>();
    }
    this.clientRoles.put(key, clientRolesItem);
    return this;
  }

  /**
   * Roles assigned to the user per client
   * @return clientRoles
   */
  @Valid 
  @Schema(name = "clientRoles", description = "Roles assigned to the user per client", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("clientRoles")
  public Map<String, List<String>> getClientRoles() {
    return clientRoles;
  }

  public void setClientRoles(Map<String, List<String>> clientRoles) {
    this.clientRoles = clientRoles;
  }

  public UserInfoResponse scope(String scope) {
    this.scope = scope;
    return this;
  }

  /**
   * Scopes associated with the token
   * @return scope
   */
  
  @Schema(name = "scope", example = "profile email", description = "Scopes associated with the token", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("scope")
  public String getScope() {
    return scope;
  }

  public void setScope(String scope) {
    this.scope = scope;
  }

  public UserInfoResponse exp(Long exp) {
    this.exp = exp;
    return this;
  }

  /**
   * Token expiration time (Unix timestamp)
   * @return exp
   */
  
  @Schema(name = "exp", example = "1725545667", description = "Token expiration time (Unix timestamp)", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("exp")
  public Long getExp() {
    return exp;
  }

  public void setExp(Long exp) {
    this.exp = exp;
  }

  public UserInfoResponse iat(Long iat) {
    this.iat = iat;
    return this;
  }

  /**
   * Token issued-at time (Unix timestamp)
   * @return iat
   */
  
  @Schema(name = "iat", example = "1725545607", description = "Token issued-at time (Unix timestamp)", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("iat")
  public Long getIat() {
    return iat;
  }

  public void setIat(Long iat) {
    this.iat = iat;
  }

  public UserInfoResponse jti(String jti) {
    this.jti = jti;
    return this;
  }

  /**
   * JWT ID (Unique identifier for the token)
   * @return jti
   */
  
  @Schema(name = "jti", example = "68055fbf-77f5-414a-86d4-cb60bc9a6ecd", description = "JWT ID (Unique identifier for the token)", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("jti")
  public String getJti() {
    return jti;
  }

  public void setJti(String jti) {
    this.jti = jti;
  }

  public UserInfoResponse iss(String iss) {
    this.iss = iss;
    return this;
  }

  /**
   * Issuer of the token
   * @return iss
   */
  
  @Schema(name = "iss", example = "http://localhost:3000/realms/master", description = "Issuer of the token", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("iss")
  public String getIss() {
    return iss;
  }

  public void setIss(String iss) {
    this.iss = iss;
  }

  public UserInfoResponse aud(String aud) {
    this.aud = aud;
    return this;
  }

  /**
   * Audience for which the token is intended
   * @return aud
   */
  
  @Schema(name = "aud", example = "account", description = "Audience for which the token is intended", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("aud")
  public String getAud() {
    return aud;
  }

  public void setAud(String aud) {
    this.aud = aud;
  }

  public UserInfoResponse typ(String typ) {
    this.typ = typ;
    return this;
  }

  /**
   * Type of the token
   * @return typ
   */
  
  @Schema(name = "typ", example = "Bearer", description = "Type of the token", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("typ")
  public String getTyp() {
    return typ;
  }

  public void setTyp(String typ) {
    this.typ = typ;
  }

  public UserInfoResponse azp(String azp) {
    this.azp = azp;
    return this;
  }

  /**
   * Authorized party (the client that requested the token)
   * @return azp
   */
  
  @Schema(name = "azp", example = "sfms-intranet", description = "Authorized party (the client that requested the token)", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("azp")
  public String getAzp() {
    return azp;
  }

  public void setAzp(String azp) {
    this.azp = azp;
  }

  public UserInfoResponse sid(String sid) {
    this.sid = sid;
    return this;
  }

  /**
   * Session ID
   * @return sid
   */
  
  @Schema(name = "sid", example = "83a24bfa-2664-46d8-acbb-ca0c129250ad", description = "Session ID", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("sid")
  public String getSid() {
    return sid;
  }

  public void setSid(String sid) {
    this.sid = sid;
  }

  public UserInfoResponse acr(String acr) {
    this.acr = acr;
    return this;
  }

  /**
   * Authentication context class reference
   * @return acr
   */
  
  @Schema(name = "acr", example = "1", description = "Authentication context class reference", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("acr")
  public String getAcr() {
    return acr;
  }

  public void setAcr(String acr) {
    this.acr = acr;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    UserInfoResponse userInfoResponse = (UserInfoResponse) o;
    return Objects.equals(this.sub, userInfoResponse.sub) &&
        Objects.equals(this.name, userInfoResponse.name) &&
        Objects.equals(this.preferredUsername, userInfoResponse.preferredUsername) &&
        Objects.equals(this.givenName, userInfoResponse.givenName) &&
        Objects.equals(this.familyName, userInfoResponse.familyName) &&
        Objects.equals(this.email, userInfoResponse.email) &&
        Objects.equals(this.emailVerified, userInfoResponse.emailVerified) &&
        Objects.equals(this.userType, userInfoResponse.userType) &&
        Objects.equals(this.bankId, userInfoResponse.bankId) &&
        Objects.equals(this.realmRoles, userInfoResponse.realmRoles) &&
        Objects.equals(this.clientRoles, userInfoResponse.clientRoles) &&
        Objects.equals(this.scope, userInfoResponse.scope) &&
        Objects.equals(this.exp, userInfoResponse.exp) &&
        Objects.equals(this.iat, userInfoResponse.iat) &&
        Objects.equals(this.jti, userInfoResponse.jti) &&
        Objects.equals(this.iss, userInfoResponse.iss) &&
        Objects.equals(this.aud, userInfoResponse.aud) &&
        Objects.equals(this.typ, userInfoResponse.typ) &&
        Objects.equals(this.azp, userInfoResponse.azp) &&
        Objects.equals(this.sid, userInfoResponse.sid) &&
        Objects.equals(this.acr, userInfoResponse.acr);
  }

  @Override
  public int hashCode() {
    return Objects.hash(sub, name, preferredUsername, givenName, familyName, email, emailVerified, userType, bankId, realmRoles, clientRoles, scope, exp, iat, jti, iss, aud, typ, azp, sid, acr);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class UserInfoResponse {\n");
    sb.append("    sub: ").append(toIndentedString(sub)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    preferredUsername: ").append(toIndentedString(preferredUsername)).append("\n");
    sb.append("    givenName: ").append(toIndentedString(givenName)).append("\n");
    sb.append("    familyName: ").append(toIndentedString(familyName)).append("\n");
    sb.append("    email: ").append(toIndentedString(email)).append("\n");
    sb.append("    emailVerified: ").append(toIndentedString(emailVerified)).append("\n");
    sb.append("    userType: ").append(toIndentedString(userType)).append("\n");
    sb.append("    bankId: ").append(toIndentedString(bankId)).append("\n");
    sb.append("    realmRoles: ").append(toIndentedString(realmRoles)).append("\n");
    sb.append("    clientRoles: ").append(toIndentedString(clientRoles)).append("\n");
    sb.append("    scope: ").append(toIndentedString(scope)).append("\n");
    sb.append("    exp: ").append(toIndentedString(exp)).append("\n");
    sb.append("    iat: ").append(toIndentedString(iat)).append("\n");
    sb.append("    jti: ").append(toIndentedString(jti)).append("\n");
    sb.append("    iss: ").append(toIndentedString(iss)).append("\n");
    sb.append("    aud: ").append(toIndentedString(aud)).append("\n");
    sb.append("    typ: ").append(toIndentedString(typ)).append("\n");
    sb.append("    azp: ").append(toIndentedString(azp)).append("\n");
    sb.append("    sid: ").append(toIndentedString(sid)).append("\n");
    sb.append("    acr: ").append(toIndentedString(acr)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

