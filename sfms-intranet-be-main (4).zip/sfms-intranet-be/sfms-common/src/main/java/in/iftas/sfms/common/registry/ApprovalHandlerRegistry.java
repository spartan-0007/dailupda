package in.iftas.sfms.common.registry;

import in.iftas.sfms.common.handler.ApprovalHandler;
import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
@Slf4j
public class ApprovalHandlerRegistry {

    @Autowired
    private List<ApprovalHandler> handlers;

    private final Map<String, ApprovalHandler> handlerMap = new HashMap<>();
    private ApprovalHandler fileUploadHandler;

    @PostConstruct
    public void initializeHandlers() {
        for (ApprovalHandler handler : handlers) {
            String entityType = handler.getEntityType().toUpperCase();

            if ("FILE_UPLOAD".equals(entityType)) {
                fileUploadHandler = handler;
                log.info("Registered FILE_UPLOAD handler for all FILE_* entity types");
            } else {
                handlerMap.put(entityType, handler);
                log.info("Registered approval handler for entity type: {}", entityType);
            }
        }
        log.info("Total registered handlers: {}", handlerMap.size() + (fileUploadHandler != null ? 1 : 0));
    }

    public ApprovalHandler getHandler(String entityType) {
        String upperEntityType = entityType.toUpperCase();

        if (upperEntityType.startsWith("FILE_") && fileUploadHandler != null) {
            log.debug("Routing {} to FileUploadHandler", entityType);
            return fileUploadHandler;
        }

        ApprovalHandler handler = handlerMap.get(upperEntityType);
        if (handler == null) {
            log.warn("No handler found for entity type: {}", entityType);
        }
        return handler;
    }

    public boolean hasHandler(String entityType) {
        String upperEntityType = entityType.toUpperCase();

        if (upperEntityType.startsWith("FILE_") && fileUploadHandler != null) {
            return true;
        }

        return handlerMap.containsKey(upperEntityType);
    }
}