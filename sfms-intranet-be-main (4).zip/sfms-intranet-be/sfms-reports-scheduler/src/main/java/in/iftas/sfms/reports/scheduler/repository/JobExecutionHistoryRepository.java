package in.iftas.sfms.reports.scheduler.repository;

import in.iftas.sfms.reports.scheduler.model.JobExecutionHistory;
import org.springframework.data.jpa.repository.JpaRepository;

public interface JobExecutionHistoryRepository extends JpaRepository<JobExecutionHistory, Long> {
}