package in.iftas.sfms.reports.scheduler.job;

import in.iftas.sfms.reports.scheduler.annotation.Job;
import org.springframework.stereotype.Component;

@Job(name = "exampleJob")
@Component("exampleJob")
public class ExampleJob implements JobInterface {

    @Override
    public void execute() {
        // write a logic to get the data from db and then download as xls
        System.out.println("Executing ExampleJob...");

    }
}