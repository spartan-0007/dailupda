package in.iftas.sfms.common.service;

/*
 * Copyright (C) 2024 Iftas Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Iftas Inc. ("Confidential Information"). You shall not disclose
 * such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with Iftas Inc.
 *
 * Author: Manoj.Illa
 * Date: May 11, 2025
 */


import in.iftas.sfms.auth.model.ApprovalRequest;
import in.iftas.sfms.common.entity.ApprovalRequestEntity;
import in.iftas.sfms.common.exception.ApprovalRequestNotFoundException;
import in.iftas.sfms.common.handler.ApprovalHandler;
import in.iftas.sfms.common.mapper.ApprovalRequestMapper;
import in.iftas.sfms.common.registry.ApprovalHandlerRegistry;
import in.iftas.sfms.common.repository.ApprovalRequestRepository;
import in.iftas.sfms.common.specification.ApprovalRequestSpecifications;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
@Slf4j
public class ApprovalService {

    private final ApprovalRequestRepository approvalRequestRepository;
    private final ApprovalRequestMapper approvalRequestMapper;
    private final ApprovalHandlerRegistry handlerRegistry;

    /**
     * Get approval requests with various filtering options and pagination
     * Returns a List of ApprovalRequest objects
     */
    @Transactional(readOnly = true)
    public List<ApprovalRequest> getApprovalRequests(
            String entityType,
            String status,
            String makerId,
            LocalDate fromDate,
            LocalDate toDate,
            String actionType,
            Integer page,
            Integer size) {

        log.info("Fetching approval requests with filters: entityType={}, status={}, makerId={}, " +
                        "fromDate={}, toDate={}, actionType={}",
                entityType, status, makerId, fromDate, toDate, actionType);

        Specification<ApprovalRequestEntity> spec = ApprovalRequestSpecifications.buildSpecification(
                status, entityType, makerId, fromDate, toDate, actionType);

        PageRequest pageRequest = PageRequest.of(page, size);
        Page<ApprovalRequestEntity> approvalEntities = approvalRequestRepository.findAll(spec, pageRequest);

        log.info("Found {} approval requests", approvalEntities.getTotalElements());

        return approvalEntities.getContent().stream()
                .map(approvalRequestMapper::toModel)
                .toList();
    }

    /**
     * Get pending approval requests for a specific entity type
     * Returns a List of ApprovalRequest objects
     */
    @Transactional(readOnly = true)
    public List<ApprovalRequest> getPendingApprovalsByEntityType(
            String entityType,
            Integer page,
            Integer size) {

        log.info("Fetching pending approval requests for entity type: {}", entityType);

        PageRequest pageRequest = PageRequest.of(page, size);
        Page<ApprovalRequestEntity> pendingApprovals = approvalRequestRepository.findByStatusAndEntityType(
                ApprovalRequestEntity.Status.PENDING.name(), entityType, pageRequest);

        log.info("Found {} pending approvals for entity type: {}",
                pendingApprovals.getTotalElements(), entityType);

        return pendingApprovals.getContent().stream()
                .map(approvalRequestMapper::toModel)
                .toList();
    }

    /**
     * Approve a request by ID
     */
    @Transactional
    public void approveRequest(Long approvalId) {
        log.info("Approving request with ID: {}", approvalId);

        // Fetch approval request
        ApprovalRequestEntity approval = approvalRequestRepository.findById(approvalId)
                .orElseThrow(() -> {
                    log.error("Approval request not found with ID: {}", approvalId);
                    throw new RuntimeException("Approval request not found with ID: " + approvalId);
                });

        // Check if already processed
        if (!ApprovalRequestEntity.Status.PENDING.name().equals(approval.getStatus())) {
            log.warn("Approval request {} is already processed with status: {}", approvalId, approval.getStatus());
            throw new RuntimeException("Approval request is already processed");
        }

        // Get current user info
        Jwt jwt = (Jwt) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        String checkerId = jwt.getClaimAsString("sub");
        String checkerName = jwt.getClaimAsString("name");

        approval.setStatus(ApprovalRequestEntity.Status.APPROVED);
        approval.setApprovalDate(LocalDateTime.now());
        approval.setCheckerId(checkerId);
        approval.setCheckerName(checkerName);

        approvalRequestRepository.save(approval);

        ApprovalHandler handler = handlerRegistry.getHandler(approval.getEntityType());

        if (handler != null) {
            try {
                handler.handleApproval(
                        approvalId,
                        approval.getActionType(),
                        approval.getRequestData(),
                        approval.getEntityId()
                );
                log.info("Successfully processed approval for entity type: {} with ID: {}",
                        approval.getEntityType(), approvalId);
            } catch (Exception e) {
                log.error("Error processing approval for entity type: {} with ID: {}",
                        approval.getEntityType(), approvalId, e);

                approval.setStatus(ApprovalRequestEntity.Status.PENDING);
                approval.setApprovalDate(null);
                approval.setCheckerId(null);
                approval.setCheckerName(null);
                approvalRequestRepository.save(approval);

                throw new RuntimeException("Failed to process approval: " + e.getMessage(), e);
            }
        } else {
            log.error("No handler found for entity type: {} with approval ID: {}",
                    approval.getEntityType(), approvalId);

            approval.setStatus(ApprovalRequestEntity.Status.PENDING);
            approval.setApprovalDate(null);
            approval.setCheckerId(null);
            approval.setCheckerName(null);
            approvalRequestRepository.save(approval);

            throw new RuntimeException("No handler configured for entity type: " + approval.getEntityType());
        }
    }

    /**
     * Reject a request by ID
     */
    @Transactional
    public void rejectRequest(Long approvalId, String rejectionReason) {
        log.info("Rejecting request with ID: {}", approvalId);

        ApprovalRequestEntity approval = approvalRequestRepository.findById(approvalId)
                .orElseThrow(() -> {
                    log.error("Approval request not found with ID: {}", approvalId);
                    throw new RuntimeException("Approval request not found with ID: " + approvalId);
                });

        if (!ApprovalRequestEntity.Status.PENDING.name().equals(approval.getStatus())) {
            log.warn("Approval request {} is already processed with status: {}", approvalId, approval.getStatus());
            throw new RuntimeException("Approval request is already processed");
        }

        Jwt jwt = (Jwt) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        String checkerId = jwt.getClaimAsString("sub");
        String checkerName = jwt.getClaimAsString("name");

        approval.setStatus(ApprovalRequestEntity.Status.REJECTED);
        approval.setRejectionReason(rejectionReason);
        approval.setCheckerId(checkerId);
        approval.setCheckerName(checkerName);

        approvalRequestRepository.save(approval);
    }
    /**
     * Deletes an approval request by its ID.
     *
     * @param id the ID of the approval request
     * @throws ApprovalRequestNotFoundException if the request does not exist
     */
    @Transactional
    public void deleteApprovalRequestById(Long id) {
        Optional<ApprovalRequestEntity> optionalApprovalRequest = approvalRequestRepository.findById(id);
        if (optionalApprovalRequest.isEmpty()) {
            throw new ApprovalRequestNotFoundException(id);
        }
        approvalRequestRepository.deleteById(id);
    }

}