package in.iftas.sfms.auth.model;

import java.net.URI;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonTypeName;
import org.openapitools.jackson.nullable.JsonNullable;
import java.time.OffsetDateTime;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


import java.util.*;
import jakarta.annotation.Generated;

/**
 * UserResponseAccess
 */

@JsonTypeName("UserResponse_access")

public class UserResponseAccess {

  private Boolean manageGroupMembership;

  private Boolean view;

  private Boolean mapRoles;

  private Boolean impersonate;

  private Boolean manage;

  public UserResponseAccess manageGroupMembership(Boolean manageGroupMembership) {
    this.manageGroupMembership = manageGroupMembership;
    return this;
  }

  /**
   * Get manageGroupMembership
   * @return manageGroupMembership
   */
  
  @Schema(name = "manageGroupMembership", example = "true", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("manageGroupMembership")
  public Boolean getManageGroupMembership() {
    return manageGroupMembership;
  }

  public void setManageGroupMembership(Boolean manageGroupMembership) {
    this.manageGroupMembership = manageGroupMembership;
  }

  public UserResponseAccess view(Boolean view) {
    this.view = view;
    return this;
  }

  /**
   * Get view
   * @return view
   */
  
  @Schema(name = "view", example = "true", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("view")
  public Boolean getView() {
    return view;
  }

  public void setView(Boolean view) {
    this.view = view;
  }

  public UserResponseAccess mapRoles(Boolean mapRoles) {
    this.mapRoles = mapRoles;
    return this;
  }

  /**
   * Get mapRoles
   * @return mapRoles
   */
  
  @Schema(name = "mapRoles", example = "true", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("mapRoles")
  public Boolean getMapRoles() {
    return mapRoles;
  }

  public void setMapRoles(Boolean mapRoles) {
    this.mapRoles = mapRoles;
  }

  public UserResponseAccess impersonate(Boolean impersonate) {
    this.impersonate = impersonate;
    return this;
  }

  /**
   * Get impersonate
   * @return impersonate
   */
  
  @Schema(name = "impersonate", example = "true", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("impersonate")
  public Boolean getImpersonate() {
    return impersonate;
  }

  public void setImpersonate(Boolean impersonate) {
    this.impersonate = impersonate;
  }

  public UserResponseAccess manage(Boolean manage) {
    this.manage = manage;
    return this;
  }

  /**
   * Get manage
   * @return manage
   */
  
  @Schema(name = "manage", example = "true", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("manage")
  public Boolean getManage() {
    return manage;
  }

  public void setManage(Boolean manage) {
    this.manage = manage;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    UserResponseAccess userResponseAccess = (UserResponseAccess) o;
    return Objects.equals(this.manageGroupMembership, userResponseAccess.manageGroupMembership) &&
        Objects.equals(this.view, userResponseAccess.view) &&
        Objects.equals(this.mapRoles, userResponseAccess.mapRoles) &&
        Objects.equals(this.impersonate, userResponseAccess.impersonate) &&
        Objects.equals(this.manage, userResponseAccess.manage);
  }

  @Override
  public int hashCode() {
    return Objects.hash(manageGroupMembership, view, mapRoles, impersonate, manage);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class UserResponseAccess {\n");
    sb.append("    manageGroupMembership: ").append(toIndentedString(manageGroupMembership)).append("\n");
    sb.append("    view: ").append(toIndentedString(view)).append("\n");
    sb.append("    mapRoles: ").append(toIndentedString(mapRoles)).append("\n");
    sb.append("    impersonate: ").append(toIndentedString(impersonate)).append("\n");
    sb.append("    manage: ").append(toIndentedString(manage)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

