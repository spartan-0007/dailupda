package in.iftas.sfms.common.repository;


import in.iftas.sfms.common.entity.ApprovalRequestEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface ApprovalRequestRepository
        extends JpaRepository<ApprovalRequestEntity, Long>,
        JpaSpecificationExecutor<ApprovalRequestEntity> {

    List<ApprovalRequestEntity> findByStatus(String status);

    List<ApprovalRequestEntity> findByStatusAndEntityType(String status, String entityType);

    List<ApprovalRequestEntity> findByCreatedBy(String makerId);

    List<ApprovalRequestEntity> findByCheckerId(String checkerId);

    // Fix for the type mismatch error - Option 1: Change parameter type
    List<ApprovalRequestEntity> findByEntityTypeAndEntityId(String entityType, Long entityId);

    // Alternative Option 2: Add a string version with explicit conversion
    @Query("SELECT a FROM ApprovalRequestEntity a WHERE a.entityType = :entityType AND CAST(a.entityId AS string) = :entityId")
    List<ApprovalRequestEntity> findByEntityTypeAndEntityIdString(
            @Param("entityType") String entityType,
            @Param("entityId") String entityId
    );

    List<ApprovalRequestEntity> findByStatusAndCreatedDateBefore(String status, LocalDateTime cutoffDate);

    Page<ApprovalRequestEntity> findByStatus(String status, Pageable pageable);

    Page<ApprovalRequestEntity> findByStatusAndEntityType(String status, String entityType, Pageable pageable);

    Page<ApprovalRequestEntity> findByStatusAndEntityTypeAndCreatedByAndCreatedDateBetween(
            String status, String entityType, String makerId,
            LocalDateTime fromDate, LocalDateTime toDate, Pageable pageable);
}