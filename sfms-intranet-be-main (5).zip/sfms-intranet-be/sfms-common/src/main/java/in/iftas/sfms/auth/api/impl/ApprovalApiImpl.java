package in.iftas.sfms.auth.api.impl;

/*
 * Copyright (C) 2024 Iftas Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Iftas Inc. ("Confidential Information"). You shall not disclose
 * such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with Iftas Inc.
 *
 * Author: Manoj.Illa
 * Date: May 11, 2025
 */

import in.iftas.sfms.auth.api.ApprovalsApi;
import in.iftas.sfms.auth.model.ApiResponseError;
import in.iftas.sfms.auth.model.ApprovalRequest;
import in.iftas.sfms.auth.model.ModelApiResponse;
import in.iftas.sfms.auth.model.RejectApproval;
import in.iftas.sfms.common.service.ApprovalService;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;

@RestController
@RequiredArgsConstructor
@Slf4j
public class ApprovalApiImpl implements ApprovalsApi {

    private final ApprovalService approvalService;

    @Override
    public ResponseEntity<ModelApiResponse> approvalsGet(Integer page, Integer size, String entityType, String status,
                                                         String makerId, Date fromDate, Date toDate) {

        log.info("Entering approvalsGet method with parameters: page={}, size={}, entityType={}, status={}, makerId={}, fromDate={}, toDate={}",
                page, size, entityType, status, makerId, fromDate, toDate);

        ModelApiResponse response = new ModelApiResponse();

        try {
            LocalDateTime fromLocalDateTime = fromDate != null ?
                    fromDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime() : null;

            LocalDateTime toLocalDateTime = toDate != null ?
                    toDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime() : null;

            List<ApprovalRequest> approvalRequests = approvalService.getApprovalRequests(
                    entityType, status, makerId, fromLocalDateTime, toLocalDateTime, null, page, size);

            response.setSuccess(true);
            response.setMessage("Approval requests retrieved successfully");
            response.setData(Collections.singletonMap("approvals", approvalRequests));

            log.info("Successfully retrieved {} approval requests", approvalRequests.size());

            return new ResponseEntity<>(response, HttpStatus.OK);

        } catch (Exception e) {
            log.error("Error retrieving approval requests: {}", e.getMessage(), e);

            response.setSuccess(false);
            response.setMessage("Failed to retrieve approval requests");
            ApiResponseError error = new ApiResponseError();
            error.setCode("APPROVAL_REQUEST_FETCH_FAILED");
            error.setMessage(e.getMessage());
            response.setError(error);

            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    public ResponseEntity<ModelApiResponse> approvalsIdApprovePost(Integer id) {

        log.info("Entering approvalsIdApprovePost method with approval request ID: {}", id);

        ModelApiResponse response = new ModelApiResponse();

        try {
            // Convert Integer to Long as the service method expects Long
            approvalService.approveRequest(id.longValue());

            response.setSuccess(true);
            response.setMessage("Approval request processed successfully");

            log.info("Successfully approved request with ID: {}", id);

            return new ResponseEntity<>(response, HttpStatus.OK);

        } catch (RuntimeException e) {
            log.error("Error processing approval request with ID: {}", id, e);

            response.setSuccess(false);
            response.setMessage("Failed to approve request");

            ApiResponseError error = new ApiResponseError();

            // Determine appropriate error code and HTTP status
            if (e.getMessage().contains("not found")) {
                error.setCode("APPROVAL_REQUEST_NOT_FOUND");
                return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
            } else if (e.getMessage().contains("already processed")) {
                error.setCode("APPROVAL_REQUEST_ALREADY_PROCESSED");
                return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
            } else if (e.getMessage().contains("No handler")) {
                error.setCode("APPROVAL_HANDLER_NOT_CONFIGURED");
                return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
            } else {
                error.setCode("APPROVAL_REQUEST_PROCESS_FAILED");
                return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }
    }

    @Override
    public ResponseEntity<ModelApiResponse> approvalsIdRejectPost(Long id, RejectApproval rejectApproval) {
        log.info("Entering approvalsIdApprovePost method with approval request ID: {}", id);

        ModelApiResponse response = new ModelApiResponse();
        try {
            approvalService.rejectRequest(id, rejectApproval.getReason());
            response.setSuccess(true);
            response.setMessage("Reject request processed successfully");

            log.info("Successfully approved request with ID: {}", id);

            return new ResponseEntity<>(response, HttpStatus.OK);

        } catch (RuntimeException e) {
            log.error("Error processing approval request with ID: {}", id, e);

            response.setSuccess(false);
            response.setMessage("Failed to approve request");
            ApiResponseError error = new ApiResponseError();
            if (e.getMessage().contains("not found")) {
                error.setCode("APPROVAL_REQUEST_NOT_FOUND");
                return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
            } else if (e.getMessage().contains("already processed")) {
                error.setCode("APPROVAL_REQUEST_ALREADY_PROCESSED");
                return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
            } else if (e.getMessage().contains("No handler")) {
                error.setCode("APPROVAL_HANDLER_NOT_CONFIGURED");
                return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
            } else {
                error.setCode("APPROVAL_REQUEST_PROCESS_FAILED");
                return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }
    }


}
