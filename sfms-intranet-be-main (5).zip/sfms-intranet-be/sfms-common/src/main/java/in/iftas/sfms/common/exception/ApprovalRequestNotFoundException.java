package in.iftas.sfms.common.exception;

public class ApprovalRequestNotFoundException extends RuntimeException {
    public ApprovalRequestNotFoundException(Long id) {
        super("Approval request with ID " + id + " not found.");
    }}