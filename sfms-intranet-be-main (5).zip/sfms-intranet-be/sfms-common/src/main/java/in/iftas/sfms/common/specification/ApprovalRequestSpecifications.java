package in.iftas.sfms.common.specification;


import in.iftas.sfms.common.entity.ApprovalRequestEntity;
import org.springframework.data.jpa.domain.Specification;

import java.time.LocalDateTime;

public class ApprovalRequestSpecifications {

    public static Specification<ApprovalRequestEntity> hasStatus(String status) {
        return (root, query, criteriaBuilder) -> 
                criteriaBuilder.equal(root.get("status"), status);
    }
    
    public static Specification<ApprovalRequestEntity> hasEntityType(String entityType) {
        return (root, query, criteriaBuilder) -> 
                criteriaBuilder.equal(root.get("entityType"), entityType);
    }
    
    public static Specification<ApprovalRequestEntity> hasMakerId(String makerId) {
        return (root, query, criteriaBuilder) -> 
                criteriaBuilder.equal(root.get("makerId"), makerId);
    }
    
    public static Specification<ApprovalRequestEntity> hasCheckerId(String checkerId) {
        return (root, query, criteriaBuilder) -> 
                criteriaBuilder.equal(root.get("checkerId"), checkerId);
    }
    
    public static Specification<ApprovalRequestEntity> createdAfter(LocalDateTime date) {
        return (root, query, criteriaBuilder) -> 
                criteriaBuilder.greaterThanOrEqualTo(root.get("createdDate"), date);
    }
    
    public static Specification<ApprovalRequestEntity> createdBefore(LocalDateTime date) {
        return (root, query, criteriaBuilder) -> 
                criteriaBuilder.lessThanOrEqualTo(root.get("createdDate"), date);
    }
    
    public static Specification<ApprovalRequestEntity> hasActionType(String actionType) {
        return (root, query, criteriaBuilder) -> 
                criteriaBuilder.equal(root.get("actionType"), actionType);
    }
    
    // Helper method to combine specifications dynamically
    public static Specification<ApprovalRequestEntity> buildSpecification(
            String status, String entityType, String makerId, 
            LocalDateTime fromDate, LocalDateTime toDate, String actionType) {
        
        Specification<ApprovalRequestEntity> spec = Specification.where(null);
        
        if (status != null) {
            spec = spec.and(hasStatus(status));
        }
        
        if (entityType != null) {
            spec = spec.and(hasEntityType(entityType));
        }
        
        if (makerId != null) {
            spec = spec.and(hasMakerId(makerId));
        }
        
        if (fromDate != null) {
            spec = spec.and(createdAfter(fromDate));
        }
        
        if (toDate != null) {
            spec = spec.and(createdBefore(toDate));
        }
        
        if (actionType != null) {
            spec = spec.and(hasActionType(actionType));
        }
        
        return spec;
    }
}
