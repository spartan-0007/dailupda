package in.iftas.sfms.common.mapper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import in.iftas.sfms.auth.model.ApprovalRequest;
import in.iftas.sfms.common.entity.ApprovalRequestEntity;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;

@Mapper(componentModel = "spring")
public interface ApprovalRequestMapper {

    ApprovalRequestMapper INSTANCE = Mappers.getMapper(ApprovalRequestMapper.class);

    @Mapping(source = "entityType", target = "entityType", qualifiedByName = "stringToEntityTypeEnum")
    @Mapping(source = "actionType", target = "actionType", qualifiedByName = "stringToActionTypeEnum")
    @Mapping(source = "status", target = "status", qualifiedByName = "stringToStatusEnum")
    @Mapping(source = "requestData", target = "requestData", qualifiedByName = "jsonStringToObject")
    @Mapping(source = "requestMetadata", target = "requestMetadata", qualifiedByName = "jsonStringToObject")
    @Mapping(source = "approvalDate", target = "approvalDate", qualifiedByName = "localDateTimeToDate")
    @Mapping(source = "createdDate", target = "createdDate", qualifiedByName = "localDateTimeToDate")
    @Mapping(source = "createdBy", target = "makerId") // Map createdBy to makerId
    ApprovalRequest toModel(ApprovalRequestEntity entity);

    @Mapping(source = "entityType", target = "entityType", qualifiedByName = "entityTypeEnumToString")
    @Mapping(source = "actionType", target = "actionType", qualifiedByName = "actionTypeEnumToString")
    @Mapping(source = "status", target = "status", qualifiedByName = "statusEnumToString")
    @Mapping(source = "requestData", target = "requestData", qualifiedByName = "objectToJsonString")
    @Mapping(source = "requestMetadata", target = "requestMetadata", qualifiedByName = "objectToJsonString")
    @Mapping(source = "approvalDate", target = "approvalDate", qualifiedByName = "dateToLocalDateTime")
    @Mapping(source = "createdDate", target = "createdDate", qualifiedByName = "dateToLocalDateTime")
    @Mapping(source = "makerId", target = "createdBy") // Map makerId to createdBy
    ApprovalRequestEntity toEntity(ApprovalRequest model);

    @Mapping(source = "entityType", target = "entityType", qualifiedByName = "entityTypeEnumToString")
    @Mapping(source = "actionType", target = "actionType", qualifiedByName = "actionTypeEnumToString")
    @Mapping(source = "status", target = "status", qualifiedByName = "statusEnumToString")
    @Mapping(source = "requestData", target = "requestData", qualifiedByName = "objectToJsonString")
    @Mapping(source = "requestMetadata", target = "requestMetadata", qualifiedByName = "objectToJsonString")
    @Mapping(source = "approvalDate", target = "approvalDate", qualifiedByName = "dateToLocalDateTime")
    @Mapping(source = "makerId", target = "createdBy") // Map makerId to createdBy
    void updateEntity(ApprovalRequest model, @MappingTarget ApprovalRequestEntity entity);

    // AfterMapping method to set makerName based on entity data
    @AfterMapping
    default void setAdditionalFields(ApprovalRequestEntity entity, @MappingTarget ApprovalRequest model) {
        // Set makerName from the entity's makerName field
        model.setMakerName(entity.getMakerName());

        // If the model makerId is null (which might happen if createdBy is null),
        // try to use the entity's makerId directly
        if (model.getMakerId() == null && entity.getCreatedBy() == null) {
            model.setMakerId(entity.getCreatedBy());
        }
    }

    // AfterMapping method for entity to ensure makerName is preserved
    @AfterMapping
    default void setEntityAdditionalFields(ApprovalRequest model, @MappingTarget ApprovalRequestEntity entity) {
        // Set makerName from model to entity
        entity.setMakerName(model.getMakerName());

        // If the entity's createdBy is null, try to use the model's makerId
        if (entity.getCreatedBy() == null && model.getMakerId() != null) {
            entity.setCreatedBy(model.getMakerId());
        }
    }

    @Named("stringToEntityTypeEnum")
    default ApprovalRequest.EntityTypeEnum stringToEntityTypeEnum(String entityType) {
        if (entityType == null) return null;
        try {
            return ApprovalRequest.EntityTypeEnum.fromValue(entityType);
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    @Named("entityTypeEnumToString")
    default String entityTypeEnumToString(ApprovalRequest.EntityTypeEnum entityType) {
        if (entityType == null) return null;
        return entityType.getValue();
    }

    @Named("stringToActionTypeEnum")
    default ApprovalRequest.ActionTypeEnum stringToActionTypeEnum(String actionType) {
        if (actionType == null) return null;
        try {
            return ApprovalRequest.ActionTypeEnum.fromValue(actionType);
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    @Named("actionTypeEnumToString")
    default String actionTypeEnumToString(ApprovalRequest.ActionTypeEnum actionType) {
        if (actionType == null) return null;
        return actionType.getValue();
    }

    @Named("stringToStatusEnum")
    default ApprovalRequest.StatusEnum stringToStatusEnum(String status) {
        if (status == null) return null;
        try {
            return ApprovalRequest.StatusEnum.fromValue(status);
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    @Named("statusEnumToString")
    default String statusEnumToString(ApprovalRequest.StatusEnum status) {
        if (status == null) return null;
        return status.getValue();
    }

    // Handle ObjectMapper for JSON conversion with Spring injection
    @Autowired
    default ObjectMapper objectMapper() {
        return new ObjectMapper();
    }

    @Named("jsonStringToObject")
    default Object jsonStringToObject(String json) {
        if (json == null || json.isEmpty()) return null;
        try {
            return objectMapper().readTree(json);
        } catch (IOException e) {
            throw new RuntimeException("Error parsing JSON: " + e.getMessage(), e);
        }
    }

    @Named("objectToJsonString")
    default String objectToJsonString(Object obj) {
        if (obj == null) return null;
        try {
            return objectMapper().writeValueAsString(obj);
        } catch (JsonProcessingException e) {
            throw new RuntimeException("Error serializing to JSON: " + e.getMessage(), e);
        }
    }

    @Named("localDateTimeToDate")
    default Date localDateTimeToDate(LocalDateTime localDateTime) {
        if (localDateTime == null) return null;
        return Date.from(localDateTime.atZone(ZoneId.systemDefault()).toInstant());
    }

    @Named("dateToLocalDateTime")
    default LocalDateTime dateToLocalDateTime(Date date) {
        if (date == null) return null;
        return LocalDateTime.ofInstant(date.toInstant(), ZoneId.systemDefault());
    }
}