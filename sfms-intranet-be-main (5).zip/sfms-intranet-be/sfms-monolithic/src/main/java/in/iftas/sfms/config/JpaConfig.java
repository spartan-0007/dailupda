package in.iftas.sfms.config;

/*
 * Copyright (C) 2024 Iftas Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Iftas Inc. ("Confidential Information"). You shall not disclose
 * such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with Iftas Inc.
 *
 * Author: Manoj.Illa
 * Date: July 11, 2024
 */

import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@Configuration
@EnableJpaRepositories(basePackages = {"in.iftas.sfms.auth.repository", "in.iftas.sfms.core.repository", "in.iftas.sfms.common.repository"})
@EntityScan(basePackages = {"in.iftas.sfms.auth.entity", "in.iftas.sfms.core.entity", "in.iftas.sfms.common.entity"})
public class JpaConfig {
}
