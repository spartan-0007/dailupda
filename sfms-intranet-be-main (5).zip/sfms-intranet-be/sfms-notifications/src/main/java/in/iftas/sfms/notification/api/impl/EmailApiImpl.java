package in.iftas.sfms.notification.api.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import in.iftas.sfms.notification.api.EmailApi;
import in.iftas.sfms.notification.model.ModelApiResponse;
import in.iftas.sfms.notification.service.EmailService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class EmailApiImpl implements EmailApi {

    private final EmailService emailService;

    private static final Logger logger = LoggerFactory.getLogger(EmailApiImpl.class);

    @Autowired
    public EmailApiImpl(EmailService emailService) {
        this.emailService = emailService;
    }

    @Override
    public ResponseEntity<ModelApiResponse> emailPost(@RequestParam("content") String content) {

        logger.info("Received email send request");

        boolean isSent = false;
        try {
            isSent = emailService.sendEmail(content);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }

        ModelApiResponse response = new ModelApiResponse();
        if (isSent) {
            response.setSuccess(true);
            response.setMessage("Email sent successfully!");
            logger.info("Email sent successfully");
            return new ResponseEntity<>(response, HttpStatus.OK);
        } else {
            response.setSuccess(false);
            response.setMessage("Failed to send email.");
            logger.error("Failed to send email.");
            return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
        }
    }

}
