package in.iftas.sfms.notification.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import in.iftas.sfms.notification.model.EmailContent;
import in.iftas.sfms.notification.service.EmailService;
import jakarta.mail.internet.MimeMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.thymeleaf.context.Context;
import org.thymeleaf.spring6.SpringTemplateEngine;

@Service
public class EmailServiceImpl implements EmailService {

    private final JavaMailSender mailSender;
    private final SpringTemplateEngine templateEngine;
    private final ObjectMapper objectMapper;

    private static final Logger logger = LoggerFactory.getLogger(EmailServiceImpl.class);

    @Autowired
    public EmailServiceImpl(JavaMailSender mailSender, SpringTemplateEngine templateEngine, ObjectMapper objectMapper) {
        this.mailSender = mailSender;
        this.templateEngine = templateEngine;
        this.objectMapper = objectMapper;
    }

    @Override
    public boolean sendEmail(String emailContent) throws JsonProcessingException {
        logger.info("Entering sendEmail method");
        EmailContent content = objectMapper.readValue(emailContent, EmailContent.class);

        String toEmail = content.getToEmail();
        String otp = content.getOtp();
        String template = content.getTemplate();

        logger.info("The extracted content is " + toEmail + " - " + otp + " - " + template);

        Context context = new Context();
        context.setVariable("otp", otp);

        logger.info("Processing the template with the context");
        String body = templateEngine.process(template, context);
        logger.info("Generated email for template: {}", template);

        try {
            MimeMessage mimeMessage = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true);
            helper.setSubject("OTP Verification");
            helper.setText(body, true);
            helper.setTo(toEmail);
            helper.setFrom("noreply.intranet@iftas.in");
            mailSender.send(mimeMessage);
            logger.info("Email sent to: {}", toEmail);
            return true;
        } catch (Exception e) {
            logger.error("Error sending email to {}: {}", toEmail, e.getMessage(), e);
            return false;
        }
    }
}