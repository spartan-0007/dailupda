CREATE TABLE IF NOT EXISTS i_lc_bg_messages (
    id BIGINT NOT NULL,
    sender_ifsc VARCHAR(11) NOT NULL,
    receiver_ifsc VARCHAR(11) NOT NULL,
    sender_reference_number VARCHAR(255) NOT NULL,
    message_type VARCHAR(50) NOT NULL,
    message_status VARCHAR(50) NOT NULL,
    message_date DATETIME NOT NULL,
    half_year TINYINT NOT NULL,
    upload_date DATETIME DEFAULT CURRENT_TIMESTAMP NOT NULL,
    PRIMARY KEY (id, half_year),  -- Primary key includes both id and half_year
    UNIQUE KEY unique_partition (sender_reference_number, half_year),  -- Unique key includes both sender_reference_number and half_year
    INDEX idx_sender_ifsc (sender_ifsc),
    INDEX idx_receiver_ifsc (receiver_ifsc),
    INDEX idx_message_date (message_date)
)
PARTITION BY RANGE (half_year) (
    PARTITION p_h1_2023 VALUES LESS THAN (2),  -- H1 (Jan-Jun)
    PARTITION p_h2_2023 VALUES LESS THAN (3),  -- H2 (Jul-Dec)
    PARTITION p_h1_2024 VALUES LESS THAN (4),
    PARTITION p_h2_2024 VALUES LESS THAN (5),
    PARTITION future VALUES LESS THAN MAXVALUE
);