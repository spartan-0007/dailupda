package in.iftas.sfms.core.api.impl;

import in.iftas.sfms.core.api.FileUploadApprovalsApi;
import in.iftas.sfms.core.exception.ResourceNotFoundException;
import in.iftas.sfms.core.model.ModelApiResponse;
import in.iftas.sfms.core.service.FileUploadApprovalService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

/**
 * Controller implementation for handling CGBS file uploads that require approval.
 * This controller follows the API contract defined in FileUploadApprovalsApi interface.
 */
@RestController
@RequiredArgsConstructor
@Slf4j
public class FileUploadApprovalsApiImpl implements FileUploadApprovalsApi {

    private final FileUploadApprovalService fileUploadApprovalService;

    /**
     * Handles the upload of a CGBS ZIP file and creates an approval request for it.
     *
     * @param file               The patch file to be uploaded (e.g., a ZIP file)
     * @param fileUploadApproval The JSON metadata about the patch (e.g., version, uploadedBy, bankIds)
     * @return ResponseEntity with the API response and appropriate HTTP status code
     */
    @Override
    public ResponseEntity<ModelApiResponse> fileUploadApprovals(MultipartFile file, String fileUploadApproval, String json) {
        log.info("Entering fileUploadApprovals method with file: {}, details: {}",
                file != null ? file.getOriginalFilename() : "null", fileUploadApproval);

        if (file == null || file.isEmpty()) {
            log.warn("No file uploaded or file is empty");
            ModelApiResponse response = new ModelApiResponse()
                    .success(false)
                    .message("File is required and cannot be empty");
            return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
        }

        try {
            fileUploadApprovalService.processFileUploadApproval(file, fileUploadApproval, json);

            log.info("File upload approval request created successfully for file: {}", file.getOriginalFilename());
            ModelApiResponse response = new ModelApiResponse();
            response.setSuccess(true);
            response.setMessage("File upload approval request created successfully");
            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch (IllegalArgumentException e) {
            log.warn("Validation error: {}", e.getMessage());
            ModelApiResponse response = new ModelApiResponse()
                    .success(false)
                    .message(e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
        } catch (Exception e) {
            log.error("Error processing file upload approval: {}", e.getMessage(), e);
            ModelApiResponse response = new ModelApiResponse()
                    .success(false)
                    .message("Server encountered an error while processing the request");
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    public ResponseEntity<ModelApiResponse> fileUploadApprovalsIdDelete(Integer id, String entityType, Long entityId) {
        try {
            fileUploadApprovalService.deleteFileUploadApproval(id, entityType);

            ModelApiResponse response = new ModelApiResponse();
            response.setSuccess(true);
            response.setMessage("File upload deletion approval request created successfully");

            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (ResourceNotFoundException e) {
            log.error("File upload not found: {}", e.getMessage());
            ModelApiResponse response = new ModelApiResponse()
                    .success(false)
                    .message(e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            log.error("Error creating file upload deletion approval: {}", e.getMessage(), e);
            ModelApiResponse response = new ModelApiResponse()
                    .success(false)
                    .message(e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    public ResponseEntity<ModelApiResponse> fileUploadApprovalsIdPut(Integer id, String fileUploadApproval, String json) {

        log.info("Entering fileUploadApprovalsIdPut method with ID: {}, file: {}, details: {}");


        try {
            fileUploadApprovalService.processFileUpdateApproval(id, fileUploadApproval, json);

            log.info("File update approval request created successfully for file: {}");
            ModelApiResponse response = new ModelApiResponse()
                    .success(true)
                    .message("File update approval request created successfully");
            return new ResponseEntity<>(response, HttpStatus.OK);

        } catch (ResourceNotFoundException e) {
            log.warn("Resource not found: {}", e.getMessage());
            ModelApiResponse response = new ModelApiResponse()
                    .success(false)
                    .message(e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
        } catch (IllegalArgumentException e) {
            log.warn("Validation error: {}", e.getMessage());
            ModelApiResponse response = new ModelApiResponse()
                    .success(false)
                    .message(e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
        } catch (Exception e) {
            log.error("Error processing file update approval: {}", e.getMessage(), e);
            ModelApiResponse response = new ModelApiResponse()
                    .success(false)
                    .message("Server encountered an error while processing the request");
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}