package in.iftas.sfms.core.service;

/*
 * Copyright (C) 2024 Iftas Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Iftas Inc. ("Confidential Information"). You shall not disclose
 * such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with Iftas Inc.
 *
 * Author: Manoj.Illa
 * Date: July 11, 2024
 */

import in.iftas.sfms.core.entity.ChangeRequestFormEntity;
import in.iftas.sfms.core.entity.CrfIpEntity;
import in.iftas.sfms.core.exception.ResourceNotFoundException;
import in.iftas.sfms.core.mapper.ChangeRequestFormMapper;
import in.iftas.sfms.core.model.ChangeRequestForm;
import in.iftas.sfms.core.model.CrfIp;
import in.iftas.sfms.core.repository.BankRepository;
import in.iftas.sfms.core.repository.ChangeRequestFormRepository;
import in.iftas.sfms.core.repository.CrfIpRepository;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.thymeleaf.spring6.SpringTemplateEngine;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

@Service
public class ChangeRequestFormService {

    private static final Logger logger = LoggerFactory.getLogger(ChangeRequestFormService.class);
    private final ChangeRequestFormRepository changeRequestFormRepository;
    private final CrfIpRepository crfIpRepository;
    private final SpringTemplateEngine templateEngine;
    private final BankRepository bankRepository;
    private final SftpService sftpService;
    private final ChangeRequestFormMapper changeRequestFormMapper;


    public ChangeRequestFormService(ChangeRequestFormRepository changeRequestFormRepository,
                                    CrfIpRepository crfIpRepository,
                                    SpringTemplateEngine templateEngine,
                                    BankRepository bankRepository,
                                    SftpService sftpService,
                                    ChangeRequestFormMapper changeRequestFormMapper) {
        this.changeRequestFormRepository = changeRequestFormRepository;
        this.crfIpRepository = crfIpRepository;
        this.templateEngine = templateEngine;
        this.bankRepository = bankRepository;
        this.sftpService = sftpService;
        this.changeRequestFormMapper = changeRequestFormMapper;
    }

    public void saveChangeRequestForm(ChangeRequestForm changeRequestForm) {
        // convert DTO to entity
        ChangeRequestFormEntity entity = convertToEntity(changeRequestForm);
        changeRequestFormRepository.save(entity);
    }

    private ChangeRequestFormEntity convertToEntity(ChangeRequestForm changeRequestForm) {
        Jwt jwt = (Jwt) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        ChangeRequestFormEntity entity = ChangeRequestFormEntity.builder()
                .crfAccess(changeRequestForm.getCrfAccess())
                .crfType(changeRequestForm.getCrfType())
                .crfDept(changeRequestForm.getCrfDept())
                .requestorName(jwt.getClaimAsString("name"))
                .requestedDate(changeRequestForm.getRequestedDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate())
                .priority(changeRequestForm.getPriority())
                .openDate(changeRequestForm.getOpenDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime())
                .closeDate(changeRequestForm.getCloseDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime())
                .reason(changeRequestForm.getReason())
                .svdTicketId(changeRequestForm.getSvdTicketId())
                .bankShortName(changeRequestForm.getBankShortName()).build();


        entity.setCrfIps(changeRequestForm.getCrfIps().stream()
                .map(crfIp -> convertCrfIpToEntity(crfIp, entity))
                .toList());


        return entity;
    }

    private CrfIpEntity convertCrfIpToEntity(CrfIp crfIp, ChangeRequestFormEntity changeRequestForm) {
        String[] sourceIps = crfIp.getSourceIp().split(",");
        String[] destinationIps = crfIp.getDestinationIp().split(",");

        CrfIpEntity.CrfIpEntityBuilder builder = CrfIpEntity.builder()
                .port(crfIp.getPort());
        builder.crf(changeRequestForm);
        setIps(sourceIps, builder, "sourceIp");
        setIps(destinationIps, builder, "destinationIp");

        return builder.build();
    }

    private void setIps(String[] ips, CrfIpEntity.CrfIpEntityBuilder builder, String ipType) {
        IntStream.range(0, Math.min(ips.length, 7)).forEach(i -> {
            try {
                String methodName = ipType + (i + 1);
                Method method = CrfIpEntity.CrfIpEntityBuilder.class.getMethod(methodName, String.class);
                method.invoke(builder, ips[i]);
            } catch (NoSuchMethodException | IllegalAccessException | InvocationTargetException e) {
                throw new RuntimeException(e);
            }
        });
    }

    private ChangeRequestForm convertToDto(ChangeRequestFormEntity entity) {
        ChangeRequestForm changeRequestForm = new ChangeRequestForm();
        changeRequestForm.setId(entity.getId());
        changeRequestForm.setCrfAccess(entity.getCrfAccess());
        changeRequestForm.setCrfType(entity.getCrfType());
        changeRequestForm.setCrfDept(entity.getCrfDept());
        //changeRequestForm.setRequestorName(entity.getRequestorName());
        changeRequestForm.setRequestedDate(Date.from(LocalDate.now().atStartOfDay().atZone(ZoneId.systemDefault()).toInstant()));
        changeRequestForm.setPriority(entity.getPriority());
        changeRequestForm.setOpenDate(convertToDate(entity.getOpenDate()));
        changeRequestForm.setCloseDate(convertToDate(entity.getCloseDate()));
        changeRequestForm.setReason(entity.getReason());
        changeRequestForm.setSvdTicketId(entity.getSvdTicketId());
        changeRequestForm.setBankShortName(entity.getBankShortName());
        changeRequestForm.setCrfIps(entity.getCrfIps().stream()
                .map(this::convertCrfIpToDto)
                .toList());

        return changeRequestForm;
    }

    private CrfIp convertCrfIpToDto(CrfIpEntity entity) {
        CrfIp crfIp = new CrfIp();
        crfIp.setId(entity.getId());
        crfIp.setCrfId(entity.getCrf().getId());

        crfIp.setSourceIp(Stream.of(
                        entity.getSourceIp1(),
                        entity.getSourceIp2(),
                        entity.getSourceIp3(),
                        entity.getSourceIp4(),
                        entity.getSourceIp5(),
                        entity.getSourceIp6(),
                        entity.getSourceIp7())
                .filter(Objects::nonNull)
                .filter(ip -> !ip.isEmpty())
                .collect(Collectors.joining(",")));

        crfIp.setDestinationIp(Stream.of(
                        entity.getDestinationIp1(),
                        entity.getDestinationIp2(),
                        entity.getDestinationIp3(),
                        entity.getDestinationIp4(),
                        entity.getDestinationIp5(),
                        entity.getDestinationIp6(),
                        entity.getDestinationIp7())
                .filter(Objects::nonNull)
                .filter(ip -> !ip.isEmpty())
                .collect(Collectors.joining(",")));

        crfIp.setPort(entity.getPort());

        return crfIp;
    }

    private Date convertToDate(LocalDateTime dateToConvert) {
        return Date.from(dateToConvert.atZone(ZoneId.systemDefault()).toInstant());
    }


    public List<ChangeRequestForm> getChangeRequestForms(Long crfId, String ipAddress, String bankShortName) {
        List<ChangeRequestFormEntity> entities = new ArrayList<>();

        if (crfId != null) {
            changeRequestFormRepository.findById(crfId).ifPresent(entities::add);
        } else if (bankShortName != null) {
            entities = changeRequestFormRepository.findByBankShortNameOrderByOpenDateDesc(bankShortName);
        } else if (ipAddress != null) {
            entities = crfIpRepository.findCrfByIpAddress(ipAddress);
        } else {
            // Handle the case where no parameters are provided, if necessary
            throw new IllegalArgumentException("At least one parameter must be provided");
        }

        return entities.stream().map(this::convertToDto).toList();
    }

    /**
     * Update all fields of a Change Request Form including associated IP information
     *
     * @param changeRequestForm The updated Change Request Form data
     */
    @Transactional
    public void updateChangeRequestForm(ChangeRequestForm changeRequestForm) {
        logger.info("Updating Change Request Form with ID: {}", changeRequestForm.getId());

        if (changeRequestForm.getId() == null) {
            throw new IllegalArgumentException("CRF ID is required for update operation");
        }

        changeRequestFormRepository.findById(changeRequestForm.getId()).ifPresentOrElse(entity -> {
            logger.info("Change Request Form found. Updating all fields.");

            // Use the mapper to update all fields from model to entity
            changeRequestFormMapper.updateEntityFromModel(changeRequestForm, entity);

            // Handle the CRF IPs - the mapper method will handle this
            changeRequestFormMapper.mapCrfIps(changeRequestForm, entity);

            // Save the updated entity
            changeRequestFormRepository.save(entity);
            logger.info("Change Request Form updated successfully with all fields.");

        }, () -> {
            logger.error("Change Request Form not found with ID: {}", changeRequestForm.getId());
            throw new ResourceNotFoundException("CRF not found with id " + changeRequestForm.getId());
        });
    }

    public Workbook downloadCrf(Long crfId) throws Exception {
        logger.info("Populating Excel for CRF ID: {}", crfId);

        try (InputStream inputStream = sftpService.downloadFile("/files/templates/crf/crf-template.xls")) {
            // Create the workbook directly from the InputStream
            Workbook workbook = new HSSFWorkbook(inputStream);
            Sheet sheet = workbook.getSheetAt(0);

            // Fetch the necessary data
            ChangeRequestFormEntity formEntity = fetchChangeRequestForm(crfId);
            List<CrfIpEntity> crfIpEntity = fetchCrfIpEntities(crfId);

            // Populate the workbook
            populateHeaderCells(sheet, formEntity);
            populateIpData(sheet, crfIpEntity);
            populateAdditionalFields(sheet, formEntity, formEntity.getCrfIps().size());

            String requestorName = formEntity.getRequestorName();
            Row row = sheet.getRow(2);
            Cell cell = row.getCell(1, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);
            cell.setCellValue("Name: " + requestorName);

            logger.info("Excel populated successfully for CRF ID: {}", crfId);
            return workbook;
        } catch (IOException e) {
            logger.error("IO Error populating Excel for CRF ID {}: {}", crfId, e.getMessage(), e);
            throw new IOException("Excel population failed for CRF ID: " + crfId, e);
        } catch (Exception e) {
            logger.error("Unexpected error populating Excel for CRF ID {}: {}", crfId, e.getMessage(), e);
            throw new Exception("Excel population failed for CRF ID: " + crfId, e);
        }
    }

    private ChangeRequestFormEntity fetchChangeRequestForm(Long crfId) {
        return changeRequestFormRepository.findById(crfId)
                .orElseThrow(() -> new ResourceNotFoundException("Change Request Form not found with ID: " + crfId));
    }

    private List<CrfIpEntity> fetchCrfIpEntities(Long crfId) {
        return crfIpRepository.findByCrfID(crfId);
    }

    private void populateHeaderCells(Sheet sheet, ChangeRequestFormEntity form) {
        setCellValue(sheet, 0, 13, form.getId().toString()); // N1
        setCellValue(sheet, 7, 1, formatDate("Close Date: ", form.getCloseDate())); // B8
        setCellValue(sheet, 6, 1, formatDate("Open Date: ", form.getOpenDate())); // B7
        setCellValue(sheet, 1, 3, form.getCrfDept()); // D2
        setCellValue(sheet, 2, 6, form.getReason()); // G3
        setCellValue(sheet, 8, 1, "Priority : " + form.getPriority()); // B9
    }

    private String validateIp(String ip) {
        return (ip == null || ip.startsWith("{") && ip.endsWith("}")) ? "" : ip;
    }

    private void populateIpData(Sheet sheet, List<CrfIpEntity> ipEntities) {
        if (ipEntities == null || ipEntities.isEmpty()) return;

        for (int i = 0, j = 0; i < ipEntities.size(); i++, j++) {
            CrfIpEntity entity = ipEntities.get(i);

            String sourceIp1 = validateIp(entity.getSourceIp1());
            String sourceIp2 = validateIp(entity.getSourceIp2());
            String sourceIp3 = validateIp(entity.getSourceIp3());
            String sourceIp4 = validateIp(entity.getSourceIp4());
            String sourceIp5 = validateIp(entity.getSourceIp5());
            String sourceIp6 = validateIp(entity.getSourceIp6());
            String sourceIp7 = validateIp(entity.getSourceIp7());

            String sourcePhysicalIps = buildIpsString(false, sourceIp1, sourceIp2, sourceIp3, sourceIp4, sourceIp5, sourceIp6, sourceIp7);
            String sourceNattedIps = buildIpsString(true, sourceIp1, sourceIp2, sourceIp3, sourceIp4, sourceIp5, sourceIp6, sourceIp7);

            String destinationIp1 = validateIp(entity.getDestinationIp1());
            String destinationIp2 = validateIp(entity.getDestinationIp2());
            String destinationIp3 = validateIp(entity.getDestinationIp3());
            String destinationIp4 = validateIp(entity.getDestinationIp4());
            String destinationIp5 = validateIp(entity.getDestinationIp5());
            String destinationIp6 = validateIp(entity.getDestinationIp6());
            String destinationIp7 = validateIp(entity.getDestinationIp7());

            String destinationPhysicalIps = buildIpsString(false, destinationIp1, destinationIp2, destinationIp3, destinationIp4, destinationIp5, destinationIp6, destinationIp7);
            String destinationNattedIps = buildIpsString(true, destinationIp1, destinationIp2, destinationIp3, destinationIp4, destinationIp5, destinationIp6, destinationIp7);


            setCellValue(sheet, 15 + j, 3, sourcePhysicalIps);
            setCellValue(sheet, 15 + j, 4, sourceNattedIps);
            setCellValue(sheet, 15 + j, 6, destinationPhysicalIps);
            setCellValue(sheet, 15 + j, 7, destinationNattedIps);
            setCellValue(sheet, 15 + j, 8, entity.getPort() != null ? entity.getPort() : "");
        }
    }

    private void populateAdditionalFields(Sheet sheet, ChangeRequestFormEntity form, int size) {
        String dateRange = formatDateRange(form.getOpenDate(), form.getCloseDate());
        for (int i = 0; i < size; i++) {
            setCellValue(sheet, 15 + i, 10, dateRange); // K16
            setCellValue(sheet, 15 + i, 12, form.getBankShortName()); // M16
        }

    }

    private String formatDateRange(LocalDateTime openDate, LocalDateTime closeDate) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");

        String open = openDate != null ? openDate.toLocalDate().format(formatter) : "N/A";
        String close = closeDate != null ? closeDate.toLocalDate().format(formatter) : "N/A";

        return open + " to " + close;
    }

    private String formatDate(String prefix, LocalDateTime date) {
        if (date == null) {
            return "";
        }

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy"); // or any other format you prefer
        return prefix + date.toLocalDate().format(formatter);
    }

    private String buildIpsString(boolean isNatted, String... ips) {
        if (ips == null || Arrays.stream(ips).allMatch(Objects::isNull)) {
            return "";
        }

        return Arrays.stream(ips)
                .filter(Objects::nonNull)
                .filter(ip -> isNatted ? ip.startsWith("10.") : !ip.startsWith("10."))
                .collect(Collectors.joining("\n"))
                .replaceAll("\n$", "");
    }

    private void setCellValue(Sheet sheet, int rowNum, int colNum, String value) {
        Row row = sheet.getRow(rowNum) != null ? sheet.getRow(rowNum) : sheet.createRow(rowNum);
        Cell cell = row.getCell(colNum, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);
        cell.setCellValue(value);
    }
}