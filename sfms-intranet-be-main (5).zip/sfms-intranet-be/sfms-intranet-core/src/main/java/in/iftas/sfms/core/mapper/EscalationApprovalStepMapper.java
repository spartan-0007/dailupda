package in.iftas.sfms.core.mapper;

import in.iftas.sfms.core.entity.EscalationApprovalStepEntity;
import in.iftas.sfms.core.model.EscalationApprovalStep;
import org.mapstruct.*;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;

@Mapper(
    componentModel = "spring",
    unmappedTargetPolicy = ReportingPolicy.IGNORE,
    nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE
)
public interface EscalationApprovalStepMapper {

    // Entity to Model (Response)
    @Mapping(target = "requiredRole", source = "requiredRole", qualifiedByName = "mapEntityRequiredRoleToModel")
    @Mapping(target = "checkerRole", source = "checkerRole", qualifiedByName = "mapEntityCheckerRoleToModel")
    @Mapping(target = "status", source = "status", qualifiedByName = "mapEntityStatusToModel")
    EscalationApprovalStep toModel(EscalationApprovalStepEntity entity);

    // Model to Entity (Request) - usually not needed for steps as they're created internally
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "approval", ignore = true) // This is the JPA relationship
    @Mapping(target = "requiredRole", source = "requiredRole", qualifiedByName = "mapModelRequiredRoleToEntity")
    @Mapping(target = "checkerRole", source = "checkerRole", qualifiedByName = "mapModelCheckerRoleToEntity")
    @Mapping(target = "status", source = "status", qualifiedByName = "mapModelStatusToEntity")
    EscalationApprovalStepEntity toEntity(EscalationApprovalStep model);

    // List mappings
    List<EscalationApprovalStep> toModelList(List<EscalationApprovalStepEntity> entities);
    List<EscalationApprovalStepEntity> toEntityList(List<EscalationApprovalStep> models);

    // Date conversion methods
    default Date localDateTimeToDate(LocalDateTime localDateTime) {
        return localDateTime != null ? 
            Date.from(localDateTime.atZone(ZoneId.systemDefault()).toInstant()) : null;
    }

    default LocalDateTime dateToLocalDateTime(Date date) {
        return date != null ? 
            LocalDateTime.ofInstant(date.toInstant(), ZoneId.systemDefault()) : null;
    }

    // Enum mappings for Required Role
    @Named("mapEntityRequiredRoleToModel")
    default EscalationApprovalStep.RequiredRoleEnum mapEntityRequiredRoleToModel(EscalationApprovalStepEntity.Role role) {
        return role != null ? EscalationApprovalStep.RequiredRoleEnum.valueOf(role.name()) : null;
    }

    @Named("mapModelRequiredRoleToEntity")
    default EscalationApprovalStepEntity.Role mapModelRequiredRoleToEntity(EscalationApprovalStep.RequiredRoleEnum role) {
        return role != null ? EscalationApprovalStepEntity.Role.valueOf(role.name()) : null;
    }

    // Enum mappings for Checker Role
    @Named("mapEntityCheckerRoleToModel")
    default EscalationApprovalStep.CheckerRoleEnum mapEntityCheckerRoleToModel(EscalationApprovalStepEntity.Role role) {
        return role != null ? EscalationApprovalStep.CheckerRoleEnum.valueOf(role.name()) : null;
    }

    @Named("mapModelCheckerRoleToEntity")
    default EscalationApprovalStepEntity.Role mapModelCheckerRoleToEntity(EscalationApprovalStep.CheckerRoleEnum role) {
        return role != null ? EscalationApprovalStepEntity.Role.valueOf(role.name()) : null;
    }

    // Enum mappings for Status
    @Named("mapEntityStatusToModel")
    default EscalationApprovalStep.StatusEnum mapEntityStatusToModel(EscalationApprovalStepEntity.Status status) {
        return status != null ? EscalationApprovalStep.StatusEnum.valueOf(status.name()) : null;
    }

    @Named("mapModelStatusToEntity")
    default EscalationApprovalStepEntity.Status mapModelStatusToEntity(EscalationApprovalStep.StatusEnum status) {
        return status != null ? EscalationApprovalStepEntity.Status.valueOf(status.name()) : null;
    }
}