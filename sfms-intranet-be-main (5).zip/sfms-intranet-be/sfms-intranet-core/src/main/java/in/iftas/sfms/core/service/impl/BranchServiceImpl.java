package in.iftas.sfms.core.service.impl;

import in.iftas.sfms.auth.api.impl.AuthApiImpl;
import in.iftas.sfms.core.dto.BranchDTO;
import in.iftas.sfms.core.entity.BankContactEntity;
import in.iftas.sfms.core.entity.BankFeatureEntity;
import in.iftas.sfms.core.entity.BranchEntity;
import in.iftas.sfms.core.enums.BranchFeatureType;
import in.iftas.sfms.core.exception.InvalidRequestException;
import in.iftas.sfms.core.exception.ResourceNotFoundException;
import in.iftas.sfms.core.mapper.BranchMapper;
import in.iftas.sfms.core.model.Branch;
import in.iftas.sfms.core.model.EnabledBranchFeatureCountResponse;
import in.iftas.sfms.core.repository.BankBranchRepository;
import in.iftas.sfms.core.repository.BankFeatureRepository;
import in.iftas.sfms.core.service.BranchService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.nio.charset.StandardCharsets;
import java.util.List;

@Service
public class BranchServiceImpl implements BranchService {

    private static final Logger logger = LoggerFactory.getLogger(BranchServiceImpl.class);

    private final BankBranchRepository branchRepository;
    private final BranchMapper branchMapper;
    private final BankFeatureRepository bankFeatureRepository;
    private final AuthApiImpl authApiImpl;
    private final JwtDecoder jwtDecoder;

    @Autowired
    public BranchServiceImpl(BankBranchRepository branchRepository, BranchMapper branchMapper, BankFeatureRepository bankFeatureRepository, AuthApiImpl authApiImpl, JwtDecoder jwtDecoder) {
        this.branchRepository = branchRepository;
        this.branchMapper = branchMapper;
        this.bankFeatureRepository = bankFeatureRepository;
        this.authApiImpl = authApiImpl;
        this.jwtDecoder = jwtDecoder;
    }

    @Override
    public void deleteBranch(String ifscCode) throws ResourceNotFoundException {
        logger.info("Deleting branch with IFSC code: {}", ifscCode);
        BranchEntity branchEntity = branchRepository.findById(ifscCode)
                .orElseThrow(() -> new ResourceNotFoundException("Branch Not Found"));
        branchRepository.delete(branchEntity);
        logger.info("Branch with IFSC code: {} deleted successfully", ifscCode);
    }

    @Override
    public void addBranch(Branch branch) throws InvalidRequestException {
        logger.info("Adding new branch with IFSC code: {}", branch.getIfscCode());
        BranchEntity branchEntity = branchMapper.toEntity(branch);
        branchRepository.save(branchEntity);
        logger.info("Branch with IFSC code: {} added successfully", branch.getIfscCode());
    }

    @Override
    public String updateBranch(Branch branch) throws InvalidRequestException, ResourceNotFoundException {
        logger.info("Updating branch with IFSC code: {}", branch.getIfscCode());

        BranchEntity existingBranchEntity = branchRepository.findById(branch.getIfscCode())
                .orElseThrow(() -> new ResourceNotFoundException("Branch Not Found"));

        BankContactEntity existingBranchContact = existingBranchEntity.getBranchContact();
        BankFeatureEntity existingBranchFeature = existingBranchEntity.getBranchFeature();

        branchMapper.updateBranchEntityFromModel(branch, existingBranchEntity);

        if (branch.getBranchContact() == null) {
            existingBranchEntity.setBranchContact(existingBranchContact);
        }
        if (branch.getBranchFeature() == null) {
            existingBranchEntity.setBranchFeature(existingBranchFeature);
        }

        logger.info("Updated BranchEntity: {}", existingBranchEntity);

        BranchEntity branchEntity = branchRepository.save(existingBranchEntity);

        logger.info("Branch with IFSC code: {} updated successfully", branch.getIfscCode());
        return branchEntity.getIfscCode();
    }

    @Override
    public void uploadBranches(MultipartFile file) throws InvalidRequestException {
        logger.info("Uploading branches from file: {}", file.getOriginalFilename());
    }

    @Override
    public EnabledBranchFeatureCountResponse getEnabledFeatureCount() {
        logger.info("Fetching enabled branch feature counts");
        String accessToken="";
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        if (principal instanceof Jwt) {
            accessToken = ((Jwt) principal).getTokenValue();
        } else {
            throw new RuntimeException("Expected Jwt token, but found: " + principal.getClass());
        }
        Jwt jwt = jwtDecoder.decode(accessToken);
        String userRole = jwt.getClaimAsString("userType");
        boolean isBanker;
        long bankId=0;
        if(userRole!=null){
            isBanker = "BANKER".equals(userRole);
            if(isBanker){
                String bankIdStr = jwt.getClaimAsString("bankId");
                bankId = Long.parseLong(bankIdStr);
            }
        }else{
            throw new RuntimeException("User Type not found ");
        }

        List<Object[]> enabledBranchFeatureCounts = isBanker ?
                bankFeatureRepository.findEnabledBranchFeatureCountsWithOwnBank(bankId) :
                bankFeatureRepository.findEnabledBranchFeatureCounts();

        return enabledBranchFeatureCounts.stream().findFirst().map(enabledFeatureCount -> {
            EnabledBranchFeatureCountResponse response = new EnabledBranchFeatureCountResponse();

            response.setTotalNeftEnabledBranches(getLongValue(enabledFeatureCount[0]));
            response.setTotalRtgsEnabledBranches(getLongValue(enabledFeatureCount[1]));
            response.setTotalRtgsAndNeftEnabledBranches(getLongValue(enabledFeatureCount[2]));
            response.setTotalLcEnabledBranches(getLongValue(enabledFeatureCount[3]));
            response.setTotalBgEnabledBranches(getLongValue(enabledFeatureCount[4]));
            response.setTotalLcAndBgEnabledBranches(getLongValue(enabledFeatureCount[5]));
            response.setTotalBranches(getLongValue(enabledFeatureCount[6]));
            response.setTotalOthersBranches(getLongValue(enabledFeatureCount[7]));
            if(isBanker)
                response.setTotalOwnBankWiseCount(getLongValue(enabledFeatureCount[8]));

            logger.info("Enabled branch feature counts fetched successfully");
            return response;
        }).orElseThrow(() -> {
            logger.error("No enabled feature counts found");
            return new RuntimeException("No enabled feature counts found");
        });
    }
    private Long getLongValue(Object value) {
        return value != null ? ((Number) value).longValue() : 0L;
    }

    @Override
    public Resource getBranchesByFeature(BranchFeatureType featureType) {
        logger.info("Fetching branches by feature type: {}", featureType);
        if (featureType == null) {
            logger.error("Feature type cannot be null");
            throw new IllegalArgumentException("Feature type cannot be null");
        }

        List<BranchDTO> results = switch (featureType) {
            case NEFT -> branchRepository.findActiveNeftEnabledBranches();
            case RTGS -> branchRepository.findActiveRtgsEnabledBranches();
            case RTGS_AND_NEFT -> branchRepository.findActiveRtgsNeftEnabledBranches();
            case LC -> branchRepository.findActiveLcEnabledBranches();
            case BG -> branchRepository.findActiveBgEnabledBranches();
            case LC_AND_BG -> branchRepository.findActiveLcBgEnabledBranches();
            case OTHERS -> branchRepository.findActiveOthersEnabledBranches();
            default -> {
                logger.error("Invalid feature type: {}", featureType);
                throw new IllegalArgumentException("Invalid feature type: " + featureType);
            }
        };

        if (results == null || results.isEmpty()) {
            logger.warn("No branches found for feature type: {}", featureType);
            return new ByteArrayResource(new byte[0]);
        }

        List<String> branchDetails = results.stream()
                .map(result -> String.format("\"%s\"|\"%s\"", result.getBranchName(), result.getIfscCode()))
                .toList();

        String reportContent = String.join("\n", branchDetails);
        logger.info("Branches by feature type: {} fetched successfully", featureType);
        return new ByteArrayResource(reportContent.getBytes(StandardCharsets.UTF_8));
    }

    public List<Branch> getBranches(Integer page, Integer size, String sort) {
        logger.info("Fetching branches with pagination - page: {}, size: {}, sort: {}", page, size, sort);
        Pageable pageable = PageRequest.of(page, size, Sort.by(sort));
        Page<BranchEntity> branchEntityPage = branchRepository.findAll(pageable);
        logger.debug("Found {} branches", branchEntityPage.getTotalElements());
        return branchEntityPage.getContent()
                .stream()
                .map(branchMapper::toModel)
                .toList();
    }
}