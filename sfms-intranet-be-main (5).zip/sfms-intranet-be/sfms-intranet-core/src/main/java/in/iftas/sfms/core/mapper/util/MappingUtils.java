package in.iftas.sfms.core.mapper.util;

import org.mapstruct.Named;
import org.openapitools.jackson.nullable.JsonNullable;

public class MappingUtils {

    // Private constructor to hide the implicit public one
    private MappingUtils() {
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }

    @Named("stringToJsonNullable")
    public static JsonNullable<String> stringToJsonNullable(String value) {
        return JsonNullable.of(value);
    }

    @Named("jsonNullableToString")
    public static String jsonNullableToString(JsonNullable<String> value) {
        return value.orElse(null);
    }
}