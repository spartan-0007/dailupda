package in.iftas.sfms.core.repository;

import in.iftas.sfms.core.entity.DepartmentEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface DepartmentRepository extends JpaRepository<DepartmentEntity, Long> {
    
    /**
     * Get all active departments with their active escalation levels for matrix building
     */
    @Query("SELECT DISTINCT d FROM DepartmentEntity d " +
           "LEFT JOIN FETCH d.escalationLevels el " +
           "WHERE d.isActive = true AND (el.isActive = true OR el.isActive IS NULL) " +
           "ORDER BY d.displayOrder, el.levelOrder")
    List<DepartmentEntity> findActiveDepartmentsWithActiveLevels();
    
    /**
     * Get all active departments for simple listing
     */
    List<DepartmentEntity> findByIsActiveTrueOrderByDisplayOrder();
}
