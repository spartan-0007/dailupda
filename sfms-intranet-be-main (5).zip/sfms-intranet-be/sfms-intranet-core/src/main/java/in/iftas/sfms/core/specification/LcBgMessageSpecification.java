package in.iftas.sfms.core.specification;

import in.iftas.sfms.core.entity.LcBgMessageEntity;
import in.iftas.sfms.core.model.LcBgMessagesReportRequest;
import jakarta.persistence.criteria.Predicate;
import org.springframework.data.jpa.domain.Specification;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class LcBgMessageSpecification {

    public static Specification<LcBgMessageEntity> getLcBgMessages(LcBgMessagesReportRequest request, LocalDateTime fromDateTime, LocalDateTime toDateTime) {
        return (root, query, criteriaBuilder) -> {
            List<Predicate> predicates = new ArrayList<>();

            if (request.getFromDate() != null && request.getToDate() != null) {
                predicates.add(criteriaBuilder.between(root.get("messageDateTime"), fromDateTime, toDateTime));
            }

            if (request.getMessageType() != null) {
                predicates.add(criteriaBuilder.equal(root.get("messageType"), request.getMessageType()));
            }

            if (request.getMessageStatus() != null) {
                predicates.add(criteriaBuilder.equal(root.get("messageStatus"), request.getMessageStatus()));
            }

            if (request.getFromBank() != null) {
                predicates.add(criteriaBuilder.equal(root.get("senderIfsc"), request.getFromBank()));
            }

            if (request.getToBank() != null) {
                predicates.add(criteriaBuilder.equal(root.get("receiverIfsc"), request.getToBank()));
            }

            return criteriaBuilder.and(predicates.toArray(new Predicate[0]));
        };
    }
}