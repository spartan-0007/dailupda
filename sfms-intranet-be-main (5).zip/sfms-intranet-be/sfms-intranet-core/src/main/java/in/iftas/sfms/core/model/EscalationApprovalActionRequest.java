package in.iftas.sfms.core.model;

import java.net.URI;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import org.openapitools.jackson.nullable.JsonNullable;
import java.time.OffsetDateTime;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


import java.util.*;
import jakarta.annotation.Generated;

/**
 * EscalationApprovalActionRequest
 */


public class EscalationApprovalActionRequest {

  private Long approvalId;

  private Boolean approved;

  private String comments;

  private String rejectionReason;

  // Add a no-args constructor
  public EscalationApprovalActionRequest() {

  }

  /**
   * Constructor with only required parameters
   */
  public EscalationApprovalActionRequest(Long approvalId, Boolean approved) {
    this.approvalId = approvalId;
    this.approved = approved;
  }

  public EscalationApprovalActionRequest approvalId(Long approvalId) {
    this.approvalId = approvalId;
    return this;
  }

  /**
   * ID of the approval request to process
   * @return approvalId
   */
  @NotNull 
  @Schema(name = "approvalId", description = "ID of the approval request to process", requiredMode = Schema.RequiredMode.REQUIRED)
  @JsonProperty("approvalId")
  public Long getApprovalId() {
    return approvalId;
  }

  public void setApprovalId(Long approvalId) {
    this.approvalId = approvalId;
  }

  public EscalationApprovalActionRequest approved(Boolean approved) {
    this.approved = approved;
    return this;
  }

  /**
   * True for approval, false for rejection
   * @return approved
   */
  @NotNull 
  @Schema(name = "approved", description = "True for approval, false for rejection", requiredMode = Schema.RequiredMode.REQUIRED)
  @JsonProperty("approved")
  public Boolean getApproved() {
    return approved;
  }

  public void setApproved(Boolean approved) {
    this.approved = approved;
  }

  public EscalationApprovalActionRequest comments(String comments) {
    this.comments = comments;
    return this;
  }

  /**
   * Comments from the checker
   * @return comments
   */
  @Size(max = 1000) 
  @Schema(name = "comments", description = "Comments from the checker", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("comments")
  public String getComments() {
    return comments;
  }

  public void setComments(String comments) {
    this.comments = comments;
  }

  public EscalationApprovalActionRequest rejectionReason(String rejectionReason) {
    this.rejectionReason = rejectionReason;
    return this;
  }

  /**
   * Reason for rejection (required if approved is false)
   * @return rejectionReason
   */
  @Size(max = 500) 
  @Schema(name = "rejectionReason", description = "Reason for rejection (required if approved is false)", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("rejectionReason")
  public String getRejectionReason() {
    return rejectionReason;
  }

  public void setRejectionReason(String rejectionReason) {
    this.rejectionReason = rejectionReason;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    EscalationApprovalActionRequest escalationApprovalActionRequest = (EscalationApprovalActionRequest) o;
    return Objects.equals(this.approvalId, escalationApprovalActionRequest.approvalId) &&
        Objects.equals(this.approved, escalationApprovalActionRequest.approved) &&
        Objects.equals(this.comments, escalationApprovalActionRequest.comments) &&
        Objects.equals(this.rejectionReason, escalationApprovalActionRequest.rejectionReason);
  }

  @Override
  public int hashCode() {
    return Objects.hash(approvalId, approved, comments, rejectionReason);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class EscalationApprovalActionRequest {\n");
    sb.append("    approvalId: ").append(toIndentedString(approvalId)).append("\n");
    sb.append("    approved: ").append(toIndentedString(approved)).append("\n");
    sb.append("    comments: ").append(toIndentedString(comments)).append("\n");
    sb.append("    rejectionReason: ").append(toIndentedString(rejectionReason)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

