package in.iftas.sfms.core.api.impl;

import in.iftas.sfms.core.api.BanksApi;
import in.iftas.sfms.core.dto.BankDTO;
import in.iftas.sfms.core.exception.BankAlreadyExistsException;
import in.iftas.sfms.core.exception.Branchalreadyexists;
import in.iftas.sfms.core.exception.ResourceNotFoundException;
import in.iftas.sfms.core.model.ApiResponseError;
import in.iftas.sfms.core.model.Bank;
import in.iftas.sfms.core.model.Branch;
import in.iftas.sfms.core.model.ModelApiResponse;
import in.iftas.sfms.core.service.BankService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;

@RestController
public class BankApiImpl implements BanksApi {
    private static final Logger logger = LoggerFactory.getLogger(BankApiImpl.class);

    private final BankService bankService;

    @Autowired
    public BankApiImpl(BankService bankService) {
        this.bankService = bankService;
    }

    @Override
    @PreAuthorize("hasAuthority('ROLE_operator-read-write')")
    public ResponseEntity<Void> banksDelete(Integer bankId) {
        bankService.deleteBank(bankId);
        return ResponseEntity.status(HttpStatusCode.valueOf(200)).build();
    }

    @Override
    @PreAuthorize("hasAnyAuthority('ROLE_operator-read-write','ROLE_operator-read-only','ROLE_banker-neft-read-write'," +
            "'ROLE_banker-neft-read-only','ROLE_banker-rtgs-read-write','ROLE_banker-rtgs-read-only','ROLE_operator-lc-bg-read-write')")
    public ResponseEntity<List<Bank>> banksGet(Integer page, Integer size, String sort) {
        logger.info("Entering banksGet method with parameters: page={}, size={}, sort={}", page, size, sort);

        int defaultPage = 0;
        int pageNumber = Objects.requireNonNullElse(page, defaultPage);
        int defaultSize = 10;
        int pageSize = Objects.requireNonNullElse(size, defaultSize);

        String defaultSort = "id";
        String sortField = Objects.requireNonNullElse(sort, defaultSort);

        logger.debug("Fetching banks with pageNumber={}, pageSize={}, sortField={}", pageNumber, pageSize, sortField);
        List<Bank> banks = bankService.getAllBanks(pageNumber, pageSize, sortField);
        logger.info("Returning {} banks", banks.size());
        return new ResponseEntity<>(banks, HttpStatus.OK);
    }

    @Override
    @PreAuthorize("hasAuthority('ROLE_operator-read-write')")
    public ResponseEntity<ModelApiResponse> banksPost(Bank bank) {
        ModelApiResponse modelApiResponse = new ModelApiResponse();
        try {
            logger.info("Entering banksPost method with bank: {}", bank);

            Long addedBankId = bankService.addBank(bank);
            logger.debug("Bank created with ID: {}", addedBankId);
            modelApiResponse.setSuccess(true);
            modelApiResponse.setMessage("Bank Created Successfully");
            modelApiResponse.setData(Collections.singletonMap("bankId", addedBankId));
            logger.info("Returning response with status CREATED and bankId: {}", addedBankId);
            return new ResponseEntity<>(modelApiResponse, HttpStatus.CREATED);
        } catch (Branchalreadyexists | BankAlreadyExistsException e) {
            modelApiResponse.setSuccess(false);
            modelApiResponse.setMessage(e.getMessage());
            ApiResponseError error = new ApiResponseError();
            error.setCode(HttpStatus.CONFLICT.toString());
            error.setMessage(e.getMessage());
            modelApiResponse.setError(error);
            return new ResponseEntity<>(modelApiResponse, HttpStatus.CONFLICT);

        } catch (Exception e) {
            logger.error("Error saving bank: {}", e);
            modelApiResponse.setSuccess(false);
            modelApiResponse.setMessage("Internal Server Error.");
            return new ResponseEntity<>(modelApiResponse, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    @PreAuthorize("hasAuthority('ROLE_operator-read-write')")
    public ResponseEntity<Void> banksBankIdPut(Integer bankId, Bank bank) {
        logger.info("Entering banksBankIdPut method with bankId: {} and bank: {}", bankId, bank);
        bank.setId(bankId);
        bankService.updateBank(bank);
        logger.info("Bank with ID: {} updated successfully", bankId);

        return ResponseEntity.status(HttpStatusCode.valueOf(204)).build();
    }

    @Override
    @PreAuthorize("hasAnyAuthority('ROLE_operator-read-write','ROLE_operator-read-only','ROLE_banker-neft-read-write'," +
            "'ROLE_banker-neft-read-only','ROLE_banker-rtgs-read-write','ROLE_banker-rtgs-read-only','ROLE_operator-lc-bg-read-write')")
    public ResponseEntity<List<Branch>> banksBankIdBranchesGet(
            Integer bankId,
            @RequestParam(value = "page", required = false, defaultValue = "0") Integer page,
            @RequestParam(value = "size", required = false, defaultValue = "10") Integer size,
            @RequestParam(value = "sort", required = false, defaultValue = "branchName") String sort) {
        logger.info("Entering banksBankIdBranchesGet method with bankId: {}, page: {}, size: {}, sort: {}", bankId, page, size, sort);
        List<Branch> branches = bankService.getBranchesByBankId(bankId, page, size, sort);
        logger.info("Returning {} branches for bankId: {}", branches.size(), bankId);

        return ResponseEntity.status(HttpStatusCode.valueOf(200)).body(branches);
    }

    @Override
    @PreAuthorize("hasAnyAuthority('ROLE_operator-read-write','ROLE_operator-read-only','ROLE_banker-neft-read-write'," +
            "'ROLE_banker-neft-read-only','ROLE_banker-rtgs-read-write','ROLE_banker-rtgs-read-only','ROLE_operator-lc-bg-read-write')")
    public ResponseEntity<ModelApiResponse> banksBranchesGet(Integer bankId, String branchId, Integer page, Integer size, String sort) {

        ModelApiResponse response = new ModelApiResponse();

        try {
            logger.info("Entering banksBranchesGet method with bankId: {}, page: {}, size: {}, sort: {}, branchId: {}", bankId, page, size, sort, branchId);
            Map<String, Object> map = bankService.getBanksWithBranches(bankId, page, size, sort, branchId);
            logger.info("Returning branches map for bankId: {}", bankId);
            response.setSuccess(true);
            response.setMessage("Banks with Branch Details fetched successfully");
            response.setData(map);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (ResourceNotFoundException e) {
            logger.warn("Bank with id not found : {}", bankId);
            response.setSuccess(false);
            response.setMessage("Patch not found.");
            return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            logger.error("Error fetching banks with ID: {}", bankId, e);
            response.setSuccess(false);
            response.setMessage("Internal Server Error.");
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    public ResponseEntity<org.springframework.core.io.Resource> generateBanksReport() {
        try {
            return bankService.downloadBanksReport();
        } catch (Exception e) {
            throw new RuntimeException("Failed to generate banks report", e);
        }
    }


}