package in.iftas.sfms.core.service;

/*
 * Copyright (C) 2024 Iftas Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Iftas Inc. ("Confidential Information"). You shall not disclose
 * such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with Iftas Inc.
 *
 * Author: Manoj.Illa
 * Date: July 11, 2024
 */

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import in.iftas.sfms.core.entity.CgbsFileDetailsEntity;
import in.iftas.sfms.core.entity.CgbsFileDetailsHistoryEntity;
import in.iftas.sfms.core.exception.ResourceNotFoundException;
import in.iftas.sfms.core.model.CGBSFileDetails;
import in.iftas.sfms.core.repository.CgbsFileDetailsRepository;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;

@Service
public class CgbsFileService {

    private static final Logger logger = LoggerFactory.getLogger(CgbsFileService.class);

    private final CgbsFileDetailsRepository cgbsFileDetailsRepository;
    private final SftpService sftpService;
    private final ObjectMapper objectMapper;

    public CgbsFileService(CgbsFileDetailsRepository cgbsFileDetailsRepository, SftpService sftpService, ObjectMapper objectMapper) {
        this.cgbsFileDetailsRepository = cgbsFileDetailsRepository;
        this.sftpService = sftpService;
        this.objectMapper = objectMapper;
    }

    public void uploadCgbsFile(String requestData) {
        logger.info("Processing CGBS file upload from approval data");

        try {
            CgbsFileDetailsEntity cgbsFileDetailsEntity = objectMapper.readValue(requestData, CgbsFileDetailsEntity.class);


            logger.info("Uploading CGBS file: {}", cgbsFileDetailsEntity.getFileName());

            Jwt jwt = (Jwt) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
            String currentUser = jwt.getClaimAsString("sub");
            CgbsFileDetailsEntity fileDetailsEntity = cgbsFileDetailsRepository.findByFileName(cgbsFileDetailsEntity.getFileName());

            CgbsFileDetailsHistoryEntity history = CgbsFileDetailsHistoryEntity.builder()
                    .uploadedBy(currentUser)
                    .sftpPath(cgbsFileDetailsEntity.getSftpPath())
                    .uploadedDate(LocalDateTime.now())
                    .build();

            if (ObjectUtils.isNotEmpty(fileDetailsEntity) && fileDetailsEntity.getFileName() != null) {
                fileDetailsEntity.setUploadedBy(currentUser);
                fileDetailsEntity.setUploadedDate(LocalDateTime.now());
                fileDetailsEntity.setFileSize(Long.valueOf(cgbsFileDetailsEntity.getFileSize()));
                fileDetailsEntity.setSftpPath(cgbsFileDetailsEntity.getSftpPath());

                history.setUploadedDate(fileDetailsEntity.getUploadedDate());
                history.setFileDetails(fileDetailsEntity);

                if (fileDetailsEntity.getHistoryEntities() == null) {
                    fileDetailsEntity.setHistoryEntities(List.of(history));
                } else {
                    fileDetailsEntity.getHistoryEntities().add(history);
                }
            } else {

                fileDetailsEntity = cgbsFileDetailsEntity;
                history.setUploadedDate(fileDetailsEntity.getUploadedDate());
                history.setFileDetails(fileDetailsEntity);
                fileDetailsEntity.setHistoryEntities(List.of(history));
            }

            cgbsFileDetailsRepository.save(fileDetailsEntity);
            logger.info("CGBS file uploaded successfully: {}", cgbsFileDetailsEntity.getFileName());

        } catch (Exception e) {
            logger.error("Failed to upload CGBS file.", e);
            throw new RuntimeException("Failed to upload CGBS file.", e);
        }
    }

    public void uploadCgbsFile(MultipartFile file) throws Exception {
        logger.info("Uploading CGBS file: {}", file.getOriginalFilename());
        String sftpPath = null;

        if (file != null) {
            try {
                sftpPath = uploadFileToSftp(file);

                Jwt jwt = (Jwt) SecurityContextHolder.getContext().getAuthentication().getPrincipal();

                CgbsFileDetailsEntity fileDetails = cgbsFileDetailsRepository.findByFileName(file.getOriginalFilename());

                CgbsFileDetailsHistoryEntity history = CgbsFileDetailsHistoryEntity.builder()
                        .uploadedBy(jwt.getClaimAsString("sub"))
                        .sftpPath(sftpPath)
                        .build();

                if (ObjectUtils.isNotEmpty(fileDetails) && fileDetails.getFileName() != null) {
                    fileDetails.setUploadedBy(jwt.getClaimAsString("sub"));
                    fileDetails.setUploadedDate(LocalDateTime.now());
                    fileDetails.setFileSize(fileDetails.getFileSize());

                    history.setUploadedDate(fileDetails.getUploadedDate());
                    history.setFileDetails(fileDetails);

                    fileDetails.getHistoryEntities().add(history);
                    logger.info("Updated existing CGBS file: {}", file.getOriginalFilename());
                } else {
                    fileDetails = CgbsFileDetailsEntity.builder()
                            .fileName(file.getOriginalFilename())
                            .uploadedBy(jwt.getClaimAsString("sub"))
                            .sftpPath(sftpPath)
                            .fileSize(file.getSize())
                            .uploadedDate(LocalDateTime.now())
                            .build();

                    history.setUploadedDate(fileDetails.getUploadedDate());
                    history.setFileDetails(fileDetails);
                    fileDetails.setHistoryEntities(List.of(history));
                    logger.info("Created new CGBS file: {}", file.getOriginalFilename());
                }
                cgbsFileDetailsRepository.save(fileDetails);

            } catch (Exception e) {
                logger.error("Failed to upload file to SFTP: {}", e.getMessage(), e);
                throw new RuntimeException("Failed to upload file to SFTP.", e);
            }
        }
    }

    private String uploadFileToSftp(MultipartFile file) throws Exception {
        logger.debug("Uploading file to SFTP: {}", file.getOriginalFilename());
        String sftpPath = "/files/cgbs/";
        try (InputStream inputStream = file.getInputStream()) {
            sftpService.uploadCRLCGBSFile(sftpPath, file.getOriginalFilename(), inputStream);
        }
        return sftpPath + file.getOriginalFilename();
    }

    public List<CGBSFileDetails> getCgbsFiles() {
        logger.info("Fetching all CGBS files");
        List<CgbsFileDetailsEntity> cgbsFileDetailsEntities = cgbsFileDetailsRepository.findAll();
        logger.debug("Found {} CGBS files", cgbsFileDetailsEntities.size());
        return cgbsFileDetailsEntities.stream()
                .map(this::convertToDto)
                .toList();
    }

    private CGBSFileDetails convertToDto(CgbsFileDetailsEntity entity) {
        logger.debug("Converting entity to DTO for file: {}", entity.getFileName());
        CGBSFileDetails dto = new CGBSFileDetails();
        dto.setFileName(entity.getFileName());
        dto.setFilePath(entity.getSftpPath());
        dto.setUploadedBy(entity.getUploadedBy());
        dto.setFileSize(convertFileSize(entity.getFileSize()));
        dto.setId(entity.getId());
        dto.setUploadedAt(Date.from(entity.getUploadedDate().atZone(ZoneId.systemDefault()).toInstant()));
        return dto;
    }

    public Resource downloadCgbsFile(String fileName) {
        logger.info("Downloading CGBS file: {}", fileName);
        CgbsFileDetailsEntity cgbsFileDetails = cgbsFileDetailsRepository.findByFileName(fileName);

        String sftpPath = cgbsFileDetails.getSftpPath();

        try {
            InputStream fileStream = sftpService.downloadFile(sftpPath);

            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            IOUtils.copy(fileStream, outputStream);
            ByteArrayInputStream inputStream = new ByteArrayInputStream(outputStream.toByteArray());

            logger.info("Downloaded CGBS file: {}", fileName);
            return new ByteArrayResource(inputStream.readAllBytes());

        } catch (Exception e) {
            logger.error("Failed to download CGBS file: {}", e.getMessage(), e);
            throw new RuntimeException(e);
        }
    }

    public String convertFileSize(Long sizeInBytes) {
        final int ONE_MB = 1024 * 1024;
        final int ONE_KB = 1024;

        if (sizeInBytes >= ONE_MB) {
            double sizeInMB = (double) sizeInBytes / ONE_MB;
            return String.format("%.2f MB", sizeInMB);
        } else {
            double sizeInKB = (double) sizeInBytes / ONE_KB;
            return String.format("%.2f KB", sizeInKB);
        }
    }

    public void deleteCGBSFile(Integer id) {
        if (!cgbsFileDetailsRepository.existsById(Long.valueOf(id))) {
            throw new ResourceNotFoundException("CGBS file not found with the specific ID: " + id);
        }
        cgbsFileDetailsRepository.deleteById(Long.valueOf(id));
    }

    private Long parseFileSize(String fileSizeStr) {
        if (fileSizeStr == null || fileSizeStr.trim().isEmpty()) {
            return 0L;
        }

        try {
            fileSizeStr = fileSizeStr.trim().toUpperCase();
            double value = Double.parseDouble(fileSizeStr.replaceAll("[^0-9.]", ""));

            if (fileSizeStr.contains("MB")) {
                return (long) (value * 1024 * 1024);
            } else if (fileSizeStr.contains("KB")) {
                return (long) (value * 1024);
            } else {
                // Assume bytes if no unit specified
                return (long) value;
            }
        } catch (NumberFormatException e) {
            logger.warn("Could not parse file size: {}", fileSizeStr);
            return 0L;
        }
    }
}