package in.iftas.sfms.core.config;

import jakarta.annotation.PreDestroy;
import org.apache.sshd.common.file.virtualfs.VirtualFileSystemFactory;
import org.apache.sshd.server.SshServer;
import org.apache.sshd.server.keyprovider.SimpleGeneratorHostKeyProvider;
import org.apache.sshd.sftp.server.SftpSubsystemFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.io.IOException;
import java.nio.file.Paths;
import java.util.Collections;


@Configuration
public class SftpServerConfig {

    private SshServer sshd;

    @Value("${sftp.port}")
    private int port;

    @Value("${sftp.username}")
    private String username;

    @Value("${sftp.password}")
    private String password;

    @Value("${sftp.local-root-dir}")
    private String localRootDir;

    @Value("${sftp.host-key-path}")
    private String hostKeyPath;

    private static final Logger logger = LoggerFactory.getLogger(SftpServerConfig.class);

    @Bean
    @ConditionalOnProperty(name = "sftp.use-inmemory-server", havingValue = "true")
    public SshServer sftpServer() throws IOException {
        sshd = SshServer.setUpDefaultServer();
        sshd.setPort(port);
        sshd.setFileSystemFactory(new VirtualFileSystemFactory(Paths.get(localRootDir)));
        sshd.setPasswordAuthenticator((username, password, session) -> this.username.equals(username) && this.password.equals(password));
        sshd.setKeyPairProvider(new SimpleGeneratorHostKeyProvider(Paths.get(hostKeyPath)));
        sshd.setSubsystemFactories(Collections.singletonList(new SftpSubsystemFactory()));
        sshd.start();
        logger.info("In-memory SFTP server started on port {}", port);
        return sshd;
    }

    @PreDestroy
    public void stopSftpServer() {
        if (sshd != null && !sshd.isClosed()) {
            try {
                sshd.stop();
                logger.info("In-memory SFTP server stopped.");
            } catch (IOException e) {
                logger.error(e.getMessage());
            }
        }
    }
}