package in.iftas.sfms.core.api.impl;

/*
 * Copyright (C) 2024 Iftas Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Iftas Inc. ("Confidential Information"). You shall not disclose
 * such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with Iftas Inc.
 *
 * Author: Manoj.Illa
 * Date: 10 October, 2024
 */

import in.iftas.sfms.core.api.UserManualsApi;
import in.iftas.sfms.core.model.GetUserManualFiles200Response;
import in.iftas.sfms.core.model.UploadUserManualFile201Response;
import in.iftas.sfms.core.model.UserManual;
import in.iftas.sfms.core.service.UserManualFileService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

@RestController
public class UserManualApiImpl implements UserManualsApi {
    private static final Logger logger = LoggerFactory.getLogger(UserManualApiImpl.class);

    private final UserManualFileService userManualFileService;

    @Autowired
    public UserManualApiImpl(UserManualFileService userManualFileService) {
        this.userManualFileService = userManualFileService;
    }

    @Override
    public ResponseEntity<UploadUserManualFile201Response> uploadUserManualFile(@RequestPart(value = "file", required = false) MultipartFile file) {
        logger.info("Received request to upload user manual file");

        try {




            if (file == null || file.isEmpty()) {

                logger.warn("File is missing or empty");
                return ResponseEntity.badRequest().build();
            }


            logger.debug("Uploading file: {}", file.getOriginalFilename());
            userManualFileService.uploadUserManualFile(file);
            UploadUserManualFile201Response response = new UploadUserManualFile201Response();
            response.setMessage(file +"uploaded successfully");

            logger.info("File uploaded successfully");
            return ResponseEntity.status(HttpStatus.CREATED).body(response);

        } catch (IOException e) {
            logger.error("Error uploading file: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        } catch (Exception e) {

            logger.error("Unexpected error: {}", e.getMessage(), e);
            throw new RuntimeException(e);
        }
    }

    @Override
    public ResponseEntity<GetUserManualFiles200Response> getUserManualFiles() {
        List<UserManual> userManuals = userManualFileService.getUserManualFiles();
        GetUserManualFiles200Response userManualFiles200Response = new GetUserManualFiles200Response();
        userManualFiles200Response.setFiles(userManuals);
        return ResponseEntity.status(HttpStatusCode.valueOf(200)).body(userManualFiles200Response);

    }

    @Override
    public ResponseEntity<Resource> downloadUserManualByFileName(String fileName) {
        Resource downloadCrlFile = userManualFileService.downloadCrlFile(fileName);

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + fileName + "\"")
                .header(HttpHeaders.CONTENT_TYPE, "application/zip")
                .body(downloadCrlFile);
    }

    @Override
    public ResponseEntity<Void> userManualsDelete(Long manualId) {
        logger.info("Received request to delete user manual by id");
        userManualFileService.deleteManualByID(manualId);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

}
