package in.iftas.sfms.core.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.integration.sftp.session.DefaultSftpSessionFactory;
import org.springframework.integration.sftp.session.SftpRemoteFileTemplate;
import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Spring Integration implementation of the SFTP client for UAT profile
 */
@Service
@Profile("uat")
public class SpringIntegrationSftpClient implements SftpClient {
    private static final Logger logger = LoggerFactory.getLogger(SpringIntegrationSftpClient.class);

    @Value("${sftp.host}")
    private String sftpHost;

    @Value("${sftp.port}")
    private int sftpPort;

    @Value("${sftp.username}")
    private String sftpUsername;

    @Value("${sftp.password}")
    private String sftpPassword;

    @Value("${sftp.remote.dir}")
    private String sftpRemoteDir;

    private DefaultSftpSessionFactory createSftpSessionFactory() {
        DefaultSftpSessionFactory factory = new DefaultSftpSessionFactory(true);
        factory.setHost(sftpHost);
        factory.setPort(sftpPort);
        factory.setUser(sftpUsername);
        factory.setPassword(sftpPassword);
        factory.setAllowUnknownKeys(true);
        return factory;
    }

    @Override
    public void uploadFile(String filePath, InputStream inputStream) throws Exception {
        logger.info("Uploading file to SFTP using Spring Integration: {}", filePath);
        DefaultSftpSessionFactory factory = createSftpSessionFactory();
        SftpRemoteFileTemplate template = new SftpRemoteFileTemplate(factory);

        try {
            String remotePath = getFullPath(filePath);
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            byte[] buffer = new byte[1024];
            int bytesRead;
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, bytesRead);
            }

            byte[] fileData = outputStream.toByteArray();

            // Using execute method with callback to upload file
            template.execute(session -> {
                try {
                    session.write(new ByteArrayInputStream(fileData), remotePath);
                    return true;
                } catch (Exception e) {
                    logger.error("Error in session callback for upload", e);
                    throw e;
                }
            });

            logger.info("File uploaded successfully to SFTP: {}", filePath);
        } catch (Exception e) {
            logger.error("Error uploading file to SFTP: {}", filePath, e);
            throw e;
        } finally {
            if (inputStream != null) {
                inputStream.close();
            }
        }
    }

    @Override
    public InputStream downloadFile(String filePath) throws Exception {
        logger.info("Downloading file from SFTP using Spring Integration: {}", filePath);
        DefaultSftpSessionFactory factory = createSftpSessionFactory();
        SftpRemoteFileTemplate template = new SftpRemoteFileTemplate(factory);

        try {
            String remotePath = getFullPath(filePath);
            final ByteArrayOutputStream outputStream = new ByteArrayOutputStream();

            // Using execute method with callback to download file
            template.execute(session -> {
                try {
                    session.read(remotePath, outputStream);
                    return true;
                } catch (Exception e) {
                    logger.error("Error in session callback for download", e);
                    throw e;
                }
            });

            logger.info("File downloaded successfully from SFTP: {}", filePath);
            return new ByteArrayInputStream(outputStream.toByteArray());
        } catch (Exception e) {
            logger.error("Error downloading file from SFTP: {}", filePath, e);
            throw e;
        }
    }

    @Override
    public boolean fileExists(String filePath, String originalFilename) throws Exception {
        logger.info("Checking if file exists on SFTP using Spring Integration: {}", filePath + originalFilename);
        DefaultSftpSessionFactory factory = createSftpSessionFactory();
        SftpRemoteFileTemplate template = new SftpRemoteFileTemplate(factory);

        try {
            final String remotePath = getFullPath(filePath + originalFilename);

            // Using execute method with callback to check if file exists
            Boolean exists = template.execute(session -> {
                try {
                    return session.exists(remotePath);
                } catch (Exception e) {
                    logger.error("Error in session callback for file existence check", e);
                    return false;
                }
            });

            logger.info("File exists: {}", exists);
            return exists != null && exists;
        } catch (Exception e) {
            logger.error("Error checking if file exists on SFTP: {}", filePath + originalFilename, e);
            return false;
        }
    }

    @Override
    public void uploadWithBackup(String filePath, String originalFilename, InputStream inputStream) throws Exception {
        logger.info("Uploading file with backup to SFTP using Spring Integration: {}", filePath + originalFilename);
        DefaultSftpSessionFactory factory = createSftpSessionFactory();
        SftpRemoteFileTemplate template = new SftpRemoteFileTemplate(factory);
        template.setAutoCreateDirectory(true);

        try {
            final String remoteFilePath = getFullPath(filePath + originalFilename);

            if (fileExists(filePath, originalFilename)) {
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
                String timestamp = LocalDateTime.now().format(formatter);
                String[] originalFilenameStrings = originalFilename.split("\\.");
                String backupDir = filePath + "backup/";
                final String backupFilePath = getFullPath(backupDir + originalFilenameStrings[0] + "_"
                        + timestamp + "." + originalFilenameStrings[1]);

                // Using execute method with callback to move existing file to backup
                template.execute(session -> {
                    try {
                        // Ensure backup directory exists
                        if (!session.exists(getFullPath(backupDir))) {
                            session.mkdir(getFullPath(backupDir));
                        }

                        // Move existing file to backup
                        session.rename(remoteFilePath, backupFilePath);
                        logger.info("Existing file moved to backup: {}", backupFilePath);
                        return true;
                    } catch (Exception e) {
                        logger.error("Error in session callback for backup", e);
                        throw e;
                    }
                });
            }

            // Upload new file
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            byte[] buffer = new byte[1024];
            int bytesRead;
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, bytesRead);
            }

            final byte[] fileData = outputStream.toByteArray();

            // Using execute method with callback to upload file
            template.execute(session -> {
                try {
                    session.write(new ByteArrayInputStream(fileData), remoteFilePath);
                    return true;
                } catch (Exception e) {
                    logger.error("Error in session callback for upload", e);
                    throw e;
                }
            });

            logger.info("File uploaded successfully with backup to SFTP: {}", filePath + originalFilename);
        } catch (Exception e) {
            logger.error("Error uploading file with backup to SFTP: {}", filePath + originalFilename, e);
            throw e;
        } finally {
            if (inputStream != null) {
                inputStream.close();
            }
        }
    }

    private String getFullPath(String path) {
        if (path.startsWith("/")) {
            return path;
        }
        return sftpRemoteDir +
                (sftpRemoteDir.endsWith("/") ? "" : "/") +
                path;
    }
}