package in.iftas.sfms.core.entity;

import jakarta.persistence.*;
import lombok.*;


@Entity
@Table(name = "i_branch_proliferation")
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class BranchProliferationEntity extends BaseEntity{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "bank_id",nullable = false)
    private Integer bankId;

    @Column(name = "branch_id", unique = true)
    private String branchId;

    @Lob
    @Column(name = "branch_details", nullable = false, columnDefinition = "LONGTEXT")
    private String branchDetailsJson;

    @Column(name = "is_proliferated", nullable = false)
    private Boolean isProliferated = false;

}