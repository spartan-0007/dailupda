package in.iftas.sfms.core.api.impl;

/*
 * Copyright (C) 2024 Iftas Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Iftas Inc. ("Confidential Information"). You shall not disclose
 * such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with Iftas Inc.
 *
 * Author: Manoj.Illa
 * Date: May 11, 2025
 */

import in.iftas.sfms.core.api.BankApprovalsApi;
import in.iftas.sfms.core.exception.BankAlreadyExistsException;
import in.iftas.sfms.core.exception.Branchalreadyexists;
import in.iftas.sfms.core.exception.ResourceNotFoundException;
import in.iftas.sfms.core.model.ApiResponseError;
import in.iftas.sfms.core.model.Bank;
import in.iftas.sfms.core.model.ModelApiResponse;
import in.iftas.sfms.core.service.BankApprovalService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;

@RestController
@RequiredArgsConstructor
@Slf4j
public class BankApprovalsApiImpl implements BankApprovalsApi {

    private final BankApprovalService bankApprovalService;

    @Override
    public ResponseEntity<ModelApiResponse> bankApprovalsPost(Bank bank) {
        log.info("Received request to create bank approval");
        ModelApiResponse modelApiResponse = new ModelApiResponse();
        try {

            bankApprovalService.createBankApproval(bank);
            modelApiResponse.setSuccess(true);
            modelApiResponse.setMessage("Bank approval request created successfully");
            log.info("Bank approval request created successfully");
            return ResponseEntity.status(HttpStatus.CREATED).body(modelApiResponse);

        } catch (BankAlreadyExistsException | Branchalreadyexists e) {
            log.error("Duplicate resource in approval: {}", e.getMessage());

            modelApiResponse.setSuccess(false);
            modelApiResponse.setMessage(e.getMessage());

            ApiResponseError error = new ApiResponseError();
            error.setCode(HttpStatus.CONFLICT.toString());
            error.setMessage(e.getMessage());
            modelApiResponse.setError(error);

            return ResponseEntity.status(HttpStatus.CONFLICT).body(modelApiResponse);

        } catch (IllegalArgumentException e) {
            // Handle validation errors
            log.error("Bad request for bank approval: {}", e.getMessage());
            ApiResponseError apiResponseError = new ApiResponseError();
            apiResponseError.setCode(HttpStatus.BAD_REQUEST.toString());
            apiResponseError.setCode("Invalid Request");
            modelApiResponse.setError(apiResponseError);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(modelApiResponse);

        } catch (IOException e) {
            // Handle IO/processing errors
            log.error("Error processing bank approval request: {}", e.getMessage(), e);
            ApiResponseError apiResponseError = new ApiResponseError();
            apiResponseError.setCode(HttpStatus.INTERNAL_SERVER_ERROR.toString());
            apiResponseError.setCode("An internal error occurred while processing the request");
            modelApiResponse.setError(apiResponseError);

            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(modelApiResponse);
        }

    }
    @Override
    public ResponseEntity<ModelApiResponse> bankApprovalsIdPut(Integer id, Bank bank) {
        log.info("Received request to create update approval for bank with ID: {}", id);
        ModelApiResponse modelApiResponse = new ModelApiResponse();

        try {
            bank.setId(id);
            bankApprovalService.updateBankApproval(id, bank);
            modelApiResponse.setSuccess(true);
            modelApiResponse.setMessage("Bank update approval request created successfully");
            log.info("Bank update approval request created successfully for bank ID: {}", id);

            return ResponseEntity.status(HttpStatus.OK).body(modelApiResponse);

        } catch (ResourceNotFoundException e) {
            log.error("Bank not found: {}", e.getMessage());

            modelApiResponse.setSuccess(false);
            modelApiResponse.setMessage(e.getMessage());

            ApiResponseError error = new ApiResponseError();
            error.setCode(HttpStatus.NOT_FOUND.toString());
            error.setMessage(e.getMessage());
            modelApiResponse.setError(error);

            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(modelApiResponse);

        } catch (Exception e) {
            log.error("Error processing bank update approval request: {}", e.getMessage(), e);

            modelApiResponse.setSuccess(false);
            modelApiResponse.setMessage("Error processing request");

            ApiResponseError apiResponseError = new ApiResponseError();
            apiResponseError.setCode(HttpStatus.INTERNAL_SERVER_ERROR.toString());
            apiResponseError.setMessage(e.getMessage());
            modelApiResponse.setError(apiResponseError);

            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(modelApiResponse);
        }
    }
    @Override
    public ResponseEntity<ModelApiResponse> bankApprovalsIdDelete(Integer id) {
        log.info("Received request to create delete approval for bank with ID: {}", id);
        ModelApiResponse modelApiResponse = new ModelApiResponse();

        try {
            bankApprovalService.deleteBankApproval(id);
            modelApiResponse.setSuccess(true);
            modelApiResponse.setMessage("Bank deletion approval request created successfully");
            log.info("Bank deletion approval request created successfully for bank ID: {}", id);

            return ResponseEntity.status(HttpStatus.OK).body(modelApiResponse);

        } catch (ResourceNotFoundException e) {
            log.error("Bank not found: {}", e.getMessage());

            modelApiResponse.setSuccess(false);
            modelApiResponse.setMessage(e.getMessage());

            ApiResponseError error = new ApiResponseError();
            error.setCode(HttpStatus.NOT_FOUND.toString());
            error.setMessage(e.getMessage());
            modelApiResponse.setError(error);

            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(modelApiResponse);

        } catch (IOException e) {
            log.error("Error processing bank deletion data: {}", e.getMessage(), e);

            modelApiResponse.setSuccess(false);
            modelApiResponse.setMessage("Error processing request data");

            ApiResponseError apiResponseError = new ApiResponseError();
            apiResponseError.setCode(HttpStatus.INTERNAL_SERVER_ERROR.toString());
            apiResponseError.setMessage("Error processing request data");
            modelApiResponse.setError(apiResponseError);

            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(modelApiResponse);
        } catch (Exception e) {
            log.error("Error processing bank deletion approval request: {}", e.getMessage(), e);

            modelApiResponse.setSuccess(false);
            modelApiResponse.setMessage("Error processing request");

            ApiResponseError apiResponseError = new ApiResponseError();
            apiResponseError.setCode(HttpStatus.INTERNAL_SERVER_ERROR.toString());
            apiResponseError.setMessage(e.getMessage());
            modelApiResponse.setError(apiResponseError);

            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(modelApiResponse);
        }
    }
}
