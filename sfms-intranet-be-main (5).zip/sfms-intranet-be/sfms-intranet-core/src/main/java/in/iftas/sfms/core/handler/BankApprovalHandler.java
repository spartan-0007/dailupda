// In sfms-intranet-core/src/main/java/in/iftas/sfms/core/service/BankApprovalHandler.java
package in.iftas.sfms.core.handler;

import com.fasterxml.jackson.databind.ObjectMapper;
import in.iftas.sfms.common.handler.ApprovalHandler;
import in.iftas.sfms.core.model.Bank;
import in.iftas.sfms.core.service.BankService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class BankApprovalHandler implements ApprovalHandler {

    private final BankService bankService;
    private final ObjectMapper objectMapper;

    @Autowired
    public BankApprovalHandler(BankService bankService, ObjectMapper objectMapper) {
        this.bankService = bankService;
        this.objectMapper = objectMapper;
    }

    @Override
    public String getEntityType() {
        return "BANK";
    }

    @Override
    public void handleApproval(Long approvalId, String actionType, String requestData, String entityId) {
        log.info("Processing bank approval - ID: {}, Action: {}", approvalId, actionType);

        try {
            Bank bank = objectMapper.readValue(requestData, Bank.class);

            switch (actionType.toUpperCase()) {
                case "CREATE":
                    bankService.addBank(bank);
                    log.info("Bank created successfully: {}", bank.getBankName());
                    break;

                case "UPDATE":
                    bankService.updateBank(bank);
                    log.info("Bank updated successfully: {}", entityId);
                    break;

                case "DELETE":
                    bankService.deleteBank(Integer.valueOf(entityId));
                    log.info("Bank deleted successfully: {}", entityId);
                    break;

                default:
                    throw new UnsupportedOperationException("Unsupported action type: " + actionType);
            }
        } catch (Exception e) {
            log.error("Error handling bank approval: {}", e.getMessage(), e);
            throw new RuntimeException("Failed to process bank approval", e);
        }
    }

    @Override
    public void handleRejection(Long approvalId, String rejectionReason, String entityType) {
        log.info("Bank approval {} rejected with reason: {}", approvalId, rejectionReason);

    }
}