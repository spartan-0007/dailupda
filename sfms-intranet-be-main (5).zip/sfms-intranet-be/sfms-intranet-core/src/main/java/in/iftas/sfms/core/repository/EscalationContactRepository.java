package in.iftas.sfms.core.repository;

import in.iftas.sfms.core.dto.EscalationContactDTO;
import in.iftas.sfms.core.entity.EscalationContactEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EscalationContactRepository extends JpaRepository<EscalationContactEntity, Long> {
    
    /**
     * Get all contacts across all banks with proper ordering for operator view
     */
    @Query("SELECT ec FROM EscalationContactEntity ec " +
           "JOIN FETCH ec.level el " +
           "JOIN FETCH el.department d " +
           "WHERE ec.isActive = true AND el.isActive = true AND d.isActive = true " +
           "ORDER BY ec.bankId, d.displayOrder, el.levelOrder, ec.contactOrder")
    List<EscalationContactEntity> findAllContactsOrderedByBankDepartmentAndLevel();
    
    /**
     * Get contacts for a specific bank with proper ordering for banker view
     */
    @Query("SELECT ec FROM EscalationContactEntity ec " +
           "JOIN FETCH ec.level el " +
           "JOIN FETCH el.department d " +
           "WHERE ec.bankId = :bankId AND ec.isActive = true AND el.isActive = true AND d.isActive = true " +
           "ORDER BY d.displayOrder, el.levelOrder, ec.contactOrder")
    List<EscalationContactEntity> findAllContactsByBankOrderedByDepartmentAndLevel(@Param("bankId") Long bankId);
    
    /**
     * Check for duplicate contact (used in insert validation)
     */
    boolean existsByBankIdAndLevelIdAndContactNameAndContactEmailAndContactNumberAndFeatureAndBusinessAndDesignation(
            Long bankId, Long levelId, String contactName, String contactEmail, String contactNumber, String feature, String business, String designation);
    
    /**
     * Get contacts by level for specific scenarios
     */
    @Query("SELECT ec FROM EscalationContactEntity ec " +
           "WHERE ec.level.id = :levelId AND ec.isActive = true " +
           "ORDER BY ec.contactOrder")
    List<EscalationContactEntity> findByLevelIdAndIsActiveTrueOrderByContactOrder(@Param("levelId") Long levelId);

    @Query("SELECT new in.iftas.sfms.core.dto.EscalationContactDTO(b.bankName, ec.contactName, ec.contactEmail, ec.contactNumber, ec.designation, el.levelName, el.levelOrder, ec.business, d.departmentCode, d.departmentName, d.displayOrder) " +
            "FROM EscalationContactEntity ec " +
            "JOIN ec.level el " +
            "JOIN el.department d " +
            "JOIN BankEntity b ON b.id = ec.bankId " +
            "WHERE ec.isActive = true")
    List<EscalationContactDTO> findAllDTO();

    @Query("SELECT new in.iftas.sfms.core.dto.EscalationContactDTO(b.bankName, ec.contactName, ec.contactEmail, ec.contactNumber, ec.designation, el.levelName, el.levelOrder, ec.business, d.departmentCode, d.departmentName, d.displayOrder) " +
            "FROM EscalationContactEntity ec " +
            "JOIN ec.level el " +
            "JOIN el.department d " +
            "JOIN BankEntity b ON b.id = ec.bankId " +
            "WHERE d.id = :departmentId AND ec.bankId = :bankId")
    List<EscalationContactDTO> findDTOByDepartmentIdAndBankId(@Param("departmentId") Long departmentId, @Param("bankId") Long bankId);

    @Query("SELECT new in.iftas.sfms.core.dto.EscalationContactDTO(b.bankName, ec.contactName, ec.contactEmail, ec.contactNumber, ec.designation, el.levelName, el.levelOrder, ec.business, d.departmentCode, d.departmentName, d.displayOrder) " +
            "FROM EscalationContactEntity ec " +
            "JOIN ec.level el " +
            "JOIN el.department d " +
            "JOIN BankEntity b ON b.id = ec.bankId " +
            "WHERE ec.bankId = :bankId")
    List<EscalationContactDTO> findDTOByBankId(@Param("bankId") Long bankId);

}