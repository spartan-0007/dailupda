package in.iftas.sfms.core.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "i_proliferation_activity_log")
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ProliferationActivityLogEntity extends BaseEntity{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "branch_id")
    private Long branchId;

    @Column(name = "validation_status")
    private String validationStatus;

    @Lob
    @Column(name = "error_message", nullable = false, columnDefinition = "LONGTEXT")
    private String errorMessage;

}