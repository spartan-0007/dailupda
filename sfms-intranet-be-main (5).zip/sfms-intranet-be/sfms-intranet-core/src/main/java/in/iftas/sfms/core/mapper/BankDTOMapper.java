package in.iftas.sfms.core.mapper;

import in.iftas.sfms.core.dto.BankDTO;
import in.iftas.sfms.core.entity.BankEntity;
import in.iftas.sfms.core.model.Bank;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper(componentModel = "spring")
public interface BankDTOMapper {

    BankDTOMapper INSTANCE = Mappers.getMapper(BankDTOMapper.class);

    @Mapping(target = "branches", source = "branches")
    BankEntity bankDTOToBankEntity(BankDTO bankDTO);

    @Mapping(target = "branches", source = "branches")
    BankDTO bankEntityToBankDTO(BankEntity bankEntity);

    @Mapping(target = "branches", source = "branches")
    Bank bankDTOToBank(BankDTO bankDTO);

    @Mapping(target = "branches", source = "branches")
    BankDTO bankToBankDTO(Bank bank);
}