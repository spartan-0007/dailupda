package in.iftas.sfms.core.dto;

import lombok.*;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Builder // Add Builder annotation
public class ProcessingResultDTO {

    private int totalProcessed;
    private int totalFailed;

    @Builder.Default
    private List<String> failedRecords = new ArrayList<>();

    public void incrementProcessed() {
        this.totalProcessed++;
    }

    public void incrementFailed() {
        this.totalFailed++;
    }

    public void addFailedRecord(String senderReference) {
        this.failedRecords.add(senderReference);
    }
}