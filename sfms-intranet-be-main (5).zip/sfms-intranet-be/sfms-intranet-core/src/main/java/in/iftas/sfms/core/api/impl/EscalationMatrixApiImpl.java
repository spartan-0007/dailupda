package in.iftas.sfms.core.api.impl;

import in.iftas.sfms.core.api.EscalationMatrixApi;
import in.iftas.sfms.core.exception.DuplicateEntryException;
import in.iftas.sfms.core.exception.FileProcessingException;
import in.iftas.sfms.core.exception.ResourceNotFoundException;
import in.iftas.sfms.core.model.EscalationContact;
import in.iftas.sfms.core.model.Level;
import in.iftas.sfms.core.service.EscalationContactService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.Resource;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class EscalationMatrixApiImpl implements EscalationMatrixApi {
    private static final Logger logger = LoggerFactory.getLogger(EscalationMatrixApiImpl.class);

    private final EscalationContactService escalationContactService;

    public EscalationMatrixApiImpl(EscalationContactService escalationContactService) {
        this.escalationContactService = escalationContactService;
    }

    @Override
    public ResponseEntity<Void> addEscalationContactForBank(@PathVariable("bankId") Long bankId,
                                                            @RequestBody EscalationContact escalationContact) {
        logger.info("Entering addEscalationContactForBank method with bankId: {} and escalationContact: {}", bankId, escalationContact);


        escalationContact.setBankId(bankId);


        try {
            escalationContactService.saveEscalationContact(escalationContact);
            logger.info("Escalation contact saved successfully for bankId: {}", bankId);
            return new ResponseEntity<>(HttpStatus.CREATED);
        } catch (DuplicateEntryException e) {
            logger.error("Duplicate Entry found for: {}", e.getMessage());
            return new ResponseEntity<>(HttpStatus.CONFLICT);
        } catch (IllegalArgumentException e) {
            logger.error("Error while processing escalation contact: {}", e.getMessage());
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        } catch (Exception e) {
            logger.error("Unexpected error while saving escalation contact: {}", e.getMessage());
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    public ResponseEntity<List<List<EscalationContact>>> getAllEscalationMatrices() {
        logger.info("Entering getAllEscalationMatrices method");


        try {
            List<List<EscalationContact>> escalationContacts = escalationContactService.getAllEscalationContacts();
            if (escalationContacts.isEmpty()) {
                logger.warn("No escalation contacts found");
                return ResponseEntity.status(HttpStatus.NOT_FOUND).build(); // Return 404 if no contacts found
            }
            logger.info("Returning {} escalation contact matrices", escalationContacts.size());
            return ResponseEntity.ok(escalationContacts); // Return 200 with the list of contacts
        } catch (Exception e) {

            logger.error("Error occurred while getting escalation contacts. Error: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build(); // Return 500 on error
        }
    }

    @Override
    public ResponseEntity<List<EscalationContact>> getEscalationMatrixByBankId(@PathVariable("bankId") Long bankId) {
        logger.info("Entering getEscalationMatrixByBankId method with bankId: {}", bankId);
        try {
            List<EscalationContact> escalationContacts = escalationContactService.getEscalationMatrixByBankId(bankId);
            if (escalationContacts.isEmpty()) {
                logger.warn("No escalation contacts found for bankId: {}", bankId);
                return new ResponseEntity<>(HttpStatus.NOT_FOUND);
            }
            logger.info("Returning {} escalation contacts for bankId: {}", escalationContacts.size(), bankId);
            return new ResponseEntity<>(escalationContacts, HttpStatus.OK);
        } catch (Exception e) {

            logger.error("Error occurred while getting escalation contacts for bankId: {}. Error: {}", bankId, e.getMessage());
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    public ResponseEntity<Void> updateEscalationMatrixEntry(EscalationContact escalationContact) {
        try{
            escalationContactService.updateEscalationMatrix(escalationContact);
            logger.info("Escalation contact updated successfully ");
            return ResponseEntity.status(HttpStatusCode.valueOf(204)).build();
        } catch (DuplicateEntryException e) {
            logger.error("Duplicate Entry found for: {}", e.getMessage());
            return new ResponseEntity<>(HttpStatus.CONFLICT);
        } catch (IllegalArgumentException e) {
            logger.error("Error while processing escalation contact: {}", e.getMessage());
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        } catch (Exception e) {
            logger.error("Unexpected error while saving escalation contact: {}", e.getMessage());
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    @Override
    public ResponseEntity<Void> escalationMatrixDelete(Long id) {
        escalationContactService.deleteEscalationMatrix(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @Override
    public ResponseEntity<Resource> downloadEscalationPdf(@RequestParam(value = "level", required = false) Long level,@RequestParam(value = "bankId", required = false) Long bankId) {
        logger.info("Attempting to download Escalation Matrix with level: {} and bankId: {}", level,bankId);

        try {
            Resource pdfResource = escalationContactService.downloadEscalationMatrixAsPDF(level,bankId);

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_PDF);
            headers.setContentDisposition(ContentDisposition.attachment().filename("EscalationMatrix.pdf").build());
            headers.setContentLength(pdfResource.contentLength());

            logger.info("Successfully retrieved PDF for Change Request Form with ID: {}", level);
            return new ResponseEntity<>(pdfResource, headers, HttpStatus.OK);

        } catch (ResourceNotFoundException e) {
            logger.error("Failed to find Escalation Matrix with ID: {}. Error: {}", level, e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();

        } catch (FileProcessingException e) {
            logger.error("Error during file generation for Escalation Matrix with ID: {}. Error: {}", level, e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();

        } catch (Exception e) {
            logger.error("Internal server error during download of Escalation Matrix with ID: {}. Error: {}", level, e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @Override
    public ResponseEntity<List<Level>> getAllEscalationMatrixLevels() {
        try {
            logger.info("Getting all escalation matrix levels");
            List<Level> levels = escalationContactService.getAllLevels();
            logger.info("Successfully retrieved {} escalation levels", levels.size());
            return new ResponseEntity<>(levels, HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error while retrieving escalation matrix levels", e);
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

}

