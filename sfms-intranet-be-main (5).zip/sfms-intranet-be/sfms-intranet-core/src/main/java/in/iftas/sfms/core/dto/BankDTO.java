package in.iftas.sfms.core.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class BankDTO {

    @JsonProperty("ID")
    private Long id;

    @JsonProperty("BANK NAME")
    private String bankName;

    @JsonProperty("BANK SHORT NAME")
    private String bankShortName;

    @JsonProperty("IS ACTIVE")
    private Boolean isActive;

    @JsonProperty("IS HOSTED ON CLOUD")
    private Boolean isHostedOnCloud;

    @JsonProperty("BUSINESS")
    private String business;

    @Valid
    @JsonProperty("BRANCHES")
    private List<BranchDTO> branches;

    public BankDTO(String bankName, String bankShortName, Boolean isActive, Boolean isHostedOnCloud, BranchDTO branch) {
        this.bankName = bankName;
        this.bankShortName = bankShortName;
        this.isActive = isActive;
        this.isHostedOnCloud = isHostedOnCloud;
        this.branches = List.of(branch);
    }

    public BankDTO(Long id, String bankName, String bankShortName, Boolean isActive, Boolean isHostedOnCloud, String business) {
        this.id = id;
        this.bankName = bankName;
        this.bankShortName = bankShortName;
        this.isActive = isActive;
        this.isHostedOnCloud = isHostedOnCloud;
        this.business = business;
    }

}