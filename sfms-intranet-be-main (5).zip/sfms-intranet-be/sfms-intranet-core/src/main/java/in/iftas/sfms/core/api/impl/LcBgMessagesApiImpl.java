package in.iftas.sfms.core.api.impl;

/*
 * Copyright (C) 2024 Iftas Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Iftas Inc. ("Confidential Information"). You shall not disclose
 * such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with Iftas Inc.
 *
 * Author: Manoj.Illa
 * Date: July 11, 2024
 */

import com.itextpdf.text.DocumentException;
import in.iftas.sfms.core.api.LcBgMessagesApi;
import in.iftas.sfms.core.dto.ProcessingResultDTO;
import in.iftas.sfms.core.exception.InvalidFileFormatException;
import in.iftas.sfms.core.exception.PartialProcessException;
import in.iftas.sfms.core.exception.ResourceNotFoundException;
import in.iftas.sfms.core.model.ApiResponseError;
import in.iftas.sfms.core.model.LcBgMessage;
import in.iftas.sfms.core.model.LcBgMessagesReportRequest;
import in.iftas.sfms.core.model.ModelApiResponse;
import in.iftas.sfms.core.service.LcBgMessagesService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.Resource;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Collections;

@RestController
public class LcBgMessagesApiImpl implements LcBgMessagesApi {

    private static final Logger logger = LoggerFactory.getLogger(LcBgMessagesApiImpl.class);


    private final LcBgMessagesService lcBgMessagesService;

    public LcBgMessagesApiImpl(LcBgMessagesService lcBgMessagesService) {
        this.lcBgMessagesService = lcBgMessagesService;
    }

    @Override
    public ResponseEntity<ModelApiResponse> uploadLcBgMessages(@RequestParam("file") MultipartFile file) {
        logger.info("Received request to upload LC/BG messages");

        ModelApiResponse response = new ModelApiResponse();

        try {

            if (file == null || file.isEmpty()) {
                logger.warn("Invalid file format or validation error");
                response.setSuccess(false);
                response.setMessage("Invalid file format or validation error.");
                return ResponseEntity.badRequest().body(response);
            }

            logger.debug("Processing the Excel file");
            ProcessingResultDTO result = lcBgMessagesService.processExcelFile(file);

            logger.info("File uploaded and validated successfully");
            response.setSuccess(true);
            response.setMessage("File uploaded and validated successfully.");
            response.setData(Collections.singletonMap("lcBgResponse", result));
            return ResponseEntity.ok(response);

        } catch (PartialProcessException ex) {
            logger.warn("Partial processing error: {}", ex.getMessage(), ex);
            response.setSuccess(false);
            response.setData(Collections.singletonMap("lcBgResponse", ex.getProcessingResultDTO()));
            ApiResponseError error = new ApiResponseError();
            error.setCode(HttpStatus.PARTIAL_CONTENT.toString());
            error.setMessage("Partial processing occurred");
            response.setError(error);
            return ResponseEntity.status(HttpStatus.PARTIAL_CONTENT).body(response);
        } catch (InvalidFileFormatException ex) {
            logger.warn("Invalid File Format error: {}", ex.getMessage(), ex);
            response.setSuccess(false);
            ApiResponseError error = new ApiResponseError();
            error.setCode(HttpStatus.BAD_REQUEST.toString());
            error.setMessage(ex.getMessage());
            response.setError(error);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
        } catch (Exception e) {
            logger.error("Internal server error: {}", e.getMessage(), e);
            response.setSuccess(false);
            ApiResponseError error = new ApiResponseError();
            error.setCode(HttpStatus.INTERNAL_SERVER_ERROR.toString());
            error.setMessage("Internal server error");
            response.setError(error);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    @Override
    public ResponseEntity<Resource> downloadLcBgMessagesPdf(
            @RequestParam(value = "fromDate", required = true) String fromDate,
            @RequestParam(value = "toDate", required = true) String toDate,
            @RequestParam(value = "bankId", required = false) Long bankId) {
        logger.info("Received request to download LC/BG messages PDF");

        try {

            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

            LocalDateTime fromDateParsed = LocalDateTime.parse(fromDate, formatter);
            logger.debug("Parsed fromDate: {}", fromDateParsed);

            LocalDateTime toDateParsed = LocalDateTime.parse(toDate, formatter);
            logger.debug("Parsed toDate: {}", toDateParsed);

            Resource pdfResource = lcBgMessagesService
                    .generateConsolidatedLcBgPdfReport(bankId, fromDateParsed, toDateParsed);
            logger.info("Generated PDF report");

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_PDF);
            headers.setContentDisposition(ContentDisposition.attachment().filename("lc_bg_messages_report.pdf").build());
            headers.setContentLength(pdfResource.contentLength());

            logger.info("Returning PDF report as a downloadable file");
            return new ResponseEntity<>(pdfResource, headers, HttpStatus.OK);

        }
        catch (ResourceNotFoundException e) {
            logger.error("Error generating report: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }catch (DocumentException | IOException e) {
            logger.error("Error generating PDF report: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }

    }

    @Override
    public ResponseEntity<org.springframework.core.io.Resource> downloadLcBgMessages(LcBgMessagesReportRequest lcBgMessagesReportRequest) {

        logger.info("Received request to download LC/BG messages report");
        try {
            Resource resource = lcBgMessagesService.generateDetailedLcBgReport(lcBgMessagesReportRequest);
            logger.info("Generated detailed LC/BG report");
            HttpHeaders headers = new HttpHeaders();
            headers.setContentLength(resource.contentLength());

            if (LcBgMessagesReportRequest.FormatEnum.PDF.equals(lcBgMessagesReportRequest.getFormat())) {
                headers.setContentType(MediaType.APPLICATION_PDF);
                headers.setContentDisposition(ContentDisposition.attachment().filename("lc_bg_detailed_report.pdf").build());
                return new ResponseEntity<>(resource, headers, HttpStatus.OK);

            } else if (LcBgMessagesReportRequest.FormatEnum.EXCEL.equals(lcBgMessagesReportRequest.getFormat())) {

                headers.setContentType(MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"));
                headers.setContentDisposition(ContentDisposition.attachment().filename("lc_bg_messages_report.xlsx").build());

                logger.info("Returning Excel report as a downloadable file");
                return new ResponseEntity<>(resource, headers, HttpStatus.OK);
            } else {
                logger.warn("Unsupported format requested: {}", lcBgMessagesReportRequest.getFormat());
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);  // Unsupported format
            }
        }
        catch (ResourceNotFoundException e) {
            logger.error("Error generating report: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }catch (Exception e) {
            logger.error("Error generating report: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }

    @Override
    public ResponseEntity<ModelApiResponse> getLcBgMessageById(@PathVariable("senderReferenceNumber") String senderReferenceNumber) {
        logger.info("Fetching LC/BG message with sender reference number: {}", senderReferenceNumber);
        ModelApiResponse response = new ModelApiResponse();
        try {
            LcBgMessage lcBgMessage = lcBgMessagesService.getBySenderReferenceNumber(senderReferenceNumber);
            response.setSuccess(true);
            response.setMessage("LC/BG message details retrieved successfully.");
            response.getData().put("lcBgMessage", lcBgMessage);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (RuntimeException e) {
            logger.error("Error fetching LC/BG message with sender reference number: {}", senderReferenceNumber, e);
            response.setSuccess(false);
            response.setMessage("Message not found.");
            ApiResponseError apiResponseError = new ApiResponseError();
            apiResponseError.setCode("404");
            apiResponseError.setMessage("Message not found.");
            response.setError(apiResponseError);
            return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            logger.error("Internal server error while fetching LC/BG message with sender reference number: {}", senderReferenceNumber, e);
            response.setSuccess(false);
            response.setMessage("Internal server error.");
            ApiResponseError apiResponseError = new ApiResponseError();
            apiResponseError.setCode("500");
            apiResponseError.setMessage("Internal Server Error.");
            response.setError(apiResponseError);
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

}
