package in.iftas.sfms.core.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "i_bank_contacts", indexes = {
        @Index(name = "idx_bank_branch_ifsc_code", columnList = "bank_branch_ifsc_code"),
        @Index(name = "idx_email", columnList = "email"),
        @Index(name = "idx_mobile", columnList = "mobile")
})
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class BankContactEntity extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "bank_branch_ifsc_code", nullable = false)
    private BranchEntity bankBranch;

    @Column(name = "email")
    private String email;

    @Column(name = "std_code")
    private String stdCode;

    @Column(name = "landline")
    private String landline;

    @Column(name = "mobile")
    private String mobile;
}