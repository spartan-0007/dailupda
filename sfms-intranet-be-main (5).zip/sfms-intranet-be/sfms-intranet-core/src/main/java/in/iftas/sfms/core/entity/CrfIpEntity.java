package in.iftas.sfms.core.entity;/*
 * Copyright (C) 2024 Iftas Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Iftas Inc. ("Confidential Information"). You shall not disclose
 * such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with Iftas Inc.
 *
 * Author: Manoj.Illa
 * Date: July 11, 2024
 */

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "i_crf_ip", indexes = {
        @Index(name = "idx_source_ip1", columnList = "source_ip1"),
        @Index(name = "idx_crf_id", columnList = "crf_id")
})
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CrfIpEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "crf_id", nullable = false)
    private ChangeRequestFormEntity crf;

    @Column(name = "source_ip1")
    private String sourceIp1;

    @Column(name = "source_ip2")
    private String sourceIp2;

    @Column(name = "source_ip3")
    private String sourceIp3;

    @Column(name = "source_ip4")
    private String sourceIp4;

    @Column(name = "source_ip5")
    private String sourceIp5;

    @Column(name = "source_ip6")
    private String sourceIp6;

    @Column(name = "source_ip7")
    private String sourceIp7;

    @Column(name = "destination_ip1")
    private String destinationIp1;

    @Column(name = "destination_ip2")
    private String destinationIp2;

    @Column(name = "destination_ip3")
    private String destinationIp3;

    @Column(name = "destination_ip4")
    private String destinationIp4;

    @Column(name = "destination_ip5")
    private String destinationIp5;

    @Column(name = "destination_ip6")
    private String destinationIp6;

    @Column(name = "destination_ip7")
    private String destinationIp7;

    @Column(name = "port")
    private String port;

}
