package in.iftas.sfms.core.api.impl;/*
 * Copyright (C) 2024 Iftas Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Iftas Inc. ("Confidential Information"). You shall not disclose
 * such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with Iftas Inc.
 *
 * Author: Manoj.Illa
 * Date: July 11, 2024
 */

import in.iftas.sfms.core.api.ContactusApi;
import in.iftas.sfms.core.model.ContactUs;
import in.iftas.sfms.core.model.ModelApiResponse;
import in.iftas.sfms.core.service.ContactUsService;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.Collections;
import java.util.List;

@RestController
public class ContactUsApiImpl implements ContactusApi {
    private static final Logger logger = LoggerFactory.getLogger(ContactUsApiImpl.class);

    private final ContactUsService contactUsService;

    public ContactUsApiImpl(ContactUsService contactUsService) {
        this.contactUsService = contactUsService;
    }

    @Override
    public ResponseEntity<ModelApiResponse> contactusPost(@Valid @RequestBody ContactUs contactUs) {
        logger.info("Entering contactusPost method with contactUs: {}", contactUs);

        try {
            ModelApiResponse modelApiResponse = new ModelApiResponse();

            Long contactId = contactUsService.createContact(contactUs);
            logger.info("Contact created successfully with ID: {}", contactId);
            modelApiResponse.setSuccess(true);
            modelApiResponse.setMessage("Contact Created Successfully");
            modelApiResponse.setData(Collections.singletonMap("contactId", contactId));
            logger.info("Returning response with status CREATED and contactId: {}", contactId);

            return new ResponseEntity<>(modelApiResponse, HttpStatus.CREATED);

        } catch (IllegalArgumentException e) {
            logger.error("Bad request error: {}", e.getMessage());
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        } catch (Exception e) {
            logger.error("Internal server error: {}", e.getMessage());
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    public ResponseEntity<List<ContactUs>> contactusGet() {
        logger.info("Entering contactusGet method");
        try {
            List<ContactUs> contactUsList = contactUsService.getAllContactEntries();
            logger.info("Retrieved {} contact entries", contactUsList.size());
            return new ResponseEntity<>(contactUsList, HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Failed to retrieve contact entries. Error: {}", e.getMessage());
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

    @Override
    public ResponseEntity<Void> contactusPut(@Valid @RequestBody ContactUs contactUs) {
        try {
            logger.info("Entering contactusPut method with contactUs: {}", contactUs);
            boolean isUpdated = contactUsService.updateContact(contactUs);
            if (isUpdated) {
                logger.info("Contact updated successfully: {}", contactUs);
                return new ResponseEntity<>(HttpStatus.OK);
            } else {
                logger.warn("Contact not found for update: {}", contactUs);
                return new ResponseEntity<>(HttpStatus.NOT_FOUND);
            }
        } catch (IllegalArgumentException e) {
            logger.error("Bad request error: {}", e.getMessage());
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        } catch (Exception e) {
            logger.error("Internal server error: {}", e.getMessage());
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

}
