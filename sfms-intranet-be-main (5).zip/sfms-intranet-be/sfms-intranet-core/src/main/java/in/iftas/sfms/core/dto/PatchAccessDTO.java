package in.iftas.sfms.core.dto;

import in.iftas.sfms.core.model.BankAccess;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.time.LocalDateTime;
import java.util.List;

@Getter
@Setter
@ToString
public class PatchAccessDTO {

    private Long patchId;
    private String fileName;
    private String version;
    private String uploadedBy;
    private LocalDateTime uploadedDate; // Assuming you're using LocalDateTime for dates
    private List<BankAccess> banksWithAccess;

}
