package in.iftas.sfms.core.exception;

import in.iftas.sfms.core.dto.ProcessingResultDTO;

public class PartialProcessException extends RuntimeException {
    private final ProcessingResultDTO processingResultDTO;

    public PartialProcessException(String message, ProcessingResultDTO processingResultDTO) {
        super(message);
        this.processingResultDTO = processingResultDTO;
    }

    public ProcessingResultDTO getProcessingResultDTO() {
        return processingResultDTO;
    }
}