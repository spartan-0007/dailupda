package in.iftas.sfms.core.repository;

import in.iftas.sfms.core.dto.BranchDTO;
import in.iftas.sfms.core.entity.BranchEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BankBranchRepository extends JpaRepository<BranchEntity, String> {
    Page<BranchEntity> findByBank_BankName(String bankName, Pageable pageable);

    boolean existsByMicrCode(String micrCode);

    Page<BranchEntity> findByBankId(Integer bankId, Pageable pageable);

    @Query("SELECT new in.iftas.sfms.core.dto.BranchDTO(bb.branchName, bb.ifscCode) in FROM BranchEntity bb " +
            "LEFT JOIN bb.bank b LEFT JOIN bb.branchFeature bf WHERE bf.rtgsEnabled = true " +
            "AND bb.isActive = true AND b.isActive = true")
    List<BranchDTO> findActiveRtgsEnabledBranches();

    @Query("SELECT new in.iftas.sfms.core.dto.BranchDTO(bb.branchName, bb.ifscCode) in FROM BranchEntity bb " +
            "LEFT JOIN bb.bank b LEFT JOIN bb.branchFeature bf WHERE bf.neftEnabled = true " +
            "AND bb.isActive = true AND b.isActive = true")
    List<BranchDTO> findActiveNeftEnabledBranches();

    @Query("SELECT new in.iftas.sfms.core.dto.BranchDTO(bb.branchName, bb.ifscCode) in FROM BranchEntity bb " +
            "LEFT JOIN bb.bank b LEFT JOIN bb.branchFeature bf " +
            "WHERE bf.rtgsEnabled = true AND bf.neftEnabled = true AND b.isActive = true AND bb.isActive = true")
    List<BranchDTO> findActiveRtgsNeftEnabledBranches();

    @Query("SELECT new in.iftas.sfms.core.dto.BranchDTO(bb.branchName, bb.ifscCode) in FROM BranchEntity bb " +
            "LEFT JOIN bb.bank b LEFT JOIN bb.branchFeature bf WHERE bf.lcEnabled = true " +
            "AND b.isActive = true AND bb.isActive = true")
    List<BranchDTO> findActiveLcEnabledBranches();

    @Query("SELECT new in.iftas.sfms.core.dto.BranchDTO(bb.branchName, bb.ifscCode) in FROM BranchEntity bb " +
            "LEFT JOIN bb.bank b LEFT JOIN bb.branchFeature bf WHERE bf.bgEnabled = true " +
            "AND b.isActive = true AND bb.isActive = true")
    List<BranchDTO> findActiveBgEnabledBranches();

    @Query("SELECT new in.iftas.sfms.core.dto.BranchDTO(bb.branchName, bb.ifscCode) in FROM BranchEntity bb " +
            "LEFT JOIN bb.bank b LEFT JOIN bb.branchFeature bf " +
            "WHERE bf.lcEnabled = true AND bf.bgEnabled = true AND b.isActive = true AND bb.isActive = true")
    List<BranchDTO> findActiveLcBgEnabledBranches();

    @Query("SELECT new in.iftas.sfms.core.dto.BranchDTO(bb.branchName, bb.ifscCode) in FROM BranchEntity bb " +
            "LEFT JOIN bb.bank b LEFT JOIN bb.branchFeature bf WHERE bf.others = true " +
            "AND b.isActive = true AND bb.isActive = true")
    List<BranchDTO> findActiveOthersEnabledBranches();

    @Query("SELECT new in.iftas.sfms.core.dto.BranchDTO(b.ifscCode, b.ifscType, b.micrCode, b.branchName, b.cityName, " +
            " b.bankAddress, b.bank.id, b.district, b.state, c.stdCode, c.mobile, " +
            "CASE WHEN f.neftEnabled THEN 'Yes' ELSE 'No' END, " +
            "CASE WHEN f.rtgsEnabled THEN 'Yes' ELSE 'No' END, " +
            "CASE WHEN f.lcEnabled THEN 'Yes' ELSE 'No' END, " +
            "CASE WHEN f.bgEnabled THEN 'Yes' ELSE 'No' END, " +
            "CASE WHEN f.others THEN 'Yes' ELSE 'No' END) " +
            "FROM BranchEntity b " +
            "LEFT JOIN b.branchContact c " +
            "LEFT JOIN b.branchFeature f " +
            "WHERE b.ifscType like :ifscType " +
            "AND b.isActive = true " +
            "AND b.bank.isActive = true")
    Page<BranchDTO> findBranchesByIfscType(@Param("ifscType") String ifscType, Pageable pageable);

    @Query("SELECT new in.iftas.sfms.core.dto.BranchDTO(b.ifscCode, b.ifscType, b.micrCode, b.branchName, b.cityName, " +
            " b.bankAddress, b.bank.id, b.district, b.state, c.stdCode, c.mobile, " +
            "CASE WHEN f.neftEnabled THEN 'Yes' ELSE 'No' END, " +
            "CASE WHEN f.rtgsEnabled THEN 'Yes' ELSE 'No' END, " +
            "CASE WHEN f.lcEnabled THEN 'Yes' ELSE 'No' END, " +
            "CASE WHEN f.bgEnabled THEN 'Yes' ELSE 'No' END, " +
            "CASE WHEN f.others THEN 'Yes' ELSE 'No' END) " +
            "FROM BranchEntity b " +
            "LEFT JOIN b.branchContact c " +
            "LEFT JOIN b.branchFeature f " +
            "WHERE b.isActive = true " +
            "AND b.bank.isActive = true")
    Page<BranchDTO> findAllBranches(Pageable pageable);

    Page<BranchEntity> findByIfscCodeContaining(String ifscCode, Pageable pageable);

    long countByBankId(Integer bankId);

    long countByIfscCodeContaining(String ifscCode);
}