package in.iftas.sfms.core.repository;

import in.iftas.sfms.core.entity.EscalationApprovalEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface EscalationApprovalRepository extends JpaRepository<EscalationApprovalEntity, Long> {

    /**
     * Find approval by ID with steps eagerly loaded
     * Used in: getApprovalDetails() to avoid N+1 problem
     */
    @Query("SELECT a FROM EscalationApprovalEntity a LEFT JOIN FETCH a.steps WHERE a.id = :id")
    Optional<EscalationApprovalEntity> findByIdWithSteps(@Param("id") Long id);

    /**
     * Find approvals by current checker and status
     * Used in: getPendingApprovalsForUser()
     */
    List<EscalationApprovalEntity> findByCurrentCheckerIdAndStatus(
            String currentCheckerId,
            EscalationApprovalEntity.Status status
    );

    /**
     * Find existing pending approval for an escalation
     * Used in: validateApprovalRequest() to prevent duplicate approvals
     */
    Optional<EscalationApprovalEntity> findByEscalationIdAndStatus(
            Long escalationId,
            EscalationApprovalEntity.Status status
    );

    /**
     * Find approvals by maker - useful for maker dashboard
     * Used in: UI to show maker's submitted requests
     */
    List<EscalationApprovalEntity> findByMakerIdOrderByCreatedDateDesc(String makerId);

    /**
     * Find approvals by status with steps eagerly loaded
     * Used in: Dashboard to show pending approvals with step details
     */
    @Query("SELECT a FROM EscalationApprovalEntity a LEFT JOIN FETCH a.steps WHERE a.status = :status")
    List<EscalationApprovalEntity> findByStatusWithSteps(@Param("status") EscalationApprovalEntity.Status status);

    /**
     * Find approvals by maker with steps eagerly loaded
     * Used in: Maker dashboard to show detailed approval status
     */
    @Query("SELECT a FROM EscalationApprovalEntity a LEFT JOIN FETCH a.steps WHERE a.makerId = :makerId ORDER BY a.createdDate DESC")
    List<EscalationApprovalEntity> findByMakerIdWithSteps(@Param("makerId") String makerId);

    /**
     * Count pending approvals for a checker - dashboard metric
     * Used in: Dashboard to show workload
     */
    @Query("SELECT COUNT(ea) FROM EscalationApprovalEntity ea WHERE " +
            "ea.currentCheckerId = :checkerId AND ea.status = 'PENDING'")
    Long countPendingApprovalsByChecker(@Param("checkerId") String checkerId);

    /**
     * Find approvals by status and action type
     * Used in: validateNoPendingApprovalForSameContactData()
     */
    List<EscalationApprovalEntity> findByStatusAndActionType(
            EscalationApprovalEntity.Status status,
            EscalationApprovalEntity.ActionType actionType
    );


    /**
     * Find approvals by status
     */
    List<EscalationApprovalEntity> findByStatus(EscalationApprovalEntity.Status status);

    /**
     * Find approvals by status with pagination
     */
    Page<EscalationApprovalEntity> findByStatus(EscalationApprovalEntity.Status status, Pageable pageable);

    /**
     * Count approvals by status
     */
    Long countByStatus(EscalationApprovalEntity.Status status);

    /**
     * Find overdue approvals
     */
    List<EscalationApprovalEntity> findByStatusAndDueDateBefore(
            EscalationApprovalEntity.Status status,
            LocalDateTime dueDate
    );

    /**
     * Search approvals by maker name or request data content
     */
    @Query("SELECT a FROM EscalationApprovalEntity a WHERE " +
            "LOWER(a.makerName) LIKE LOWER(CONCAT('%', :searchTerm, '%')) OR " +
            "LOWER(a.requestData) LIKE LOWER(CONCAT('%', :searchTerm, '%'))")
    List<EscalationApprovalEntity> searchByMakerNameOrRequestData(@Param("searchTerm") String searchTerm);

    List<EscalationApprovalEntity> findByStatusAndDueDateAfter(EscalationApprovalEntity.Status status, LocalDateTime currentDateTime);
}