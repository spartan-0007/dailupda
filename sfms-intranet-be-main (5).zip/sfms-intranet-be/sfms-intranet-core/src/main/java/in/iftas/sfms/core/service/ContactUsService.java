package in.iftas.sfms.core.service;

/*
 * Copyright (C) 2024 Iftas Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Iftas Inc. ("Confidential Information"). You shall not disclose
 * such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with Iftas Inc.
 *
 * Author: Manoj.Illa
 * Date: July 11, 2024
 */

import in.iftas.sfms.core.entity.ContactUsEntity;
import in.iftas.sfms.core.entity.ContactUsLevelEntity;
import in.iftas.sfms.core.model.ContactUs;
import in.iftas.sfms.core.repository.ContactUsLevelRepository;
import in.iftas.sfms.core.repository.ContactUsRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Stream;

@Service
public class ContactUsService {
    private static final Logger logger = LoggerFactory.getLogger(ContactUsService.class);
    private final ContactUsRepository contactUsRepository;
    private final ContactUsLevelRepository contactUsLevelRepository;

    public ContactUsService(ContactUsRepository contactUsRepository, ContactUsLevelRepository contactUsLevelRepository) {
        this.contactUsRepository = contactUsRepository;
        this.contactUsLevelRepository = contactUsLevelRepository;
    }

    public Long createContact(ContactUs contactUs) {
        logger.info("Creating new contact: {}", contactUs.getContactName());
        validateContactUs(contactUs);
        ContactUsEntity contactUsEntity = buildContactUsEntity(contactUs);
        ContactUsEntity newEntity = contactUsRepository.save(contactUsEntity);
        logger.info("Contact created with id: {}", newEntity.getId());
        return newEntity.getId();
    }

    private void validateContactUs(ContactUs contactUs) {
        logger.debug("Validating contact: {}", contactUs.getContactName());
        if (contactUs.getLevelId() == null || contactUs.getContactName() == null) {
            logger.error("Validation failed: Level ID and contact name are required");
            throw new IllegalArgumentException("Level ID and contact name are required");
        }
        if (!contactUsLevelRepository.existsById(contactUs.getLevelId())) {
            logger.error("Validation failed: Invalid level ID");
            throw new IllegalArgumentException("Invalid level ID");
        }
    }

    public List<ContactUs> getAllContactEntries() {
        logger.info("Fetching all contact entries");
        List<ContactUsEntity> entities = contactUsRepository.findAll();
        logger.debug("Found {} contact entries", entities.size());
        return entities.stream().map(this::convertToDto).toList();
    }

    private ContactUs convertToDto(ContactUsEntity entity) {
        logger.debug("Converting entity to DTO for contact: {}", entity.getContactName());
        ContactUs contactUs = new ContactUs();
        contactUs.setLevelId(entity.getLevel().getId());
        contactUs.setContactName(entity.getContactName());
        contactUs.setContactEmail(entity.getContactEmail());

        List<String> contactNumbers = Stream.of(entity.getContactNumber1(),
                        entity.getContactNumber2(), entity.getContactNumber3())
                .filter(Objects::nonNull).toList();
        contactUs.setContactNumber(contactNumbers);
        return contactUs;
    }

    private ContactUsEntity buildContactUsEntity(ContactUs contactUs) {
        logger.debug("Building entity from DTO for contact: {}", contactUs.getContactName());
        ContactUsLevelEntity levelEntity = contactUsLevelRepository.findById(contactUs.getLevelId()).orElseThrow(() -> {
            logger.error("Invalid level ID: {}", contactUs.getLevelId());
            return new IllegalArgumentException("Invalid level ID");
        });
        ContactUsEntity contactUsEntity = ContactUsEntity.builder()
                .contactName(contactUs.getContactName())
                .contactEmail(contactUs.getContactEmail())
                .level(levelEntity)
                .build();
        List<String> contactNumbers = contactUs.getContactNumber();
        if (contactNumbers != null) {
            int size = contactNumbers.size();
            if (size > 0) contactUsEntity.setContactNumber1(contactNumbers.get(0));
            if (size > 1) contactUsEntity.setContactNumber2(contactNumbers.get(1));
            if (size > 2) contactUsEntity.setContactNumber3(contactNumbers.get(2));
        }
        return contactUsEntity;
    }

    public boolean updateContact(ContactUs contactUs) {
        logger.info("Updating contact with id: {}", contactUs.getLevelId());
        if (contactUs.getLevelId() == null) {
            logger.error("Validation failed: Contact ID is required");
            throw new IllegalArgumentException("Contact ID is required");
        }
        Optional<ContactUsEntity> existingContact = contactUsRepository.findById(contactUs.getLevelId());
        if (existingContact.isEmpty()) {
            logger.warn("Contact not found with id: {}", contactUs.getLevelId());
            return false;
        }
        ContactUsEntity contactUsEntity = existingContact.get();
        contactUsLevelRepository.findById(contactUs.getLevelId())
                .ifPresentOrElse(contactUsEntity::setLevel,
                        () -> {
                            logger.error("Invalid level ID: {}", contactUs.getLevelId());
                            throw new IllegalArgumentException("Invalid level ID");
                        });
        contactUsEntity.setContactName(contactUs.getContactName());
        contactUsEntity.setContactEmail(contactUs.getContactEmail());
        List<String> contactNumbers = contactUs.getContactNumber();
        if (contactNumbers != null) {
            int size = contactNumbers.size();
            if (size > 0) contactUsEntity.setContactNumber1(contactNumbers.get(0));
            if (size > 1) contactUsEntity.setContactNumber2(contactNumbers.get(1));
            if (size > 2) contactUsEntity.setContactNumber3(contactNumbers.get(2));
        }
        contactUsRepository.save(contactUsEntity);
        logger.info("Contact with id: {} updated successfully", contactUs.getLevelId());
        return true;
    }
}