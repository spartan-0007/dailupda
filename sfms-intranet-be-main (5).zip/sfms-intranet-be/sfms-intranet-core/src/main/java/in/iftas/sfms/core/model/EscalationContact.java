package in.iftas.sfms.core.model;

import java.net.URI;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import org.openapitools.jackson.nullable.JsonNullable;
import java.time.OffsetDateTime;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


import java.util.*;
import jakarta.annotation.Generated;

/**
 * Details of an escalation matrix entry
 */

@Schema(name = "EscalationContact", description = "Details of an escalation matrix entry")

public class EscalationContact {

  private Long id;

  private Long bankId;

  private Long levelId;

  private String feature;

  private String contactName;

  private String contactNumber;

  private String contactEmail;

  public EscalationContact id(Long id) {
    this.id = id;
    return this;
  }

  /**
   * Get id
   * @return id
   */
  
  @Schema(name = "id", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("id")
  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public EscalationContact bankId(Long bankId) {
    this.bankId = bankId;
    return this;
  }

  /**
   * Get bankId
   * @return bankId
   */
  
  @Schema(name = "bankId", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("bankId")
  public Long getBankId() {
    return bankId;
  }

  public void setBankId(Long bankId) {
    this.bankId = bankId;
  }

  public EscalationContact levelId(Long levelId) {
    this.levelId = levelId;
    return this;
  }

  /**
   * Get levelId
   * @return levelId
   */
  
  @Schema(name = "levelId", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("levelId")
  public Long getLevelId() {
    return levelId;
  }

  public void setLevelId(Long levelId) {
    this.levelId = levelId;
  }

  public EscalationContact feature(String feature) {
    this.feature = feature;
    return this;
  }

  /**
   * Get feature
   * @return feature
   */
  
  @Schema(name = "feature", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("feature")
  public String getFeature() {
    return feature;
  }

  public void setFeature(String feature) {
    this.feature = feature;
  }

  public EscalationContact contactName(String contactName) {
    this.contactName = contactName;
    return this;
  }

  /**
   * Get contactName
   * @return contactName
   */
  
  @Schema(name = "contactName", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("contactName")
  public String getContactName() {
    return contactName;
  }

  public void setContactName(String contactName) {
    this.contactName = contactName;
  }

  public EscalationContact contactNumber(String contactNumber) {
    this.contactNumber = contactNumber;
    return this;
  }

  /**
   * Get contactNumber
   * @return contactNumber
   */
  
  @Schema(name = "contactNumber", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("contactNumber")
  public String getContactNumber() {
    return contactNumber;
  }

  public void setContactNumber(String contactNumber) {
    this.contactNumber = contactNumber;
  }

  public EscalationContact contactEmail(String contactEmail) {
    this.contactEmail = contactEmail;
    return this;
  }

  /**
   * Get contactEmail
   * @return contactEmail
   */
  
  @Schema(name = "contactEmail", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("contactEmail")
  public String getContactEmail() {
    return contactEmail;
  }

  public void setContactEmail(String contactEmail) {
    this.contactEmail = contactEmail;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    EscalationContact escalationContact = (EscalationContact) o;
    return Objects.equals(this.id, escalationContact.id) &&
        Objects.equals(this.bankId, escalationContact.bankId) &&
        Objects.equals(this.levelId, escalationContact.levelId) &&
        Objects.equals(this.feature, escalationContact.feature) &&
        Objects.equals(this.contactName, escalationContact.contactName) &&
        Objects.equals(this.contactNumber, escalationContact.contactNumber) &&
        Objects.equals(this.contactEmail, escalationContact.contactEmail);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, bankId, levelId, feature, contactName, contactNumber, contactEmail);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class EscalationContact {\n");
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    bankId: ").append(toIndentedString(bankId)).append("\n");
    sb.append("    levelId: ").append(toIndentedString(levelId)).append("\n");
    sb.append("    feature: ").append(toIndentedString(feature)).append("\n");
    sb.append("    contactName: ").append(toIndentedString(contactName)).append("\n");
    sb.append("    contactNumber: ").append(toIndentedString(contactNumber)).append("\n");
    sb.append("    contactEmail: ").append(toIndentedString(contactEmail)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

