package in.iftas.sfms.core.api.impl;/*
 * Copyright (C) 2024 Iftas Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Iftas Inc. ("Confidential Information"). You shall not disclose
 * such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with Iftas Inc.
 *
 * Author: Manoj.Illa
 * Date: July 11, 2024
 */

import in.iftas.sfms.core.api.PatchesApi;
import in.iftas.sfms.core.exception.PatchNotFoundException;
import in.iftas.sfms.core.exception.ResourceNotFoundException;
import in.iftas.sfms.core.model.ApiResponseError;
import in.iftas.sfms.core.model.GetPatches200Response;
import in.iftas.sfms.core.model.ModelApiResponse;
import in.iftas.sfms.core.model.PatchUploadRequest;
import in.iftas.sfms.core.service.PatchService;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

@RestController
public class PatchesApiImpl implements PatchesApi {

    private static final Logger logger = LoggerFactory.getLogger(PatchesApiImpl.class);


    @Autowired
    private PatchService patchService;

    @Override
    public ResponseEntity<String> uploadPatch(@RequestPart(value = "file", required = false) MultipartFile file, @RequestPart(value = "details", required = true) @Valid String detailsJson) {
        logger.info("Received request to upload patch");

        try {

            logger.debug("Calling patchService.uploadPatch with file: {} and detailsJson: {}", file != null ? file.getOriginalFilename() : "null", detailsJson);
            patchService.uploadPatch(file, detailsJson);


            logger.info("Release uploaded successfully");
            return ResponseEntity.status(HttpStatus.CREATED).body("Release Uploaded Successfully !");

        } catch (IOException e) {

            logger.error("Error uploading patch: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }

    @Override
    public ResponseEntity<GetPatches200Response> getPatches(@RequestParam(value = "page", required = false, defaultValue = "1") Integer page, @RequestParam(value = "size", required = false, defaultValue = "10") Integer size) {
        logger.info("Received request to get patches with page: {} and size: {}", page, size);

        try {

            logger.debug("Fetching patches from service with page: {} and size: {}", page, size);
            GetPatches200Response patchesResponse = patchService.getPatches(page, size);


            logger.info("Returning patches response");
            return ResponseEntity.ok(patchesResponse);

        } catch (Exception e) {

            logger.error("Error fetching patches: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }

    @Override
    public ResponseEntity<Resource> downloadPatchById(@PathVariable("patchId") Long patchId) {
        logger.info("Received request to download patch with ID: {}", patchId);


        try {

            logger.debug("Calling patchService.downloadPatchFile with patchId: {}", patchId);
            Resource fileResource = patchService.downloadPatchFile(patchId);


            logger.info("Successfully retrieved file for patchId: {}", patchId);
            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + fileResource.getFilename() + "\"")
                    .body(fileResource);

        } catch (PatchNotFoundException e) {

            logger.warn("Patch not found for ID: {}", patchId);
            return ResponseEntity.status(404).build();

        } catch (Exception e) {
            logger.error("Error downloading patch with ID: {}", patchId, e);
            return ResponseEntity.status(500).body(null);
        }
    }

    @Override
    public ResponseEntity<Void> patchesPatchIdDelete(Long patchId) {
        logger.info("Received request to delete patch with ID: {}", patchId);
        patchService.deletePatchByID(patchId);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

//    public ResponseEntity<GetBanksWithAccess200Response> getBanksWithAccess(Long patchId) {
//        logger.info("Received request to get banks with access for patch ID: {}", patchId);
//
//        ModelApiResponse response = new ModelApiResponse();
//        try {
//            logger.debug("Calling patchService.getBanksWithAccess with patchId: {}", patchId);
//            PatchAccessDTO patchAccessResponse = patchService.getBanksWithAccess(patchId);
//            logger.info("Successfully retrieved banks with access for patch ID: {}", patchId);
//            response.setSuccess(true);
//            response.setMessage("Banks with access for specific patch is fetched successfully.");
//            response.setData(Collections.singletonMap("release", patchAccessResponse));
//            return new ResponseEntity<>(response, HttpStatus.OK);
//        } catch (PatchNotFoundException e) {
//            logger.warn("Patch not found for ID: {}", patchId);
//            response.setSuccess(false);
//            response.setMessage("Patch not found.");
//            return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
//        } catch (Exception e) {
//            logger.error("Error fetching banks with access for patch ID: {}", patchId, e);
//            response.setSuccess(false);
//            response.setMessage("Internal Server Error.");
//            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
//        }
//    }

    public ResponseEntity<ModelApiResponse> updatePatch(Long patchId, PatchUploadRequest patchUploadRequest) {
        ModelApiResponse response = new ModelApiResponse();
        try {
            logger.debug("Calling patchService.updatePatch with patchId: {}", patchId);
            patchService.updatePatch(patchId, patchUploadRequest);
            logger.info("Successfully updated patch with ID: {}", patchId);
            response.setSuccess(true);
            response.setMessage("Patch updated successfully.");
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (ResourceNotFoundException e) {
            logger.warn("Patch not found for ID: {}", patchId);
            response.setSuccess(false);
            response.setMessage("Patch not found.");
            ApiResponseError apiResponseError = new ApiResponseError();
            apiResponseError.setMessage("Patch not found.");
            apiResponseError.setCode("400");
            response.setError(apiResponseError);
            return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            logger.error("Error updating patch with ID: {}", patchId, e);
            response.setSuccess(false);
            response.setMessage("Internal Server Error");
            ApiResponseError apiResponseError = new ApiResponseError();
            apiResponseError.setMessage("Internal Server Error. ");
            apiResponseError.setCode("500");
            response.setError(apiResponseError);
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
