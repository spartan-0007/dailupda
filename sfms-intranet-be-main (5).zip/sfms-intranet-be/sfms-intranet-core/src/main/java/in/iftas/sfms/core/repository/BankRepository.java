package in.iftas.sfms.core.repository;

import in.iftas.sfms.core.dto.BankDTO;
import in.iftas.sfms.core.entity.BankEntity;
import in.iftas.sfms.core.model.Bank;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Set;

@Repository
public interface BankRepository extends JpaRepository<BankEntity, Integer> {

    @Query("SELECT b FROM BankEntity b")
    List<BankEntity> findAllWithBranches(Pageable pageable);

    Page<BankEntity> findById(Long bankId, Pageable pageable);

    Bank findBankById(Long id);

    @Query("SELECT b FROM BankEntity b WHERE b.bankShortName = :bankShortName")
    BankEntity findByBankShortName(@Param("bankShortName") String bankShortName);

    List<BankEntity> findByIdIn(Set<Long> ids);

    @Query("SELECT b FROM BankEntity b LEFT JOIN BranchEntity br ON b.id = br.bank.id WHERE br.ifscCode = :ifscCode")
   List<BankEntity> findByIfscCode(@Param("ifscCode") String ifscCode);

    @Query("SELECT new in.iftas.sfms.core.dto.BankDTO(b.bankName, b.bankShortName, b.isActive, b.isHostedOnCloud, " +
            "new in.iftas.sfms.core.dto.BranchDTO(br.ifscCode, br.ifscType, br.micrCode, br.branchName, br.cityName, " +
            "br.bankAddress, br.bank.id, br.district, br.state, c.stdCode, c.mobile, " +
            "CASE WHEN f.neftEnabled THEN 'Yes' ELSE 'No' END, " +
            "CASE WHEN f.rtgsEnabled THEN 'Yes' ELSE 'No' END, " +
            "CASE WHEN f.lcEnabled THEN 'Yes' ELSE 'No' END, " +
            "CASE WHEN f.bgEnabled THEN 'Yes' ELSE 'No' END, " +
            "CASE WHEN f.others THEN 'Yes' ELSE 'No' END, " +
            "br.isActive)) " +
            "FROM BankEntity b " +
            "LEFT JOIN b.branches br " +
            "LEFT JOIN br.branchContact c " +
            "LEFT JOIN br.branchFeature f " +
            "WHERE br.ifscCode = :ifscCode")
    Page<BankDTO> findBankWithBranchByIfscCode(@Param("ifscCode") String ifscCode, Pageable pageable);

    BankEntity findByBankNameOrBankShortName(String bankName, String bankShortName);

    @Query("SELECT new in.iftas.sfms.core.dto.BankDTO(b.id, b.bankName, b.bankShortName, b.isActive, b.isHostedOnCloud, " +
            "CONCAT(" +
            "CASE WHEN MAX(CASE WHEN br.ifscType LIKE '%RTGS-HO%' THEN 1 ELSE 0 END) = 1 THEN 'RTGS' ELSE '' END, " +
            "CASE WHEN MAX(CASE WHEN br.ifscType LIKE '%RTGS-HO%' THEN 1 ELSE 0 END) = 1 AND MAX(CASE WHEN br.ifscType LIKE '%NEFT_SC%' THEN 1 ELSE 0 END) = 1 THEN ',' ELSE '' END, " +
            "CASE WHEN MAX(CASE WHEN br.ifscType LIKE '%NEFT_SC%' THEN 1 ELSE 0 END) = 1 THEN 'NEFT' ELSE '' END)) " +
            "FROM BankEntity b " +
            "LEFT JOIN b.branches br " +
            "LEFT JOIN br.branchFeature bf " +
            "WHERE br.ifscType LIKE '%RTGS-HO%' OR br.ifscType LIKE '%NEFT_SC%' " +
            "GROUP BY b.id, b.bankName, b.bankShortName, b.isActive, b.isHostedOnCloud")
    Page<BankDTO> findAllBanks(Pageable pageable);
}
