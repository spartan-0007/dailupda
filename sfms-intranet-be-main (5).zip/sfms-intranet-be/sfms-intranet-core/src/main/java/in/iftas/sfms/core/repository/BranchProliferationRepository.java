package in.iftas.sfms.core.repository;

import in.iftas.sfms.core.entity.BranchProliferationEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BranchProliferationRepository extends JpaRepository<BranchProliferationEntity, Long> {

    List<BranchProliferationEntity> findAllByIsProliferatedFalse();

    @Query("SELECT b FROM BranchProliferationEntity b WHERE b.isProliferated = true AND DATE(b.lastModifiedDate) = CURRENT_DATE")
    List<BranchProliferationEntity> findProliferatedBranchesToday();

    boolean existsByBranchId(String ifscCode);

    List<BranchProliferationEntity> findAllByBankIdAndIsProliferatedFalse(Integer bankId);
}
