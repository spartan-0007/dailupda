package in.iftas.sfms.core.model;

import java.net.URI;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonTypeName;
import in.iftas.sfms.core.model.ApiResponseError;
import java.util.HashMap;
import java.util.Map;
import org.openapitools.jackson.nullable.JsonNullable;
import java.time.OffsetDateTime;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


import java.util.*;
import jakarta.annotation.Generated;

/**
 * ModelApiResponse
 */

@JsonTypeName("ApiResponse")

public class ModelApiResponse {

  private Boolean success;

  private String message;

  @Valid
  private Map<String, Object> data = new HashMap<>();

  private ApiResponseError error;

  public ModelApiResponse success(Boolean success) {
    this.success = success;
    return this;
  }

  /**
   * Indicates if the request was successful
   * @return success
   */
  
  @Schema(name = "success", description = "Indicates if the request was successful", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("success")
  public Boolean getSuccess() {
    return success;
  }

  public void setSuccess(Boolean success) {
    this.success = success;
  }

  public ModelApiResponse message(String message) {
    this.message = message;
    return this;
  }

  /**
   * A message providing additional information
   * @return message
   */
  
  @Schema(name = "message", description = "A message providing additional information", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("message")
  public String getMessage() {
    return message;
  }

  public void setMessage(String message) {
    this.message = message;
  }

  public ModelApiResponse data(Map<String, Object> data) {
    this.data = data;
    return this;
  }

  public ModelApiResponse putItem(String key, Object dataItem) {
    if (this.data == null) {
      this.data = new HashMap<>();
    }
    this.data.put(key, dataItem);
    return this;
  }

  /**
   * The data returned by the API
   * @return data
   */
  
  @Schema(name = "data", description = "The data returned by the API", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("data")
  public Map<String, Object> getData() {
    return data;
  }

  public void setData(Map<String, Object> data) {
    this.data = data;
  }

  public ModelApiResponse error(ApiResponseError error) {
    this.error = error;
    return this;
  }

  /**
   * Get error
   * @return error
   */
  @Valid 
  @Schema(name = "error", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("error")
  public ApiResponseError getError() {
    return error;
  }

  public void setError(ApiResponseError error) {
    this.error = error;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ModelApiResponse _apiResponse = (ModelApiResponse) o;
    return Objects.equals(this.success, _apiResponse.success) &&
        Objects.equals(this.message, _apiResponse.message) &&
        Objects.equals(this.data, _apiResponse.data) &&
        Objects.equals(this.error, _apiResponse.error);
  }

  @Override
  public int hashCode() {
    return Objects.hash(success, message, data, error);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ModelApiResponse {\n");
    sb.append("    success: ").append(toIndentedString(success)).append("\n");
    sb.append("    message: ").append(toIndentedString(message)).append("\n");
    sb.append("    data: ").append(toIndentedString(data)).append("\n");
    sb.append("    error: ").append(toIndentedString(error)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

