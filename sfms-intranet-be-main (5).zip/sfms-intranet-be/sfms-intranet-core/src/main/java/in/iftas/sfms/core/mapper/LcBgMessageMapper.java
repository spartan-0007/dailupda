package in.iftas.sfms.core.mapper;

import in.iftas.sfms.core.entity.LcBgMessageEntity;
import in.iftas.sfms.core.model.LcBgMessage;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface LcBgMessageMapper {

    @Mapping(source = "messageDateTime", target = "messageDate")
    LcBgMessage toModel(LcBgMessageEntity entity);

}
