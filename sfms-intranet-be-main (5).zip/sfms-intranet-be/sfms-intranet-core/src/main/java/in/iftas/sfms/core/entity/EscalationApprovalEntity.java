package in.iftas.sfms.core.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "i_escalation_approvals", indexes = {
        @Index(name = "idx_status", columnList = "status"),
        @Index(name = "idx_maker", columnList = "maker_id"),
        @Index(name = "idx_current_checker", columnList = "current_checker_id"),
        @Index(name = "idx_escalation", columnList = "escalation_id"),
        @Index(name = "idx_checker_status", columnList = "current_checker_id, status")
})
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class EscalationApprovalEntity extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "escalation_id")
    private Long escalationId;

    @Column(name = "action_type", nullable = false)
    @Enumerated(EnumType.STRING)
    private ActionType actionType;

    @Column(name = "request_data", nullable = false, columnDefinition = "LONGTEXT")
    private String requestData;

    @Column(name = "status", nullable = false)
    @Enumerated(EnumType.STRING)
    private Status status;

    @Column(name = "current_level", nullable = false)
    private Integer currentLevel = 1;

    @Column(name = "total_levels", nullable = false)
    private Integer totalLevels;

    // Maker details
    @Column(name = "maker_id", nullable = false)
    private String makerId;

    @Column(name = "maker_name", nullable = false)
    private String makerName;

    @Column(name = "maker_role", nullable = false)
    @Enumerated(EnumType.STRING)
    private Role makerRole;

    @Column(name = "current_checker_id")
    private String currentCheckerId;

    @Column(name = "current_checker_name")
    private String currentCheckerName;

    @Column(name = "current_checker_role")
    @Enumerated(EnumType.STRING)
    private Role currentCheckerRole;

    // Dates
    @Column(name = "due_date")
    private LocalDateTime dueDate;

    @Column(name = "completion_date")
    private LocalDateTime completionDate;

    // OneToMany relationship to steps
    @OneToMany(mappedBy = "approval", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @OrderBy("levelNumber ASC")
    @Builder.Default
    private List<EscalationApprovalStepEntity> steps = new ArrayList<>();

    public enum ActionType {
        CREATE, UPDATE, DELETE
    }

    public enum Status {
        PENDING, COMPLETED, REJECTED
    }

    public enum Role {
        BANKER, OPERATOR, ADMIN
    }

    public boolean isVisibleToUser(String userId) {
        if (makerId.equals(userId) && Status.COMPLETED.equals(status)) {
            return false;
        }
        return true;
    }

    public boolean canApprove(String userId) {
        return Status.PENDING.equals(status) &&
                userId.equals(currentCheckerId);
    }

    public boolean isLastLevel() {
        return currentLevel.equals(totalLevels);
    }

    // Convenience method to get current step
    public EscalationApprovalStepEntity getCurrentStep() {
        if (steps == null || steps.isEmpty()) {
            return null;
        }
        return steps.stream()
                .filter(step -> step.getLevelNumber().equals(currentLevel))
                .findFirst()
                .orElse(null);
    }

    // Convenience method to add a step (maintains both sides of relationship)
    public void addStep(EscalationApprovalStepEntity step) {
        if (steps == null) {
            steps = new ArrayList<>();
        }
        steps.add(step);
        step.setApproval(this);
        // JPA will automatically set the approvalId via the relationship
    }

    // Convenience method to remove a step (maintains both sides of relationship)
    public void removeStep(EscalationApprovalStepEntity step) {
        if (steps != null) {
            steps.remove(step);
        }
        step.setApproval(null);
    }
}