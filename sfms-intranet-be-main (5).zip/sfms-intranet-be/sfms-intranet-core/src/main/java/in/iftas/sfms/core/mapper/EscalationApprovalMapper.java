package in.iftas.sfms.core.mapper;

import in.iftas.sfms.core.entity.EscalationApprovalEntity;
import in.iftas.sfms.core.entity.EscalationApprovalStepEntity;
import in.iftas.sfms.core.model.EscalationApproval;
import in.iftas.sfms.core.model.EscalationApprovalStep;
import org.mapstruct.*;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;

@Mapper(
        componentModel = "spring",
        unmappedTargetPolicy = ReportingPolicy.IGNORE,
        nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE
        // Removed uses = {EscalationApprovalStepMapper.class} to avoid ambiguous mapping
)
public interface EscalationApprovalMapper {

    // Entity to Model (Response) - Simple mapping without steps
    @Named("toModelWithoutSteps")
    @Mapping(target = "approvalSteps", ignore = true)
    @Mapping(target = "progressPercentage", expression = "java(calculateProgress(entity))")
    @Mapping(target = "isOverdue", expression = "java(isOverdue(entity))")
    @Mapping(target = "statusDisplayText", expression = "java(getStatusDisplayText(entity))")
    @Mapping(target = "comments", ignore = true)
    @Mapping(target = "reason", ignore = true)
    @Mapping(target = "businessJustification", ignore = true)
    @Mapping(target = "expectedImpact", ignore = true)
    @Mapping(target = "makerRole", source = "makerRole", qualifiedByName = "mapEntityMakerRoleToModel")
    @Mapping(target = "currentCheckerRole", source = "currentCheckerRole", qualifiedByName = "mapEntityCurrentCheckerRoleToModel")
    @Mapping(target = "actionType", source = "actionType", qualifiedByName = "mapEntityActionTypeToModel")
    @Mapping(target = "status", source = "status", qualifiedByName = "mapEntityStatusToModel")
    @Mapping(target = "dueDate", source = "dueDate", qualifiedByName = "mapLocalDateTimeToDate")
    @Mapping(target = "completionDate", source = "completionDate", qualifiedByName = "mapLocalDateTimeToDate")
    @Mapping(target = "createdDate", source = "createdDate", qualifiedByName = "mapLocalDateTimeToDate")
    EscalationApproval toModel(EscalationApprovalEntity entity);

    // Entity to Model (Response) - WITH steps included
    @Mapping(target = "approvalSteps", source = "steps")
    @Mapping(target = "progressPercentage", expression = "java(calculateProgress(entity))")
    @Mapping(target = "isOverdue", expression = "java(isOverdue(entity))")
    @Mapping(target = "statusDisplayText", expression = "java(getStatusDisplayText(entity))")
    @Mapping(target = "comments", ignore = true)
    @Mapping(target = "reason", ignore = true)
    @Mapping(target = "businessJustification", ignore = true)
    @Mapping(target = "expectedImpact", ignore = true)
    @Mapping(target = "makerRole", source = "makerRole", qualifiedByName = "mapEntityMakerRoleToModel")
    @Mapping(target = "currentCheckerRole", source = "currentCheckerRole", qualifiedByName = "mapEntityCurrentCheckerRoleToModel")
    @Mapping(target = "actionType", source = "actionType", qualifiedByName = "mapEntityActionTypeToModel")
    @Mapping(target = "status", source = "status", qualifiedByName = "mapEntityStatusToModel")
    @Mapping(target = "dueDate", source = "dueDate", qualifiedByName = "mapLocalDateTimeToDate")
    @Mapping(target = "completionDate", source = "completionDate", qualifiedByName = "mapLocalDateTimeToDate")
    @Mapping(target = "createdDate", source = "createdDate", qualifiedByName = "mapLocalDateTimeToDate")
    EscalationApproval toModelWithSteps(EscalationApprovalEntity entity);

    // Model to Entity (Request)
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "status", ignore = true)
    @Mapping(target = "currentCheckerId", ignore = true)
    @Mapping(target = "currentCheckerName", ignore = true)
    @Mapping(target = "currentCheckerRole", ignore = true)
    @Mapping(target = "currentLevel", ignore = true)
    @Mapping(target = "totalLevels", ignore = true)
    @Mapping(target = "dueDate", ignore = true)
    @Mapping(target = "completionDate", ignore = true)
    @Mapping(target = "steps", ignore = true)
    @Mapping(target = "makerRole", source = "makerRole", qualifiedByName = "mapModelMakerRoleToEntity")
    @Mapping(target = "actionType", source = "actionType", qualifiedByName = "mapModelActionTypeToEntity")
    @Mapping(target = "requestData", source = "requestData", qualifiedByName = "mapObjectToString")
    EscalationApprovalEntity toEntity(EscalationApproval model);

    // List mappings - specify which method to use
    @IterableMapping(qualifiedByName = "toModelWithoutSteps")
    List<EscalationApproval> toModelList(List<EscalationApprovalEntity> entities);

    List<EscalationApprovalEntity> toEntityList(List<EscalationApproval> models);

    // Date conversion methods
    @Named("mapLocalDateTimeToDate")
    default Date localDateTimeToDate(LocalDateTime localDateTime) {
        return localDateTime != null ?
                Date.from(localDateTime.atZone(ZoneId.systemDefault()).toInstant()) : null;
    }

    @Named("mapDateToLocalDateTime")
    default LocalDateTime dateToLocalDateTime(Date date) {
        return date != null ?
                LocalDateTime.ofInstant(date.toInstant(), ZoneId.systemDefault()) : null;
    }

    // Object to String mapping for requestData
    @Named("mapObjectToString")
    default String objectToString(Object obj) {
        return obj != null ? obj.toString() : null;
    }

    // Enum mappings for ActionType
    @Named("mapEntityActionTypeToModel")
    default EscalationApproval.ActionTypeEnum mapEntityActionTypeToModel(EscalationApprovalEntity.ActionType actionType) {
        return actionType != null ? EscalationApproval.ActionTypeEnum.valueOf(actionType.name()) : null;
    }

    @Named("mapModelActionTypeToEntity")
    default EscalationApprovalEntity.ActionType mapModelActionTypeToEntity(EscalationApproval.ActionTypeEnum actionType) {
        return actionType != null ? EscalationApprovalEntity.ActionType.valueOf(actionType.name()) : null;
    }

    // Enum mappings for Status
    @Named("mapEntityStatusToModel")
    default EscalationApproval.StatusEnum mapEntityStatusToModel(EscalationApprovalEntity.Status status) {
        return status != null ? EscalationApproval.StatusEnum.valueOf(status.name()) : null;
    }

    @Named("mapModelStatusToEntity")
    default EscalationApprovalEntity.Status mapModelStatusToEntity(EscalationApproval.StatusEnum status) {
        return status != null ? EscalationApprovalEntity.Status.valueOf(status.name()) : null;
    }

    // Enum mappings for Maker Role
    @Named("mapEntityMakerRoleToModel")
    default EscalationApproval.MakerRoleEnum mapEntityMakerRoleToModel(EscalationApprovalEntity.Role role) {
        return role != null ? EscalationApproval.MakerRoleEnum.valueOf(role.name()) : null;
    }

    @Named("mapModelMakerRoleToEntity")
    default EscalationApprovalEntity.Role mapModelMakerRoleToEntity(EscalationApproval.MakerRoleEnum role) {
        return role != null ? EscalationApprovalEntity.Role.valueOf(role.name()) : null;
    }

    // Enum mappings for Current Checker Role
    @Named("mapEntityCurrentCheckerRoleToModel")
    default EscalationApproval.CurrentCheckerRoleEnum mapEntityCurrentCheckerRoleToModel(EscalationApprovalEntity.Role role) {
        return role != null ? EscalationApproval.CurrentCheckerRoleEnum.valueOf(role.name()) : null;
    }

    @Named("mapModelCurrentCheckerRoleToEntity")
    default EscalationApprovalEntity.Role mapModelCurrentCheckerRoleToEntity(EscalationApproval.CurrentCheckerRoleEnum role) {
        return role != null ? EscalationApprovalEntity.Role.valueOf(role.name()) : null;
    }

    // Progress calculation
    default Double calculateProgress(EscalationApprovalEntity entity) {
        if (entity.getTotalLevels() == null || entity.getTotalLevels() == 0) {
            return 0.0;
        }

        if (EscalationApprovalEntity.Status.COMPLETED.equals(entity.getStatus())) {
            return 100.0;
        }

        if (EscalationApprovalEntity.Status.REJECTED.equals(entity.getStatus())) {
            return 0.0;
        }

        // For pending, calculate based on current level
        if (entity.getCurrentLevel() != null) {
            double progress = ((double) entity.getCurrentLevel() - 1) / entity.getTotalLevels() * 100;
            return Math.max(0.0, Math.min(100.0, progress));
        }

        return 0.0;
    }

    // Overdue check
    default Boolean isOverdue(EscalationApprovalEntity entity) {
        if (entity.getDueDate() == null) {
            return false;
        }

        if (EscalationApprovalEntity.Status.COMPLETED.equals(entity.getStatus()) ||
                EscalationApprovalEntity.Status.REJECTED.equals(entity.getStatus())) {
            return false;
        }

        return LocalDateTime.now().isAfter(entity.getDueDate());
    }

    // Status display text
    default String getStatusDisplayText(EscalationApprovalEntity entity) {
        if (entity.getStatus() == null) {
            return "Unknown";
        }

        Integer currentLevel = entity.getCurrentLevel() != null ? entity.getCurrentLevel() : 1;
        Integer totalLevels = entity.getTotalLevels() != null ? entity.getTotalLevels() : 1;

        switch (entity.getStatus()) {
            case PENDING:
                if (isOverdue(entity)) {
                    return String.format("Pending - Overdue (Level %d of %d)", currentLevel, totalLevels);
                } else {
                    return String.format("Pending Approval (Level %d of %d)", currentLevel, totalLevels);
                }
            case COMPLETED:
                return "Approved & Completed";
            case REJECTED:
                return "Rejected";
            default:
                return entity.getStatus().name();
        }
    }
}