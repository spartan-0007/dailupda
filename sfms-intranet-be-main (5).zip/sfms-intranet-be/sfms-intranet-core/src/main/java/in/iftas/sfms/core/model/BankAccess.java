package in.iftas.sfms.core.model;

import java.net.URI;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;
import org.openapitools.jackson.nullable.JsonNullable;
import java.time.OffsetDateTime;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


import java.util.*;
import jakarta.annotation.Generated;

/**
 * BankAccess
 */


public class BankAccess {

  private Integer bankId;

  private String bankName;

  @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
  private Date accessGrantedDate;

  private Boolean accessRevoked;

  public BankAccess bankId(Integer bankId) {
    this.bankId = bankId;
    return this;
  }

  /**
   * Unique identifier of the bank.
   * @return bankId
   */
  
  @Schema(name = "bankId", description = "Unique identifier of the bank.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("bankId")
  public Integer getBankId() {
    return bankId;
  }

  public void setBankId(Integer bankId) {
    this.bankId = bankId;
  }

  public BankAccess bankName(String bankName) {
    this.bankName = bankName;
    return this;
  }

  /**
   * Name of the bank.
   * @return bankName
   */
  
  @Schema(name = "bankName", description = "Name of the bank.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("bankName")
  public String getBankName() {
    return bankName;
  }

  public void setBankName(String bankName) {
    this.bankName = bankName;
  }

  public BankAccess accessGrantedDate(Date accessGrantedDate) {
    this.accessGrantedDate = accessGrantedDate;
    return this;
  }

  /**
   * Timestamp when access was granted to the bank.
   * @return accessGrantedDate
   */
  @Valid 
  @Schema(name = "accessGrantedDate", description = "Timestamp when access was granted to the bank.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("accessGrantedDate")
  public Date getAccessGrantedDate() {
    return accessGrantedDate;
  }

  public void setAccessGrantedDate(Date accessGrantedDate) {
    this.accessGrantedDate = accessGrantedDate;
  }

  public BankAccess accessRevoked(Boolean accessRevoked) {
    this.accessRevoked = accessRevoked;
    return this;
  }

  /**
   * Whether access has been revoked for the bank.
   * @return accessRevoked
   */
  
  @Schema(name = "accessRevoked", description = "Whether access has been revoked for the bank.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("accessRevoked")
  public Boolean getAccessRevoked() {
    return accessRevoked;
  }

  public void setAccessRevoked(Boolean accessRevoked) {
    this.accessRevoked = accessRevoked;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    BankAccess bankAccess = (BankAccess) o;
    return Objects.equals(this.bankId, bankAccess.bankId) &&
        Objects.equals(this.bankName, bankAccess.bankName) &&
        Objects.equals(this.accessGrantedDate, bankAccess.accessGrantedDate) &&
        Objects.equals(this.accessRevoked, bankAccess.accessRevoked);
  }

  @Override
  public int hashCode() {
    return Objects.hash(bankId, bankName, accessGrantedDate, accessRevoked);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BankAccess {\n");
    sb.append("    bankId: ").append(toIndentedString(bankId)).append("\n");
    sb.append("    bankName: ").append(toIndentedString(bankName)).append("\n");
    sb.append("    accessGrantedDate: ").append(toIndentedString(accessGrantedDate)).append("\n");
    sb.append("    accessRevoked: ").append(toIndentedString(accessRevoked)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

