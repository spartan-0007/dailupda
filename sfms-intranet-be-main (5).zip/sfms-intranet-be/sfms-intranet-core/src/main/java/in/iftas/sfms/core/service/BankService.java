package in.iftas.sfms.core.service;


import in.iftas.sfms.core.model.Bank;
import in.iftas.sfms.core.model.Branch;
import org.springframework.core.io.Resource;
import org.springframework.http.ResponseEntity;

import java.util.List;
import java.util.Map;

public interface BankService {
    List<Branch> getBranchesByBankId(Integer bankId, Integer page, Integer size, String sort);
    void deleteBank(Integer bankId);
    List<Bank> getAllBanks(Integer page, Integer size, String sort);
    Long addBank(Bank bank);
    void updateBank(Bank bank);
    Map<String, Object> getBanksWithBranches(Integer bankId, Integer page, Integer size, String sort, String branchId);

    ResponseEntity<Resource> downloadBanksReport();
}