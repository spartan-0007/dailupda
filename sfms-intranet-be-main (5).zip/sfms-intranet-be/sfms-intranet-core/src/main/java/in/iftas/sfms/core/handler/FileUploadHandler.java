package in.iftas.sfms.core.handler;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import in.iftas.sfms.common.entity.ApprovalRequestEntity;
import in.iftas.sfms.common.handler.ApprovalHandler;
import in.iftas.sfms.common.repository.ApprovalRequestRepository;
import in.iftas.sfms.core.entity.UserManualEntity;
import in.iftas.sfms.core.model.Bank;
import in.iftas.sfms.core.model.UserManual;
import in.iftas.sfms.core.service.CgbsFileService;
import in.iftas.sfms.core.service.CrlFileService;
import in.iftas.sfms.core.service.PatchService;
import in.iftas.sfms.core.service.UserManualFileService;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class FileUploadHandler implements ApprovalHandler {
    private final CrlFileService crlFileService;
    private final CgbsFileService cgbsFileService;
    private final ApprovalRequestRepository approvalRequestRepository;
    private final UserManualFileService userManualFileService;
    private final ObjectMapper objectMapper;
    private final PatchService patchService;

    public FileUploadHandler(CrlFileService crlFileService, CgbsFileService cgbsFileService, ApprovalRequestRepository approvalRequestRepository, UserManualFileService userManualFileService, ObjectMapper objectMapper, PatchService patchService) {
        this.crlFileService = crlFileService;

        this.cgbsFileService = cgbsFileService;
        this.approvalRequestRepository = approvalRequestRepository;
        this.userManualFileService = userManualFileService;
        this.objectMapper = objectMapper;
        this.patchService = patchService;
    }

    @Override
    public String getEntityType() {
        return "FILE_UPLOAD";
    }


    @Override
    public void handleApproval(Long approvalId, String actionType, String requestData, String entityId) {
        log.info("Processing approval - ID: {}, Action: {}, Entity: {}",
                approvalId, actionType, entityId);

        String fileType;

        if ("DELETE".equals(actionType)) {
            ApprovalRequestEntity approvalRequestEntity = approvalRequestRepository.findById(approvalId).get();
            fileType = approvalRequestEntity.getEntityType().substring(5);

        } else {
            fileType = determineFileType(requestData, entityId);
        }


        String upperActionType = actionType.toUpperCase();
        String upperFileType = fileType.toUpperCase();

        try {
            switch (upperFileType) {
                case "CGBS":
                    switch (upperActionType) {
                        case "CREATE":
                            cgbsFileService.uploadCgbsFile(requestData);
                            log.info("CGBS file created successfully");
                            break;
                        case "UPDATE":
                            log.info("CGBS file updated successfully: {}", entityId);
                            break;
                        case "DELETE":
                            cgbsFileService.deleteCGBSFile(Integer.valueOf(entityId));
                            log.info("CGBS file deleted successfully: {}", entityId);
                            break;
                        default:
                            throw new UnsupportedOperationException("Unsupported action type for CGBS: " + actionType);
                    }
                    break;

                case "CRL":
                    switch (upperActionType) {
                        case "CREATE":
                            crlFileService.uploadCrlFile(requestData);
                            log.info("CRL file created successfully");
                            break;
                        case "UPDATE":
                            log.info("CRL file updated successfully: {}", entityId);
                            break;
                        case "DELETE":
                            crlFileService.deleteCrlFile(Integer.valueOf(entityId));
                            log.info("CRL file deleted successfully: {}", entityId);
                            break;
                        default:
                            throw new UnsupportedOperationException("Unsupported action type for CRL: " + actionType);
                    }
                    break;

                case "USERMANUALS":
                    switch (upperActionType) {
                        case "CREATE":
                            UserManualEntity userManualEntity = objectMapper.readValue(requestData, UserManualEntity.class);
                            userManualFileService.uploadUserManualFile(userManualEntity);
                            log.info("User manual created successfully");
                            break;
                        case "UPDATE":
                            log.info("User manual updated successfully: {}", entityId);
                            break;
                        case "DELETE":
                            userManualFileService.deleteManualByID(Long.valueOf(entityId));
                            log.info("User manual deleted successfully: {}", entityId);
                            break;
                        default:
                            throw new UnsupportedOperationException("Unsupported action type for USER_MANUALS: " + actionType);
                    }
                    break;

                case "RELEASES":
                    switch (upperActionType) {
                        case "CREATE":
                            patchService.uploadPatchApproved(requestData);
                            log.info("Release created successfully");
                            break;
                        case "UPDATE":
                            patchService.updatePatchApproval(Long.valueOf(entityId) ,requestData);
                            log.info("Release updated successfully: {}", entityId);
                            break;
                        case "DELETE":
                            patchService.deletePatchByID(Long.valueOf(entityId));
                            log.info("Release deleted successfully: {}", entityId);
                            break;
                        default:
                            throw new UnsupportedOperationException("Unsupported action type for RELEASES: " + actionType);
                    }
                    break;

                default:
                    log.warn("Unknown file type: {} for approval ID: {}", fileType, approvalId);
                    throw new UnsupportedOperationException("Unsupported file type: " + fileType);
            }
        } catch (Exception e) {
            log.error("Error processing approval ID {}: {}", approvalId, e.getMessage());

        }
    }

    @Override
    public void handleRejection(Long approvalId, String rejectionReason, String entityType) {
        log.info("Processing file upload rejection - ID: {}, Type: {}, Reason: {}",
                approvalId, entityType, rejectionReason);

        switch (entityType.toUpperCase()) {
            case "FILE_CGBS":
                handleCgbsFileRejection(approvalId, rejectionReason);
                break;
            case "FILE_CRL":
                log.info("Processing CRL file approval: {}", approvalId);
                handleCrlFileRejection(approvalId, rejectionReason);
                break;
            case "FILE_USER_MANUALS":
                handleUserManualsFileRejection(approvalId, rejectionReason);
                break;
            case "FILE_RELEASES":
                handleReleasesFileRejection(approvalId, rejectionReason);
                break;
            default:
                handleGenericFileRejection(approvalId, rejectionReason, entityType);
        }
    }

    private String determineFileType(String requestData, String entityId) {
        if (requestData != null) {
            if (requestData.contains("cgbs")) return "CGBS";
            if (requestData.contains("crl")) return "CRL";
            if (requestData.contains("manual")) return "USERMANUALS";
            if (requestData.contains("release")) return "RELEASES";
        }

        return "";
    }

    private void handleCgbsFileApproval(Long approvalId, String actionType, String requestData, String entityId) {
        log.info("Processing CGBS file approval: {}", approvalId);
    }


    private void handleUserManualsFileApproval(Long approvalId, String actionType, String requestData, String entityId) {
        log.info("Processing User Manuals file approval: {}", approvalId);
    }

    private void handleReleasesFileApproval(Long approvalId, String actionType, String requestData, String entityId) {
        log.info("Processing Releases file approval: {}", approvalId);
    }

    private void handleCgbsFileRejection(Long approvalId, String rejectionReason) {
        log.info("Processing CGBS file rejection: {}", approvalId);
    }

    private void handleCrlFileRejection(Long approvalId, String rejectionReason) {
        log.info("Processing CRL file rejection: {}", approvalId);
    }

    private void handleUserManualsFileRejection(Long approvalId, String rejectionReason) {
        log.info("Processing User Manuals file rejection: {}", approvalId);
    }

    private void handleReleasesFileRejection(Long approvalId, String rejectionReason) {
        log.info("Processing Releases file rejection: {}", approvalId);
    }

    private void handleGenericFileRejection(Long approvalId, String rejectionReason, String entityType) {
        log.info("Processing generic file rejection: {} for type: {}", approvalId, entityType);
    }
}