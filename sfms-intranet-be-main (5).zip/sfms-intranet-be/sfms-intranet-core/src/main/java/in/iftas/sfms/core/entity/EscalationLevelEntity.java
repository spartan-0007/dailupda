package in.iftas.sfms.core.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "i_escalation_levels")
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class EscalationLevelEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;


    @Column(name = "level_name", nullable = false)
    private String levelName;
}