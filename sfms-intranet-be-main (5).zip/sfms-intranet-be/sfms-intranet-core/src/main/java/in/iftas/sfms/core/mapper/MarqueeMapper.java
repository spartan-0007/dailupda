package in.iftas.sfms.core.mapper;

import in.iftas.sfms.core.entity.BankEntity;
import in.iftas.sfms.core.entity.MarqueeEntity;
import in.iftas.sfms.core.model.Marquee;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;


@Mapper(componentModel = "spring")
public interface MarqueeMapper {
    MarqueeMapper INSTANCE = Mappers.getMapper(MarqueeMapper.class);

    @Mapping(source = "banks", target = "bankIds", qualifiedByName = "banksToBankIds")
    Marquee toModel(MarqueeEntity marqueeEntity);

    @Mapping(source = "bankIds", target = "banks", qualifiedByName = "bankIdsToBanks")
    MarqueeEntity toEntity(Marquee marquee);

    void toEntity(Marquee marquee, @MappingTarget MarqueeEntity marqueeEntity);

    @Named("banksToBankIds")
    default String banksToBankIds(List<BankEntity> banks) {
        return banks.stream()
                .map(bank -> bank.getId().toString())
                .collect(Collectors.joining(","));
    }

    @Named("bankIdsToBanks")
    default List<BankEntity> bankIdsToBanks(String bankIds) {
        if (bankIds == null || bankIds.isEmpty()) {
            return Collections.emptyList();
        }
        return Arrays.stream(bankIds.split(","))
                .map(id -> {
                    BankEntity bank = new BankEntity();
                    bank.setId(Long.parseLong(id));
                    return bank;
                })
                .toList();
    }
}