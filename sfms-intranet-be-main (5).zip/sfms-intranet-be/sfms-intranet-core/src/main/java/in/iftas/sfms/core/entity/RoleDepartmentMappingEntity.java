package in.iftas.sfms.core.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "i_role_department_mapping", 
       uniqueConstraints = {
           @UniqueConstraint(name = "uk_role_dept", columnNames = {"keycloak_role_name", "department_id"})
       })
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class RoleDepartmentMappingEntity {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(name = "keycloak_role_name", nullable = false)
    private String keycloakRoleName;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "department_id", referencedColumnName = "id", nullable = false)
    private DepartmentEntity department;
    
    @Enumerated(EnumType.STRING)
    @Column(name = "access_type")
    @Builder.Default
    private AccessType accessType = AccessType.VIEW;
    
    @Column(name = "granted_by")
    private String grantedBy;
    
    @Column(name = "granted_date")
    private LocalDateTime grantedDate;
    
    @Column(name = "is_active")
    @Builder.Default
    private Boolean isActive = true;
    
    public enum AccessType {
        VIEW, EDIT, ADMIN
    }
}