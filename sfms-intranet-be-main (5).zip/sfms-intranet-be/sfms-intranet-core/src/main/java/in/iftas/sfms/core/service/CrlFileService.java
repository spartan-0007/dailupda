package in.iftas.sfms.core.service;

/*
 * Copyright (C) 2024 Iftas Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Iftas Inc. ("Confidential Information"). You shall not disclose
 * such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with Iftas Inc.
 *
 * Author: Manoj.Illa
 * Date: July 11, 2024
 */

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import in.iftas.sfms.core.entity.CgbsFileDetailsEntity;
import in.iftas.sfms.core.entity.CrlFileDetailsEntity;
import in.iftas.sfms.core.entity.CrlFileDetailsHistoryEntity;
import in.iftas.sfms.core.exception.ResourceNotFoundException;
import in.iftas.sfms.core.model.CRLFileDetails;
import in.iftas.sfms.core.repository.CrlFileDetailsRepository;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;

@Service
public class CrlFileService {

    private static final Logger logger = LoggerFactory.getLogger(CrlFileService.class);
private final ObjectMapper objectMapper;

    private final CrlFileDetailsRepository crlFileDetailsRepository;
    private final SftpService sftpService;

    public CrlFileService(ObjectMapper objectMapper, CrlFileDetailsRepository crlFileDetailsRepository, SftpService sftpService) {
        this.objectMapper = objectMapper;
        this.crlFileDetailsRepository = crlFileDetailsRepository;
        this.sftpService = sftpService;
    }

    public void uploadCrlFile(String requestData) {
        logger.info("Processing CRL file upload from approval data");

        try {
            CrlFileDetailsEntity crlFileDetailsEntity = objectMapper.readValue(requestData, CrlFileDetailsEntity.class);
                        logger.info("Uploading CRL file: {}", crlFileDetailsEntity.getFileName());

            Jwt jwt = (Jwt) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
            String currentUser = jwt.getClaimAsString("sub");

            CrlFileDetailsEntity fileDetailsEntity = crlFileDetailsRepository.findByFileName(crlFileDetailsEntity.getFileName());

            CrlFileDetailsHistoryEntity history = CrlFileDetailsHistoryEntity.builder()
                    .uploadedBy(currentUser)
                    .sftpPath(crlFileDetailsEntity.getSftpPath())
                    .build();

            if (ObjectUtils.isNotEmpty(fileDetailsEntity) && fileDetailsEntity.getFileName() != null) {
                fileDetailsEntity.setUploadedBy(currentUser);
                fileDetailsEntity.setUploadedDate(LocalDateTime.now());
                fileDetailsEntity.setFileSize(crlFileDetailsEntity.getFileSize());
                fileDetailsEntity.setSftpPath(crlFileDetailsEntity.getSftpPath());

                history.setUploadedDate(fileDetailsEntity.getUploadedDate());
                history.setFileDetails(fileDetailsEntity);

                if (fileDetailsEntity.getHistoryEntities() == null) {
                    fileDetailsEntity.setHistoryEntities(List.of(history));
                } else {
                    fileDetailsEntity.getHistoryEntities().add(history);
                }
            } else {
                fileDetailsEntity = CrlFileDetailsEntity.builder()
                        .fileName(crlFileDetailsEntity.getFileName())
                        .uploadedBy(currentUser)
                        .sftpPath(String.valueOf(crlFileDetailsEntity.getSftpPath()))
                        .fileSize(crlFileDetailsEntity.getFileSize())
                        .uploadedDate(LocalDateTime.now())
                        .build();

                history.setUploadedDate(fileDetailsEntity.getUploadedDate());
                history.setFileDetails(fileDetailsEntity);
                fileDetailsEntity.setHistoryEntities(List.of(history));
            }

            crlFileDetailsRepository.save(fileDetailsEntity);
            logger.info("CRL file uploaded successfully: {}", crlFileDetailsEntity.getFileName());

        } catch (Exception e) {
            logger.error("Failed to upload CRL file: {}", e.getMessage(), e);
            throw new RuntimeException("Failed to upload CRL file.", e);
        }
    }



    private String uploadFileToSftp(MultipartFile file) throws Exception {
        logger.debug("Uploading file to SFTP: {}", file.getOriginalFilename());
        String sftpPath = "/files/crls/";
        try (InputStream inputStream = file.getInputStream()) {
            sftpService.uploadCRLCGBSFile(sftpPath, file.getOriginalFilename(), inputStream);
        }
        return sftpPath + file.getOriginalFilename();
    }

    public List<CRLFileDetails> getCrlFiles() {
        logger.info("Fetching all CRL files");
        List<CrlFileDetailsEntity> crlFileDetailsEntities = crlFileDetailsRepository.findAll();
        logger.debug("Found {} CRL files", crlFileDetailsEntities.size());
        return crlFileDetailsEntities.stream()
                .map(this::convertToDto)
                .toList();
    }

    private CRLFileDetails convertToDto(CrlFileDetailsEntity entity) {
        logger.debug("Converting entity to DTO for file: {}", entity.getFileName());
        CRLFileDetails dto = new CRLFileDetails();
        dto.setFileName(entity.getFileName());
        dto.setFilePath(entity.getSftpPath());
        dto.setUploadedBy(entity.getUploadedBy());
        dto.setFileSize(convertFileSize(entity.getFileSize()));
        dto.setId(entity.getId());
        dto.setUploadedAt(Date.from(entity.getUploadedDate().atZone(ZoneId.systemDefault()).toInstant()));
        return dto;
    }

    public Resource downloadCrlFile(String fileName) {
        logger.info("Downloading CRL file: {}", fileName);
        CrlFileDetailsEntity crlFileDetailsEntity = crlFileDetailsRepository.findByFileName(fileName);

        if (ObjectUtils.isNotEmpty(crlFileDetailsEntity)) {
            String sftpPath = crlFileDetailsEntity.getSftpPath();

            try {
                InputStream fileStream = sftpService.downloadFile(sftpPath);

                ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
                IOUtils.copy(fileStream, outputStream);
                ByteArrayInputStream inputStream = new ByteArrayInputStream(outputStream.toByteArray());

                logger.info("Downloaded CRL file: {}", fileName);
                return new ByteArrayResource(inputStream.readAllBytes());

            } catch (Exception e) {
                logger.error("Failed to download CRL file: {}", e.getMessage(), e);
                throw new RuntimeException(e);
            }
        } else {
            logger.error("File not found: {}", fileName);
            throw new RuntimeException("File Not Found");
        }
    }

    public String convertFileSize(Long sizeInBytes) {
        final int ONE_MB = 1024 * 1024;
        final int ONE_KB = 1024;

        if (sizeInBytes >= ONE_MB) {
            double sizeInMB = (double) sizeInBytes / ONE_MB;
            return String.format("%.2f MB", sizeInMB);
        } else {
            double sizeInKB = (double) sizeInBytes / ONE_KB;
            return String.format("%.2f KB", sizeInKB);
        }
    }
    public void deleteCrlFile(Integer id) {
        if (!crlFileDetailsRepository.existsById(Long.valueOf(id))) {
            throw new ResourceNotFoundException("CGBS file not found with the specific ID: " + id);
        }
        crlFileDetailsRepository.deleteById(Long.valueOf(id));

    }
    private Long parseFileSize(String fileSizeStr) {
        if (fileSizeStr == null || fileSizeStr.trim().isEmpty()) {
            return 0L;
        }

        try {
            fileSizeStr = fileSizeStr.trim().toUpperCase();
            double value = Double.parseDouble(fileSizeStr.replaceAll("[^0-9.]", ""));

            if (fileSizeStr.contains("MB")) {
                return (long) (value * 1024 * 1024);
            } else if (fileSizeStr.contains("KB")) {
                return (long) (value * 1024);
            } else {
                // Assume bytes if no unit specified
                return (long) value;
            }
        } catch (NumberFormatException e) {
            logger.warn("Could not parse file size: {}", fileSizeStr);
            return 0L;
        }
    }
}