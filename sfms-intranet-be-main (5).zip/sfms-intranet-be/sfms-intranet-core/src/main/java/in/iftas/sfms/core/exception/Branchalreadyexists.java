package in.iftas.sfms.core.exception;

public class Branchalreadyexists extends RuntimeException {
    public Branchalreadyexists(String ifscCode) {
        super(String.format (" Branch already exists with ifsc code " + ifscCode));
    }
}
