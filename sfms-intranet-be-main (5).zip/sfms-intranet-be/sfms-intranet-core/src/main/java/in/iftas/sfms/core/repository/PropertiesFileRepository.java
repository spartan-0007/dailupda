package in.iftas.sfms.core.repository;

import in.iftas.sfms.core.entity.PropertiesFileEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface PropertiesFileRepository extends JpaRepository<PropertiesFileEntity, Integer> {

    boolean existsByIfscCode(String ifscCode);

    @Query("SELECT p.ifscTypes FROM PropertiesFileEntity p WHERE p.ifscCode = :ifscCode")
    String findIfscTypesByIfscCode(@Param("ifscCode") String ifscCode);
}