package in.iftas.sfms.core.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "lc_bg_messages_audit_log")
public class LcBgMessageAuditLogEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "file_name", nullable = false)
    private String fileName;

    @Column(name = "operation", nullable = false)
    private String operation;  // e.g., "BATCH_PROCESS"

    @Column(name = "operation_timestamp", nullable = false)
    private LocalDateTime operationTimestamp;

    @Column(name = "details")
    private String details;  // e.g., "Processed 1000 records"

    @Column(name = "status", nullable = false)
    private String status;  // e.g., "SUCCESS", "FAILURE"

    @Column(name = "last_successful_batch")
    private Long lastSuccessfulBatch;  // Track the last successful batch, if needed

    @Column(name = "error_details")
    private String errorDetails;  // Capture any errors during processing
}