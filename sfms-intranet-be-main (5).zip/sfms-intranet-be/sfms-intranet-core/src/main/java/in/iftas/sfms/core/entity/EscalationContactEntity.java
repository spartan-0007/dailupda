package in.iftas.sfms.core.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "i_escalation_contacts", indexes = {
        @Index(name = "idx_bank_id", columnList = "bank_id"),
        @Index(name = "idx_level_id", columnList = "level_id")
})
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class EscalationContactEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "bank_id", nullable = false)
    private Long bankId;

    @ManyToOne
    @JoinColumn(name = "level_id", referencedColumnName = "id", nullable = false)
    private EscalationLevelEntity level;

    @Column(name = "feature")
    private String feature;

    @Column(name = "designation")
    private String designation;

    @Column(name = "contact_name")
    private String contactName;

    @Column(name = "contact_number")
    private String contactNumber;

    @Column(name = "contact_email")
    private String contactEmail;
}