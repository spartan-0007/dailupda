package in.iftas.sfms.core.service;

/*
 * Copyright (C) 2024 Iftas Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Iftas Inc. ("Confidential Information"). You shall not disclose
 * such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with Iftas Inc.
 *
 * Author: Manoj.Illa
 * Date: July 11, 2024
 */

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import in.iftas.sfms.core.dto.BankMessageCountDTO;
import in.iftas.sfms.core.dto.ProcessingResultDTO;
import in.iftas.sfms.core.entity.LcBgMessageAuditLogEntity;
import in.iftas.sfms.core.entity.LcBgMessageEntity;
import in.iftas.sfms.core.exception.InvalidFileFormatException;
import in.iftas.sfms.core.exception.PartialProcessException;
import in.iftas.sfms.core.exception.ResourceNotFoundException;
import in.iftas.sfms.core.mapper.LcBgMessageMapper;
import in.iftas.sfms.core.model.LcBgMessage;
import in.iftas.sfms.core.model.LcBgMessagesReportRequest;
import in.iftas.sfms.core.repository.LcBgMessageAuditLogRepository;
import in.iftas.sfms.core.repository.LcBgMessageRepository;
import in.iftas.sfms.core.specification.LcBgMessageSpecification;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

@Service
public class LcBgMessagesService {

    private static final Logger logger = LoggerFactory.getLogger(LcBgMessagesService.class);

    private final LcBgMessageRepository lcBgMessageRepository;
    private final LcBgMessageAuditLogRepository lcBgMessageAuditLogRepository;
    private final LcBgMessageMapper lcBgMessageMapper;

    private ProcessingResultDTO processingResultDTO;

    public LcBgMessagesService(LcBgMessageRepository lcBgMessageRepository,
                               LcBgMessageAuditLogRepository lcBgMessageAuditLogRepository,
                               LcBgMessageMapper lcBgMessageMapper) {
        logger.info("Initializing LcBgMessagesService");
        this.lcBgMessageRepository = lcBgMessageRepository;
        this.lcBgMessageAuditLogRepository = lcBgMessageAuditLogRepository;
        this.lcBgMessageMapper = lcBgMessageMapper;
        logger.info("LcBgMessagesService initialized with repositories and mapper");
    }

    public ProcessingResultDTO processExcelFile(MultipartFile file) throws IOException, InvalidFormatException {
        this.processingResultDTO = new ProcessingResultDTO();
        LocalDateTime startTime = LocalDateTime.now();
        String fileName = file.getOriginalFilename();
        logger.info("Starting processExcelFile for file: {}", fileName);
        try (InputStream is = file.getInputStream()) {
            Workbook workbook;
            if (fileName != null && fileName.endsWith(".xls")) {
                workbook = new HSSFWorkbook(new POIFSFileSystem(is));
            } else if (fileName != null && fileName.endsWith(".xlsx")) {
                workbook = new XSSFWorkbook(OPCPackage.open(is));
            } else {
                logger.error("The specified file is not an Excel file: {}", fileName);
                throw new InvalidFileFormatException("The specified file is not an Excel file");
            }

            Sheet sheet = workbook.getSheetAt(0);

            if (!validateHeaders(sheet)) {
                logger.error("Excel file header validation failed for file: {}", fileName);
                saveAuditLog(fileName, "HEADER_VALIDATION", "File processing aborted",
                        "FAILURE", null, "Excel file headers do not match expected format");
                throw new InvalidFileFormatException("Excel file headers do not match the expected format");
            }

            int totalRows = sheet.getLastRowNum() + 1;
            int startRow = 6;

            List<CompletableFuture<Void>> futures = new ArrayList<>();
            long lastSuccessfulBatch = 0L;
            int batchSize = 500;

            for (int i = startRow; i < totalRows; i += batchSize) {
                int end = Math.min(i + batchSize, totalRows);
                List<Row> rowsBatch = getRowsInRange(sheet, i, end);
                Long batchNumber = (long) ((i - startRow) / batchSize) + 1;
                logger.info("Processing batch {} from row {} to {}", batchNumber, i, end - 1);
                futures.add(processAndSaveBatchAsync(rowsBatch, batchNumber, fileName));
                lastSuccessfulBatch = batchNumber;
            }
            CompletableFuture.allOf(futures.toArray(new CompletableFuture[0])).join();


            if (processingResultDTO.getTotalFailed() > 0) {
                throw new PartialProcessException(" LC BG file processed with partial success", processingResultDTO);
            }else {
                saveAuditLog(fileName, "BATCH_PROCESS", "All batches processed successfully",
                        "SUCCESS", lastSuccessfulBatch, null);
            }

            logger.info("Total Records Processed: {}", totalRows - startRow);

        } catch (PartialProcessException e) {
            logger.error("Error processing file: {}", e.getMessage(), e);
            throw e;
        } catch (Exception e) {
            logger.error("Error processing file: {}", e.getMessage(), e);
            saveAuditLog(fileName, "BATCH_PROCESS", "Processing failed",
                    "FAILURE", null, "Exception Occurred while process the file");
            throw e;
        }
        LocalDateTime endTime = LocalDateTime.now();
        Duration duration = Duration.between(startTime, endTime);
        logger.info("Total time taken to upload LC & BG Excel: {} milliseconds", duration.toMillis());
        return processingResultDTO;
    }

    @Async("taskExecutor")
    private CompletableFuture<Void> processAndSaveBatchAsync(List<Row> rowsBatch, Long batchNumber, String fileName) {
        try {
            List<LcBgMessageEntity> messagesBatch = rowsBatch.stream()
                    .map(this::convertRowToMessage)
                    .toList();

            saveRecordsInBatch(messagesBatch, batchNumber, fileName);
            logger.info("Successfully processed batch {}", batchNumber);

        } catch (Exception e) {
            logger.error("Error processing batch {}: {}", batchNumber, e.getMessage(), e);
            saveAuditLog(fileName, "BATCH_PROCESS", "Batch " + batchNumber + " failed",
                    "FAILURE", batchNumber, e.getMessage());

        }
        return CompletableFuture.completedFuture(null);
    }

    @Transactional
    public void saveRecordsInBatch(List<LcBgMessageEntity> messages, Long batchNumber, String fileName) {
        if (messages.isEmpty()) {
            logger.info("No messages to process.");
            return;
        }

        // Step 1: Get all existing sender references in one query
        List<String> senderReferences = messages.stream()
                .map(LcBgMessageEntity::getSenderReferenceNumber)
                .toList();

        Set<String> existingSenderReferences = new HashSet<>(
                Collections.unmodifiableSet(lcBgMessageRepository.findBySenderReferenceNumberIn(senderReferences)
                        .stream()
                        .map(LcBgMessageEntity::getSenderReferenceNumber)
                        .collect(Collectors.toSet()))
        );

        logger.info("Existing sender reference numbers: {}", existingSenderReferences);

        // Step 2: Filter new messages and process them
        List<LcBgMessageEntity> newMessages = new ArrayList<>();

        for (LcBgMessageEntity message : messages) {
            if (!existingSenderReferences.contains(message.getSenderReferenceNumber())) {
                newMessages.add(message);
                processingResultDTO.incrementProcessed();
            } else {
                processingResultDTO.incrementFailed();
                processingResultDTO.addFailedRecord(message.getSenderReferenceNumber());
            }
        }

        // Step 3: Save the new messages in a single batch insert
        if (!newMessages.isEmpty()) {
            lcBgMessageRepository.saveAll(newMessages);
            logger.info("Successfully saved {} new records.", newMessages.size());
        }

        saveAuditLog(fileName, "BATCH_PROCESS",
                "Batch " + batchNumber + " processed successfully. Processed: " + processingResultDTO.getTotalProcessed() +
                        ", Failed: " + processingResultDTO.getTotalFailed(),
                processingResultDTO.getTotalFailed() > 0 ? "PARTIAL_SUCCESS" : "SUCCESS",
                batchNumber, null);

        if (processingResultDTO.getTotalFailed() > 0) {
            for (String failedRecord : processingResultDTO.getFailedRecords()) {
                saveAuditLog(fileName, "BATCH_PROCESS_FAILED",
                        "Batch " + batchNumber + " failed on record: " + failedRecord,
                        "FAILURE", batchNumber, "Record with sender reference " + failedRecord + " already exists.");
            }
        }

        logger.info("Total processed : {}", processingResultDTO.getTotalProcessed());
        logger.info("Total failed: {}", processingResultDTO.getTotalFailed());
        logger.info("Failed records: {}", processingResultDTO.getFailedRecords());
    }

    private void saveAuditLog(String fileName, String operation, String details,
                              String status, Long lastSuccessfulBatch, String errorDetails) {
        logger.info("Saving audit log for operation: {} on file: {}", operation, fileName);
        LcBgMessageAuditLogEntity auditLog = LcBgMessageAuditLogEntity.builder()
                .fileName(fileName)
                .operation(operation)
                .operationTimestamp(LocalDateTime.now())
                .details(details)
                .status(status)
                .lastSuccessfulBatch(lastSuccessfulBatch)
                .errorDetails(errorDetails)
                .build();

        lcBgMessageAuditLogRepository.save(auditLog);
        logger.info("Audit log saved successfully for operation: {}", operation);
    }

    private LcBgMessageEntity convertRowToMessage(Row row) {
        logger.debug("Converting row to LcBgMessageEntity: {}", row);
        return LcBgMessageEntity.builder()
                .senderIfsc(getCellValue(row.getCell(1)))
                .receiverIfsc(getCellValue(row.getCell(2)))
                .senderReferenceNumber(getCellValue(row.getCell(3)))
                .messageType(getCellValue(row.getCell(4)))
                .messageStatus(getCellValue(row.getCell(5)))
                .messageDateTime(parseLocalDateTime(getCellValue(row.getCell(6))))
                .halfYear(calculateHalfYear(parseLocalDateTime(getCellValue(row.getCell(6)))))
                .uploadDate(LocalDate.now())
                .build();
    }

    private String getCellValue(Cell cell) {
        return cell != null ? cell.getStringCellValue().trim() : "";
    }

    private LocalDateTime parseLocalDateTime(String dateTimeString) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        return LocalDateTime.parse(dateTimeString, formatter);
    }

    private int calculateHalfYear(LocalDateTime messageDateTime) {
        return messageDateTime.getMonthValue() <= 6 ? 1 : 2;
    }

    private List<Row> getRowsInRange(Sheet sheet, int start, int end) {
        List<Row> rows = new ArrayList<>();
        for (int i = start; i < end; i++) {
            rows.add(sheet.getRow(i));
        }
        logger.debug("Fetched {} rows from sheet", rows.size());
        return rows;
    }

    public ByteArrayResource generateConsolidatedLcBgPdfReport(Long bankId, LocalDateTime fromDate, LocalDateTime toDate) throws DocumentException, IOException {

        logger.info("Generating consolidated LC/BG PDF report for bank ID: {} from {} to {}", bankId, fromDate, toDate);
        List<BankMessageCountDTO> messages = lcBgMessageRepository.findMessagesByBankNameAndDateRange(fromDate, toDate, bankId);
        if (messages.isEmpty()) {
            logger.warn("No LC/BG messages found for the specified criteria.");
            throw new ResourceNotFoundException("No LC/BG messages found for the specified criteria.");
        }
        Document document = new Document();
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        PdfWriter.getInstance(document, byteArrayOutputStream);
        document.open();
        InputStream logoStream = this.getClass().getClassLoader().getResourceAsStream("images/iftas-logo.jpg");
        if (logoStream != null) {
            Image logo = Image.getInstance(logoStream.readAllBytes());
            logo.scaleToFit(180, 120); // Increased logo size to match the detailed report
            logo.setAlignment(Element.ALIGN_CENTER);
            document.add(logo);
        }
        document.add(new Paragraph(" "));  // Add space before title
        BaseColor customColor = new BaseColor(0, 77, 153);
        Font titleFontFont = new Font(Font.FontFamily.TIMES_ROMAN, 16, Font.BOLD, customColor); // Reduced title font
        Font subTitleFont = new Font(Font.FontFamily.TIMES_ROMAN, 12, Font.BOLD); // Reduced subtitle font
        Font normalFont = new Font(Font.FontFamily.TIMES_ROMAN, 10, Font.NORMAL); // Reduced normal font
        Font boldFont = new Font(Font.FontFamily.TIMES_ROMAN, 10, Font.BOLD); // Reduced bold font
        Paragraph title = new Paragraph("STRUCTURED FINANCIAL MESSAGING SYSTEM", titleFontFont);
        title.setAlignment(Element.ALIGN_CENTER);
        document.add(title);
        document.add(new Paragraph(" "));
        PdfPTable lineTable = new PdfPTable(1);
        lineTable.setWidthPercentage(80);
        PdfPCell lineCell = new PdfPCell();
        lineCell.setFixedHeight(2f);
        lineCell.setBackgroundColor(BaseColor.YELLOW);
        lineCell.setBorder(PdfPCell.NO_BORDER);
        lineCell.setHorizontalAlignment(Element.ALIGN_CENTER);
        lineTable.addCell(lineCell);
        document.add(lineTable);
        document.add(new Paragraph(" "));
        Paragraph subTitle = new Paragraph("CONSOLIDATED LC-BG REPORT", subTitleFont);
        subTitle.setAlignment(Element.ALIGN_CENTER);
        document.add(subTitle);

        document.add(new Paragraph(" "));

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        Paragraph dateRange = new Paragraph("FROM DATE: " + fromDate.format(formatter) + " TO DATE: " + toDate.format(formatter), boldFont);
        dateRange.setAlignment(Element.ALIGN_CENTER);
        document.add(dateRange);
        document.add(new Paragraph(" "));

        PdfPTable table = new PdfPTable(2);
        table.setWidthPercentage(100);
        table.setSpacingBefore(10f);
        table.setSpacingAfter(10f);

        PdfPCell cell1 = new PdfPCell(new Phrase("Bank Name", subTitleFont));
        cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell1.setBackgroundColor(BaseColor.YELLOW);
        cell1.setPadding(5f);
        table.addCell(cell1);

        PdfPCell cell2 = new PdfPCell(new Phrase("Message Count", subTitleFont));
        cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell2.setBackgroundColor(BaseColor.YELLOW);
        cell2.setPadding(5f);
        table.addCell(cell2);

        for (BankMessageCountDTO bankMessageCountDTO : messages) {
            PdfPCell bankNameCell = new PdfPCell(new Phrase(bankMessageCountDTO.getBankName(), normalFont));
            bankNameCell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            bankNameCell.setPadding(5f);  // Add padding to the cell
            table.addCell(bankNameCell);

            PdfPCell countCell = new PdfPCell(new Phrase(bankMessageCountDTO.getMessageCount().toString(), normalFont));
            countCell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            countCell.setPadding(5f);  // Add padding to the cell
            table.addCell(countCell);
        }
        document.add(table);

        document.close();
        logger.info("Consolidated LC/BG PDF report generated successfully.");

        return new ByteArrayResource(byteArrayOutputStream.toByteArray());
    }

    public ByteArrayResource generateDetailedLcBgPdfReport(LcBgMessagesReportRequest request) throws DocumentException, IOException {

        logger.info("Generating detailed LC/BG PDF report for request: {}", request);

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd' 'HH:mm:ss");
        LocalDateTime fromDateTime = LocalDateTime.parse(request.getFromDate(), formatter);
        LocalDateTime toDateTime = LocalDateTime.parse(request.getToDate(), formatter);
        List<LcBgMessageEntity> messages = lcBgMessageRepository.findAll(LcBgMessageSpecification.getLcBgMessages(request, fromDateTime, toDateTime));

        if (messages.isEmpty()) {
            logger.warn("No LC/BG messages found for the specified criteria.");
            throw new ResourceNotFoundException("No LC/BG messages found for the specified criteria.");
        }
        Document document = new Document();
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        PdfWriter.getInstance(document, byteArrayOutputStream);

        document.open();

        InputStream logoStream = this.getClass().getClassLoader().getResourceAsStream("images/iftas-logo.jpg");
        if (logoStream != null) {
            Image logo = Image.getInstance(logoStream.readAllBytes());
            logo.scaleToFit(180, 120);
            logo.setAlignment(Element.ALIGN_CENTER);
            document.add(logo);
        }

        document.add(new Paragraph(" "));

        BaseColor customColor = new BaseColor(0, 77, 153);
        Font titleFontFont = new Font(Font.FontFamily.TIMES_ROMAN, 16, Font.BOLD, customColor);
        Font subTitleFont = new Font(Font.FontFamily.TIMES_ROMAN, 12, Font.BOLD);
        Font normalFont = new Font(Font.FontFamily.TIMES_ROMAN, 10, Font.NORMAL);
        Font boldFont = new Font(Font.FontFamily.TIMES_ROMAN, 10, Font.BOLD);

        Paragraph title = new Paragraph("STRUCTURED FINANCIAL MESSAGING SYSTEM", titleFontFont);
        title.setAlignment(Element.ALIGN_CENTER);
        document.add(title);

        document.add(new Paragraph(" "));

        PdfPTable lineTable = new PdfPTable(1);
        lineTable.setWidthPercentage(80);
        PdfPCell lineCell = new PdfPCell();
        lineCell.setFixedHeight(2f);
        lineCell.setBackgroundColor(BaseColor.YELLOW);
        lineCell.setBorder(PdfPCell.NO_BORDER);
        lineCell.setHorizontalAlignment(Element.ALIGN_CENTER);
        lineTable.addCell(lineCell);
        document.add(lineTable);

        document.add(new Paragraph(" "));

        Paragraph subTitle = new Paragraph("DETAILED LC & BG REPORT", subTitleFont);
        subTitle.setAlignment(Element.ALIGN_CENTER);
        document.add(subTitle);

        document.add(new Paragraph(" "));

        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        Paragraph dateRange = new Paragraph("FROM DATE:  " + fromDateTime.format(dateFormatter) + "  TO DATE:  " + toDateTime.format(dateFormatter), boldFont);
        dateRange.setAlignment(Element.ALIGN_CENTER);
        document.add(dateRange);

        document.add(new Paragraph(" "));

        PdfPTable table = new PdfPTable(6);
        table.setWidthPercentage(100);
        table.setSpacingBefore(10f);
        table.setSpacingAfter(10f);

        PdfPCell cell1 = new PdfPCell(new Phrase("Sender IFSC", subTitleFont));
        cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell1.setBackgroundColor(BaseColor.YELLOW);
        cell1.setPadding(5f);
        table.addCell(cell1);

        PdfPCell cell2 = new PdfPCell(new Phrase("Receiver IFSC", subTitleFont));
        cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell2.setBackgroundColor(BaseColor.YELLOW);
        cell2.setPadding(5f);
        table.addCell(cell2);

        PdfPCell cell3 = new PdfPCell(new Phrase("Sender Reference", subTitleFont));
        cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell3.setBackgroundColor(BaseColor.YELLOW);
        cell3.setPadding(5f);
        table.addCell(cell3);

        PdfPCell cell4 = new PdfPCell(new Phrase("Message Type", subTitleFont));
        cell4.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell4.setBackgroundColor(BaseColor.YELLOW);
        cell4.setPadding(5f);
        table.addCell(cell4);

        PdfPCell cell5 = new PdfPCell(new Phrase("Message Status", subTitleFont));
        cell5.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell5.setBackgroundColor(BaseColor.YELLOW);
        cell5.setPadding(5f);
        table.addCell(cell5);

        PdfPCell cell6 = new PdfPCell(new Phrase("Message Date", subTitleFont));
        cell6.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell6.setBackgroundColor(BaseColor.YELLOW);
        cell6.setPadding(5f);
        table.addCell(cell6);

        for (LcBgMessageEntity message : messages) {
            PdfPCell senderIfscCell = new PdfPCell(new Phrase(message.getSenderIfsc(), normalFont));
            senderIfscCell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            senderIfscCell.setPadding(5f);
            table.addCell(senderIfscCell);

            PdfPCell receiverIfscCell = new PdfPCell(new Phrase(message.getReceiverIfsc(), normalFont));
            receiverIfscCell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            receiverIfscCell.setPadding(5f);
            table.addCell(receiverIfscCell);

            PdfPCell senderReferenceCell = new PdfPCell(new Phrase(message.getSenderReferenceNumber(), normalFont));
            senderReferenceCell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            senderReferenceCell.setPadding(5f);
            table.addCell(senderReferenceCell);

            PdfPCell messageTypeCell = new PdfPCell(new Phrase(message.getMessageType(), normalFont));
            messageTypeCell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            messageTypeCell.setPadding(5f);
            table.addCell(messageTypeCell);

            PdfPCell messageStatusCell = new PdfPCell(new Phrase(message.getMessageStatus(), normalFont));
            messageStatusCell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            messageStatusCell.setPadding(5f);
            table.addCell(messageStatusCell);

            PdfPCell messageDateCell = new PdfPCell(new Phrase(message.getMessageDateTime().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")), normalFont));
            messageDateCell.setHorizontalAlignment(Element.ALIGN_CENTER);
            messageDateCell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            messageDateCell.setPadding(5f);
            messageDateCell.setNoWrap(true);
            table.addCell(messageDateCell);
        }

        document.add(table);

        document.close();
        logger.info("Detailed LC/BG PDF report generated successfully.");

        return new ByteArrayResource(byteArrayOutputStream.toByteArray());
    }

    public ByteArrayResource generateExcelReport(LcBgMessagesReportRequest request) throws IOException {
        logger.info("Generating Excel report for request: {}", request);

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd' 'HH:mm:ss");
        LocalDateTime fromDateTime = LocalDateTime.parse(request.getFromDate(), formatter);
        LocalDateTime toDateTime = LocalDateTime.parse(request.getToDate(), formatter);

        List<LcBgMessageEntity> messages = lcBgMessageRepository.findAll(LcBgMessageSpecification.getLcBgMessages(request, fromDateTime, toDateTime));
        if (messages.isEmpty()) {
            logger.warn("No LC/BG messages found for the specified criteria.");
            throw new ResourceNotFoundException("No LC/BG messages found for the specified criteria.");
        }




        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("LC-BG Report");

        int rowNum = 0;

        Row headerRow = sheet.createRow(rowNum++);
        headerRow.createCell(0).setCellValue("STRUCTURED FINANCIAL MESSAGING SYSTEM");

        Row reportMessageRow = sheet.createRow(rowNum++);
        reportMessageRow.createCell(0).setCellValue("DETAILED LC & BG REPORT");

        Row reportDateRow = sheet.createRow(rowNum++);
        reportDateRow.createCell(0).setCellValue("FROM DATE: " + fromDateTime + " TO DATE: " + toDateTime);

        Row columnRow = sheet.createRow(rowNum++);
        columnRow.createCell(0).setCellValue("Sender IFSC");
        columnRow.createCell(1).setCellValue("Receiver IFSC");
        columnRow.createCell(2).setCellValue("Sender Reference");
        columnRow.createCell(3).setCellValue("Message Type");
        columnRow.createCell(4).setCellValue("Message Status");
        columnRow.createCell(5).setCellValue("Message Date");

        sheet.setColumnWidth(0, 20 * 256);
        sheet.setColumnWidth(1, 20 * 256);
        sheet.setColumnWidth(2, 30 * 256);
        sheet.setColumnWidth(3, 15 * 256);
        sheet.setColumnWidth(4, 15 * 256);
        sheet.setColumnWidth(5, 25 * 256);

        for (LcBgMessageEntity item : messages) {
            Row row = sheet.createRow(rowNum++);
            row.createCell(0).setCellValue(item.getSenderIfsc());
            row.createCell(1).setCellValue(item.getReceiverIfsc());
            row.createCell(2).setCellValue(item.getSenderReferenceNumber());
            row.createCell(3).setCellValue(item.getMessageType());
            row.createCell(4).setCellValue(item.getMessageStatus());
            row.createCell(5).setCellValue(item.getMessageDateTime().toString());
        }

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        workbook.write(out);
        workbook.close();
        logger.info("Excel report generated successfully for LC/BG messages.");

        ByteArrayResource resource = new ByteArrayResource(out.toByteArray());
        return resource;
    }

    public LcBgMessage getBySenderReferenceNumber(String serviceRequestNumber) {
        logger.info("Fetching LC/BG message with Service Request Number: {}", serviceRequestNumber);
        return lcBgMessageRepository.findBySenderReferenceNumber(serviceRequestNumber)
                .map(entity -> {
                    logger.info("LC/BG message found: {}", entity);
                    return lcBgMessageMapper.toModel(entity);
                })
                .orElseThrow(() -> {
                    logger.warn("LC/BG message with Service Request Number: {} not found", serviceRequestNumber);
                    return new RuntimeException("LC/BG message not found");
                });
    }

    public Resource generateDetailedLcBgReport(LcBgMessagesReportRequest lcBgMessagesReportRequest) throws DocumentException, IOException {
       logger.info("Entering generateDetailedLcBgReport with request: {}", lcBgMessagesReportRequest);
        Resource resource;
        if (LcBgMessagesReportRequest.FormatEnum.PDF.equals(lcBgMessagesReportRequest.getFormat())) {
            logger.info("Generating PDF report for request: {}", lcBgMessagesReportRequest);
            resource = generateDetailedLcBgPdfReport(lcBgMessagesReportRequest);
        } else {
            logger.info("Generating Excel report for request: {}", lcBgMessagesReportRequest);
            resource = generateExcelReport(lcBgMessagesReportRequest);
        }
        logger.info("Exiting generateDetailedLcBgReport");
        return resource;
    }

    private boolean validateHeaders(Sheet sheet) {
        Row headerRow = sheet.getRow(5);
        if (headerRow == null) {
            logger.error("Header row is missing in the Excel file");
            return false;
        }

        List<String> expectedHeaders = Arrays.asList(
                "Bank Name",
                "sender ifsc",
                "Receiver ifsc",
                "Sender Refernce Number",
                "Message Type",
                "Message Status",
                "Date"
        );

        int lastCellNum = headerRow.getLastCellNum();
        if (lastCellNum < expectedHeaders.size()) {
            logger.error("Header row has fewer columns than expected. Found: {}, Expected: {}",
                    lastCellNum, expectedHeaders.size());
            return false;
        }

        for (int i = 0; i < expectedHeaders.size(); i++) {
            Cell cell = headerRow.getCell(i);
            if (cell == null) {
                logger.info("Header cell at position {} is missing", i);
                return false;
            }

            String cellValue = cell.getStringCellValue().trim();
            String expectedHeader = expectedHeaders.get(i);

            if (expectedHeader.equalsIgnoreCase("Date")) {
                if (!cellValue.toLowerCase().contains("date")) {
                    logger.info("Header validation failed for column {}. Expected: contains 'date', Found: '{}'",
                            i, cellValue);
                    return false;
                }
            } else {
                if (!cellValue.equalsIgnoreCase(expectedHeader)) {
                    logger.info("Header validation failed for column {}. Expected: '{}', Found: '{}'",
                            i, expectedHeader, cellValue);
                    return false;
                }
            }
        }

        logger.info("Header validation successful");
        return true;
    }

}