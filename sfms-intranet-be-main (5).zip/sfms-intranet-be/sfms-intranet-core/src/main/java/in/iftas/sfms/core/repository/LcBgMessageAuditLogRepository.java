package in.iftas.sfms.core.repository;

import in.iftas.sfms.core.entity.LcBgMessageAuditLogEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LcBgMessageAuditLogRepository extends JpaRepository<LcBgMessageAuditLogEntity, Long> {
}