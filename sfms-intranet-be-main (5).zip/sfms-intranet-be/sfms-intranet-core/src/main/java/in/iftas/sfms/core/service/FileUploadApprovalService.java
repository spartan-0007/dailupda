package in.iftas.sfms.core.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import in.iftas.sfms.common.entity.ApprovalRequestEntity;
import in.iftas.sfms.common.repository.ApprovalRequestRepository;
import in.iftas.sfms.core.entity.*;
import in.iftas.sfms.core.exception.ResourceNotFoundException;
import in.iftas.sfms.core.model.FileUploadApprovalRequest;
import in.iftas.sfms.core.model.PatchUploadRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * Service class that handles the processing of file uploads and creation of approval requests.
 */
@Service
@Slf4j
public class FileUploadApprovalService {

    private final ApprovalRequestRepository approvalRequestRepository;
    private final ObjectMapper objectMapper;
    private final SftpService sftpService;

    @Value("${sftp.remote.dir.base:/files}")
    private String sftpBasePath;

    /**
     * Constant for the FILE_UPLOAD entity type used in approval requests.
     */
    private static final String ENTITY_TYPE_FILE_UPLOAD = "FILE_UPLOAD";

    private static final Set<String> ALLOWED_ZIP_FILE_TYPES = Set.of(
            "application/zip",
            "application/x-zip-compressed",
            "application/octet-stream"
    );

    private static final Set<String> ALLOWED_USER_MANUAL_FILE_TYPES = Set.of(
            "application/pdf",
            "text/plain",
            "application/msword",
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            "application/vnd.ms-excel",
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            "application/vnd.ms-powerpoint",
            "application/vnd.openxmlformats-officedocument.presentationml.presentation",
            "text/html",
            "application/zip",
            "application/x-zip-compressed",
            "application/octet-stream"
    );

    private static final Map<String, String> ENTITY_SFTP_PATHS = Map.of(
            "FILE_CGBS", "/cgbs",
            "FILE_CRL", "/crls",
            "FILE_RELEASES", "/releases",
            "FILE_USERMANUALS", "/user-manuals"
    );

    public FileUploadApprovalService(ApprovalRequestRepository approvalRequestRepository,
                                     ObjectMapper objectMapper,
                                     SftpService sftpService) {
        this.approvalRequestRepository = approvalRequestRepository;
        this.objectMapper = objectMapper;
        this.sftpService = sftpService;
        log.info("Initialized FileUploadApprovalService with SftpService");
    }

    /**
     * Process the uploaded file and create an approval request for it.
     *
     * @param file        The file to be uploaded
     * @param detailsJson JSON string containing FileUploadApprovalRequest details
     * @param json        Additional JSON parameter (currently unused)
     * @return ModelApiResponse with the result of the operation
     * @throws IllegalArgumentException if the request is invalid
     * @throws RuntimeException         if there's a server error
     */
    @Transactional
    public void processFileUploadApproval(MultipartFile file, String detailsJson, String json) {
        try {
            log.debug("Processing file upload approval for file: {}", file.getOriginalFilename());

            FileUploadApprovalRequest approvalRequest = parseApprovalRequestDetails(detailsJson);
            validateApprovalRequest(approvalRequest);

            validateFile(file, approvalRequest.getEntityType());

            String sftpPath = uploadFileToSftp(file, approvalRequest.getEntityType());

            Object fileDetails = createFileDetailsEntity(file, sftpPath, approvalRequest.getEntityType(), json);

            ApprovalRequestEntity approvalRequestEntity = createApprovalRequest(fileDetails, approvalRequest);
            approvalRequestRepository.save(approvalRequestEntity);

        } catch (IllegalArgumentException e) {
            log.warn("Invalid request: {}", e.getMessage());
            throw e;
        } catch (Exception e) {
            log.error("Error processing file upload approval: {}", e.getMessage(), e);
            throw new RuntimeException("Error processing file upload: " + e.getMessage(), e);
        }
    }

    /**
     * Parse JSON string to FileUploadApprovalRequest object
     */
    private FileUploadApprovalRequest parseApprovalRequestDetails(String detailsJson) {
        try {
            if (!StringUtils.hasText(detailsJson)) {
                throw new IllegalArgumentException("Approval request details cannot be empty");
            }
            return objectMapper.readValue(detailsJson, FileUploadApprovalRequest.class);
        } catch (Exception e) {
            log.error("Error parsing approval request details: {}", e.getMessage());
            throw new IllegalArgumentException("Invalid JSON format for approval request details", e);
        }
    }

    /**
     * Validates the uploaded file.
     *
     * @param file       The file to validate
     * @param entityType The entity type to determine validation rules
     * @throws IllegalArgumentException if the file is invalid
     */
    private void validateFile(MultipartFile file, String entityType) {
        if (file == null || file.isEmpty()) {
            throw new IllegalArgumentException("File cannot be null or empty");
        }

        String fileName = file.getOriginalFilename();
        if (!StringUtils.hasText(fileName)) {
            throw new IllegalArgumentException("File name cannot be empty");
        }

        if (fileName.contains("..") || fileName.contains("/") || fileName.contains("\\")) {
            throw new IllegalArgumentException("Invalid file name: contains prohibited characters");
        }

        String contentType = file.getContentType();
        String resolvedEntityType = StringUtils.hasText(entityType) ? entityType.toUpperCase() : "FILE_CGBS";

        if ("FILE_USERMANUALS".equals(resolvedEntityType)) {
            if (contentType == null || !ALLOWED_USER_MANUAL_FILE_TYPES.contains(contentType)) {
                throw new IllegalArgumentException("File type not allowed for user manuals: " + contentType);
            }
        } else {
            if (contentType == null || !ALLOWED_ZIP_FILE_TYPES.contains(contentType)) {
                throw new IllegalArgumentException("File type not allowed: " + contentType + ". Only ZIP files are accepted.");
            }

            if (!fileName.toLowerCase().endsWith(".zip")) {
                throw new IllegalArgumentException("Only ZIP files are accepted");
            }
        }
    }

    /**
     * Validate approval request
     */
    private void validateApprovalRequest(FileUploadApprovalRequest request) {
        if (request == null) {
            throw new IllegalArgumentException("Approval request cannot be null");
        }

        if (!StringUtils.hasText(request.getActionType())) {
            throw new IllegalArgumentException("Action type is required");
        }

        try {
            ApprovalRequestEntity.ActionType actionType = ApprovalRequestEntity.ActionType.valueOf(request.getActionType());

            if ((actionType == ApprovalRequestEntity.ActionType.UPDATE ||
                    actionType == ApprovalRequestEntity.ActionType.DELETE) &&
                    !StringUtils.hasText(request.getEntityId())) {
                throw new IllegalArgumentException("Entity ID is required for " + actionType + " operations");
            }
        } catch (IllegalArgumentException e) {
            if (e.getMessage().contains("Entity ID is required")) {
                throw e;
            }
            throw new IllegalArgumentException("Invalid action type: " + request.getActionType());
        }

        if (StringUtils.hasText(request.getEntityType())) {
            try {
                ApprovalRequestEntity.EntityType.valueOf(request.getEntityType());
            } catch (IllegalArgumentException e) {
                throw new IllegalArgumentException("Invalid entity type: " + request.getEntityType());
            }
        }
    }

    /**
     * Uploads the file to SFTP server based on entity type.
     *
     * @param file       The file to upload
     * @param entityType The entity type to determine the upload path
     * @return The path where the file was uploaded
     * @throws Exception if there's an error uploading the file
     */
    private String uploadFileToSftp(MultipartFile file, String entityType) throws Exception {
        log.debug("Uploading file to SFTP: {}", file.getOriginalFilename());

        String sftpSubPath = getSftpPathForEntityType(entityType);
        String sftpPath = sftpBasePath + sftpSubPath + "/";

        log.debug("Upload path for entity type {}: {}", entityType, sftpPath);

        try (InputStream inputStream = file.getInputStream()) {
            sftpService.uploadCRLCGBSFile(sftpPath, file.getOriginalFilename(), inputStream);
        }
        return sftpPath + file.getOriginalFilename();
    }

    /**
     * Get SFTP sub-path based on entity type
     */
    private String getSftpPathForEntityType(String entityType) {
        if (!StringUtils.hasText(entityType) || ENTITY_TYPE_FILE_UPLOAD.equals(entityType)) {
            return ENTITY_SFTP_PATHS.get("FILE_CGBS");
        }

        return ENTITY_SFTP_PATHS.getOrDefault(entityType.toUpperCase(), ENTITY_SFTP_PATHS.get("FILE_CGBS"));
    }

    /**
     * Creates appropriate file details entity based on entity type.
     * Uses switch case to instantiate the correct entity type.
     *
     * @param file       The uploaded file
     * @param sftpPath   The path where the file was uploaded on SFTP server
     * @param entityType The entity type to determine which entity to create
     * @param json       Additional JSON data for entity-specific fields
     * @return The specific file details entity of type T
     */
    @SuppressWarnings("unchecked")
    private <T> T createFileDetailsEntity(MultipartFile file, String sftpPath, String entityType, String json) {
        String currentUsername = getCurrentUsername();
        LocalDateTime now = LocalDateTime.now();

        String resolvedEntityType = StringUtils.hasText(entityType) ? entityType.toUpperCase() : "FILE_CGBS";

        log.debug("Creating file details entity for type: {}", resolvedEntityType);

        return switch (resolvedEntityType) {
            case "FILE_CGBS" -> (T) CgbsFileDetailsEntity.builder()
                    .fileName(file.getOriginalFilename())
                    .uploadedBy(currentUsername)
                    .uploadedDate(now)
                    .sftpPath(sftpPath)
                    .fileSize(file.getSize())
                    .build();
            case "FILE_CRL" -> (T) CrlFileDetailsEntity.builder()
                    .fileName(file.getOriginalFilename())
                    .uploadedBy(currentUsername)
                    .uploadedDate(now)
                    .sftpPath(sftpPath)
                    .fileSize(file.getSize())
                    .build();
            case "FILE_RELEASES" -> {
                ReleaseDetailsEntity releaseEntity = ReleaseDetailsEntity.builder()
                        .fileName(file.getOriginalFilename())
                        .uploadedBy(currentUsername)
                        .uploadedDate(now)
                        .sftpPath(sftpPath)
                        .fileSize(file.getSize())
                        .build();

                if (StringUtils.hasText(json)) {
                    try {
                        PatchUploadRequest patchRequest = objectMapper.readValue(json, PatchUploadRequest.class);

                        if (patchRequest.getVersion() != null) {
                            releaseEntity.setVersion(patchRequest.getVersion());
                        }
                        if (patchRequest.getDescription() != null) {
                            releaseEntity.setDescription(patchRequest.getDescription());
                        }

                        if (patchRequest.getBankIds() != null) {
                            log.info("Processing {} bankIds from PatchUploadRequest", patchRequest.getBankIds().size());
                            Set accessEntities = new HashSet();
                            for (Long bankId : patchRequest.getBankIds()) {

                                accessEntities.add(ReleaseAccessEntity.builder().bankId(bankId)
                                        .accessGrantedDate(LocalDateTime.now()).accessRevoked(false).build());

                            }
                            releaseEntity.setReleaseAccessEntities(accessEntities);
                        }
                    } catch (JsonProcessingException e) {
                        log.error("Failed to parse additional JSON for FILE_RELEASES: {}", e.getMessage(), e);
                    }
                }

                yield (T) releaseEntity;
            }
            case "FILE_USERMANUALS" -> (T) UserManualEntity.builder()
                    .fileName(file.getOriginalFilename())
                    .uploadedBy(currentUsername)
                    .uploadedDate(now)
                    .sftpPath(sftpPath)
                    .fileSize(file.getSize())
                    .build();
            default -> {
                log.warn("Unknown entity type: {}, defaulting to CGBS", resolvedEntityType);
                yield (T) CgbsFileDetailsEntity.builder()
                        .fileName(file.getOriginalFilename())
                        .uploadedBy(currentUsername)
                        .uploadedDate(now)
                        .sftpPath(sftpPath)
                        .fileSize(file.getSize())
                        .build();
            }
        };
    }

    /**
     * Creates an ApprovalRequestEntity for the file upload.
     * Now accepts any file details entity using generics.
     *
     * @param fileDetails     The file details entity (can be any type)
     * @param approvalRequest The approval request details
     * @return An ApprovalRequestEntity
     * @throws Exception if there's an error creating the approval request
     */
    private <T> ApprovalRequestEntity createApprovalRequest(T fileDetails,
                                                            FileUploadApprovalRequest approvalRequest) throws Exception {
        log.info("Creating file upload approval request for action: {}", approvalRequest.getActionType());

        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

            String userId;
            String userName;

            if (authentication != null && authentication.getPrincipal() instanceof Jwt jwt) {
                userId = jwt.getClaimAsString("sub");
                userName = jwt.getClaimAsString("name");
            } else {
                userId = "system";
                userName = "System";
            }

            String requestData = prepareRequestData(fileDetails, approvalRequest);

            String entityId = determineEntityId(approvalRequest, userId);

            String entityType = StringUtils.hasText(approvalRequest.getEntityType())
                    ? approvalRequest.getEntityType()
                    : ENTITY_TYPE_FILE_UPLOAD;


            ApprovalRequestEntity entity = ApprovalRequestEntity.builder()
                    .entityType(entityType)
                    .entityId(entityId)
                    .actionType(approvalRequest.getActionType())
                    .requestData(objectMapper.writeValueAsString(fileDetails))
                    .status(ApprovalRequestEntity.Status.PENDING.name())
                    .makerName(userName)
                    .build();

            entity.setCreatedBy(userId);
            entity.setCreatedDate(LocalDateTime.now());

            log.info("File upload approval request created successfully for action: {}", approvalRequest.getActionType());
            return entity;

        } catch (Exception e) {
            log.error("Error creating approval request: {}", e.getMessage());
            throw new RuntimeException("Failed to create approval request", e);
        }
    }

    /**
     * Prepare request data based on action type.
     * Now accepts any file details entity using generics.
     */
    private <T> String prepareRequestData(T fileDetails,
                                          FileUploadApprovalRequest approvalRequest) throws Exception {
        Map<String, Object> requestData = new HashMap<>();

        ApprovalRequestEntity.ActionType actionType = ApprovalRequestEntity.ActionType.valueOf(approvalRequest.getActionType());

        switch (actionType) {
            case CREATE:
                requestData.put("fileDetails", fileDetails);
                requestData.put("actionType", "CREATE");
                requestData.put("entityType", approvalRequest.getEntityType());
                break;
            case UPDATE:
                requestData.put("fileDetails", fileDetails);
                requestData.put("entityId", approvalRequest.getEntityId());
                requestData.put("actionType", "UPDATE");
                requestData.put("entityType", approvalRequest.getEntityType());
                break;
            case DELETE:
                requestData.put("entityId", approvalRequest.getEntityId());
                requestData.put("entityType", approvalRequest.getEntityType());
                requestData.put("actionType", "DELETE");
                try {
                    Object fileName = fileDetails.getClass().getMethod("getFileName").invoke(fileDetails);
                    requestData.put("fileName", fileName);
                } catch (Exception e) {
                    log.warn("Could not extract fileName from fileDetails: {}", e.getMessage());
                    requestData.put("fileName", "unknown");
                }
                requestData.put("entityType", approvalRequest.getEntityType());
                break;
        }

        return objectMapper.writeValueAsString(requestData);
    }

    /**
     * Determine entity ID based on action type
     * For UPDATE and DELETE: use the provided entityId from approvalRequest
     * For CREATE: use the current user ID
     */
    private String determineEntityId(FileUploadApprovalRequest approvalRequest, String userId) {
        ApprovalRequestEntity.ActionType actionType = ApprovalRequestEntity.ActionType.valueOf(approvalRequest.getActionType());

        switch (actionType) {
            case UPDATE:
            case DELETE:
                return approvalRequest.getEntityId();
            case CREATE:
                return userId;
            default:
                throw new IllegalArgumentException("Unsupported action type: " + actionType);
        }
    }

    /**
     * Gets the current authenticated username.
     *
     * @return The current username or "system" if not authenticated
     */
    private String getCurrentUsername() {
        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            if (authentication != null && authentication.getPrincipal() instanceof Jwt jwt) {
                return jwt.getClaimAsString("name");
            }
            return "system";
        } catch (Exception e) {
            log.warn("Error getting current username: {}", e.getMessage());
            return "system";
        }
    }

    /**
     * Gets the display name of the current authenticated user.
     *
     * @return The display name or "System" if not authenticated
     */
    private String getCurrentUserDisplayName() {
        // In a real implementation, you would fetch this from user service
        // For now, we just return the username
        return getCurrentUsername();
    }

    public void deleteFileUploadApproval(Integer id, String entityType) throws ResourceNotFoundException, IOException {
        log.info("Creating file upload deletion approval request for file ID: {}", id);


        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

            String userId;
            String userName;

            if (authentication != null && authentication.getPrincipal() instanceof Jwt jwt) {
                userId = jwt.getClaimAsString("sub");
                userName = jwt.getClaimAsString("name");
            } else {
                userId = "system";
                userName = "System";
            }

            ApprovalRequestEntity entity = ApprovalRequestEntity.builder()
                    .entityType(entityType)
                    .entityId(String.valueOf(id))
                    .actionType(ApprovalRequestEntity.ActionType.DELETE.name())
                    .status(ApprovalRequestEntity.Status.PENDING.name())
                    .makerName(userName)
                    .build();

            entity.setCreatedBy(userId);
            entity.setCreatedDate(LocalDateTime.now());

            approvalRequestRepository.save(entity);

            log.info("File upload deletion approval request created successfully for file ID: {}", id);
        } catch (Exception e) {
            log.error("Error creating file upload deletion approval request: {}", e.getMessage(), e);
            throw new RuntimeException("Failed to create file upload deletion approval request", e);
        }
    }

    /**
     * Process the update request for a file upload, creating an approval request.
     * Currently only supports updates for FILE_RELEASES entities.
     *
     * @param id          The ID of the entity to update
     * @param detailsJson JSON string containing FileUploadApprovalRequest details
     * @param json        Additional JSON parameter for entity-specific fields
     * @throws ResourceNotFoundException if the entity doesn't exist
     * @throws IllegalArgumentException  if the request is invalid
     * @throws RuntimeException          if there's a server error
     */
    @Transactional
    public void processFileUpdateApproval(Integer id, String detailsJson, String json) {
        try {
            log.debug("Processing file update approval for ID: {}", id);

            FileUploadApprovalRequest approvalRequest = parseApprovalRequestDetails(detailsJson);

            approvalRequest.setActionType(ApprovalRequestEntity.ActionType.UPDATE.name());
            approvalRequest.setEntityId(id.toString());

            if (!"FILE_RELEASES".equals(approvalRequest.getEntityType())) {
                throw new IllegalArgumentException("Update operation is only supported for release files");
            }

            validateEntityExists(id, approvalRequest.getEntityType());
            validateApprovalRequest(approvalRequest);

            ReleaseDetailsEntity releaseEntity = createReleaseDetailsUpdateEntity(id, json);

            ApprovalRequestEntity approvalRequestEntity = createApprovalRequest(releaseEntity, approvalRequest);
            approvalRequestRepository.save(approvalRequestEntity);

            log.info("File update approval request created successfully for ID: {}", id);

        } catch (ResourceNotFoundException e) {
            log.warn("Resource not found: {}", e.getMessage());
            throw e;
        } catch (IllegalArgumentException e) {
            log.warn("Invalid request: {}", e.getMessage());
            throw e;
        } catch (Exception e) {
            log.error("Error processing file update approval: {}", e.getMessage(), e);
            throw new RuntimeException("Error processing file update: " + e.getMessage(), e);
        }
    }

    /**
     * Validates that the entity exists before attempting an update.
     *
     * @param id         The ID of the entity
     * @param entityType The type of the entity
     * @throws ResourceNotFoundException if the entity doesn't exist
     */
    private void validateEntityExists(Integer id, String entityType) {
        if ("FILE_RELEASES".equals(entityType)) {
            log.debug("Validating that release with ID {} exists", id);
            // Add repository check here if needed
        }
    }

    /**
     * Creates a ReleaseDetailsEntity for updating an existing release.
     * Modified to not require a file.
     *
     * @param id   The ID of the release to update
     * @param json Additional JSON data
     * @return A ReleaseDetailsEntity
     */
    private ReleaseDetailsEntity createReleaseDetailsUpdateEntity(Integer id, String json) {
        String currentUsername = getCurrentUsername();
        LocalDateTime now = LocalDateTime.now();

        ReleaseDetailsEntity releaseEntity = ReleaseDetailsEntity.builder()
                .id(id.longValue())
                .uploadedBy(currentUsername)
                .uploadedDate(now)
                .build();

        if (StringUtils.hasText(json)) {
            try {
                PatchUploadRequest patchRequest = objectMapper.readValue(json, PatchUploadRequest.class);

                if (patchRequest.getVersion() != null) {
                    releaseEntity.setVersion(patchRequest.getVersion());
                }
                if (patchRequest.getDescription() != null) {
                    releaseEntity.setDescription(patchRequest.getDescription());
                }

                if (patchRequest.getBankIds() != null) {
                    log.info("Processing {} bankIds from PatchUploadRequest for update", patchRequest.getBankIds().size());
                    Set<ReleaseAccessEntity> accessEntities = new HashSet<>();
                    for (Long bankId : patchRequest.getBankIds()) {
                        accessEntities.add(ReleaseAccessEntity.builder()
                                .bankId(bankId)
                                .accessGrantedDate(LocalDateTime.now())
                                .accessRevoked(false)
                                .build());
                    }
                    releaseEntity.setReleaseAccessEntities(accessEntities);
                }
            } catch (JsonProcessingException e) {
                log.error("Failed to parse additional JSON for FILE_RELEASES update: {}", e.getMessage(), e);
            }
        }

        return releaseEntity;
    }
}