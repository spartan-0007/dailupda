package in.iftas.sfms.core.model;

import java.net.URI;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import in.iftas.sfms.core.model.Branch;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.springframework.format.annotation.DateTimeFormat;
import org.openapitools.jackson.nullable.JsonNullable;
import java.time.OffsetDateTime;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


import java.util.*;
import jakarta.annotation.Generated;

/**
 * Bank
 */


public class Bank {

  private Integer id;

  private String bankName;

  private String bankShortName;

  @Valid
  private List<@Valid Branch> branches;

  private Boolean isActive;

  private Boolean isHostedOnCloud;

  private String business;

  private String createdBy;

  @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
  private Date createdDate;

  private String lastModifiedBy;

  @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
  private Date lastModifiedDate;

  public Bank id(Integer id) {
    this.id = id;
    return this;
  }

  /**
   * Get id
   * @return id
   */
  
  @Schema(name = "id", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("id")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public Bank bankName(String bankName) {
    this.bankName = bankName;
    return this;
  }

  /**
   * Get bankName
   * @return bankName
   */
  
  @Schema(name = "bankName", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("bankName")
  public String getBankName() {
    return bankName;
  }

  public void setBankName(String bankName) {
    this.bankName = bankName;
  }

  public Bank bankShortName(String bankShortName) {
    this.bankShortName = bankShortName;
    return this;
  }

  /**
   * Get bankShortName
   * @return bankShortName
   */
  
  @Schema(name = "bankShortName", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("bankShortName")
  public String getBankShortName() {
    return bankShortName;
  }

  public void setBankShortName(String bankShortName) {
    this.bankShortName = bankShortName;
  }

  public Bank branches(List<@Valid Branch> branches) {
    this.branches = branches;
    return this;
  }

  public Bank addItem(Branch branchesItem) {
    if (this.branches == null) {
      this.branches = new ArrayList<>();
    }
    this.branches.add(branchesItem);
    return this;
  }

  /**
   * Get branches
   * @return branches
   */
  @Valid 
  @Schema(name = "branches", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("branches")
  public List<@Valid Branch> getBranches() {
    return branches;
  }

  public void setBranches(List<@Valid Branch> branches) {
    this.branches = branches;
  }

  public Bank isActive(Boolean isActive) {
    this.isActive = isActive;
    return this;
  }

  /**
   * Get isActive
   * @return isActive
   */
  
  @Schema(name = "isActive", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("isActive")
  public Boolean getIsActive() {
    return isActive;
  }

  public void setIsActive(Boolean isActive) {
    this.isActive = isActive;
  }

  public Bank isHostedOnCloud(Boolean isHostedOnCloud) {
    this.isHostedOnCloud = isHostedOnCloud;
    return this;
  }

  /**
   * Get isHostedOnCloud
   * @return isHostedOnCloud
   */
  
  @Schema(name = "isHostedOnCloud", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("isHostedOnCloud")
  public Boolean getIsHostedOnCloud() {
    return isHostedOnCloud;
  }

  public void setIsHostedOnCloud(Boolean isHostedOnCloud) {
    this.isHostedOnCloud = isHostedOnCloud;
  }

  public Bank business(String business) {
    this.business = business;
    return this;
  }

  /**
   * Get business
   * @return business
   */
  
  @Schema(name = "business", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("business")
  public String getBusiness() {
    return business;
  }

  public void setBusiness(String business) {
    this.business = business;
  }

  public Bank createdBy(String createdBy) {
    this.createdBy = createdBy;
    return this;
  }

  /**
   * Get createdBy
   * @return createdBy
   */
  
  @Schema(name = "createdBy", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("createdBy")
  public String getCreatedBy() {
    return createdBy;
  }

  public void setCreatedBy(String createdBy) {
    this.createdBy = createdBy;
  }

  public Bank createdDate(Date createdDate) {
    this.createdDate = createdDate;
    return this;
  }

  /**
   * Get createdDate
   * @return createdDate
   */
  @Valid 
  @Schema(name = "createdDate", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("createdDate")
  public Date getCreatedDate() {
    return createdDate;
  }

  public void setCreatedDate(Date createdDate) {
    this.createdDate = createdDate;
  }

  public Bank lastModifiedBy(String lastModifiedBy) {
    this.lastModifiedBy = lastModifiedBy;
    return this;
  }

  /**
   * Get lastModifiedBy
   * @return lastModifiedBy
   */
  
  @Schema(name = "lastModifiedBy", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("lastModifiedBy")
  public String getLastModifiedBy() {
    return lastModifiedBy;
  }

  public void setLastModifiedBy(String lastModifiedBy) {
    this.lastModifiedBy = lastModifiedBy;
  }

  public Bank lastModifiedDate(Date lastModifiedDate) {
    this.lastModifiedDate = lastModifiedDate;
    return this;
  }

  /**
   * Get lastModifiedDate
   * @return lastModifiedDate
   */
  @Valid 
  @Schema(name = "lastModifiedDate", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("lastModifiedDate")
  public Date getLastModifiedDate() {
    return lastModifiedDate;
  }

  public void setLastModifiedDate(Date lastModifiedDate) {
    this.lastModifiedDate = lastModifiedDate;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Bank bank = (Bank) o;
    return Objects.equals(this.id, bank.id) &&
        Objects.equals(this.bankName, bank.bankName) &&
        Objects.equals(this.bankShortName, bank.bankShortName) &&
        Objects.equals(this.branches, bank.branches) &&
        Objects.equals(this.isActive, bank.isActive) &&
        Objects.equals(this.isHostedOnCloud, bank.isHostedOnCloud) &&
        Objects.equals(this.business, bank.business) &&
        Objects.equals(this.createdBy, bank.createdBy) &&
        Objects.equals(this.createdDate, bank.createdDate) &&
        Objects.equals(this.lastModifiedBy, bank.lastModifiedBy) &&
        Objects.equals(this.lastModifiedDate, bank.lastModifiedDate);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, bankName, bankShortName, branches, isActive, isHostedOnCloud, business, createdBy, createdDate, lastModifiedBy, lastModifiedDate);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Bank {\n");
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    bankName: ").append(toIndentedString(bankName)).append("\n");
    sb.append("    bankShortName: ").append(toIndentedString(bankShortName)).append("\n");
    sb.append("    branches: ").append(toIndentedString(branches)).append("\n");
    sb.append("    isActive: ").append(toIndentedString(isActive)).append("\n");
    sb.append("    isHostedOnCloud: ").append(toIndentedString(isHostedOnCloud)).append("\n");
    sb.append("    business: ").append(toIndentedString(business)).append("\n");
    sb.append("    createdBy: ").append(toIndentedString(createdBy)).append("\n");
    sb.append("    createdDate: ").append(toIndentedString(createdDate)).append("\n");
    sb.append("    lastModifiedBy: ").append(toIndentedString(lastModifiedBy)).append("\n");
    sb.append("    lastModifiedDate: ").append(toIndentedString(lastModifiedDate)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

