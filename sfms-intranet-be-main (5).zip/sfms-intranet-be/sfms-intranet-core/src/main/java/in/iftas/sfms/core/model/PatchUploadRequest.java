package in.iftas.sfms.core.model;

import java.net.URI;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import java.util.ArrayList;
import java.util.List;
import org.openapitools.jackson.nullable.JsonNullable;
import java.time.OffsetDateTime;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


import java.util.*;
import jakarta.annotation.Generated;

/**
 * PatchUploadRequest
 */


public class PatchUploadRequest {

  private String fileName;

  private String version;

  private String description;

  @Valid
  private List<Long> bankIds;

  public PatchUploadRequest fileName(String fileName) {
    this.fileName = fileName;
    return this;
  }

  /**
   * Name of the patch file.
   * @return fileName
   */
  
  @Schema(name = "fileName", description = "Name of the patch file.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("fileName")
  public String getFileName() {
    return fileName;
  }

  public void setFileName(String fileName) {
    this.fileName = fileName;
  }

  public PatchUploadRequest version(String version) {
    this.version = version;
    return this;
  }

  /**
   * Version of the patch.
   * @return version
   */
  
  @Schema(name = "version", description = "Version of the patch.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("version")
  public String getVersion() {
    return version;
  }

  public void setVersion(String version) {
    this.version = version;
  }

  public PatchUploadRequest description(String description) {
    this.description = description;
    return this;
  }

  /**
   * Short description of the patch.
   * @return description
   */
  
  @Schema(name = "description", description = "Short description of the patch.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("description")
  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public PatchUploadRequest bankIds(List<Long> bankIds) {
    this.bankIds = bankIds;
    return this;
  }

  public PatchUploadRequest addItem(Long bankIdsItem) {
    if (this.bankIds == null) {
      this.bankIds = new ArrayList<>();
    }
    this.bankIds.add(bankIdsItem);
    return this;
  }

  /**
   * List of bank IDs that have access to this patch.
   * @return bankIds
   */
  
  @Schema(name = "bankIds", description = "List of bank IDs that have access to this patch.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("bankIds")
  public List<Long> getBankIds() {
    return bankIds;
  }

  public void setBankIds(List<Long> bankIds) {
    this.bankIds = bankIds;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    PatchUploadRequest patchUploadRequest = (PatchUploadRequest) o;
    return Objects.equals(this.fileName, patchUploadRequest.fileName) &&
        Objects.equals(this.version, patchUploadRequest.version) &&
        Objects.equals(this.description, patchUploadRequest.description) &&
        Objects.equals(this.bankIds, patchUploadRequest.bankIds);
  }

  @Override
  public int hashCode() {
    return Objects.hash(fileName, version, description, bankIds);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class PatchUploadRequest {\n");
    sb.append("    fileName: ").append(toIndentedString(fileName)).append("\n");
    sb.append("    version: ").append(toIndentedString(version)).append("\n");
    sb.append("    description: ").append(toIndentedString(description)).append("\n");
    sb.append("    bankIds: ").append(toIndentedString(bankIds)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

