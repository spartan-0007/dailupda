package in.iftas.sfms.reports.scheduler.service;

import in.iftas.sfms.reports.scheduler.job.JobInterface;
import in.iftas.sfms.reports.scheduler.model.JobExecutionHistory;
import in.iftas.sfms.reports.scheduler.model.JobSchedule;
import in.iftas.sfms.reports.scheduler.repository.JobExecutionHistoryRepository;
import in.iftas.sfms.reports.scheduler.repository.JobScheduleRepository;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.scheduling.TaskScheduler;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.scheduling.support.CronTrigger;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ScheduledFuture;

@Service
public class JobExecutionService {
    @Autowired
    private ApplicationContext applicationContext;

    @Autowired
    private JobScheduleRepository jobScheduleRepository;

    @Autowired
    private JobExecutionHistoryRepository jobExecutionHistoryRepository;

    @Autowired
    private TaskScheduler taskScheduler;

    private final Map<String, ScheduledFuture<?>> scheduledTasks = new HashMap<>();

    @PostConstruct
    public void init() {
        loadJobs();
    }

    public void loadJobs() {
        jobScheduleRepository.findAll().forEach(this::scheduleJob);
    }

    public void scheduleJob(JobSchedule jobSchedule) {
        JobInterface job = (JobInterface) applicationContext.getBean(jobSchedule.getJobName());
        ScheduledFuture<?> scheduledTask = taskScheduler.schedule(
            job::execute,
            new CronTrigger(jobSchedule.getCronExpression())
        );
        scheduledTasks.put(jobSchedule.getJobName(), scheduledTask);
    }

    public void updateJob(JobSchedule jobSchedule) {
        ScheduledFuture<?> scheduledTask = scheduledTasks.get(jobSchedule.getJobName());
        if (scheduledTask != null) {
            scheduledTask.cancel(false);
        }
        scheduleJob(jobSchedule);
    }

    public void executeJob(String jobName) {
        JobSchedule jobSchedule = jobScheduleRepository.findByJobName(jobName);
        if (jobSchedule != null) {
            JobInterface job = (JobInterface) applicationContext.getBean(jobSchedule.getJobName());
            long startTime = System.currentTimeMillis();
            job.execute();
            long executionTime = System.currentTimeMillis() - startTime;
            JobExecutionHistory history = new JobExecutionHistory();
            history.setJobName(jobName);
            history.setStatus("COMPLETED");
            history.setExecutionTime(executionTime);
            jobExecutionHistoryRepository.save(history);
        }
    }

    @Scheduled(fixedRate = 60000)
    public void checkForJobUpdates() {
        jobScheduleRepository.findAll().forEach(this::updateJob);
    }
}