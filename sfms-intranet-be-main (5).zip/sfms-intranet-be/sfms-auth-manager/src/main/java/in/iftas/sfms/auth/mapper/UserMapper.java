package in.iftas.sfms.auth.mapper;

import in.iftas.sfms.auth.model.UserInfoResponse;
import org.keycloak.representations.idm.UserRepresentation;
import org.mapstruct.Mapper;

import java.util.List;
import java.util.Set;

@Mapper(componentModel = "spring")
public interface UserMapper {

    UserInfoResponse toUserInfoResponse(UserRepresentation userRepresentation);

    // Converts a List<String> to a comma-separated String
    default String convertListToString(List<String> list) {
        return (list != null && !list.isEmpty()) ? String.join(",", list) : null;
    }

    // Converts a Set<String> to a comma-separated String
    default String convertSetToString(Set<String> set) {
        return (set != null && !set.isEmpty()) ? String.join(",", set) : null;
    }
}