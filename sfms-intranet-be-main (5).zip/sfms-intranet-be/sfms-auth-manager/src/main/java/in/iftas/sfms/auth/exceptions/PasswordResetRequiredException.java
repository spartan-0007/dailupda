package in.iftas.sfms.auth.exceptions;

public class PasswordResetRequiredException extends RuntimeException {
    public PasswordResetRequiredException(String message) {
        super(message);
    }
}