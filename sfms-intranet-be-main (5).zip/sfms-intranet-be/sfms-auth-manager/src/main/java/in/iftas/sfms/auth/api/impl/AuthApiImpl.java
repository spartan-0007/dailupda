package in.iftas.sfms.auth.api.impl;

import in.iftas.sfms.auth.api.AuthApi;
import in.iftas.sfms.auth.exceptions.MaxUserCountExceededException;
import in.iftas.sfms.auth.exceptions.PasswordResetException;
import in.iftas.sfms.auth.exceptions.UserAlreadyPresentException;
import in.iftas.sfms.auth.exceptions.UserNotFoundException;
import in.iftas.sfms.auth.model.*;
import in.iftas.sfms.auth.service.AuthService;
import in.iftas.sfms.auth.service.KeycloakTokenService;
import in.iftas.sfms.auth.service.OtpService;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.util.CollectionUtils;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import org.springframework.web.util.WebUtils;

import java.util.Collections;
import java.util.List;
import java.util.Objects;

import static org.springframework.web.context.request.RequestAttributes.SCOPE_REQUEST;

@RestController
public class AuthApiImpl implements AuthApi {

    private static final Logger logger = LoggerFactory.getLogger(AuthApiImpl.class);

    private final AuthService authService;

    private final OtpService otpService;

    @Value("${email.server-url}")
    private String emailServerUrl;

    @Value("${keycloak.username}")
    private String appUsername;

    @Value("${keycloak.password}")
    private String appPassword;

    private final KeycloakTokenService keycloakTokenService;

    @Autowired
    public AuthApiImpl(AuthService authService, OtpService otpService, KeycloakTokenService keycloakTokenService) {
        this.authService = authService;
        this.otpService = otpService;
        this.keycloakTokenService = keycloakTokenService;
    }


    @Override
    public ResponseEntity<TokenResponse> authLoginPost(String username, String password) {
        MDC.put("username", username);
        logger.info("Starting authLoginPost method for user: {}", username);
        try {
            ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
            TokenResponse tokenResponse = (TokenResponse) Objects.requireNonNull(attributes).getAttribute("tokenResponse", SCOPE_REQUEST);
            if (tokenResponse != null) {
                logger.info("User token generated successfully");
                return ResponseEntity.ok(tokenResponse);
            } else {
                logger.error("Error occurred while generating token for user : {}", username);
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
            }
        } catch (Exception e) {
            logger.error("Error occurred while generating token for user : {}", username, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        } finally {
            logger.info("Ending authLoginPost method");
            MDC.clear();
        }
    }

    @Override
    public ResponseEntity<UserInfoResponse> authUserinfoGet() {
        logger.info("Starting authUserinfoGet method");
        try {
            String accessToken = extractTokenFromHeaders();
            logger.info("Access token extracted successfully");
            UserInfoResponse userInfoResponse = authService.getUserInfo(accessToken);
            logger.info("User info retrieved successfully");
            return new ResponseEntity<>(userInfoResponse, HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error occurred while retrieving user info", e);
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    @Override
    public ResponseEntity<ModelApiResponse> authUsersGet(String username, String id, String search, Integer page, Integer size, String sort) {
        logger.info("Starting authUsersGet with page: {}, size: {}", page, size);
        String accessToken = extractTokenFromHeaders();
        List<UserResponse> users;

        try {
            if (Objects.isNull(search)) {
                if (username != null && !username.isEmpty()) {
                    logger.info("Fetching user by username: {}", username);
                    users = authService.getUsersByUsername(accessToken, username);
                } else if (id != null && !id.isEmpty()) {
                    logger.info("Fetching user by ID: {}", id);
                    users = authService.getUsersById(accessToken, id);
                } else {
                    logger.info("Fetching all users");
                    users = authService.getAllUsers(accessToken, page, size, sort);
                }
            } else {
                logger.info("Searching users with search term: {}", search);
                users = authService.searchUsers(accessToken, search, page, size, sort);
            }

            ModelApiResponse response = new ModelApiResponse();
            if (users != null && !users.isEmpty()) {
                logger.info("Users retrieved successfully");
                response.setSuccess(true);
                response.setMessage("Users retrieved successfully");
                response.setData(Collections.singletonMap("data", users));
                return ResponseEntity.ok(response);
            } else {
                logger.info("No users found");
                response.setSuccess(true);
                response.setMessage("No users found");
                response.setData(Collections.singletonMap("data", Collections.emptyList()));
                return ResponseEntity.status(HttpStatus.NO_CONTENT).body(response);
            }
        } catch (WebClientResponseException.Forbidden e) {
            logger.error("Access Denied: {}", e.getMessage());
            ModelApiResponse response = new ModelApiResponse();
            response.setSuccess(false);
            response.setMessage("Access Denied");
            ApiResponseError error = new ApiResponseError();
            error.setCode("403");
            error.setMessage("Access Denied: User doesn't have access to get users");
            response.setError(error);
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(response);
        } catch (Exception e) {
            logger.error("Exception in authUsersGet: {}", e.getMessage());
            ModelApiResponse response = new ModelApiResponse();
            response.setSuccess(false);
            response.setMessage("Internal Server Error");
            ApiResponseError error = new ApiResponseError();
            error.setCode("500");
            error.setMessage("Internal Server Error: " + e.getMessage());
            response.setError(error);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    @Override
    public ResponseEntity<String> authForgetPasswordPost(@Valid @RequestBody ForgotPasswordRequest forgotPasswordRequest) {
        logger.info("Starting authForgetPasswordPost method for email: {}", forgotPasswordRequest.getEmail());
        try {
            String otp = authService.handleForgotPassword(forgotPasswordRequest.getEmail());
            logger.info("Generated OTP: {}", otp);

            String jsonContent = String.format("{\"toEmail\":\"%s\",\"otp\":\"%s\",\"template\":\"EmailOTP.html\"}",
                    forgotPasswordRequest.getEmail(), otp);

            MultiValueMap<String, String> formData = new LinkedMultiValueMap<>();
            formData.add("content", jsonContent);

            WebClient webClient = WebClient.builder().baseUrl(emailServerUrl).build();
            logger.info("WebClient built successfully");

            ModelApiResponse response = webClient.post()
                    .uri("/email")
                    .header(HttpHeaders.AUTHORIZATION, "Bearer " + keycloakTokenService.getAdminToken())
                    .contentType(MediaType.MULTIPART_FORM_DATA)
                    .cookie("refreshToken", keycloakTokenService.getAdminRefreshToken())
                    .bodyValue(formData)
                    .retrieve()
                    .bodyToMono(ModelApiResponse.class)
                    .block();

            if (response.getSuccess()) {
                logger.info("Email sent successfully");
            } else {
                logger.info("Email failed to sent");
            }
            logger.info("OTP sent successfully to email: {}", forgotPasswordRequest.getEmail());
            return ResponseEntity.ok("OTP has been sent to your email " + otp);
        } catch (UserNotFoundException e) {
            logger.error("UserNotFoundException for email: {}", forgotPasswordRequest.getEmail(), e);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User not found: " + e.getMessage());
        } catch (RuntimeException e) {
            logger.error("RuntimeException for email: {}", forgotPasswordRequest.getEmail(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("An unexpected error occurred: " + e.getMessage());
        } catch (Exception e) {
            logger.error("Exception for email: {}", forgotPasswordRequest.getEmail(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error processing the request: " + e.getMessage());
        }
    }

    @Override
    public ResponseEntity<String> authResendOtpPost(@Valid @RequestBody ResendOtpRequest resendOtpRequest) {
        logger.info("Starting authResendOtpPost method for username: {}", resendOtpRequest.getEmail());
        try {
            String otp = authService.handleResendOtp(resendOtpRequest.getEmail());
            return ResponseEntity.ok("OTP has been sent to your email " + otp);
        } catch (UserNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Error processing the request: " + e.getMessage());
        } catch (Exception e) {
            logger.error("Exception for username: {}", resendOtpRequest.getEmail(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error processing the request: " + e.getMessage());
        }

    }

    @Override
    public ResponseEntity<String> authValidateOtpPost(OtpRequest otpRequest) {
        logger.info("Starting authValidateOtpPost method for username: {}", otpRequest.getEmail());
        try {
            var userResponses = authService.getUserResponseByEmail(otpRequest.getEmail());
            boolean isValidOtp = otpService.validateOtp(userResponses.get(0).getUsername(), otpRequest.getOtp());

            if (isValidOtp) {
                logger.info("OTP is valid for username: {}", otpRequest.getEmail());
                return ResponseEntity.ok("OTP is valid. You can now reset your password.");
            } else {
                logger.warn("Invalid OTP for username: {}", otpRequest.getEmail());
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid OTP.");
            }
        } catch (Exception e) {
            logger.error("Error occurred while validating OTP for username: {}", otpRequest.getEmail(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
        }
    }

    @Override
    public ResponseEntity<String> authChangePasswordPost(ChangePasswordRequest changePasswordRequest) {
        logger.info("Starting authChangePasswordPost method");
        Jwt jwt = (Jwt) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        String username = jwt.getClaimAsString("name");
        try {
            authService.changePasswordForUser(changePasswordRequest, jwt.getClaimAsString("sub"));
            logger.info("Password changed successfully for username: {}", username);
            return ResponseEntity.ok("Password changed successfully.");
        } catch (Exception e) {
            logger.error("Error processing the request for username: {}", username, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error processing the request: " + e.getMessage());
        }
    }

    @Override
    public ResponseEntity<String> authChangePasswordChangePost(ChangePasswordRequest changePasswordRequest) {
        logger.info("Starting authChangePasswordChangePost method");

        try {
            authService.handleChangePasswordFromForgotPassword(changePasswordRequest, changePasswordRequest.getEmail());
            logger.info("Password changed successfully for username: {}", changePasswordRequest.getEmail());
            return ResponseEntity.ok("Password changed successfully.");
        } catch (UserNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Error processing the request: " + e.getMessage());
        } catch (Exception e) {
            logger.error("Error processing the request for username: {}", changePasswordRequest.getEmail(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error processing the request: " + e.getMessage());
        }
    }

    @Override
    public ResponseEntity<Void> authUsersIdDelete(@PathVariable("id") String id) {
        logger.info("Starting authUsersIdDelete method for user ID: {}", id);

        String accessToken = extractTokenFromHeaders();
        boolean isDeleted = authService.deleteUser(id, accessToken);
        if (isDeleted) {
            logger.info("User with ID: {} deleted successfully", id);
            return ResponseEntity.noContent().build();
        } else {
            logger.warn("User with ID: {} not found", id);
            return ResponseEntity.notFound().build();
        }
    }

    @Override
    public ResponseEntity<ModelApiResponse> authUsersPost(UserCreateRequest userCreateRequest) {
        logger.info("Starting authUsersPost method for user: {}", userCreateRequest.getUsername());
        ModelApiResponse response = new ModelApiResponse();
        try {
            String accessToken = extractTokenFromHeaders();
            authService.createUser(accessToken, userCreateRequest);
            logger.info("User created successfully: {}", userCreateRequest.getUsername());
            response.setSuccess(true);
            response.setMessage("User Added Successfully");
            return new ResponseEntity<>(HttpStatus.CREATED);
        } catch (WebClientResponseException ex) {
            logger.error("WebClientResponseException occurred while creating user: {}", userCreateRequest.getUsername(), ex);
            ApiResponseError error = new ApiResponseError();
            error.setCode(HttpStatus.INTERNAL_SERVER_ERROR.toString());
            error.setMessage("Failed to Add User");
            response.setError(error);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        } catch (UserAlreadyPresentException ex) {
            logger.error("User Already Prsent Exception: {}", userCreateRequest.getUsername(), ex);
            ApiResponseError error = new ApiResponseError();
            error.setCode(HttpStatus.CONFLICT.toString());
            error.setMessage("User is already present in system");
            response.setError(error);
            return ResponseEntity.status(HttpStatus.CONFLICT).body(response);
        } catch (MaxUserCountExceededException ex) {
            logger.error("Max User Count Limit Exceeded Exception: {}", userCreateRequest.getUsername(), ex);
            ApiResponseError error = new ApiResponseError();
            error.setCode(HttpStatus.CONFLICT.toString());
            error.setMessage("Max User Creation count Exceeded. Please contact support team.");
            response.setError(error);
            return ResponseEntity.status(HttpStatus.CONFLICT).body(response);
        } catch (Exception ex) {
            logger.error("Error occurred while creating user: {}", userCreateRequest.getUsername(), ex);
            ApiResponseError error = new ApiResponseError();
            error.setCode(HttpStatus.INTERNAL_SERVER_ERROR.toString());
            error.setMessage("Failed to Add User");
            response.setError(error);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    @Override
    public ResponseEntity<List<UserRoleResponse>> authRolesGet(String userType) {
        logger.info("Starting authRolesGet method");
        try {
            List<UserRoleResponse> userRoleResponses = authService.getRealmRoles(userType);
            if (userRoleResponses != null && !userRoleResponses.isEmpty()) {
                logger.info("User roles retrieved successfully");
                return ResponseEntity.ok(userRoleResponses);
            } else {
                logger.info("No user roles found");
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }
        } catch (Exception e) {
            logger.error("Error occurred while retrieving user roles", e);
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    @Override
    public ResponseEntity<List<UserRoleResponse>> authUsersIdRolesGet(String id, String userType) {
        logger.info("Starting authUsersIdRolesGet method for user ID: {}, userType: {}", id, userType);
        try {
            logger.debug("Calling getUserRoles with ID: {} and userType: {}", id, userType);
            List<UserRoleResponse> roles = authService.getUserRoles(id, userType);
            if (CollectionUtils.isEmpty(roles)) {
                logger.info("No roles found for user ID: {}", id);
                return ResponseEntity.ok(Collections.emptyList());
            } else {
                logger.info("Roles retrieved successfully for user ID: {}", id);
                return ResponseEntity.ok(roles);
            }
        } catch (WebClientResponseException.NotFound e) {
            logger.warn("User ID not found: {}", id);
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            logger.error("Error occurred while retrieving roles for user ID: {}", id, e);
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    public ResponseEntity<Void> authUsersIdRolesPost(String id, List<UserRoleResponse> roles) {
        logger.info("Starting authUsersIdRolesPost method for user ID: {}", id);
        try {
            if (roles != null && !roles.isEmpty()) {
                logger.info("Assigning roles to user ID: {}", id);
                authService.assignRolesToUser(id, roles);
            }
            logger.info("Roles assigned successfully to user ID: {}", id);
            return new ResponseEntity<>(HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error occurred while assigning roles to user ID: {}", id, e);
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    public ResponseEntity<Void> authUsersIdPut(String id, UserUpdateRequest userUpdateRequest) {
        logger.info("Starting authUsersIdPut method for username: {}", userUpdateRequest.getUsername());
        try {
            authService.updateUser(id, userUpdateRequest);
            logger.info("User with ID: {} updated successfully", id);
            return ResponseEntity.status(HttpStatusCode.valueOf(204)).build();
        } catch (Exception e) {
            logger.error("Failed to update user with username: {}", userUpdateRequest.getUsername(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @Override
    public ResponseEntity<String> authAdminUserPut(UserUpdateRequest userUpdateRequest) {
        logger.info("Starting authAdminUserPut method for user: {}", userUpdateRequest);
        authService.updateUserByAdmin(userUpdateRequest);
        logger.info("User updated successfully by admin: {}", userUpdateRequest);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @Override
    public ResponseEntity<UserResponse> authUsersIdGet(String id) {
        logger.info("Starting authUsersIdGet method for user ID: {}", id);
        try {
            String accessToken = extractTokenFromHeaders();
            UserResponse userResponse = authService.getUserById(accessToken, id);
            if (userResponse != null) {
                logger.info("User retrieved successfully for user ID: {}", id);
                return ResponseEntity.ok(userResponse);
            } else {
                logger.warn("User not found for user ID: {}", id);
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
            }
        } catch (Exception e) {
            logger.error("Error occurred while retrieving user for user ID: {}", id, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }

    }

    @Override
    public ResponseEntity<TokenResponse> authRefreshTokenPost(String refreshToken, String grantType) {
        MDC.put("refreshToken", refreshToken);
        logger.info("Starting authRefreshTokenPost");
        try {
            TokenResponse authTokenResponse = authService.refreshAccessToken(refreshToken);
            if (authTokenResponse != null) {
                logger.info("Token refreshed successfully");
                return ResponseEntity.ok(authTokenResponse);
            } else {
                logger.error("Error occurred while refreshing token with refresh token: {}", refreshToken);
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
            }
        } catch (Exception e) {
            logger.error("Error occurred while refreshing token with refresh token: {}", refreshToken, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        } finally {
            logger.info("Ending authRefreshTokenPost method");
            MDC.clear();
        }
    }

    @Override
    public ResponseEntity<ModelApiResponse> authLogoutUser() {
        logger.info("Received request to logout User ");
        ModelApiResponse response = new ModelApiResponse();

        try {
            boolean isDeleted = authService.logoutUser();
            if (isDeleted) {
                logger.info("Successfully logged out user");
                response.setSuccess(true);
                response.setMessage("Successfully logged out");
                return ResponseEntity.ok(response);
            } else {
                logger.error("Failed to log out user");
                response.setSuccess(false);
                response.setMessage("Internal Server Error");
                ApiResponseError error = new ApiResponseError();
                error.setCode("500");
                error.setMessage("Internal Server Error");
                response.setError(error);
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                        .body(response);
            }
        } catch (UserNotFoundException e) {
            logger.error("Exception in authLogoutDelete: {}", e.getMessage(), e);
            response.setSuccess(false);
            response.setMessage("User Not Found ");
            ApiResponseError error = new ApiResponseError();
            error.setCode("404");
            error.setMessage(e.getMessage());
            response.setError(error);
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(response);
        } catch (Exception e) {
            logger.error("Exception in authLogoutDelete: {}", e.getMessage(), e);
            response.setSuccess(false);
            response.setMessage("Internal Server Error");
            ApiResponseError error = new ApiResponseError();
            error.setCode("500");
            error.setMessage("Internal Server Error: " + e.getMessage());
            response.setError(error);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(response);
        }
    }


    private String extractTokenFromHeaders() {
        logger.info("Starting extractTokenFromHeaders method");
        HttpServletRequest request = ((ServletRequestAttributes) Objects.requireNonNull(RequestContextHolder.getRequestAttributes())).getRequest();
        String authHeader = request.getHeader("Authorization");
        if (authHeader != null && authHeader.startsWith("Bearer ")) {
            logger.info("Token extracted successfully");
            return authHeader.substring(7);
        }
        logger.warn("Authorization header is missing or does not start with 'Bearer '");
        return null;
    }

    public ResponseEntity<ModelApiResponse> authResetPasswordPost(ResetPasswordRequest resetPasswordRequest) {
        logger.info("Starting authResetPasswordPost method");
        ModelApiResponse response = new ModelApiResponse();
        try {
            authService.resetPasswordForUser(resetPasswordRequest);
            logger.info("Password reset successfully for user: {}", resetPasswordRequest.getUsername());
            response.setSuccess(true);
            response.setMessage("Password reset successfully");
            return ResponseEntity.ok(response);

        } catch (PasswordResetException e) {
            logger.error("PasswordResetException in authResetPasswordPost: {}", e.getMessage(), e);
            response.setSuccess(false);
            response.setMessage("Password reset failed");
            ApiResponseError error = new ApiResponseError();
            error.setCode("500");
            error.setMessage("Password reset failed: " + e.getMessage());
            response.setError(error);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);

        } catch (Exception e) {
            logger.error("Exception in authResetPasswordPost: {}", e.getMessage(), e);
            response.setSuccess(false);
            response.setMessage("Internal Server Error");
            ApiResponseError error = new ApiResponseError();
            error.setCode("500");
            error.setMessage("Internal Server Error: " + e.getMessage());
            response.setError(error);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

}