package in.iftas.sfms.auth.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import in.iftas.sfms.auth.entity.UserQuotaEntity;
import in.iftas.sfms.auth.exceptions.*;
import in.iftas.sfms.auth.mapper.UserCreateRequestMapper;
import in.iftas.sfms.auth.mapper.UserResponseMapper;
import in.iftas.sfms.auth.model.*;
import in.iftas.sfms.auth.repository.UserQuotaRepository;
import io.jsonwebtoken.JwtException;
import jakarta.transaction.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.MediaType;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Mono;

import java.time.Duration;
import java.time.Instant;
import java.time.format.DateTimeParseException;
import java.time.temporal.ChronoUnit;
import java.util.*;

@Service
public class AuthService {

    private static final Logger logger = LoggerFactory.getLogger(AuthService.class);

    private final WebClient webClient;

    @Value("${keycloak.auth-server-url}")
    private String authServerUrl;

    @Value("${keycloak.realm}")
    private String realm;

    @Value("${keycloak.resource}")
    private String clientId;

    @Value("${keycloak.credentials.secret}")
    private String clientSecret;

    @Value("${keycloak.username}")
    private String appUsername;

    private final JwtDecoder jwtDecoder;

    private final OtpService otpService;

    private final UserResponseMapper userResponseMapper;

    private final ObjectMapper objectMapper;

    private final UserCreateRequestMapper userCreateRequestMapper;

    private final UserQuotaRepository userQuotaRepository;

    private final KeycloakTokenService keycloakTokenService;

    @Autowired
    public AuthService(WebClient webClient, JwtDecoder jwtDecoder, OtpService otpService, UserResponseMapper userResponseMapper,
                       ObjectMapper objectMapper, UserCreateRequestMapper userCreateRequestMapper, UserQuotaRepository userQuotaRepository,
                       KeycloakTokenService keycloakTokenService) {
        this.webClient = webClient;
        this.jwtDecoder = jwtDecoder;
        this.otpService = otpService;
        this.userResponseMapper = userResponseMapper;
        this.objectMapper = objectMapper;
        this.userCreateRequestMapper = userCreateRequestMapper;
        this.userQuotaRepository = userQuotaRepository;
        this.keycloakTokenService = keycloakTokenService;
    }

//    public TokenResponse authenticateUser(String username, String password) {
//        String tokenEndpoint = authServerUrl + "realms/" + realm + "/protocol/openid-connect/token";
//        logger.info("Starting authenticateUser method for user: {}", username);
//
//        MultiValueMap<String, String> formData = new LinkedMultiValueMap<>();
//        formData.add("client_id", clientId);
//        formData.add("client_secret", clientSecret);
//        formData.add("grant_type", "password");
//        formData.add("username", username);
//        formData.add("password", password);
//
//        return webClient.post()
//                .uri(tokenEndpoint)
//                .contentType(MediaType.APPLICATION_FORM_URLENCODED)
//                .body(BodyInserters.fromFormData(formData))
//                .retrieve()
//                .onStatus(HttpStatusCode::is4xxClientError, response -> {
//                    if (response.statusCode() == HttpStatus.NOT_FOUND) {
//                        logger.error("User not found for username: {}", username);
//                        return Mono.error(new RuntimeException("User not found"));
//                    }
//                    logger.error("Client error for username: {}, Status Code: {}", username, response.statusCode());
//                    return Mono.error(new RuntimeException("Client error: " + response.statusCode()));
//                })
//                .bodyToMono(TokenResponse.class)
//                .block();
//    }

    public UserInfoResponse getUserInfo(String authorization) {
        logger.info("Starting getUserInfo method with authorization header");
        try {
            String token = getAccessToken(authorization);
            var jwt = jwtDecoder.decode(token);
            logger.info("Access token retrieved successfully");
            return mapClaimsToUserInfoResponse(jwt.getClaims());
        } catch (JwtException e) {
            logger.error("Invalid token: {}", e.getMessage());
            throw new RuntimeException("Invalid token");
        }
    }

    public String getAccessToken(String authorization) {
        logger.info("Starting getAccessToken method");
        return authorization.replace("Bearer ", "");
    }

    private UserInfoResponse mapClaimsToUserInfoResponse(Map<String, Object> claims) {
        UserInfoResponse userInfoResponse = new UserInfoResponse();
        userInfoResponse.setSub((String) claims.get("sub"));
        userInfoResponse.setName((String) claims.get("name"));
        userInfoResponse.setPreferredUsername((String) claims.get("preferred_username"));
        userInfoResponse.setGivenName((String) claims.get("given_name"));
        userInfoResponse.setFamilyName((String) claims.get("family_name"));
        userInfoResponse.setEmail((String) claims.get("email"));
        userInfoResponse.setEmailVerified(claims.get("email_verified") != null
                ? (Boolean) claims.get("email_verified") : false);


        if (claims.get("realm_access") != null) {
            Map<String, Object> realmAccess = (Map<String, Object>) claims.get("realm_access");
            userInfoResponse.setRealmRoles((List<String>) realmAccess.get("roles"));
        }

        if (claims.get("resource_access") != null) {
            Map<String, Map<String, Object>> resourceAccess = (Map<String, Map<String, Object>>) claims.get("resource_access");
            Map<String, List<String>> clientRolesMap = new HashMap<>();

            for (Map.Entry<String, Map<String, Object>> entry : resourceAccess.entrySet()) {
                String clientId = entry.getKey();
                Map<String, Object> clientDetails = entry.getValue();
                if (clientDetails != null && clientDetails.get("roles") instanceof List) {
                    List<String> roles = (List<String>) clientDetails.get("roles");
                    clientRolesMap.put(clientId, roles);
                }
            }
            userInfoResponse.setClientRoles(clientRolesMap);
        }
        userInfoResponse.setScope((String) claims.get("scope"));
        userInfoResponse.setExp(parseDateStringToEpoch(claims.get("exp")));
        userInfoResponse.setIat(parseDateStringToEpoch(claims.get("iat")));
        Object audClaim = claims.get("aud");
        if (audClaim instanceof String) {
            userInfoResponse.setAud((String) audClaim);
        } else if (audClaim instanceof List) {
            List<String> audList = (List<String>) audClaim;

            userInfoResponse.setAud(String.join(",", audList));
        }
        userInfoResponse.setJti((String) claims.get("jti"));
        userInfoResponse.setIss((String) claims.get("iss"));
        userInfoResponse.setTyp((String) claims.get("typ"));
        userInfoResponse.setAzp((String) claims.get("azp"));
        userInfoResponse.setSid((String) claims.get("sid"));
        userInfoResponse.setAcr((String) claims.get("acr"));
        String bankIdStr = (String) claims.get("bankId");
        Integer bankId = bankIdStr != null ? Integer.valueOf(bankIdStr) : null;
        userInfoResponse.setBankId(bankId);
        userInfoResponse.setUserType((String) claims.get("userType"));
        return userInfoResponse;
    }


    public boolean isTokenExpired(String accessToken) {
        logger.info("Starting isTokenExpired method");
        try {
            Jwt jwt = jwtDecoder.decode(accessToken);
            logger.info("JWT decoded successfully");
            Instant expiration = jwt.getExpiresAt();
            if (expiration == null) {
                logger.warn("Expiration is null. Considering token expired.");
                return true;
            }
            Instant now = Instant.now();
            Instant expirationWithBuffer = expiration.minusSeconds(30);
            logger.info("Token Expiration Time: {}", expiration);
            logger.info("Current Time: {}", now);
            logger.info("Time until expiration with buffer (seconds): {}", ChronoUnit.SECONDS.between(now, expirationWithBuffer));
            logger.info("Is token expired (with buffer)? ");
            return expirationWithBuffer.isBefore(now);
        } catch (Exception e) {
            logger.error("Exception occurred while decoding token: {}", e.getMessage());
            return true;
        }
    }


    private Long parseDateStringToEpoch(Object dateStr) {
        logger.info("Entering parseDateStringToEpoch method with parameter: " + dateStr);
        if (dateStr instanceof String) {
            try {
                Instant instant = Instant.parse((String) dateStr);
                return instant.getEpochSecond();
            } catch (DateTimeParseException e) {

            }
        }
        logger.info("Exiting parseDateStringToEpoch method with null return value");
        return null;
    }


    private String getAllowedOrigins(List<String> strings) {
        return String.join(",", strings);
    }

    public boolean isRefreshTokenExpired(String refreshToken) {
        logger.info("Checking refresh token expiry");
        String refreshTokenEndpoint = authServerUrl + "/realms/" + realm + "/protocol/openid-connect/token/introspect";

        TokenIntrospectionResponse tokenIntrospectionResponse = webClient.post()
                .uri(refreshTokenEndpoint)
                .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                .bodyValue("client_id=" + clientId +
                        "&client_secret=" + clientSecret +
                        "&token=" + refreshToken)
                .retrieve()
                .bodyToMono(TokenIntrospectionResponse.class)
                .block();

        logger.info("Token active status in isRefreshTokenExpired");

        return Objects.requireNonNull(tokenIntrospectionResponse).getActive();
    }

    public TokenResponse refreshAccessToken(String refreshToken) {
        logger.info("Entering refreshAccessToken");

        // To-Do Need to implement Token Expiration Specific Exception
        if (!isRefreshTokenExpired(refreshToken)) {
            logger.error("Refresh token is expired");
            throw new RuntimeException("Refresh token is expired");
        }

        String refreshTokenIntrospect = authServerUrl + "realms/" + realm + "/protocol/openid-connect/token";

        return webClient.post()
                .uri(refreshTokenIntrospect)
                .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                .bodyValue("client_id=" + clientId +
                        "&client_secret=" + clientSecret +
                        "&grant_type=refresh_token" +
                        "&refresh_token=" + refreshToken)
                .retrieve()
                .onStatus(HttpStatusCode::is4xxClientError, response -> {
                    if (response.statusCode() == HttpStatus.NOT_FOUND) {

                        return Mono.error(new RuntimeException("User not found"));
                    }
                    logger.error("Client error for Status Code: {}", response.statusCode());
                    return Mono.error(new RuntimeException("Client error: " + response.statusCode()));
                })
                .bodyToMono(TokenResponse.class)
                .block();
    }

    public List<UserResponse> getAllUsers(String accessToken, Integer page, Integer size, String sort) {
        logger.info("Entering getAllUsers - page: {}, size: {}", page, size);

        String userRole;
        String bankId;

        try {
            Jwt jwt = jwtDecoder.decode(accessToken);
            userRole = jwt.getClaimAsString("userType");
            bankId = jwt.getClaimAsString("bankId");
        } catch (Exception e) {
            logger.error("Error decoding the JWT token: {}", e.getMessage());
            return List.of();
        }

        String getUsersUrl = authServerUrl + "admin/realms/master/users";

        try {
            List<Object> userObjectResponses = webClient.get()
                    .uri(getUsersUrl)
                    .headers(headers -> {
                        headers.set(HttpHeaders.AUTHORIZATION, "Bearer " + accessToken);
                        headers.setAccept(List.of(MediaType.APPLICATION_JSON));
                    })
                    .retrieve()
                    .bodyToFlux(Object.class)
                    .collectList()
                    .block();

            if (userObjectResponses == null || userObjectResponses.isEmpty()) {
                logger.warn("No users found or response is null");
                return List.of();
            }

            logger.info("Returning user responses from getAllUsers");

            final String finalUserRole = userRole;
            final String finalBankId = bankId;

            return userObjectResponses.stream()
                    .map(userObject -> {
                        Map<String, Object> userMap = objectMapper.convertValue(userObject, Map.class);
                        return userResponseMapper.mapToUserResponse(userMap);
                    })
                    .filter(userResponse -> {
                        boolean isNotAdmin = !appUsername.equals(userResponse.getUsername());

                        if ("BANKER".equals(finalUserRole)) {
                            Integer userBankId = userResponse.getAttributes() != null ? userResponse.getAttributes().getBankId() : null;
                            return finalBankId != null && finalBankId.equals(String.valueOf(userBankId)) && isNotAdmin;
                        } else if ("OPERATOR".equals(finalUserRole)) {
                            return isNotAdmin;
                        }

                        return isNotAdmin;
                    })
                    .toList();

        } catch (WebClientResponseException.Forbidden e) {
            logger.error("Access Denied: {}", e.getMessage());
            throw new AccessDeniedException("Access Denied: User doesn't have access to get users");
        } catch (Exception e) {
            logger.error("Exception in getAllUsers: {}", e.getMessage());
            return List.of();
        }
    }

    public boolean deleteUser(String userId, String accessToken) {
        logger.info("Entering deleteUser method with parameters: userId: {}, accessToken: {}", userId, accessToken);
        String deleteUserUrl = authServerUrl + "admin/realms/master/users/" + userId;
        try {
            webClient.delete()
                    .uri(deleteUserUrl)
                    .headers(headers -> {
                        headers.set("Authorization", "Bearer " + accessToken);
                        headers.setAccept(List.of(MediaType.APPLICATION_JSON));
                    })
                    .retrieve()
                    .onStatus(HttpStatusCode::is4xxClientError, response -> {
                        if (response.statusCode() == HttpStatus.NOT_FOUND) {
                            return Mono.error(new RuntimeException("User not found"));
                        }
                        return Mono.error(new RuntimeException("Client error: " + response.statusCode()));
                    })
                    .onStatus(HttpStatusCode::is5xxServerError, response -> {
                        return Mono.error(new RuntimeException("Server error: " + response.statusCode()));
                    })
                    .bodyToMono(Void.class)
                    .block();
            logger.info("User successfully deleted: {}", userId);
            return true;
        } catch (Exception e) {
            logger.error("Exception in deleteUser: {}", e.getMessage());
            return false;
        }
    }

    public List<UserResponse> getUsersByUsername(String authorization, String username) {
        logger.info("Entering getUsersByUsername method with parameters: authorization: {},username : {}", authorization, username);
        String getUserInfoUrl = authServerUrl + "admin/realms/master/users?username={username}&exact=true";

        try {
            String finalAuthorization = authorization.startsWith("Bearer ") ? authorization : "Bearer " + authorization;

            List<Object> userObjectResponses = webClient.get()
                    .uri(getUserInfoUrl, username)
                    .headers(headers -> {
                        headers.set(HttpHeaders.AUTHORIZATION, finalAuthorization);
                        headers.setAccept(List.of(MediaType.APPLICATION_JSON));
                    })
                    .retrieve()
                    .bodyToFlux(Object.class)
                    .collectList()
                    .block();

            if (userObjectResponses == null || userObjectResponses.isEmpty()) {
                logger.warn("No users found or response is null");
                return List.of();
            }
            logger.info("Returning user responses from getUsersByUsername");
            return getUserResponseList(userObjectResponses);

        } catch (Exception e) {

            logger.error("Exception in getUsersByUsername:{} ", e.getMessage());
            return List.of();
        }
    }

    private List<UserResponse> getUserResponseList(List<Object> userObjectResponses) {
        return userObjectResponses.stream()
                .map(userObject -> {
                    Map userMap = objectMapper.convertValue(userObject, Map.class);
                    return userResponseMapper.mapToUserResponse(userMap);
                })
                .toList();
    }

    public List<UserResponse> getUsersById(String authorization, String id) {
        logger.info("Entering getUsersById method with parameters: authorization: {},id: {} ", authorization, id);

        String getUserInfoUrl = authServerUrl + "admin/realms/master/users/" + id;

        try {
            String finalAuthorization = authorization.startsWith("Bearer ") ? authorization : "Bearer " + authorization;

            List<Object> userObjectResponses = webClient.get()
                    .uri(getUserInfoUrl)
                    .headers(headers -> {
                        headers.set(HttpHeaders.AUTHORIZATION, finalAuthorization);
                        headers.setAccept(List.of(MediaType.APPLICATION_JSON));
                    })
                    .retrieve()
                    .bodyToFlux(Object.class)
                    .collectList()
                    .block();

            if (userObjectResponses == null || userObjectResponses.isEmpty()) {
                logger.warn("No users found or response is null");
                return List.of();
            }
            logger.info("Returning user responses from getUsersById");
            return getUserResponseList(userObjectResponses);

        } catch (Exception e) {
            logger.error("Exception in getUsersById: " + e.getMessage());
            return List.of();
        }
    }

    public List<UserResponse> getUsersByEmail(String authorization, String email) {
        logger.info("Entering getUsersByEmail method with parameters: email : {}", email);

        final String GET_USER_INFO_URL = authServerUrl + "admin/realms/master/users?email=" + email + "&exact=true";

        try {
            String finalAuthorization = authorization.startsWith("Bearer ") ? authorization : "Bearer " + authorization;

            List<Object> userObjectResponses = webClient.get()
                    .uri(GET_USER_INFO_URL)
                    .headers(headers -> {
                        headers.set(HttpHeaders.AUTHORIZATION, finalAuthorization);
                        headers.setAccept(List.of(MediaType.APPLICATION_JSON));
                    })
                    .retrieve()
                    .bodyToFlux(Object.class)
                    .collectList()
                    .block();

            if (userObjectResponses == null || userObjectResponses.isEmpty()) {
                logger.warn("No users found or response is null");
                throw new UserNotFoundException("No users found with the email: " + email);
            }
            logger.info("Returning user response from getUsersByEmail");
            return getUserResponseList(userObjectResponses);

        } catch (UserNotFoundException e) {
            logger.error("UserNotFoundException in getUsersByEmail: {}", e.getMessage(), e);
            throw e;
        } catch (Exception e) {
            logger.error("Exception in getUsersByEmail: {}", e.getMessage(), e);
            throw new RuntimeException("An unexpected error occurred: " + e.getMessage(), e);
        }
    }

    @Transactional
    public void resetPassword(ChangePasswordRequest changePasswordRequest) {
        List<UserResponse> userResponses = getUsersByUsername(keycloakTokenService.getAdminToken(), changePasswordRequest.getUsername());

        if (userResponses == null || userResponses.isEmpty()) {
            throw new RuntimeException("User not found for username: " + changePasswordRequest.getUsername());
        }
        logger.info("Entering resetPassword method with parameter: {} ", changePasswordRequest);

        String userId = userResponses.get(0).getId();
        logger.info("Admin token retrieved");
        try {

            if (!otpService.isOtpValidated(userResponses.get(0).getUsername())) {

                changePassword(changePasswordRequest, userId);

                otpService.setOtpValidatedTrue(userResponses.get(0).getUsername());
                logger.info("Password reset and OTP validated for username: {} ", userResponses.get(0).getUsername());

            } else {
                logger.warn("OTP already validated for username: {} ", userResponses.get(0).getUsername());
                throw new RuntimeException("Otp already validated");
            }
        } catch (RuntimeException e) {
            logger.error("Exception in resetPassword: {} ", e.getMessage());
            throw new RuntimeException(e);
        }

    }

    private void changePassword(ChangePasswordRequest changePasswordRequest, String userId) {
        logger.info("Entering changePassword method for userId: {}", userId);
        String adminApiEndpoint = authServerUrl + "admin/realms/master/users/" + userId + "/reset-password";

        Map<String, Object> passwordRequest = Map.of(
                "type", "password",
                "value", changePasswordRequest.getNewPassword(),
                "temporary", false
        );
        webClient.put()
                .uri(adminApiEndpoint)
                .header(HttpHeaders.AUTHORIZATION, "Bearer " + keycloakTokenService.getAdminToken())
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(passwordRequest)
                .retrieve()
                .toBodilessEntity()
                .block();
        logger.info("Password reset request sent successfully for userId: {}", userId);
    }

    public String handleForgotPassword(String email) {
        logger.info("Entering handleForgotPassword method with parameter: {}", email);
        try {
            logger.info("Admin token retrieved");
            List<UserResponse> userResponses = getUsersByEmail(keycloakTokenService.getAdminToken(), email);

            if (CollectionUtils.isEmpty(userResponses) || userResponses.get(0) == null) {
                logger.warn("User with email " + email + " not found");
                throw new UserNotFoundException("User with email " + email + " not found");
            }
            logger.info("OTP generated for username: {} ", userResponses.get(0).getUsername());
            return otpService.generateOtp(userResponses.get(0).getUsername());

        } catch (UserNotFoundException e) {
            logger.error("UserNotFoundException: {} ", e.getMessage());
            throw e;
        } catch (Exception e) {
            logger.error("UserNotFoundException: {} ", e.getMessage());
            logger.warn("Exception in handleForgotPassword: {} ", e.getMessage());
            throw new RuntimeException("An unexpected error occurred", e);
        }
    }

    public void createUser(String authorization, UserCreateRequest userCreateRequest) {
        logger.info("Entering createUser");
        String createUserUrl = authServerUrl + "admin/realms/master/users";
        try {
            Integer bankId = userCreateRequest.getAttributes().getBankId() != null ? userCreateRequest.getAttributes().getBankId() : null;
            logger.info("Bank Id is {}", bankId);

            if (bankId != null) {
                logger.info("Checking UserQuota for bankId: {}", bankId);
                UserQuotaEntity userQuota = userQuotaRepository.findByBankId(bankId);

                if (userQuota != null) {
                    logger.info("UserQuotaEntity found: {}", userQuota);
                    if (userQuota.getUserCount() < userQuota.getMaxUserCount()) {
                        userQuota.setUserCount(userQuota.getUserCount() + 1);
                        userQuotaRepository.save(userQuota);
                        logger.info("Incremented userCount. New userCount: {}", userQuota.getUserCount());
                    } else {
                        logger.info("Max user count exceeded for bankId: {}. Current userCount: {}, Max userCount: {}", bankId, userQuota.getUserCount(), userQuota.getMaxUserCount());
                        throw new MaxUserCountExceededException("Max User Creation count Exceeded. Please contact support team.");
                    }
                } else {
                    logger.info("No UserQuotaEntity found for bankId: {}. Creating a new record.", bankId);
                    UserQuotaEntity newQuota = UserQuotaEntity.builder()
                            .bankId(bankId)
                            .userCount(1)
                            .maxUserCount(5)
                            .build();

                    userQuotaRepository.save(newQuota);
                    logger.info("New UserQuotaEntity created: {}", newQuota);
                }
            } else {
                logger.info("BankId is null, cannot proceed with userCount check.");
            }

            logger.info("Sending request to create user with email: {}", userCreateRequest.getEmail());
            webClient.post()
                    .uri(createUserUrl)
                    .header(HttpHeaders.AUTHORIZATION, "Bearer " + authorization)
                    .contentType(MediaType.APPLICATION_JSON)
                    .bodyValue(userCreateRequestMapper.toCreateUserDto(userCreateRequest))
                    .retrieve()
                    .onStatus(
                            HttpStatusCode::is5xxServerError,
                            clientResponse -> clientResponse.createException().flatMap(Mono::error)
                    )
                    .onStatus(
                            status -> status.equals(HttpStatus.CONFLICT),
                            clientResponse -> clientResponse.createException()
                                    .flatMap(ex -> Mono.error(new UserAlreadyPresentException("User Already Present")))
                    )
                    .toBodilessEntity()
                    .block();

            getUsersByEmail(authorization, userCreateRequest.getEmail())
                    .stream()
                    .findFirst()
                    .ifPresentOrElse(
                            userResponse -> {
                                String userId = userResponse.getId();
                                logger.info("User found with id: {}", userId);
                                assignRolesToUser(userId, userCreateRequest.getUserRoles());
                            },
                            () -> {
                                logger.error("User not found with email: {}", userCreateRequest.getEmail());
                                throw new UserNotFoundException("User not found with email: " + userCreateRequest.getEmail());
                            }
                    );

            logger.info("User creation request sent for userCreateRequest: {} ", userCreateRequest);
        } catch (WebClientResponseException | UserAlreadyPresentException | MaxUserCountExceededException ex) {
            logger.warn("WebClientResponseException in createUser: {}", ex.getMessage());
            throw ex;
        } catch (Exception ex) {
            logger.warn("Exception in createUser: {} ", ex.getMessage());
            throw new RuntimeException("Error creating user", ex);
        }
    }

    public List<UserRoleResponse> getRealmRoles(String userType) {
        logger.info("Entering getRealmRoles method with userType " + userType);
        List<UserRoleResponse> userRoleResponses = webClient.get()
                .uri(authServerUrl + "admin/realms/master/roles")
                .header(HttpHeaders.AUTHORIZATION, "Bearer " + keycloakTokenService.getAdminToken())
                .retrieve()
                .bodyToFlux(UserRoleResponse.class)
                .collectList()
                .block();

        return userRoleResponses.stream().filter(
                        userRoleResponse -> userRoleResponse.getName().contains(userType.toLowerCase()))
                .toList();
    }

    public List<UserRoleResponse> getUserRoles(String userId, String userType) {
        logger.info("Entering getUserRoles method with parameter: userId: {}, userType: {} ", userId, userType);
        try {
            logger.info("Admin token retrieved");
            Map response = webClient.get()
                    .uri(authServerUrl + "admin/realms/master/users/{id}/role-mappings", userId)
                    .header(HttpHeaders.AUTHORIZATION, "Bearer " + keycloakTokenService.getAdminToken())
                    .retrieve()
                    .bodyToMono(Map.class)
                    .block();

            if (response == null || response.isEmpty()) {
                logger.warn("No roles found or response is null for userId: ");
                return Collections.emptyList();
            }

            List<Map<String, Object>> realmMappings = (List<Map<String, Object>>) response.get("realmMappings");

            if (realmMappings == null || realmMappings.isEmpty()) {
                logger.warn("No realm mappings found for userId: {} ", userId);
                return Collections.emptyList();
            }

            return realmMappings.stream()
                    .map(mapping -> {
                        UserRoleResponse userRole = new UserRoleResponse();
                        userRole.setId((String) mapping.get("id"));
                        userRole.setName((String) mapping.get("name"));
                        userRole.setDescription((String) mapping.get("description"));
                        logger.info("Returning user roles for userId: {},roles: {} ", userRole);
                        return userRole;
                    })
                    .filter(userRoleResponse -> userRoleResponse.getName().contains(userType.toLowerCase()))
                    .toList();

        } catch (Exception e) {
            logger.error("Exception in getUserRoles: {} ", e.getMessage());
            throw new RuntimeException("Failed to retrieve user roles", e);
        }
    }

    public void assignRolesToUser(String userId, List<UserRoleResponse> roles) {
        logger.info("Entering assignRolesToUser method with parameters: userId: {},roles: {}", userId, roles);
        try {
            logger.info("Admin token retrieved");

            clearUserRoles(userId, keycloakTokenService.getAdminToken());
            logger.info("Cleared roles for userId: {} ", userId);

            webClient.post()
                    .uri(authServerUrl + "admin/realms/{realm}/users/{id}/role-mappings/realm", realm, userId)
                    .header(HttpHeaders.AUTHORIZATION, "Bearer " + keycloakTokenService.getAdminToken())
                    .bodyValue(roles)
                    .retrieve()
                    .bodyToMono(Void.class)
                    .block();
            logger.info("Roles assigned: {}", roles);
        } catch (WebClientResponseException e) {
            logger.warn("WebClientResponseException in assignRolesToUser: {}", e.getMessage());
            throw new RuntimeException("Failed to assign roles to user", e);
        }
    }

    public void clearUserRoles(String userId, String accessToken) {
        logger.info("Entering clearUserRoles method with parameters: userId: {} , accessToken:{} ", userId, accessToken);
        try {
            webClient.delete()
                    .uri(authServerUrl + "admin/realms/{realm}/users/{id}/role-mappings/realm", realm, userId)
                    .header(HttpHeaders.AUTHORIZATION, "Bearer " + accessToken)
                    .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                    .retrieve()
                    .bodyToMono(Void.class)
                    .block();
            logger.info("User roles cleared for userId: {} ", userId);
        } catch (WebClientResponseException e) {
            logger.error("WebClientResponseException in clearUserRoles: ");
            throw new RuntimeException("Failed to clear user roles", e);
        }
    }

    public void updateUser(String userId, UserUpdateRequest userUpdateRequest) {
        logger.info("Entering updateUser method with parameters: userId: {} ,userUpdateRequest: {} ", userId, userUpdateRequest);
        String updateUrl = authServerUrl + "admin/realms/master/users/" + userId;

        Map<String, Object> keycloakUser = convertToKeycloakFormat(userUpdateRequest);
        try {
            logger.info("Admin token retrieved");
            webClient.put()
                    .uri(updateUrl)
                    .header(HttpHeaders.AUTHORIZATION, "Bearer " + keycloakTokenService.getAdminToken())
                    .contentType(MediaType.APPLICATION_JSON)
                    .bodyValue(keycloakUser)
                    .retrieve()
                    .bodyToMono(Void.class)
                    .block();
            logger.info("User update request sent for userId: {},userUpdateRequest: {}  ", userId, userUpdateRequest);
        } catch (Exception e) {
            logger.error("Exception in updateUser: {} ", e.getMessage());
            throw new RuntimeException("Failed to update user", e);
        }
    }

    public void updateUserByAdmin(UserUpdateRequest userUpdateRequest) {
        logger.info("Entering updateUserByAdmin method with parameter: {} ", userUpdateRequest);
        try {
            logger.info("Admin token retrieved");

            List<UserResponse> userResponses = getUsersById(keycloakTokenService.getAdminToken(), userUpdateRequest.getId());
            if (userResponses == null || userResponses.isEmpty()) {
                throw new ResourceNotFoundException("User not found with id: " + userUpdateRequest.getId());
            }
            logger.info("User details fetched for id: {} ", userUpdateRequest.getId());

            updateUser(userUpdateRequest.getId(), userUpdateRequest);
            logger.info("User details updated for userId: {} ", userResponses.get(0).getId());

            if (userUpdateRequest.getUserRoles() != null && !userUpdateRequest.getUserRoles().isEmpty()) {
                assignRolesToUser(userUpdateRequest.getId(), userUpdateRequest.getUserRoles());
                logger.info("User Roles updated for userId: {} ", userResponses.get(0).getId());
            }

        } catch (Exception e) {
            logger.error("Exception in updateUserByAdmin: {} ", e.getMessage());
            throw new RuntimeException(e);
        }
    }

    public UserResponse getUserById(String authorization, String id) {
        logger.info("Entering getUserById method with parameters: authorization: {},id: {}", authorization, id);
        String getUserInfoUrl = authServerUrl + "admin/realms/master/users/" + id;

        Object response = webClient.get()
                .uri(getUserInfoUrl)
                .header(HttpHeaders.AUTHORIZATION, authorization)
                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                .retrieve()
                .onStatus(
                        status -> status.is4xxClientError() || status.is5xxServerError(),
                        clientResponse -> clientResponse.createException().flatMap(Mono::error)
                )
                .bodyToMono(Object.class)
                .timeout(Duration.ofSeconds(5))
                .onErrorResume(throwable -> {
                    return Mono.empty();

                }).block();

        if (response != null) {

            Map responseMap = objectMapper.convertValue(response, Map.class);


            logger.info("Returning user response from getUserById: ");
            return UserResponseMapper.INSTANCE.mapToUserResponse(responseMap);

        } else {
            logger.warn("No response received for userId: {} ", id);
            return null;
        }
    }

    public List<UserResponse> searchUsers(String authorization, String query, Integer page, Integer size, String sort) {
        logger.info("Entering searchUsers method with parameters: authorization: {}  , query: {}  , page: {}  ,size: {}, sort: {}", authorization, query, page, size, sort);

        if (query == null || query.length() < 3) {
            logger.warn("Search string must be at least 3 characters long");
            throw new IllegalArgumentException("Search string must be at least 3 characters long");
        }

        List<UserResponse> userResponses = getAllUsers(authorization, page, size, authorization);
        logger.info("Fetched all users");
        Set<UserResponse> uniqueUsers = new HashSet<>();

        uniqueUsers.addAll(filterUsersByAttribute(userResponses, "firstName", query));
        uniqueUsers.addAll(filterUsersByAttribute(userResponses, "lastName", query));
        uniqueUsers.addAll(filterUsersByAttribute(userResponses, "username", query));

        List<UserResponse> sortedUsers = uniqueUsers.stream()
                .sorted(Comparator.comparing(user -> {
                    return switch (sort) {
                        case "firstName" -> user.getFirstName();
                        case "lastName" -> user.getLastName();
                        case "username" -> user.getUsername();
                        case "email" -> user.getEmail();
                        default -> user.getId();
                    };
                })).toList();
        logger.info("Sorted users by: {} ", sort);

        int start = page * size;
        int end = Math.min(start + size, sortedUsers.size());

        if (start > end) {
            logger.warn("Start index is greater than end index, returning empty list");
            return Collections.emptyList();
        }
        logger.info("Returning paginated user list");
        return sortedUsers.subList(start, end);
    }

    private List<UserResponse> filterUsersByAttribute(List<UserResponse> users, String attribute, String searchString) {
        logger.info("Entering filterUsersByAttribute method with parameters: attribute: {} ,searchString: {} ", attribute, searchString);
        return users.stream()
                .filter(user -> {
                    String value = switch (attribute) {
                        case "firstName" -> user.getFirstName();
                        case "lastName" -> user.getLastName();
                        case "username" -> user.getUsername();
                        default -> null;
                    };


                    return value != null && value.toLowerCase().contains(searchString.toLowerCase());
                }).toList();
    }

    public void changePasswordForUser(ChangePasswordRequest changePasswordRequest, String sub) {
        logger.info("Starting password change for user with sub: {}", sub);

        this.changePassword(changePasswordRequest, sub);

        logger.info("Password change successful for user with sub: {}", sub);
    }

    public boolean logoutUser() {
        logger.info("Entering logoutUser method");

        Jwt jwt = (Jwt) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        String sessionId = jwt.getClaimAsString("sid");
        logger.info("Got Session ID from JWT {}",sessionId);

        return deleteUserSession(sessionId);
    }

    public String handleResendOtp(String email) {
        logger.info("Entering handleResendOtp method with parameter: {}", email);
        try {
            List<UserResponse> userResponses = getUsersByEmail(keycloakTokenService.getAdminToken(), email);
            if (userResponses == null || userResponses.isEmpty()) {
                throw new UserNotFoundException("User not found for username: " + email);
            }
            String userName = userResponses.get(0).getUsername();
            logger.info("OTP generated for username: {} ", userName);
            return otpService.generateOtp(userName);
        } catch (UserNotFoundException e) {
            logger.error("UserNotFoundException: {} ", e.getMessage());
            throw e;
        } catch (Exception e) {
            logger.error("Exception: {} ", e.getMessage());
            throw new RuntimeException("An unexpected error occurred", e);
        }
    }

    public void handleChangePasswordFromForgotPassword(ChangePasswordRequest changePasswordRequest, String email) {
        logger.info("Entering handleChangePasswordFromForgotPassword method with parameter: {}", email);
        try {
            List<UserResponse> userResponses = this.getUserResponseByEmail(email);
            logger.info("Entering handleChangePasswordFromForgotPassword method with parameter: {} ", email);
            this.changePasswordForUser(changePasswordRequest, userResponses.get(0).getId());
        } catch (UserNotFoundException e) {
            throw e;
        } catch (Exception e) {
            throw new RuntimeException("An unexpected error occurred", e);
        }
    }

    public List<UserResponse> getUserResponseByEmail(String email) {
        List<UserResponse> userResponses = getUsersByEmail(keycloakTokenService.getAdminToken(), email);
        if (userResponses == null || userResponses.isEmpty()) {
            throw new UserNotFoundException("User not found for username: " + email);
        }
        return userResponses;
    }

    private Map<String, Object> convertToKeycloakFormat(UserUpdateRequest request) {
        logger.info("Converting UserUpdateRequest to Keycloak format: {}", request);
        Map<String, Object> keycloakUser = new HashMap<>();

        keycloakUser.put("id", request.getId());
        keycloakUser.put("username", request.getUsername());
        keycloakUser.put("firstName", request.getFirstName());
        keycloakUser.put("lastName", request.getLastName());
        keycloakUser.put("enabled", request.getEnabled());
        logger.info("Added keycloakUser");

        if (request.getAttributes() != null) {
            Map<String, List<String>> attributes = new HashMap<>();
            logger.info("Processing user attributes...");

            if (request.getAttributes().getBankId() != null) {
                attributes.put("bankId", Collections.singletonList(
                        request.getAttributes().getBankId().toString()));
                logger.info("Set bankId: {}", request.getAttributes().getBankId());
            }

            if (request.getAttributes().getUserType() != null) {
                attributes.put("userType", Collections.singletonList(
                        request.getAttributes().getUserType()));
                logger.info("Set userType: {}", request.getAttributes().getUserType());
            }

            keycloakUser.put("attributes", attributes);
            logger.info("Added attributes to Keycloak user: {}", attributes);
        } else {
            logger.info("No attributes found in UserUpdateRequest.");
        }

        logger.info("Finished converting UserUpdateRequest to Keycloak format: {}", keycloakUser);
        return keycloakUser;
    }

    public void logoutUserUsingToken(String accessToken) {
        logger.info("Entering logoutUserUsingToken method");

        var jwt = jwtDecoder.decode(accessToken);
        String sessionId = jwt.getClaimAsString("sid");
        logger.info("Got Session ID from JWT");

        deleteUserSession(sessionId);
    }

    private boolean deleteUserSession(String sessionId) {
        logger.info("Deleting session for user");

        String sessionsLogoutUrl = authServerUrl + "admin/realms/master/sessions/" + sessionId;
        logger.debug("sessions Logout URL: {}", sessionsLogoutUrl);

        try {
            webClient.delete()
                    .uri(sessionsLogoutUrl)
                    .headers(headers -> {
                        headers.set("Authorization", "Bearer " + keycloakTokenService.getAdminToken());
                        headers.setAccept(List.of(MediaType.APPLICATION_JSON));
                    })
                    .retrieve()
                    .onStatus(HttpStatusCode::is4xxClientError, response -> {
                        if (response.statusCode() == HttpStatus.NOT_FOUND) {
                            return Mono.error(new UserNotFoundException("User not found"));
                        }
                        return Mono.error(new RuntimeException("Client error: " + response.statusCode()));
                    })
                    .onStatus(HttpStatusCode::is5xxServerError, response -> {
                        return Mono.error(new RuntimeException("Server error: " + response.statusCode()));
                    })
                    .bodyToMono(Void.class)
                    .block();
            logger.info("Session successfully deleted for user");
            return true;
        } catch (UserNotFoundException e) {
            logger.error("User not found: {}", e.getMessage());
            throw e;
        } catch (Exception e) {
            logger.error("Exception in deleteUserSession: {}", e.getMessage());
            return false;
        }
    }

    public void resetPasswordForUser(ResetPasswordRequest resetPasswordRequest) {

        List<UserResponse> userResponses = getUsersByUsername(keycloakTokenService.getAdminToken(), resetPasswordRequest.getUsername());
        String userId = userResponses.get(0).getId();
        String adminApiEndpoint = authServerUrl + "admin/realms/master/users/" + userId + "/reset-password";

        Map<String, Object> passwordRequest = Map.of(
                "type", "password",
                "value", resetPasswordRequest.getPassword(),
                "temporary", false
        );

        webClient.put()
                .uri(adminApiEndpoint)
                .header(HttpHeaders.AUTHORIZATION, "Bearer " + keycloakTokenService.getAdminToken())
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(passwordRequest)
                .retrieve()
                .onStatus(HttpStatusCode::is4xxClientError, clientResponse -> {
                    return clientResponse.bodyToMono(String.class)
                            .flatMap(responseBody -> {
                                throw new PasswordResetException("Client error occurred: " + responseBody);
                            });
                })
                .onStatus(HttpStatusCode::is5xxServerError, clientResponse -> {
                    return clientResponse.bodyToMono(String.class)
                            .flatMap(responseBody -> {
                                throw new PasswordResetException("Server error occurred: " + responseBody);
                            });
                })
                .toBodilessEntity()
                .block();

        logger.info("Password reset successfully for : {}", userId);
    }
}
