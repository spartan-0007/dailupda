package in.iftas.sfms.auth.converter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.server.resource.authentication.JwtGrantedAuthoritiesConverter;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Component
public class KeycloakRoleConverter {
    private static final Logger logger = LoggerFactory.getLogger(KeycloakRoleConverter.class);

    public Collection<GrantedAuthority> convert(Jwt jwt) {
        logger.info("Converting JWT to GrantedAuthority");
        JwtGrantedAuthoritiesConverter defaultGrantedAuthoritiesConverter = new JwtGrantedAuthoritiesConverter();
        Collection<GrantedAuthority> authorities = defaultGrantedAuthoritiesConverter.convert(jwt);


        Map<String, Object> realmAccess = jwt.getClaim("realm_access");
        if (realmAccess != null && realmAccess.containsKey("roles")) {
            logger.debug("Extracting realm roles from JWT");
            List<String> realmRoles = (List<String>) realmAccess.get("roles");
            if (realmRoles != null) {
                Collection<GrantedAuthority> realmAuthorities = realmRoles.stream().map(role -> new SimpleGrantedAuthority("ROLE_" + role)).collect(Collectors.toList());
                authorities.addAll(realmAuthorities);
                logger.debug("Realm roles added: {}", realmRoles);
            }
        }


        Map<String, List<String>> clientRoles = jwt.getClaim("clientRoles");
        if (clientRoles != null) {
            logger.debug("Extracting client roles from JWT");
            clientRoles.values().forEach(roles -> {
                Collection<GrantedAuthority> clientAuthorities = roles.stream().map(role -> new SimpleGrantedAuthority("ROLE_" + role)).collect(Collectors.toList());
                authorities.addAll(clientAuthorities);
                logger.debug("Client roles added: {}", roles);
            });
        }
        logger.info("JWT conversion to GrantedAuthority completed");
        return authorities;
    }
}