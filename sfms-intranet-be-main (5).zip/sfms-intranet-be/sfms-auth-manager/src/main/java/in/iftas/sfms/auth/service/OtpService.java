package in.iftas.sfms.auth.service;

/*
 * Copyright (C) 2024 Iftas Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Iftas Inc. ("Confidential Information"). You shall not disclose
 * such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with Iftas Inc.
 *
 * Author: Manoj.Illa
 * Date: July 11, 2024
 */

import in.iftas.sfms.auth.entity.OtpEntity;
import in.iftas.sfms.auth.repository.OtpRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.security.SecureRandom;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Optional;

@Service
public class OtpService {


    private final OtpRepository otpRepository;

    private static final int OTP_EXPIRATION_MINUTES = 60;

    @Autowired
    public OtpService(OtpRepository otpRepository) {
        this.otpRepository = otpRepository;
    }

    public String generateOtp(String username) {
        // Step 1: Check for existing OTP
        Optional<OtpEntity> otpEntityOptional = otpRepository.findByUsername(username);

        // Define date-time formatter
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

        if (otpEntityOptional.isPresent()) {
            OtpEntity existingOtp = otpEntityOptional.get();
            LocalDateTime expirationTime = LocalDateTime.parse(existingOtp.getExpirationTime(), formatter);

            // Step 2: Check if the existing OTP is still valid
            if (LocalDateTime.now().isBefore(expirationTime) && !existingOtp.isOtpUsed()) {
                return existingOtp.getOtp();
            } else {
                // Update the existing OTP
                return updateOtp(existingOtp, username, formatter);
            }
        } else {
            // Create a new OTP
            return createNewOtp(username, formatter);
        }
    }

    private String createNewOtp(String username, DateTimeFormatter formatter) {
        // Step 1: Generate a random 6-digit OTP
        String otp = String.format("%06d", new SecureRandom().nextInt(999999));
        // Step 2: Set the expiration time
        LocalDateTime expirationTime = LocalDateTime.now().plusMinutes(OTP_EXPIRATION_MINUTES);
        String formattedExpirationTime = expirationTime.format(formatter);

        // Step 3: Save OTP to database (overwriting any existing OTP for the user)
        OtpEntity otpEntity = OtpEntity.builder()
                .username(username)
                .otp(otp)
                .isValidated(false)
                .expirationTime(formattedExpirationTime)
                .isOtpUsed(false)
                .build();
        otpRepository.save(otpEntity); // Save the new OTP
        return otp;
    }

    private String updateOtp(OtpEntity existingOtp, String username, DateTimeFormatter formatter) {
        // Step 1: Generate a random 6-digit OTP
        String otp = String.format("%06d", new SecureRandom().nextInt(999999));
        // Step 2: Set the new expiration time
        LocalDateTime expirationTime = LocalDateTime.now().plusMinutes(OTP_EXPIRATION_MINUTES);
        String formattedExpirationTime = expirationTime.format(formatter);

        // Step 3: Update existing OTP
        existingOtp.setOtp(otp);
        existingOtp.setExpirationTime(formattedExpirationTime);
        existingOtp.setValidated(false);
        existingOtp.setOtpUsed(false);
        otpRepository.save(existingOtp); // Save the updated OTP
        return otp;
    }

    // Validate OTP: Check if the OTP is correct and not expired
    public boolean validateOtp(String userName, String otp) {
        Optional<OtpEntity> otpEntityOptional = otpRepository.findByUsername(userName);
        if (otpEntityOptional.isPresent()) {
            OtpEntity otpEntity = otpEntityOptional.get();
            // Check if the OTP matches and is not expired
            LocalDateTime expirationTime = LocalDateTime.parse(otpEntity.getExpirationTime(), DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
            boolean isValid = otpEntity.getOtp().equals(otp) && LocalDateTime.now().isBefore(expirationTime);
            if (isValid) {
                otpEntity.setValidated(true);
                otpRepository.save(otpEntity);
            }
            return isValid;
        }
        return false; // OTP is invalid or expired
    }

    public boolean isOtpValidated(String username) {
        return otpRepository.findByUsername(username).map(OtpEntity::isOtpUsed).orElse(false);
    }

    // Invalidate the OTP (optional, after successful OTP validation)
    @Transactional
    public void j(String userId) {
        otpRepository.deleteByUsername(userId);
    }

    public void setOtpValidatedTrue(String username) {
        OtpEntity otpEntity = otpRepository.findByUsername(username)
                .orElseThrow(() -> new UsernameNotFoundException("Username not found: " + username));
        otpEntity.setOtpUsed(true);
        otpRepository.save(otpEntity);
    }
}
