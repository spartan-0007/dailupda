package in.iftas.sfms.auth.config;

import in.iftas.sfms.auth.converter.CustomJwtAuthenticationConverter;
import in.iftas.sfms.auth.filter.TokenFilter;
import in.iftas.sfms.auth.handler.CustomAccessDeniedHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.oauth2.core.OAuth2TokenValidatorResult;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.jwt.NimbusJwtDecoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import java.util.Arrays;
import java.util.List;

@Configuration
@EnableMethodSecurity(prePostEnabled = true)
public class SecurityConfig {
    private static final Logger logger = LoggerFactory.getLogger(SecurityConfig.class);

    private final CustomJwtAuthenticationConverter customJwtAuthenticationConverter;

    private final CustomAccessDeniedHandler accessDeniedHandler;

    private final TokenFilter tokenFilter;

    @Value("${cors.allowed-origins}")
    String[] allowedOrigins;

    @Value("${keycloak.auth-server-url}")
    private String authServerUrl;

    @Value("${keycloak.realm}")
    private String realm;

    public SecurityConfig(CustomJwtAuthenticationConverter customJwtAuthenticationConverter, CustomAccessDeniedHandler accessDeniedHandler, @Lazy TokenFilter tokenFilter) {
        this.customJwtAuthenticationConverter = customJwtAuthenticationConverter;
        this.accessDeniedHandler = accessDeniedHandler;
        this.tokenFilter = tokenFilter;
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        logger.info("Configuring SecurityFilterChain");
        http
                .csrf(AbstractHttpConfigurer::disable)
                .cors(cors -> cors.configurationSource(corsConfigurationSource()))
                .authorizeHttpRequests(requests -> requests
                        .requestMatchers(
                                "/auth/login",
                                "/auth/change-password",
                                "/auth/reset-password",
                                "/auth/forget-password",
                                "/auth/validate-otp",
                                "/hello",
                                "/auth/refresh-token",
                                "/auth/resend-otp",
                                "/auth/change-password/change"

                        ).permitAll()
                        .anyRequest().authenticated()
                ).oauth2ResourceServer(oauth2 -> oauth2
                        .jwt(jwtConfigurer -> {
                            jwtConfigurer.decoder(jwtDecoder());
                            jwtConfigurer.jwtAuthenticationConverter(customJwtAuthenticationConverter);
                        })
                ).exceptionHandling(exceptionHandling ->
                        exceptionHandling.accessDeniedHandler(accessDeniedHandler))
                .addFilterBefore(tokenFilter, UsernamePasswordAuthenticationFilter.class);
        logger.info("SecurityFilterChain configured successfully");
        return http.build();
    }

    @Bean
    public JwtDecoder jwtDecoder() {
        logger.info("Creating JwtDecoder bean");
        NimbusJwtDecoder jwtDecoder = NimbusJwtDecoder.withJwkSetUri(authServerUrl + "realms/" + realm + "/protocol/openid-connect/certs").build();

        logger.debug("Skipping default JWT validation");
        jwtDecoder.setJwtValidator(token -> OAuth2TokenValidatorResult.success());

        logger.debug("JwtDecoder bean created successfully");
        return jwtDecoder;
    }


    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        logger.info("Creating CorsConfigurationSource bean");
        CorsConfiguration configuration = new CorsConfiguration();
        logger.debug("Setting allowed origins");
        configuration.setAllowedOrigins(Arrays.asList(allowedOrigins));
        logger.debug("Setting allowed methods");
        configuration.setAllowedMethods(Arrays.asList("GET", "POST", "PUT", "DELETE", "OPTIONS"));
        logger.debug("Setting allowed headers");
        configuration.setAllowedHeaders(List.of("*"));
        logger.debug("Setting allow credentials");
        configuration.setAllowCredentials(true);


        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        logger.debug("Registering CORS configuration for all paths");
        source.registerCorsConfiguration("/**", configuration);
        logger.debug("CorsConfigurationSource bean created successfully");
        return source;
    }

}