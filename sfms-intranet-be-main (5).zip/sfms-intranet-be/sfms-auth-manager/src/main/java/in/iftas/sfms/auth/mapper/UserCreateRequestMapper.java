package in.iftas.sfms.auth.mapper;

import in.iftas.sfms.auth.dto.AttributesDto;
import in.iftas.sfms.auth.dto.CreateUserDto;
import in.iftas.sfms.auth.model.Attributes;
import in.iftas.sfms.auth.model.UserCreateRequest;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.util.List;

@Mapper(componentModel = "spring")
public interface UserCreateRequestMapper {

    UserCreateRequestMapper INSTANCE = Mappers.getMapper(UserCreateRequestMapper.class);

    @Mapping(target = "attributes", source = "attributes")
    @Mapping(target = "credentials", source = "credentials")
    CreateUserDto toCreateUserDto(UserCreateRequest userCreateRequest);

    // Map the Attributes class to AttributesDto
    default AttributesDto mapAttributes(Attributes attributes) {
        if (attributes == null) {
            return null;
        }
        
        AttributesDto attributesDto = new AttributesDto();

        // Map bankId
        if (attributes.getBankId() != null) {
            attributesDto.setBankId(List.of(String.valueOf(attributes.getBankId())));
        }

        // Map userType
        if (attributes.getUserType() != null) {
            attributesDto.setUserType(List.of(attributes.getUserType()));
        }

        return attributesDto;
    }
}