package in.iftas.sfms.auth.dto;

 /*
 * Copyright (C) 2024 Iftas Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Iftas Inc. ("Confidential Information"). You shall not disclose
 * such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with Iftas Inc.
 *
 * Author: Manoj.Illa
 * Date: July 11, 2024
 */

import in.iftas.sfms.auth.model.CredentialsRequest;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class CreateUserDto {

    private String username;

    private String email;

    private String firstName;

    private String lastName;

    private Boolean enabled;

    private List<CredentialsRequest> credentials;

    private AttributesDto attributes;

    private Boolean emailVerified;


}
