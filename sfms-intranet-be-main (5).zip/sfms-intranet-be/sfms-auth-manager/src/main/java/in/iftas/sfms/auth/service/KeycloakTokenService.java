package in.iftas.sfms.auth.service;

import in.iftas.sfms.auth.exceptions.PasswordResetRequiredException;
import in.iftas.sfms.auth.model.TokenResponse;
import jakarta.annotation.PostConstruct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.HttpStatusCode;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.time.Instant;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Service to manage Keycloak token operations with caching capabilities.
 * This service caches and reuses admin tokens to prevent multiple admin sessions.
 */
@Service
public class KeycloakTokenService {
    private static final Logger logger = LoggerFactory.getLogger(KeycloakTokenService.class);
    private static final int TOKEN_REFRESH_BUFFER_SECONDS = 30;

    private final ReentrantLock tokenLock = new ReentrantLock();
    private final WebClient webClient;

    @Value("${keycloak.auth-server-url}")
    private String authServerUrl;

    @Value("${keycloak.realm}")
    private String realm;

    @Value("${keycloak.resource}")
    private String clientId;

    @Value("${keycloak.credentials.secret}")
    private String clientSecret;

    @Value("${keycloak.username}")
    private String appUsername;

    @Value("${keycloak.password}")
    private String appPassword;

    // Cache for admin token
    private TokenResponse adminToken;
    private Instant tokenExpiry;

    /**
     * Constructor with WebClient injection
     *
     * @param webClientBuilder WebClient.Builder for HTTP operations
     */
    public KeycloakTokenService(WebClient.Builder webClientBuilder) {
        this.webClient = webClientBuilder.build();
    }

    /**
     * Initialize the admin token during service startup
     */
    @PostConstruct
    public void init() {
        getAdminToken();
    }

    /**
     * Returns the current valid admin token, refreshing if necessary.
     * This method uses a lock to ensure thread safety.
     *
     * @return Valid access token string
     */
    public String getAdminToken() {
        tokenLock.lock();
        try {
            // Check if token is null or expired
            if (adminToken == null || isTokenExpired()) {
                logger.info("Admin token is null or expired. Getting a new one.");
                refreshAdminToken(true);
            }
            // Check if token will expire soon
            else if (isTokenNearExpiry()) {
                logger.info("Admin token is near expiry. Refreshing it.");
                refreshAdminToken(false);
            }

            if (adminToken != null) {
                return adminToken.getAccessToken();
            } else {
                throw new RuntimeException("Failed to obtain admin token");
            }
        } finally {
            tokenLock.unlock();
        }
    }

    /**
     * Refreshes the admin token either using a refresh token or full authentication
     *
     * @param forceFullAuth Force full authentication even if refresh token is available
     */
    private void refreshAdminToken(boolean forceFullAuth) {
        if (!forceFullAuth && adminToken != null && adminToken.getRefreshToken() != null) {
            TokenResponse refreshedToken = refreshToken(adminToken.getRefreshToken());
            if (refreshedToken != null) {
                adminToken = refreshedToken;
                updateTokenExpiry();
                return;
            }
            logger.warn("Token refresh failed, falling back to full authentication");
        }
        adminToken = authenticateUser(appUsername, appPassword);
        if (adminToken != null) {
            updateTokenExpiry();
        } else {
            logger.error("Failed to authenticate admin user");
        }
    }

    /**
     * Update the token expiry time based on the current token
     */
    private void updateTokenExpiry() {
        if (adminToken != null && adminToken.getExpiresIn() != null) {
            tokenExpiry = Instant.now().plusSeconds(adminToken.getExpiresIn());
            logger.debug("Token will expire at: {}", tokenExpiry);
        }
    }

    /**
     * Authenticate a user and get a new token
     *
     * @param username User's username
     * @param password User's password
     * @return TokenResponse with token details
     */
    public TokenResponse authenticateUser(String username, String password) {
        String tokenEndpoint = authServerUrl + "realms/" + realm + "/protocol/openid-connect/token";
        logger.info("Authenticating user: {}", username);

        MultiValueMap<String, String> formData = new LinkedMultiValueMap<>();
        formData.add("client_id", clientId);
        formData.add("client_secret", clientSecret);
        formData.add("grant_type", "password");
        formData.add("username", username);
        formData.add("password", password);


        return webClient.post()
                .uri(tokenEndpoint)
                .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                .body(BodyInserters.fromFormData(formData))
                .retrieve()
                .onStatus(HttpStatusCode::is4xxClientError, response -> {
                    if (response.statusCode() == HttpStatus.NOT_FOUND) {
                        logger.error("User not found: {}", username);
                        return Mono.error(new RuntimeException("User not found"));
                    }

                    return response.bodyToMono(String.class)
                            .flatMap(errorBody -> {
                                logger.error("Authentication error: {}", errorBody);
                                if (errorBody.contains("invalid_grant") &&
                                        errorBody.contains("Account is not fully set up")) {
                                    return Mono.error(new PasswordResetRequiredException("Temporary password detected, reset required"));
                                }
                                logger.error("Client error, Status Code: {}", response.statusCode());
                                return Mono.error(new RuntimeException("Client error: " + response.statusCode() + " - " + errorBody));
                            });
                })
                .bodyToMono(TokenResponse.class)
                .block();

    }

    /**
     * Refresh an existing token using the refresh token
     *
     * @param refreshToken The refresh token to use
     * @return Updated TokenResponse or null if refresh failed
     */
    private TokenResponse refreshToken(String refreshToken) {
        String tokenEndpoint = authServerUrl + "realms/" + realm + "/protocol/openid-connect/token";
        logger.info("Refreshing token");

        MultiValueMap<String, String> formData = new LinkedMultiValueMap<>();
        formData.add("client_id", clientId);
        formData.add("client_secret", clientSecret);
        formData.add("grant_type", "refresh_token");
        formData.add("refresh_token", refreshToken);

        try {
            return webClient.post()
                    .uri(tokenEndpoint)
                    .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                    .body(BodyInserters.fromFormData(formData))
                    .retrieve()
                    .onStatus(HttpStatusCode::is4xxClientError, response -> {
                        logger.error("Error refreshing token, Status Code: {}", response.statusCode());
                        return Mono.error(new RuntimeException("Client error during refresh: " + response.statusCode()));
                    })
                    .bodyToMono(TokenResponse.class)
                    .block();
        } catch (Exception e) {
            logger.error("Error refreshing token: {}", e.getMessage(), e);
            return null;
        }
    }

    /**
     * Check if the current token is expired
     *
     * @return true if token is expired
     */
    private boolean isTokenExpired() {
        return tokenExpiry == null || Instant.now().isAfter(tokenExpiry);
    }

    /**
     * Check if the current token will expire soon
     *
     * @return true if token will expire within buffer period
     */
    private boolean isTokenNearExpiry() {
        return tokenExpiry == null ||
                Instant.now().plusSeconds(TOKEN_REFRESH_BUFFER_SECONDS).isAfter(tokenExpiry);
    }

    /**
     * Returns the current valid admin refresh token, refreshing if necessary.
     * This method uses a lock to ensure thread safety.
     *
     * @return Valid refresh token string
     */
    public String getAdminRefreshToken() {
        tokenLock.lock();
        try {
            // Check if token is null or expired
            if (adminToken == null || isTokenExpired()) {
                logger.info("Admin token is null or expired. Getting a new one.");
                refreshAdminToken(true);
            }
            // Check if token will expire soon
            else if (isTokenNearExpiry()) {
                logger.info("Admin token is near expiry. Refreshing it.");
                refreshAdminToken(false);
            }

            if (adminToken != null && adminToken.getRefreshToken() != null) {
                return adminToken.getRefreshToken();
            } else {
                throw new RuntimeException("Failed to obtain admin refresh token");
            }
        } finally {
            tokenLock.unlock();
        }
    }
}