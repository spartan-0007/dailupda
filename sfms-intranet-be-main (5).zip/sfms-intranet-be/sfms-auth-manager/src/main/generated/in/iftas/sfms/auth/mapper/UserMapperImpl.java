package in.iftas.sfms.auth.mapper;

import in.iftas.sfms.auth.model.UserInfoResponse;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import org.keycloak.representations.idm.UserRepresentation;
import org.springframework.stereotype.Component;

@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2024-09-30T20:16:44+0530",
    comments = "version: 1.4.2.Final, compiler: javac, environment: Java 17.0.11 (Oracle Corporation)"
)
@Component
public class UserMapperImpl implements UserMapper {

    @Override
    public UserInfoResponse toUserInfoResponse(UserRepresentation userRepresentation) {
        if ( userRepresentation == null ) {
            return null;
        }

        UserInfoResponse userInfoResponse = new UserInfoResponse();

        userInfoResponse.setEmail( userRepresentation.getEmail() );
        userInfoResponse.setEmailVerified( userRepresentation.isEmailVerified() );
        List<String> list = userRepresentation.getRealmRoles();
        if ( list != null ) {
            userInfoResponse.setRealmRoles( new ArrayList<String>( list ) );
        }
        Map<String, List<String>> map = userRepresentation.getClientRoles();
        if ( map != null ) {
            userInfoResponse.setClientRoles( new HashMap<String, List<String>>( map ) );
        }

        return userInfoResponse;
    }
}
